# The LILA Language — Reference (v7)

LILA (**L**ightweight **I**nteger **L**anguage for **A**rcade) is a strict,
compile-time-compiled DSL for deterministic 2D arcade games. A game is one
`.lila` file; the compiler (`lilac`) turns it into one `.libyte` binary that
runs identically on the native (Zig) and WebAssembly runtimes.

## Philosophy

- **Integers only.** All spatial math is Q24.8 fixed-point (`i32`, 8
  fractional bits). `1.5` compiles to the integer `384`. This buys
  bit-perfect cross-platform determinism and branch-free wrapping.
- **Names are compile-time.** Resources are `#atoms` — interned, indexed,
  and gone after compilation. The only strings in a game are `text {}`
  labels.
- **Data layout is the compiler's job.** You declare fields with widths
  (`hp: u4`); the compiler computes bit offsets, dense/cold placement, and
  emits the integration code.

## Source layout

Declarations may appear in any order (fns must be defined before referenced
by `scene`/`table` blocks at check time — order in the file is otherwise
free):

```lila
game { title: "MY GAME"  width: 512  height: 512  wrap: true
       world_w: 4096  world_h: 512          // v7: scrolling world (optional)
       capacity { entities: 2048 } }
key     { #left, #right, #up, #fire }
sound   { #shoot, #boom }
text    { #score_label: "SCORE", #over: "GAME OVER" }
scene   { #play: start_play, #over: start_over }
sprite  #ship (12) { poly [ 0,-12, 8,10, 0,5, -8,10 ] fill: 0x66CCFF grad: 0x3366AA }
music   #track { bpm: 150
                 square: [ C4 . E4 . G4 . E4 . ]
                 tri:    [ C2 . . . G1 . . . ]
                 noise:  [ . . x . . . x . ] }
sfx     #shoot { wave: square  freq: 880  sweep: -1200  decay: 10  vol: 10 }
anim    #bob   { keys: [ (0,0), (32,80), (64,0) ] }
global  { score: u16 = 0  lives: u = 3  px: fixed = 256 }
entity  Bullet { x: fixed  y: fixed  vx: fixed  vy: fixed  ttl: u8 = 60
                 cold kind: u2 = 0 }
table   behaviors { 0: drift, 1: sine, 2: chase }
fn init() { spawn Player; goto(#play); }
```

### `capacity` (v6): declare what the game needs

`game.capacity.entities` is the number of live-entity slots per type the
game is built for (default 512, range 16..65535). It is written into a v2
`.libyte` header and checked at load: an engine build whose profile has
fewer slots rejects the file with a typed error instead of silently
clamping spawns. Build the engine to match with
`scripts/build_engine.sh big` (2048 slots) / `huge` (4096) or custom
`max_ent=...` overrides — see the repo README, *Engine profiles*.

### `world_w` / `world_h` (v7): scrolling worlds

The screen (`width`/`height`) is the VIEWPORT; the world is the simulation
bounds. Declare a world larger than the screen and drive the viewport with
`camera(x, y)` — positions, wrap masks, spawns, everything stays in world
coordinates; the renderer subtracts the camera and the starfield parallaxes
against it. Defaults: world == screen (a fixed-camera game — byte-compatible
with v1/v6 files). Limits: 16..32768 per axis; power-of-two per axis when
`wrap: true`.

### `world_w` / `world_h` (v7): scrolling worlds

The screen (`width`/`height`) is the VIEWPORT; the world is the simulation
bounds. Declare a world larger than the screen and drive the viewport with
`camera(x, y)` — positions, wrap masks, spawns, everything stays in world
coordinates; the renderer subtracts the camera and the starfield parallaxes
against it. Defaults: world == screen (a fixed-camera game — byte-compatible
with v1/v6 files). Limits: 16..32768 per axis; power-of-two per axis when
`wrap: true`.

## Types

| Type | Meaning | Storage |
|---|---|---|
| `fixed` | Q24.8 fixed-point (i32, `>> 8`) | 32 bits |
| `uN` / `sN` (N = 1..16) | bit-packed integer | N bits |
| `u` / `s` | width inferred from initializer (min 4 bits) | inferred |
| `bool` | flag | 1 bit |
| `ang` | angle: u16, 4096 units = 360° | 16 bits |

Rules: `fixed ⊕ fixed → fixed`; `int ⊕ int → int`; **int widens to fixed**
implicitly in mixed arithmetic, comparisons, and assignments (like C's
`int → double`). `bool` only combines via `&& || !` and comparisons. `ang`
converts with `ang(x)`; `sin`/`cos` take `ang` and return `fixed`.

Literals: `42`, `0x3AF` (u32 ints); `1.5`, `-0.25` (fixed, max 2 decimals);
`true` / `false`. Hex colors are `0xRRGGBB` in sprite fills (alpha is baked
opaque) and `0xRRGGBBAA` in draw calls.

## #Atoms

`#name` is a compile-time resource symbol. Each domain keeps its own index
table; compiled code references positions, never strings:

| Domain | Declared in | Used by |
|---|---|---|
| key | `key {}` | `key(#x)` |
| sound | `sound {}` | `sfx(#x)` |
| text | `text {}` | `draw_text(#x, …)` |
| scene | `scene {}` | `goto(#x)` |
| sprite | `sprite #x …` | `draw(#x, …)` |
| music | `music #x …` | `music(#x)` |
| anim | `anim #x …` | `anim(#x, t)` |

Using an atom in the wrong domain, or an undeclared one, is a compile error.

## Entities & globals

```lila
entity Enemy {
    x: fixed = 0          // dense row, 32 bits
    y: fixed = 0
    hp: u = 3             // inferred u4 (fits 0..3, min 4 bits)
    behavior: u8 = 0
    rot: ang = 0
    cold seed: u8 = 0     // seldom-read: cold side storage
}
```

- Field names are globally unique across all entities (they become global
  field IDs).
- Entities with `x`/`y` **and** `vx`/`vy` fixed fields get compiler-emitted
  auto-integration: `pos = (pos + vel) & wrap_mask` once per frame (the mask
  is `(dim<<8)-1` when `game.wrap`, else unmasked). You never write the
  movement loop yourself.
- Globals work the same way but live in the flat buffer at a
  compile-time-known offset — hosts can live-patch them at runtime.
- Handles are `u32`: bits 0–19 slot index, bits 20–31 generation. Stale
  references fail their generation check and read as zeros — no crashes,
  no null checks.

## Functions

```lila
fn init() { ... }            // runs once at startup
fn update() { ... }          // runs every frame (global logic)
fn update(e: Enemy) { ... }  // runs once per live Enemy (declaration order)
fn draw() { ... }            // runs every frame AFTER entities (HUD)
fn draw(e: Enemy) { ... }    // per live entity, render pass
fn helper(x: fixed, y: fixed) { ... }   // call via `call helper(x, y);`
```

- `update`/`draw` may **overload by entity type** — one `update` per entity.
- Draw fns may only contain `draw*`, `sfx`, `music`, `stop_music`
  statements (checker-enforced).
- Scene fns (referenced in `scene {}`) are 0-arg helpers fired by `goto`.
- Table fns take exactly one entity param; dispatched via
  `call behaviors[e.behavior](e);`.
- `return;` exits early. Locals rebind via `let` (Python-style).

## Statements

```
let n = 1 + wave;                    // local
target = expr;  target += e;  -=  *= // assignment (fields, globals, locals)
if cond { } else if cond { } else { }
while cond { }
for (b: Bullet) { ... }              // iterate live entities (slot order)
spawn Enemy { x: 256, y: 32 };       // fields evaluated in written order
kill e;                              // frees the slot (gen++)
sfx(#shoot);   music(#track);   stop_music();
music_vol(8);                        // v7: master music volume 0..16 (16 = full)
shake(5);                             // screen shake, amplitude 0..255 px (literal)
camera(px + 110, py);                // v7: aim the viewport center at a world point
save(0, best);                       // v7: write SRAM slot 0..63 (raw 32-bit)
goto(#play);                         // switch scene + run its fn
draw(#ship, e.x, e.y, e.rot, 1.0, 0xFFFFFFFF);
draw_text(#score_label, 8, 8, 0x88CCFFFF);
draw_num(score, 64, 8, 0xFFFFFFFF);
call boom(ex, ey);                   // helper (0-2 args)
call behaviors[e.behavior](e);       // table dispatch
return;
```

Screen convention: rotation `0` faces **up**; `vx = sin(rot)`,
`vy = -cos(rot)`. Draw x/y/scale take fixed-point values; rot takes `ang`.

**Camera semantics (v7):** `camera(x, y)` sets the viewport CENTER in world
coords; the engine clamps it so the viewport never leaves the world (a
world == screen game pins it to offset 0 — identical to no camera at all).
`cam_x` / `cam_y` read back the viewport TOP-LEFT (world coords, fixed) —
use them for spawn-relative-to-view math (`spawn Cell { x: cam_x + 700 }`).
They are engine registers: declaring a variable of those names is an error.

## Engine services

Services the runtime provides without game code:

- **Starfield** — 60 hashed stars in 3 parallax layers (twinkling,
  additive, scrolling) rendered behind all game draws. No setup; it is
  always on.
- **Screen shake** — `shake(n)` bumps a decaying amplitude register
  (~25% decay per frame, overlapping shakes take the max). Only the world
  layer offsets — HUD text and the starfield stay fixed.
- **Camera (v7)** — `camera(x, y)` clamps the viewport inside the world;
  world-space draws are translated at emit time so every host (WebGL2,
  WebGL1, software rasterizer) renders scrolling worlds unchanged. The
  starfield layers scroll against the camera at depths 1/8, 1/4, 1/2.
- **SRAM (v7)** — 64 raw 32-bit save slots that survive re-init and
  restarts (battery-backed semantics); hosts persist them to localStorage
  (web) or files (native `--sram`).

## Expressions

```
key(#left)            // -> bool (input bitmask test)
sin(a)  cos(a)        // ang -> fixed (LUT)
atan2(dy, dx)         // v7: -> ang, screen convention (0 = up, clockwise) — CORDIC
dist(x1, y1, x2, y2)  // v7: -> fixed px, i64 internals (cannot overflow)
saved(ix)  savedf(ix) // v7: SRAM slot as int / as fixed (raw 32-bit bits)
ang(x)  fixed(x)  int(x)   // casts
rand(N)               // -> int in 0..N-1 (deterministic LCG)
anim(#bob, t)         // -> fixed (Hermite curve at frame t, wraps)
count(Enemy)          // -> int (live entity count)
cam_x  cam_y          // v7: viewport top-left (fixed, world coords)
```

Operator precedence (low → high): `||` < `&&` < comparisons <
`& | ^` < `<< >>` < `+ -` < `* / %` < unary `- !` < `.` field access.
Integer overflow wraps (two's complement) — the wrap-around world relies on
it.

## Sprites

```lila
sprite #ship (12) {                  // (12) = hit radius in px
    poly [ 0,-12, 8,10, 0,5, -8,10 ] // closed polygon, pixel coords,
                                     // origin = sprite center
        fill: 0x66CCFF               // flat RGB
        grad: 0x3366AA               // per-vertex color lerp
        add: true                    // additive blend token
        pat: noise;                  // noise dither token (or flat)
}
```

The compiler fans the polygon into triangles and quantizes each vertex to
14 bytes. Sprites render with infinite mathematical crispness at any scale —
they are geometry, not bitmaps.

## Audio

**Music** — a tracker: up to 4 voices × 16 steps. Notes `C1`..`B8`, `-`
hold, `.` silence, `x` noise hit; optional `vol: 0..15` per voice.
**SFX** — one-line synth programs: `wave` (square/tri/noise/saw), `freq`
(Hz), `sweep` (Hz/s), `decay` (in 1/60 s), `vol`. The mixer runs pure
integer adds through a 256-byte IMA-ADPCM ring (4:1 vs 16-bit PCM).

## Anim curves

```lila
anim #bob { keys: [ (0,0), (32,80), (64,0) ] }
```

Keyframes are `(frame, fixed-value)`. The compiler simplifies the polyline
(RDP) and bakes cubic Hermite control points; runtime evaluates in O(#segs)
integer math and wraps at the last key time.

## v11/v12 — Arrays, 3D math, indexed meshes

### Arrays (v11)

```lila
global { arr fixed[1800] terr  arr u8[64] vb }   // game-wide arrays
entity Orb { arr fixed[8] trail }                 // per-instance arrays
```

Fixed-capacity, zero-alloc i32-cell aggregates. Literal indices are
bounds-**proven** at compile time; dynamic indices wrap (power-of-two caps
mask in one AND, others modulo) — never a trap. `alen(name)` returns the
compile-time capacity. Cells are raw values: `fixed`/`u8`/… type the
element for checking; storage is one flat plane.

### 3D camera + projection (v11)

```lila
cam3(x, y, z, yaw, pitch);              // position the 3D camera (page-0 regs)
let s = proj3(x, y, z);                 // -> scale (focal / view depth)
draw(#sprite, projx(), projy(), 0, s * 0.1, rgba);   // billboard through cam3
if (projok()) { ... }                   // last proj3 was in front
```

Convention: +X right, +Y forward, +Z up; yaw 0 looks along +Y; positive
pitch looks up; fov 90. All Q24.8 integer math + the shared ang LUT —
bit-exact on every runtime, snapshot/rewind-safe (registers live in page 0).

### mat4 / quat builtins over arrays (v12)

A **mat4** is 16 consecutive cells of a global array, column-major
(`m[c*4 + r]`, translation in cells 12..14). A **quat** is 4 consecutive
cells `(x, y, z, w)`, right-handed: positive angle rotates counter-clockwise
viewed from the +axis. Each statement is ONE native opcode — the game
orchestrates the rig, the engine crunches the math:

```lila
quat_aa(lq, 0, 0.0, 1.0, 0.0, ang(int(sin(t) * 60)));  // axis-angle quat (axis normalized here)
qmul(qd, 0, qa, 0, qb, 0);                             // d = a*b (Hamilton, alias-safe)
m4qt(wm, 0, lq, 0, tx, ty, tz);                        // M = T(t) * R(q) in one op
m4mul(wm, 16, wm, 0, lm, 0);                           // D = A*B (world = parent * local)
skinv(rv, v * 3, wm, bone * 16, bx, by, bz);           // verts = M * (x, y, z, 1)
```

Rules: all arrays are GLOBAL (rig storage is shared); offsets are int
expressions (literal offsets are bounds-proven: `+4` for quats, `+16` for
mats); products accumulate in i64 and truncate `>> 8` once. Gameplay-side
only — rejected in draw fns.

### Indexed mesh pass (v12)

```lila
draw3di(verts, nv, idx, ni, x, y, z, yaw, rgba);   // draw-pass only
```

The GPU vertex/index-buffer vocabulary: `verts` holds 3 fixed cells per
UNIQUE vertex (animated in place by `skinv`), `idx` holds vertex indices,
3 per triangle. The engine transforms/views/projects/backface-culls/
near-clips/depth-sorts/rasterizes exactly like `draw3d` — triangles address
shared vertices, so an articulated model animates without touching its
topology. Budgets: nv <= 768, ni <= 768 (256 tris), literal counts proven
against the array capacities; out-of-range runtime indices drop the tri.

### Z-buffer profile knob (v12)

The 3D rasterizer has two variants: the v11 **painter's sort** (default,
zero extra memory) and a per-pixel **Z-buffer** (correct triangle-triangle
occlusion for interpenetrating geometry, +512KB depth buffer). Engine
config, not game state:

- `scripts/build_engine.sh zbuffer3d=1` — bake the z-buffer as the build's
  default profile (like max_ent);
- `runner game.libyte --zbuffer` / `--no-zbuffer` — per-run override.

In z mode each 3D tri ships a 12-bit view depth in the vertex token
(bit 3 = flag, bits 4..15 = depth); the rasterizer depth-tests per pixel,
additive tris test but never write (glows don't occlude), and 2D content
keeps painter's semantics. Each mode is fully deterministic.

### Frame locals limit (v12)

A fn may use 32 local slots (params + `let` bindings). Needing more is a
BUILD ERROR ("needs N local slots") — the old silent behavior (writes past
the frame dropped, reads returned 0) hung loops instead of failing loudly.

## v16 — the cinematic fidelity knobs

Five QUALITY knobs (the Unity "quality settings" model: engine-level, not
game state — they never touch the save-state hash) plus one real pipeline
fix. Default is OFF for every one of them, which makes a default build
byte-identical to v15; the golden regression proves it by replaying the
v15 movie. Turn the whole stack on with one flag:

```
runner showcase.libyte --zbuffer --preset cinematic
```

- **`--light3d`** — per-FACE directional lighting for 3D tris: each tri's
  geometric normal (cross of its model-space edges, rotated by the model
  yaw) is dotted against the world sun and answered with a per-CHANNEL
  response (a dim neutral ambient + a warm strong lobe — lit faces go
  sunset gold, away faces drop to deep dusk, ~2x spread). One cross + one
  dot per tri; per-pixel cost unchanged. Stream-content knob: GPU hosts
  render it for free.
- **`--fog3d`** — per-VERTEX distance fog: the inverse-square-onto-a-floor
  weight blends each vertex's color toward a warm horizon haze chosen to
  EXACTLY match the sky service's horizon stop, so the far ground melts
  into the sunset. Gouraud interpolation carries the ramp inside big tris.
  Replaces the multiplicative depthShade darkening when on.
- **`--sky`** — engine skybox: the checkerboard clear is replaced by a
  baked 9-stop dusk ramp (deep indigo -> violet -> rose -> amber -> gold;
  the horizon gold sits at the pitch -160 camera's horizon line, y=192).
  The starfield twinkles over it. Framebuffer-only — never in the state
  hash, so replay/rollback are identical either way.
- **`--dither`** — 4x4 Bayer ORDERED DITHER, applied AT THE QUANTIZATION
  SITES (the sky ramp, the Gouraud fog/light interpolation, and every
  alpha/additive blend), not as a post-process noise pass: the Bayer
  offset joins the pre-rounding numerator, so slow gradients that would
  band in 3-5px strata dissolve into fine texture instead. Flat fills
  stay crisp.
- **`--vignette`** — a subtle radial post pass (to ~65% at the corners):
  the cheapest cinematic framing there is. Framebuffer-only.
- **near-plane CLIPPING (always on)** — tris that straddle the near plane
  are now Sutherland-Hodgman clipped in view space (up to a 4-vert fan)
  instead of whole-dropped: geometry sweeping past the camera stays
  visible instead of popping out of existence. Games that keep geometry
  out of the near band (all v1..v15 content) emit identical streams.

Presets: `--preset cinematic` = gamma + light + fog + sky + dither +
vignette; `--preset retro` = everything off (the v14/v15 look). Build
profiles can bake the knobs (`scripts/build_engine.sh cinematic`), and
`runner` overrides per-run.

The `demo/showcase.lila` scene exercises the full stack: an orbit camera
at dusk, a sun built from 13 stacked additive discs (a radial falloff in
linear light), a pale moon, a 10-pyramid necropolis receding into the
haze, a checkered temple court, a planar-projected shadow driven by the
v12 quat/mat4/skinv rig math, and firefly billboards.

## Determinism

Given the same input script, the native runner and the wasm host produce
identical frame streams and audio samples: LCG rand seeded in the flat
buffer, Q24.8 math, LUT trig, integer audio. The 60 Hz fixed-step web loop
is display-rate independent (accumulator-based, max 3 steps/frame).

## Toolchain

```
lilac build  <in.lila> [-o out.libyte]   # compile
lilac disasm <in.libyte>                 # dump + validate the binary
lilac watch  <in.lila> [-o out.libyte]   # rebuild on save (hot reload)
```

Runtime CLIs: `runner <game.libyte> [--frames N] [--watch] [--sram FILE]`
(native — `--sram` persists save slots to a file), `wasm.zig` → `lila.wasm`
+ `web/index.html` (browser — SRAM persists to localStorage).

## v17 — the expression-language pass

The "make it feel like a real language" round. The engine's numbers, memory
map, and determinism contract are untouched; what changed is everything you
can now WRITE. Games that use none of it compile to byte-identical v1/v2/v3
binaries; games that use the new opcodes carry a **v4** header (runtimes
built before v17 reject v4 loudly with the version error, never by
misdecoding the stream).

### Function return values + calls in expressions

```lila
fn dist_to_player(x: fixed, y: fixed) { return dist(x, y, px, py); }
fn threat(d: fixed) { return d < 80.0 ? 2 : (d < 160.0 ? 1 : 0); }

fn update(e: Enemy) {
  let d = dist_to_player(e.x, e.y);        // call IN an expression
  if (threat(d) == 2) { e.state = 3; }     // ...in a condition
  e.vx = lerp(e.vx, 2.0, 0.15) * min(3.0, d);   // ...inside arithmetic
}
```

Rules:
- The return TYPE is inferred by unifying every `return expr;` (int widens
  to fixed, like every other mixed context). `return;` in a valued fn and
  falling off the end both mean `return 0;`.
- Inference is a FIXPOINT: forward and mutually-recursive helpers resolve;
  a true cycle (`fn a() { return b(); } fn b() { return a(); }`) is a
  build error, not a guess.
- Auto-run fns (`init`/`update`/`draw`/table fns) cannot return values —
  the value would be silently discarded.
- Builtins keep precedence in expressions: a user fn named `sin` is only
  reachable via `call sin(...)` statements.
- Helpers may take **3 params** (was 2).
- The calling convention is two opcodes: `RET_V` parks the value in a
  threadlocal return register (one per interpreter — including each v10
  parallel worker — so it never touches the flat memory image or the
  snapshot hash chain), `RET_GET` fetches it. Statement-form calls
  (`call helper(x);`) simply skip the fetch.

### Control flow

```lila
for (i: 0..16) { if (i == 7) { hit = i; break; } }   // numeric for (half-open)
for (i: 0..n) { if (i % 2 == 0) { continue; } odd += 1; }
let m = clamp(v, lo, hi);                            // min/max/abs/clamp/lerp
let c = hp > 6 ? 0x44FF44FF : (hp > 2 ? 0xFFAA22FF : 0xFF4444FF);  // ternary

switch (e.state) {          // lowered to an equality chain, no fallthrough
  0: { wander(e); }
  1: { chase(e); }
  2 | 3: { flee(e); }       // multi-label arms
  default: { idle(e); }
}
```

- `break`/`continue` work in every loop shape (`while`, `for (v: Type)`,
  `for (i: a..b)`); the checker proves they are inside a loop.
- Breaking out of an entity `for` pops the loop's iterator (new
  `ITER_POP` opcode) — iterator slots never leak.
- The numeric `for` evaluates its bounds ONCE; the loop variable binds
  like a `let` (Python for-loop semantics: it rebinds an existing name and
  stays in scope after the loop).
- `switch` scrutinee: int, fixed or ang. Int labels widen against a fixed
  scrutinee exactly like `==`; the scrutinee is evaluated exactly once.
- The ternary is LAZY (only the taken arm evaluates) and types like the
  two arms of a comparison.

### Two-dimensional arrays

```lila
global { arr u8[8][8] walls   arr u8[8][8] heat }
entity Orb { arr fixed[4][4] marks }

walls[2][3] = 1;                       // literal indices: bounds-proven per axis
heat[i][j] = clamp(h, 0, 200);         // dynamic indices wrap per axis
```

Row-major; `grid[i][j]` compiles to cell `i*W + j`. The wire format and
the runtime plane layout are UNCHANGED (capacity is the total cell count) —
2-D arrays are pure compiler sugar, so they ride the v3 arrays schema.

### Input edge detection

```lila
if (key_pressed(#fire)) { spawn Bullet { ... }; }   // true ONLY on the press frame
if (key_released(#jump)) { jumps += 1; }
```

No more manual `was_down` globals. The engine maintains press/release edge
registers (page 0, snapshot-safe) — but ONLY for games that actually use
`key_pressed`/`key_released` (the loader detects the opcode), so legacy
games' memory image and recorded movies stay bit-identical. First frame
after init counts every held key as pressed (prev starts at 0).

### Nearest-entity query

```lila
let d = dist_nearest(px, py, Enemy);   // engine-side scan, i64 math
if (d < 120.0) { heat_lvl = 2; }      // 0x7FFFFFFF ("infinitely far") if none live
```

One opcode scans the type's live slots and returns the minimum distance.
The entity type needs dense fixed `x`/`y` fields (the same fields the
auto-integrator uses — the checker enforces this with a pointed message).

### Look-at matrices

```lila
m4look(m, 0, ex, ey, ez, tx, ty, tz);  // M aims local +Y from eye at target, +Z up
```

One opcode instead of a hand-rolled atan2/sin/cos chain — turrets, rig
cameras, planar shadows. Degenerate cases (eye == target, straight up/down)
are exact and deterministic.

### Multi-file games (includes)

```lila
include "demo17_lib.lila"     // alone on its line, path relative to THIS file
```

The include is spliced at build time (comment/string-aware, cycle-checked,
depth-capped at 16, 128 files max). Diagnostics map through the line map
and render the REAL file and line:

```
error: demo17_lib.lila:12:9: unknown variable 'grid' (did you mean...)
   11 | fn helper() {
   12 |   grid[0][0] = 1;
   12 |         ^
```

`lilac watch` hashes EVERY included file, so editing a library rebuilds.
Asset paths (`sfx ... from:`) stay relative to the MAIN file.

### Draw-fn discipline is now transitive

Draw fns may call helpers — but only helpers the compiler PROVED
presentation-only (no spawn/kill/save/goto/fsm/rig math, transitively).
The v16 hole (a draw fn calling a helper that spawns) is closed.

### The v4 file format

Everything above that lowers to existing opcodes (ternary, switch, numeric
for, break/continue, 2-D arrays, includes) keeps the v1/v2/v3 format.
Using any of: valued-fn expression calls, `key_pressed`/`key_released`,
`dist_nearest`, or `m4look` emits **v4** — identical layout to v3, plus
the six appended opcodes `0x60 RET_V` .. `0x65 M4_LOOK`. Pre-v17 runtimes
reject v4 by version, loudly.

## v20 — the C#/C++ parity pass

The "close every gap, keep every guarantee" round. C++/C# game features
rethought the LILA way: everything stays deterministic (wyhash chain),
snapshot-safe (flat-image memcpy), fixed-60Hz, and compiles to cartridges
legacy runtimes reject loudly — never misdecode. Games that use none of it
compile byte-identical to v19 (the golden regression proves it).

### POOLS — List&lt;T&gt; / std::vector (the DSL-Prison fix)

```lila
pool Trail (512) { x: fixed  y: fixed  life: u8 = 26  kind: u2 = 0 }

push Trail { x: ex, y: ey, life: 40 };   // append (defaults fill unlisted)
for (t: Trail) { t.life -= 1;  if (t.life == 0) { remove(t); } }
let n = plen(Trail);                      // live rows
if (pfull(Trail)) { ... }                 // count == cap
```

Dynamic append-only SoA side tables INSIDE the flat image: handles are u32
(`gen<<20 | idx`) exactly like entities (stale reads = 0, stale removes =
no-ops), rows grow to the declared capacity (checked at load —
`ERR_LIMIT_POOLS`), and `remove` is a gen-checked swap-remove (the row
swapped in is documented-skipped for the rest of the frame's iteration).
Because the plane is part of `c.mem`, snapshots, rewind and the hash chain
carry pools for free — the whole "dynamic data vs save-anywhere" conflict
does not exist here.

### F32 — deterministic software float (the Math-Problem fix)

```lila
let g = 9.81f;                        // IEEE binary32 literal (suffix f)
let acc = (0.0f - xf) * 0.05f - vf * 0.02f;   // a true damped spring
vf += acc;  xf += vf;
let r = fsqrt(2.0f);                 // EXACT correctly-rounded sqrt
let a = fabs(vf);                     // |x| (sign-bit clear)

xf = f32(int_v);  xi = int(xf);      // casts: int/fixed <-> f32
let px = fixed(xf);                   // at the presentation boundary
```

Q24.8 stays the default number system. `f32` is the opt-in escape hatch for
standard physics equations: **software-emulated IEEE 754 binary32** in the VM
(correctly rounded, round-to-nearest-even, subnormals exact, canonical NaN)
— bit-exact on every platform, no libm, no FPU, no FTZ/DAZ flags. Strict
typing: f32 mixes with NOTHING implicitly (cast explicitly with `f32()`,
`fixed()`, `int()`); `%` is not defined (IEEE fmod semantics differ — use
`a - b * int(a / b)`). `int()` truncates toward zero, saturating; NaN casts
to 0. Fields, globals, pool cells and array elements can be `f32`.

### STATES — coroutines (Unity StartCoroutine / C# async-await)

```lila
fn update(e: Enemy) {
  state spawn { spawn Drone { x: 32.0 };  wait(30); }
  state hunt  { if (dist_nearest(e.x, e.y, Player) < 48.0) { -> attack; } }
  state attack{ e.fuse -= 1;  if (e.fuse == 0) { -> spawn; } }
}
```

`state` blocks are per-frame re-entering behavior segments (a state IS the
update's current segment). `wait(n)` suspends exactly n frames and resumes
after the statement; `-> name` transitions (any nesting depth). Lowered
pre-check into a `switch` over two synthesized fields (`st: u8`,
`wt: u16`): **ZERO new opcodes** — a state-machine update compiles to a v1
cartridge. Limits: 15 states × 16 phases per entity; `wait` must be a
direct child of a state block; one state system per entity (not with `fsm:`).

### MIXINS — C++ composition / Unity components

```lila
mixin movable { x: fixed  y: fixed  vx: fixed  vy: fixed }
entity Drone { use movable, hp: u8 = 3 }     // compose; overlaps are errors
```

Pure compile-time splice (mixins may compose mixins, cycles rejected).
Auto-integration still fires (x/vx magic names survive the splice).

### WHERE — LINQ filters

```lila
for (e: Enemy) where (e.hp < 3 && e.y < 100.0) { ... }
for (i: 0..n) where (i % 2 == 0) { ... }
```

### AGGREGATES — LINQ Sum/Min/Max

```lila
let total = sum(Enemy, gold);     // one engine-side scan opcode
let weakest = fmin(Enemy, hp);
let strongest = fmax(Enemy, hp);
```

Empty sets: sum 0, min 0x7FFFFFFF, max -2147483648 (the dist_nearest
sentinel convention). i64 accumulation — no overflow paths.

### SIGNALS — C# events/delegates

```lila
signal #rock_died { bump_score, flash_ring }   // handler fns, fire order
emit #rock_died;                               // fires both, in order
```

Handlers are 0-param helpers (globals carry the payload — the atom
philosophy). Compiled to a sequence of plain CALL_FN opcodes: the runtime
has NO signal machinery at all. `emit` is gameplay-side only.

### REFLECTION — System.Reflection, LILA way

```lila
game { reflection: true }
```

Ships a names trailer (entity/field/fn/pool names). Hosts resolve ids to
labels through the ABI-4 `lila_name(kind, a, b, out, cap)`. Gameplay never
reads it; the trailer rides after every section legacy loaders consume, so
old runtimes simply never reach it.

### Memory tiers — the Scale fix

```lila
game { capacity { entities: 256  mem: 16 } }   // MB, 0 = default 2MB
```

The flat-image tier the game is built for; the loader validates against the
engine build (`ERR_LIMIT_MEM`). Bigger tiers grow the pool plane (the image
tail). `scripts/build_engine.sh mem_mb=16` builds the matching profile.

### The v5 file format

Pools, any opcode past v17's `0x65`, or a declared memory tier → **v5**
header (+ `u32 mem_mb` after the v2 block; pool schema trailer on flags bit
4). Pre-v20 runtimes reject v5 loudly. Mixins, where-clauses, states,
signals and aggregates compile to EXISTING opcodes (v1-era where possible).

## v21 — the engine-fundamentals round

Round two of the C#/C++ parity pass, same doctrine: everything below is
either PURE BYTECODE (compiled to a v1-era instruction mix) or an
APPENDED OPCODE (0x7F..0x89) riding the existing v5 file contract.
Games that use none of it compile byte-identical to v20 — the golden
regression proves it. Snapshots, the wyhash chain, rewind and rollback
carry every new structure for free (it all lives in `c.mem`).

### MATHF — the System.MathF / Unity Mathf parity set

```lila
let a = floor(2.75);                  // 2.0     (Q24.8 grid op: mask)
let b = ceil(2.25);                   // 3.0     (bias + mask)
let c = round(2.5);                   // 3.0     (bias + mask, ties up)
let s = sign(v);                      // -1 / 0 / +1 in the arg's class
let t = smoothstep(0.0, 10.0, x);     // 3t^2-2t^3 hermite ease
let m = move_to(cur, target, 2.0);    // MoveTowards — step by max_delta
let r = repeat(-1.0, 4.0);            // 3.0 (true modulo, negative-safe)
let p = pingpong(5.0, 4.0);          // 3.0 (triangle fold)
let d = delta_ang(a, b);              // signed smallest rotation (-2048..2047)
let l = lerp_ang(a, b, 0.5);         // wrap-aware angular lerp
let v = damp(cur, target, 12.0);      // frame-rate-independent approach;
                                      // rate is a LITERAL per-second — the
                                      // compiler bakes 1-e^(-rate/60)
```

All lower to existing opcodes (branch diamonds over temps; opt::select
may fuse). Each argument evaluates exactly once.

### DICTS — C# Dictionary / C++ unordered_map

```lila
dict Kills (64)                        // power-of-two slots
mput(Kills, enemy_id, 7);              // insert/overwrite (key 0xFFFFFFFF reserved)
let k = mget(Kills, enemy_id);        // 0 if absent (cell convention)
mdel(Kills, enemy_id);                // backward-shift delete, no tombstones
let n = mlen(Kills);                  // live entry count
```

Engine-side open addressing (splitmix32 + linear probe) over a flat-image
plane: deterministic, snapshot-safe, no runtime allocation. Full tables
drop the insert (documented — size for the load).

### PSORT — stable sort of pool rows

```lila
psort(Trail, score);                  // ascending by field
psort(Trail, score, 1);               // descending
```

One opcode: a stable LSD radix sort of the pool's live rows (equal keys
keep push order). Rows permute in place — gens move WITH rows, so stale
handles soft-land; iteration order after the sort IS key order.

### RAY — grid raycast (Physics2D.Raycast, the LILA way)

```lila
let d = ray(grid, 8, 8, x, y, ang(1024), 200.0);  // Q24.8, 0x7FFFFFFF = miss
if (d < 200.0) { spawn Spark { x: rayx() * 32.0, y: rayy() * 32.0 }; }
```

Fixed-point Amanatides-Woo DDA over a global array as a gw x gh tile
grid (nonzero = solid). Distances are in the engine's own velocity
units: a projectile moving `vx = sin(a), vy = -cos(a)` reaches the hit
after exactly `d` frames — the ray and the movement SHARE the ang LUT,
so they can never disagree. The hit cell is stashed for rayx()/rayy().

### ASTAR — grid pathfinding (NavMesh, the LILA way)

```lila
let n = astar(grid, 8, 8, path, 1, 1, 7, 1);   // waypoint count, -1 = blocked
let i = 0;
while (i < n) { move_toward(path[i * 2], path[i * 2 + 1]); i += 1; }
```

Deterministic 8-way octile A* (binary heap, (f, node) tie-break —
bit-identical on every runtime). Writes (x, y) int cell pairs into the
path array start-adjacent first; the last waypoint IS the target.

### ENGINE SERVICES

```lila
let f = frame();                       // Time.frameCount — page-0 counter
draw_numz(score, 6, 8.0, 8.0, rgba);  // zero-padded scoreboard integer
```

### GAMEPLAY SYNTHESIS (compile-time, zero runtime machinery)

```lila
fn tick_ambient() every 32 { ... }    // InvokeRepeating — a frame()%32
                                      // guard compiled into update()

collide Bullet vs Rock (12) { hit }   // OnCollisionEnter2D — the pair scan
                                      // + circle test compiles into update()

entity Ball { x: fixed y: fixed vx: fixed vy: fixed
  body { gravity: 0.15 bounce: 0.5 drag: 0.02 } }   // Rigidbody2D-lite:
  // semi-implicit Euler + wall reflection, synthesized into update()

level #arena { grid [ "..X..", ".O..." ] legend { X: place, O: orb } }
                                      // Tilemap-lite — each legended cell
                                      // calls fn(c, r) at init
```

`optimize: true` games get the collide loops rewritten by opt::physics
(Chebyshev guards + Galois bitmasks) automatically. There is no physics
engine, no tile engine and no scheduler in the runtime — the gameplay
fundamentals ARE the game's own bytecode.

### The v21 file format

No new version: the new opcodes (0x7F PSORT .. 0x89 DRAW_NUMZ) and dict
declarations ride the v5 header; the dict schema is a trailer on flags
bit 6 (one u16 slot count per dict, bases derived after the pools).
Names-trailer kind 5 = dict names. Pre-v20 runtimes still reject v5
loudly — never by misdecode.

## v22 — the deterministic-collections round

Round three of the C#/C++ parity pass. Everything below is either PURE
SUGAR (a queue/stack decl is a hidden global array — zero schema, zero
init code), PURE BYTECODE (contact edges compile to the game's own pair
scan + one synthesized `touch` counter field), or an APPENDED OPCODE
(0x8A..0x9A) riding the v5 contract. Games that use none of it compile
byte-identical to v21 — the golden regression proves it. Every new
structure lives in `c.mem` (or page-0 stash cells written ONLY by games
that contain the opcodes — the v17 edge-register doctrine), so
snapshots, the wyhash chain, rewind and rollback carry them for free.

### NOISE — Mathf.PerlinNoise, the LILA way

```lila
let n = noise1(t);                    // 1-D lattice value noise, Q24.8 [0,1)
let c = noise2(x, y);                 // 2-D lattice value noise
```

A splitmix32-style hash lattice with Perlin's quintic fade
`u^3(6u^2-15u+10)` interpolated in chained Q24.8 multiplies (every
intermediate is a legal fixed-point value — no overflow, C2-continuous
joins). Zero tables, pure integer math, floor-correct for negative
coordinates. Layer calls for octaves; the hash constants differ per axis
so the (x,y) transpose never aliases.

### MNEXT — foreach over a Dictionary

```lila
let k = mnext(Tab, 0);                // next live key in SLOT order (-1 = done)
while (k != -1) {
  let v = mnextv();                   // that entry's value
  let cur = mnextc();                 // the cursor to feed back
  k = mnext(Tab, cur);
}
```

Deterministic slot-scan iteration: allocation-free, order-stable on every
runtime. The value + next-cursor stash rides two page-0 cells (0x1C/0x20
— free since v17). Deleting while iterating is the caller's
responsibility (backward-shift moves entries behind the cursor — the C#
enumerator throws; LILA documents it).

### QUEUES + STACKS — Queue<T> / Stack<T> / std::queue / std::stack

```lila
queue Events (4);                     // sugar: a hidden `arr u32[cap+2]`
stack Undo (8);

qpush(Events, 11);                    // FIFO append (full: drops — soft-land)
let oldest = qpop(Events);            // 0 when empty (cell convention)
let n = qlen(Events);

spush(Undo, 7);                       // LIFO append
let top = speek(Undo);                 // Stack<T>.Peek — read without popping
let last = spop(Undo);
let depth = slen(Undo);
```

The substrate is the transparent-memory doctrine: cell 0 = head counter,
cell 1 = tail counter, data = cells `2 + i % dcap` in a modulo ring.
Zero-init means empty (no init code, no schema — a queue decl lowers to
a plain `arr u32[cap+2]` in the parser). Counters are raw u32 and
`len = tail -% head` stays correct across the 2^32 wrap (2.2 years of
one push per frame at 60Hz — the frame-counter contract). ANY global
array is a legal queue/stack substrate, so `arr fixed[66] q` gives a
typed ring if the game wants one (one discipline per array, documented).

### ARRAY OPS — Fill / Copy / Shuffle / IndexOf / Count

```lila
afill(buf, 0);                        // Array.Fill / memset — whole capacity
acopy(dst, src, 4);                   // Array.Copy / memcpy — first n cells
ashuffle(deck, 52);                   // Random.Shuffle / std::shuffle
let i = afind(buf, 9);                // Array.IndexOf — first index or -1
let n = acount(buf, 9);               // count-if over the array
```

`ashuffle` is Fisher-Yates driven by the hashed LCG chain (ADDR_RAND
lives in `c.mem`: seeding = writing it, snapshot/rewind carry the
shuffle state with everything else). n is clamped to the array capacity.

### CONTACT EDGES — OnCollisionEnter2D / OnCollisionExit2D

```lila
collide Bullet vs Rock (12) enter { hit_begin }   // fires ONCE per contact
collide Bullet vs Rock (12) exit  { hit_end }     // fires ONCE per break
collide Bullet vs Rock (12) { hit_stay }          // v21: every touching frame

fn hit_begin(b: Bullet, r: Rock) { ... }  // 2 params: a + the first partner
fn hit_end(b: Bullet) { ... }             // 1 param: the departed partner is
                                          // unreachable by design (no
                                          // dangling refs, ever)
```

Enter/exit decls sharing an (A, B, radius) group MERGE into one pair
scan with a synthesized `touch_<B>_<radius>: u16` counter field on A —
the live partner count, refreshed every frame. Enter fires on the 0 -> n
edge (with the first touching partner), exit on the n -> 0 edge. The
plain stay form keeps v21's exact scan (byte-compat). The touch field
is image state — hashed, snapshot/rewind-safe for free. Still zero
collision machinery in the runtime.

### RAW u32 ARRAYS

```lila
arr u32[16] raw;                      // legal ONLY as array element type
raw[3] = 4242;                        // full 32-bit cells (the queue
                                      // substrate; SoA fields stay 1..16)
```

### The v22 file format

No new version: the new opcodes (0x8A NOISE1 .. 0x9A ACOUNT) ride the v5
header (any op > 0x7E forces it — emitted_version's existing rule).
Queues/stacks are plain arrays (the v3 array schema carries them);
contact edges are plain bytecode + a synthesized field. Pre-v20 runtimes
still reject v5 loudly — never by misdecode.
