# LILA Engine v23 — Tiered Compilation Build

This is the modified v23 source tree with the full tiered-compilation
roadmap shipped. All 8 steps are complete. 229 tests pass. Byte-identical
output verified for micro/demo17/showcase against the original v23
cartridges (SHA-256).

## What's new in v23.6 (the last two f64 gates lifted + the tier flip)

Both remaining by-design f64 limitations are gone, and the tier policy is
flipped: **f64 functions now compile NATIVELY in both AOT backends**
instead of being demoted to the interpreter tier. The differential gate
(`scripts/run_diff.sh --all`) proves 10 carts x 2 backends frame-for-frame
bit-identical — including `diff_f64`, which now exercises every f64
surface under `optimize: true` so all six code-level optimizer subsystems
run over f64 code.

### f64 pool fields (wire v7)

- Pool fields accept `f64` (two cell planes, lo + hi columns; defaults
  +0.0). The v7 pool schema derives the width from a new vt tag (5);
  vec4 pool fields stay gated (the host overlay generators have no
  multi-lane pool schema).
- New opcodes `PL_LD64` (0xBC) / `PL_ST64` (0xBD) — same operand shape as
  PL_LD/PL_ST, width-test-first drain discipline.
- `PL_PUSH` is width-aware (b counts CELLS; the listed-field count moved
  to the previously-unused c operand — legacy carts decode
  byte-identically, and any push forces v7 so old loaders reject loudly
  instead of desyncing). `PL_REM` swap-remove and the engine radix sort
  are width-aware; `psort` by an f64 field keys in IEEE-754 total order
  (8 stable byte passes over u64 keys).
- The differential harness caught this work the way it caught v23.5's:
  the first `diff_f64` run found the pool-push extra-list desync (an
  OOB write 1 MB past the image during init) and the disassembler's
  missing v7 opcode names.

### f64 returns — the baked `__ret64` table

The return register stays one 32-bit cell; an f64 result rides a hidden
global f64 array `__ret64` (one slot per f64-returning fn, fn order).
`return e` stores the (lo, hi) pair into the slot and parks a dummy 0 in
the register; every expression-context call loads the pair immediately
after `CALL_FN` (per-fn slots make recursion and `f() + g()` safe; the
table lives in the GARR plane, so snapshots/rollback/hash chains carry
it). The checker's ret-type inference unifies f64 strictly (f64 mixes
with nothing) and the old "f64 returns are not supported" gate is now an
end-to-end compile+run path.

### Baked-table f64 returns (forge/tables)

Pure f64-returning fns are TABLEABLE: `lilac forge` promotes them (the
cast builtins `f64/f32/fixed/int` are now recognized as pure value
conversions), the TBL1 pack section carries a `(ret_wide, ret_arr,
ret_slot)` trailer, the runtime bake captures each entry's (lo, hi) pair
from `__ret64` after running the REAL fn, and every probe hit rewrites
the same cells (image-identical to the real call — hash-neutral by
construction; the post-bake pass zeroes the slot so install leaves no
residue). End-to-end proof (`demo/table_f64.lila`): mine → pack →
`--tables` replay = 60/60 hash chain MATCH with 120 probe hits,
64 spot-verified re-runs, 0 mismatches. The f64-PARAM skip remains (the
(a0, a1)-keyed probe cannot key half a value).

### The tier flip — f64 fns compile natively

`is_tier1_type(VT::F64)` is now false (`thread<T>` remains the one
Tier-1 type) and `F64Lit` no longer demotes. Consequences, all proven by
the differential gate:

- Both AOT backends lower the whole f64 family (0xA0–0xB0) as calls to
  the bridge's exported softfloat helpers (`lila_f64_add` …
  `lila_f642f32`) — bit-identical to the interpreter BY CONSTRUCTION
  (the same correctly-rounded binary64 routines run in both tiers).
- The AOT path is schema-width-aware everywhere: `LD/ST_GLBL` and
  `LD/ST_ENT` on f64 fields move (lo, hi) pairs through new
  `lila_global_read64/write64`, `lila_ent_field64/set_field64` bridge
  exports, exactly like the interpreter's handlers.
- The six code-level optimizer subsystems now FIRE on f64 code
  (`demo/diff_f64.lila` runs under `optimize: true`): SoA packs the
  8-byte f64 field into the hot register window, ranges never narrows
  f64 (VT::Int-only gates), physics Chebyshev-rewrites a dist() guard in
  an fn that also does f64 math (the checker's f64 dist-arg gate remains
  the hard wall), fsm bakes a bit-plane table whose guards are f64
  compares (1-cell bools), select leaves f64 diamonds structural
  (multi-cell values cannot ride the 1-cell SEL), arena accounts the
  wider rows.
- The LLVM backend's 64-bit split/join patterns (v23.5's wide-array arms
  included) emitted self-referential SSA (`%v = trunc %v`) that clang
  rejects — all copies now use a proper three-value split/join. The C
  backend's f64 snippets were verified against the harness.

### Verification (all green, fresh runs)

- `cargo test --release`: 229 passed / 0 failed (pool-field, return,
  tier-flip, and vec4-gate tests updated/added).
- `bash scripts/build_engine.sh --test`: all engine suites, 358 checks OK.
- `bash scripts/run_diff.sh --all`: PASS 10 FAIL 0 (both backends,
  frame-for-frame bit-identity; diff_f64 now covers pool f64 fields,
  baked-table returns, native f64 math, f64 FSM guards, Chebyshev+f64,
  SoA f64 lanes, f64 psort).
- Record/replay: diff_f64 240/240, mesh_demo 120/120, demo19 120/120 —
  "VERDICT: PASS — deterministic".
- Forge loop with tables (table_f64): 60/60 hash MATCH, 120 hits,
  64 spot-checks, 0 mismatches.

See `docs/SPEC.md` for the v7 wire format and the `__ret64` return ABI.

## What's new in v23.5 (ABI v2 proof, v6 wire, f64 arrays/params)

### AOT ABI v2 — differential proof now runs GREEN on the full corpus

The shared-state ABI (compiled fns receive the LIVE interpreter state —
no per-call mirror copies) is proven frame-for-frame bit-identical
against the pure interpreter on 10 carts x 2 backends (C + LLVM):
`scripts/run_diff.sh --all` (see Verification). Bugs found and fixed by
the proof:

- `runtime/src/lila_aot_bridge.zig` — removed a leftover `std.debug.print`
  ("ook]") firing on EVERY AOT fn invocation; removed `[ldg]`/`[stg]`
  prints on every AOT array access.
- `runtime/src/timetravel.zig` — removed the `[scalars]` print firing on
  every state hash (twice per frame).
- `runtime/src/entity.zig` — removed the `[fstore]` print on every field
  store.
- `compiler/src/opt/cbackend.rs` — OP_GOTO lowered to a phantom
  `lila_goto` helper (never existed): now the machinery fallback, which
  runs the REAL scene-switch handler. OP_COLLIDE_MASK / OP_DIST_NEAR
  lowered to leaf helpers that would have read the EXTRA table at the
  fn-ENTRY pc: now the machinery fallback (iExtra needs the instruction's
  own pc). OP_SWEPT's snippet popped its 8 operands in REVERSE order:
  fixed to VM order with a new exact `lila_swept` bridge helper.
  OP_RAND_MAX read the (unused) operand and pushed WITHOUT popping
  (+1 sp per rand call): now pops the max like the VM.
- `compiler/src/opt/llvm_backend.rs` — same OP_RAND_MAX bug fixed.
- `scripts/lila_aot_diff.c` (+ new `lila_aot_diff_dbg.c` byte-diff
  debugger) — the two-pass harness now RESETS SRAM between passes: the
  battery region survives `lila_init` by design, so pass 2 inherited
  pass 1's final hi-score (demo17's `best = saved(0)` read it — a harness
  artifact that looked like an AOT divergence whose onset moved with the
  pass length).
- `scripts/run_diff.sh` — export-list snapshot instead of per-symbol
  `nm -D` re-invocation (transient short reads flagged real exports as
  phantom); `scripts/build_engine.sh` test/build lines carry the zig 0.16
  `-lc` opt-in.

### File format v6 — baked cold data (mesh import at plane scale)

`mesh name from "file.obj" scale s;` no longer generates one constant
store per cell (3 instructions/cell — hard-capped a mesh at ~150
triangles against the 8192-instruction budget). The quantized Q24.8
cells ride a v6 TRAILER (`[arr_id u16][n_cells u32][cells i32...]` per
entry, count always present) that the loader copies straight into the
GARR plane after the schema tables assign bases, before init() runs —
the exact plane bytes the old path produced, at ZERO instruction cost.
The cap is now the GARR plane itself (32768 cells = ~1819 triangles),
enforced loudly by the loader (`ERR_LIMIT_ARRAYS` covers the combined
budget). Old runtimes reject v6 by version. The v6 wire also carries the
arrays schema's new per-array ELEM-WIDTH byte (see f64 below); v1..v5
carts parse byte-identically. SPEC.md documents v5/v6. New demo:
`demo/mesh_demo.lila` (6-tri pyramid + 720-triangle UV sphere —
impossible under v23.4 — 12,960 baked cells, 23 instructions of code,
120/120 replay hash match).

### f64 arrays and fn params

- ARRAYS: `arr f64[N]` (1-D and 2-D, global and per-entity) — elements
  move TWO cells (lo, hi) in the stack's standard f64 pair order. The
  logical capacity and the mask/mod wrap semantics are unchanged; the
  plane is sized `cap * 4 * width` by the loader from the v6 width byte
  (`c.arr_wide`). VM LD/ST_GARR + LD/ST_EARR are width-aware; every path
  (live, stale handle, wrong kind) drains exactly what was pushed.
  Entity-array row zeroing on respawn is width-aware (`earrRowBytes`).
- PARAMS: `fn f(x: f64 ...)` — 2 cells pushed (lo, hi); the callee's
  frame reserves two adjacent slots (value + hidden high, the same
  convention as f64 locals). int/fixed/f32 args widen through the VM's
  deterministic I2F64 / FIX2F64 / F322F64. The call-site arg window
  widened from 8 to 16 CELLS (`b` operand of CALL_FN now counts cells);
  the checker caps a fn's total arg cells at 16 (max 7 params
  unchanged). The v19 table baker skips f64-param fns (the (a0,a1)-keyed
  probe would key half a value).
- Still gated, loudly: pool fields (32-bit lanes only) and fn RETURNS
  (the ret register is one cell) — the return error now says exactly
  that and suggests globals/entity fields/array cells.
- New proof cart `demo/diff_f64.lila`: f64 array fill/arithmetic, f64
  params with all three widenings, deterministic casts — bit-identical
  interp-vs-C-vs-LLVM on the differential harness and 240/240 replay
  hash match.

### Verification (v23.5)

```sh
cd compiler && cargo test --release        # 226 passed
bash scripts/build_engine.sh --test        # all 17 engine suites (358 checks)
bash scripts/run_diff.sh --all             # 10 carts x {C,LLVM}: bit-identical
# record/replay (determinism):
runtime/src/runner demo/mesh_demo.libyte --frames 120 --record /tmp/m.lir
runtime/src/runner demo/mesh_demo.libyte --frames 120 --replay /tmp/m.lir
runtime/src/runner demo/diff_f64.libyte --frames 240 --record /tmp/f.lir
runtime/src/runner demo/diff_f64.libyte --frames 240 --replay /tmp/f.lir
runtime/src/runner demo/demo19.libyte  --frames 120 --record /tmp/d.lir
runtime/src/runner demo/demo19.libyte  --frames 120 --replay /tmp/d.lir
```

## What's new (vs the original v23)

### New files

**Compiler** (`compiler/src/`):
- `opt/tier.rs` — tier purity fixpoint (subsystem 0). Classifies every
  fn as Tier-0 (provably pure) or Tier-1 (touches heap/threads/
  exceptions/host-callbacks). Monotone fixpoint, same shape as the
  existing draw-fn purity proof. 8 unit tests.
- `opt/cbackend.rs` — C backend (`lilac aot`). Lowers Tier-0-pure fns
  to C source. All 153 opcodes lowered. 4 unit tests.
- `opt/llvm_backend.rs` — LLVM IR backend (`lilac aot-llvm`). Lowers
  Tier-0-pure fns to textual LLVM IR. Verified with llvmlite (parse +
  verify + MCJIT compile). 2 unit tests.

**Runtime** (`runtime/src/`):
- `lila_aot_runtime.h` — C-side LilaState struct + ~100 runtime
  function declarations (the AOT C output includes this).
- `lila_aot_bridge.zig` — Zig-side `export fn` wrappers for every
  runtime helper + the runtime globals (`lila_code`, `lila_pool`, etc.).
- `lila_debug.zig` — breakpoint registry + variable inspection +
  Chrome tracing event buffer (Step 6).

**Demo** (`demo/`):
- `test_f64_tier1.lila` — proves the f64 type works end-to-end.

### Modified files

**Tier purity + gates** (Steps 0-1):
- `opt/mod.rs` — added `pub mod tier`, `pub mod cbackend`, `pub mod
  llvm_backend`; `tier_purity` field on OptReport; print line.
- `opt/ranges.rs` — gate: skip Tier-1 fns in bit-width synthesis.
- `opt/soa.rs` — gate: skip Tier-1 fns in access-density SoA repack.
- `opt/select.rs` — gate: skip Tier-1 fns in SEL superoptimization.
- `opt/physics.rs` — gate: skip Tier-1 fns in collision rewrite.
- `opt/arena.rs` — gate: skip Tier-1 fns in spawn budget + parallel
  groups proof.
- `opt/fsm.rs` — gate: skip Tier-1 fns in FSM bit-plane synthesis.
- `checker/mod.rs` — added `tier_purity_ctx: Option<TierPurityReport>`
  on Ctx.

**f64 type** (Step 2):
- `ast.rs` — `Ty::F64` variant + `Expr::F64Lit(u64)` variant.
- `lexer.rs` — `Tok::F64(u64)` token; `d` suffix lexing.
- `parser.rs` — `f64` type annotation; `Tok::F64(bits)` → `Expr::F64Lit`.
- `checker/mod.rs` — `VT::F64` in arr_elem_vt, pool fields, fn params.
- `checker/layout.rs` — `Ty::F64` → 64-bit field layout.
- `checker/expr.rs` — `Expr::F64Lit` → `VT::F64`.
- `codegen.rs` — `Expr::F64Lit` emits two-cell push (low + high 32 bits).

**SIMD vec4 types** (Step 5):
- `ast.rs` — `Ty::Vec4Fixed`, `Ty::Vec4U8`.
- `parser.rs` — `vec4fixed` / `vec4u8` type annotations.
- `checker/mod.rs` — `VT::Vec4Fixed`, `VT::Vec4U8` in all 3 sites.
- `checker/layout.rs` — vec4 field layouts (128-bit, 32-bit).
- `opt/tier.rs` — `is_tier1_type` returns false for vec4 (Tier-0).
- `codegen.rs` — 7 new opcodes `0xB1-0xB7` (vec4f add/sub/mul/dot,
  vec4u add/pack/unpack).
- `opt/cbackend.rs` — C lowering for all 7 vec4 opcodes.
- `opt/select.rs` — vec4 in the value_class None arm.

**Debugger/profiler bridge** (Step 6):
- `runtime/src/lila_debug.zig` — new file (breakpoints, inspection,
  tracing).
- `runtime/src/lila_c.zig` — 11 new C ABI exports.

**Threads** (Step 7):
- `ast.rs` — `Ty::Thread(String)`.
- `parser.rs` — `thread<FnName>` type annotation.
- `checker/mod.rs` — `VT::Thread(usize)`; resolution in param site.
- `checker/layout.rs` — `Ty::Thread` → 32-bit handle.
- `opt/tier.rs` — `is_tier1_type(VT::Thread(_))` returns true.
- `opt/select.rs` — Thread in the value_class None arm.

**Exceptions** (Step 8):
- `ast.rs` — `Stmt::TryCatch { body, catch_var, catch_body }` and
  `Stmt::Throw(Expr)`.
- `opt/tier.rs` — walk_stmts_for_tier1 detects TryCatch + Throw
  (demotes the fn to Tier-1); walk_calls recurses into try/catch bodies.
- `checker/stmt.rs` — check_stmt validates TryCatch + Throw.
- `codegen.rs` — gen_stmt emits TryCatch (body + catch_body inline) +
  Throw (evaluate expr).
- `opt/arena.rs` — collect_rw + RwAnalyzer handle TryCatch + Throw.

**C backend opcode lowering** (Part 1):
- `opt/cbackend.rs` — extended from 50 to 153 opcodes (all of them).
  Engine services (spawn/kill/draw/audio/3D/physics/FSM/pools/dicts/
  arrays/queues/stacks/noise/f32) all lowered to runtime helper calls.

**Runtime bridge** (Part 2):
- `runtime/src/lila_aot_runtime.h` — new file.
- `runtime/src/lila_aot_bridge.zig` — new file.
- `opt/cbackend.rs` — header now `#include "lila_aot_runtime.h"`; fn
  names suffixed with fn_idx for uniqueness.

**softfloat.zig binary64** (Part 3):
- `runtime/src/softfloat.zig` — extended from 604 to 872 lines. Added
  `F64` type + `f64_add/sub/mul/div/sqrt/eq/ne/lt/gt/le/ge/i2f64/
  f642i/fix2f64/f642fix` (all correctly rounded, round-to-nearest-even,
  subnormals exact, canonical NaN).
- `codegen.rs` — 17 new f64 opcodes `0xA0-0xB0`.

**LLVM IR backend** (Part 4):
- `opt/llvm_backend.rs` — new file.
- `main.rs` — `lilac aot-llvm` CLI verb + `aot_llvm_verb()` function.

## Build

```sh
cd compiler && cargo build --release
# -> target/release/lilac
```

## Usage

```sh
# Build a .libyte cartridge (unchanged from v23)
./lilac build game.lila -o game.libyte

# AOT-compile Tier-0 fns to C
./lilac aot game.lila -o out/
cc -O2 -c out/lila_aot.c -o lila_aot.o

# AOT-compile Tier-0 fns to LLVM IR
./lilac aot-llvm game.lila -o out/
clang -O2 -c out/lila_aot.ll -o lila_aot.o

# Emit pointer-overlay bridges (Unity/Unreal) — unchanged from v23
./lilac build game.lila -o game.libyte --emit-bridges bridges/
```

## Verification

- 202 tests pass (`cargo test --release`)
- Byte-identical output for micro/demo17/showcase (SHA-256 verified)
- f64 type works end-to-end (`demo/test_f64_tier1.lila` compiles)
- LLVM IR parses + verifies + MCJIT-compiles (llvmlite)

See `/home/z/my-project/download/LILA_v23_Tier_Purity_Implementation.md`
for the full implementation summary.
