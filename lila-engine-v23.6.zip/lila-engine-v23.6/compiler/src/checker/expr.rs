//! Expression typing: lvalue types, engine registers, the VT algebra
//! (int widens to fixed), and every builtin call's signature.
//! (split out of the checker monolith)

use super::*;


pub(crate) fn lvalue_type(e: &Expr, env: &[(String, VT)], f: &FnInfo, r: &CtxRefs) -> Result<(VT, String), String> {
    match e {
        Expr::Ident(name) => {
            if let Some((_, vt)) = env.iter().find(|(n, _)| n == name) {
                return Ok((*vt, format!("local '{}'", name)));
            }
            if let Some(gi) = r.global_index.get(name) {
                return Ok((r.globals[*gi].vt, format!("global '{}'", name)));
            }
            // params are in env.locals (pre-registered) — covered above
            Err(format!("unknown variable '{}'", name))
        }
        Expr::Field(base, fname) => {
            // base must be a simple variable of entity (or pool) type
            match &**base {
                Expr::Ident(v) => {
                    if let Some((_, VT::Ent(ei))) = env.iter().find(|(n, _)| n == v) {
                        let fi = r.entities[*ei].fields.iter().position(|x| &x.name == fname)
                            .ok_or_else(|| format!("entity {} has no field '{}'",
                                r.entities[*ei].name, fname))?;
                        return Ok((r.entities[*ei].fields[fi].vt, format!("{}.{}", v, fname)));
                    }
                    // v20 POOLS: `t.x` — pool handle field. Stale handles
                    // read as 0 / store as no-op at runtime; type-wise it is
                    // exactly the pool field's declared cell type.
                    if let Some((_, VT::Pool(pi))) = env.iter().find(|(n, _)| n == v) {
                        let f = r.pools[*pi].fields.iter().find(|x| &x.name == fname)
                            .ok_or_else(|| format!("pool {} has no field '{}'",
                                r.pools[*pi].name, fname))?;
                        return Ok((f.vt, format!("{}.{}", v, fname)));
                    }
                    Err(format!("'{}' is not an entity or pool variable", v))
                }
                _ => Err("field access target must be a variable".into()),
            }
        }
        Expr::Index(base, _ix) => {
            // v11 ARRAYS: `name[i] = v` / `e.arr[i] += v`. Element type from
            // the registry; literal indices bounds-proven (same as reads).
            // v17: nested indices flatten (`grid[i][j] = v`) — flatten the
            // WHOLE access node (root + every chained index).
            let full = Expr::Index(base.clone(), _ix.clone());
            let id = r.resolve_arr(&crate::checker::flatten_arr_access(&full).0, env)?;
            let (_root, indices) = crate::checker::flatten_arr_access(&full);
            let elem = r.check_index(id, &indices, env, f)?;
            Ok((elem, "array element".to_string()))
        }
        _ => Err("invalid assignment target".into()),
    }
}

// v7: engine registers readable as expressions (declaration of these names
// is rejected at check time, so a match here is unambiguous).
pub(crate) fn engine_reg_type(name: &str) -> Option<VT> {
    match name {
        "cam_x" | "cam_y" => Some(VT::Fixed),
        _ => None,
    }
}

pub fn expr_type(e: &Expr, env: &[(String, VT)], f: &FnInfo, r: &CtxRefs) -> Result<VT, String> {
    match e {
        Expr::IntLit(_) => Ok(VT::Int),
        Expr::FixLit(_) => Ok(VT::Fixed),
        Expr::F32Lit(_) => Ok(VT::F32),
        // v23 TIER-1: f64 literal — type is F64. Marks the fn as Tier-1.
        Expr::F64Lit(_) => Ok(VT::F64),
        Expr::BoolLit(_) => Ok(VT::Bool),
        Expr::Atom(a) => Err(format!("line {}: atom #{} can only be used as an argument to key/sfx/music/goto/draw/draw_text/anim",
            crate::diag::cur_pos(), r.aname(*a))),
        Expr::Ident(name) => {
            if let Some((_, vt)) = env.iter().find(|(n, _)| n == name) {
                return Ok(*vt);
            }
            if let Some(gi) = r.global_index.get(name) {
                return Ok(r.globals[*gi].vt);
            }
            if let Some(vt) = engine_reg_type(name) {
                return Ok(vt);
            }
            Err(format!("line {}: unknown variable '{}'", crate::diag::cur_pos(), name))
        }
        Expr::Field(..) => {
            // field reads type exactly like the lvalue path (checked there)
            let (vt, _) = lvalue_type(e, env, f, r)?;
            Ok(vt)
        }
        // v11 ARRAYS: element type of the resolved array; literal indices are
        // bounds-proven here (out-of-range literals never compile).
        // v17: nested indices flatten (`grid[i][j]`).
        Expr::Index(base, _ix) => {
            let full = Expr::Index(base.clone(), _ix.clone());
            let id = r.resolve_arr(&crate::checker::flatten_arr_access(&full).0, env)
                .map_err(|e| format!("line {}: {}", crate::diag::cur_pos(), e))?;
            let (_root, indices) = crate::checker::flatten_arr_access(&full);
            r.check_index(id, &indices, env, f)
        }
        Expr::Unary(UnOp::Neg, inner) => {
            let vt = expr_type(inner, env, f, r)?;
            match vt {
                // v23.1: f64 negation (sign-bit XOR on the high cell)
                VT::Fixed | VT::Int | VT::F32 | VT::F64 => Ok(vt),
                _ => Err(format!("line {}: cannot negate {:?}", crate::diag::cur_pos(), vt)),
            }
        }
        Expr::Unary(UnOp::Not, inner) => {
            let vt = expr_type(inner, env, f, r)?;
            if vt == VT::Bool { Ok(VT::Bool) }
            else { Err(format!("line {}: '!' needs bool, got {:?}", crate::diag::cur_pos(), vt)) }
        }
        // v17 TERNARY: cond must be bool; arms unify exactly like the two
        // sides of `==`/arithmetic (int widens to fixed; same-type otherwise).
        Expr::Ternary(c, a, b) => {
            let cvt = expr_type(c, env, f, r)?;
            if cvt != VT::Bool {
                return Err(format!("line {}: ternary condition must be bool, got {:?}", crate::diag::cur_pos(), cvt));
            }
            let at = expr_type(a, env, f, r)?;
            let bt = expr_type(b, env, f, r)?;
            // v23.1: the ternary lowers to a one-cell select/scratch-local
            // path — two-cell (f64) and four-cell (vec4fixed) values cannot
            // ride it. Loud gate instead of a silent miscompile.
            if matches!(at, VT::F64 | VT::Vec4Fixed) || matches!(bt, VT::F64 | VT::Vec4Fixed) {
                return Err(format!("line {}: ternary on f64/vec4fixed is not supported (multi-cell values cannot ride the select path) — use if/else", crate::diag::cur_pos()));
            }
            unify_value_types(at, bt).map_err(|e| format!("line {}: ternary arms: {}", crate::diag::cur_pos(), e))
        }
        Expr::Binary(op, a, b) => {
            let at = expr_type(a, env, f, r)?;
            let bt = expr_type(b, env, f, r)?;
            use BinOp::*;
            match op {
                Add | Sub | Mul => {
                    match (at, bt) {
                        (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) | (VT::Int, VT::Fixed) => Ok(VT::Fixed),
                        (VT::Int, VT::Int) => Ok(VT::Int),
                        (VT::Ang, VT::Int) | (VT::Int, VT::Ang) if *op == Add || *op == Sub => Ok(VT::Ang),
                        // v20: f32 arithmetic is STRICT (no implicit mixing —
                        // the exactness contract; cast explicitly)
                        (VT::F32, VT::F32) => Ok(VT::F32),
                        // v23.1: f64 arithmetic WORKS now (two-cell stack
                        // convention, correctly-rounded softfloat core) —
                        // equally strict: f64 mixes with nothing.
                        (VT::F64, VT::F64) => Ok(VT::F64),
                        _ => Err(format!("line {}: bad operand types for {:?}: {:?} and {:?} (f32/f64 mix with nothing — use f32()/f64()/fixed()/int() casts)",
                            crate::diag::cur_pos(), op, at, bt)),
                    }
                }
                Div | Mod => {
                    match (at, bt) {
                        (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) | (VT::Int, VT::Fixed) => Ok(VT::Fixed),
                        (VT::Int, VT::Int) => Ok(VT::Int),
                        (VT::F32, VT::F32) if *op == Div => Ok(VT::F32),
                        (VT::F32, VT::F32) => Err(format!("line {}: % is not defined for f32 (no fmod — use a - b * int(a / b))", crate::diag::cur_pos())),
                        (VT::F64, VT::F64) if *op == Div => Ok(VT::F64),
                        (VT::F64, VT::F64) => Err(format!("line {}: % is not defined for f64 (no fmod — use a - b * int(a / b))", crate::diag::cur_pos())),
                        _ => Err(format!("line {}: bad operand types for {:?}: {:?} and {:?}", crate::diag::cur_pos(), op, at, bt)),
                    }
                }
                And | Or | Xor | Shl | Shr => {
                    match (at, bt) {
                        (VT::Int, VT::Int) => Ok(VT::Int),
                        _ => Err(format!("line {}: bitwise ops need int operands, got {:?} and {:?}", crate::diag::cur_pos(), at, bt)),
                    }
                }
                Eq | Ne => {
                    match (at, bt) {
                        (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) | (VT::Int, VT::Fixed) => Ok(VT::Bool),
                        (VT::Int, VT::Int) | (VT::Bool, VT::Bool) | (VT::Ang, VT::Ang) | (VT::Ang, VT::Int) | (VT::Int, VT::Ang) => Ok(VT::Bool),
                        (VT::Ent(_), VT::Ent(_)) => Ok(VT::Bool),
                        // v20: pool handles compare like entity handles
                        (VT::Pool(_), VT::Pool(_)) => Ok(VT::Bool),
                        // v20: f32 compares (NaN != NaN per IEEE, encoded in
                        // the softfloat opcode)
                        (VT::F32, VT::F32) => Ok(VT::Bool),
                        // v23.1: f64 compares (IEEE 754 semantics via softfloat)
                        (VT::F64, VT::F64) => Ok(VT::Bool),
                        _ => Err(format!("line {}: cannot compare {:?} and {:?}", crate::diag::cur_pos(), at, bt)),
                    }
                }
                Lt | Gt | Le | Ge => {
                    match (at, bt) {
                        (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) | (VT::Int, VT::Fixed) => Ok(VT::Bool),
                        (VT::Int, VT::Int) => Ok(VT::Bool),
                        (VT::F32, VT::F32) => Ok(VT::Bool),
                        (VT::F64, VT::F64) => Ok(VT::Bool),
                        _ => Err(format!("line {}: cannot order-compare {:?} and {:?}", crate::diag::cur_pos(), at, bt)),
                    }
                }
                LAnd | LOr => {
                    if at == VT::Bool && bt == VT::Bool { Ok(VT::Bool) }
                    else { Err(format!("line {}: &&/|| need bool operands, got {:?} and {:?}", crate::diag::cur_pos(), at, bt)) }
                }
            }
        }
        Expr::Call(name, args) => check_builtin(name, args, env, f, r),
        // Optimizer intrinsics exist only AFTER checking (the passes inject
        // them); codegen re-types expressions containing them through this
        // recursive walker, where they carry their PROVEN result type — all
        // three intrinsics yield Int at the VM level. During real checking
        // this arm is unreachable (no Intrin exists in source).
        Expr::Intrin(..) => Ok(VT::Int),
    }
}

/// v17: unify two value types the way mixed arithmetic does — int widens
/// to fixed; identical types match; anything else is an error. Angles and
/// entities never widen (angle/int arithmetic keeps the `ang()` cast rule).
pub(crate) fn unify_value_types(a: VT, b: VT) -> Result<VT, String> {
    match (a, b) {
        (VT::Fixed, VT::Fixed) | (VT::Fixed, VT::Int) | (VT::Int, VT::Fixed) => Ok(VT::Fixed),
        (VT::Int, VT::Int) => Ok(VT::Int),
        (VT::Bool, VT::Bool) => Ok(VT::Bool),
        (VT::Ang, VT::Ang) => Ok(VT::Ang),
        (VT::F32, VT::F32) => Ok(VT::F32),
        (t, u) => Err(format!("mismatched types {:?} and {:?} (int widens to fixed; use a cast otherwise)", t, u)),
    }
}

pub(crate) fn check_builtin(name: &str, args: &[Expr], env: &[(String, VT)], f: &FnInfo, r: &CtxRefs) -> Result<VT, String> {
    match name {
        "key" => {
            if args.len() != 1 || !matches!(args[0], Expr::Atom(_)) {
                return Err(format!("line {}: key(#atom) takes exactly one atom", crate::diag::cur_pos()));
            }
            if let Expr::Atom(a) = &args[0] {
                r.domain_pos(r.keys, *a, "key")?;
            }
            Ok(VT::Bool)
        }
        "sin" | "cos" => {
            if args.len() != 1 {
                return Err(format!("line {}: {} takes one ang argument", crate::diag::cur_pos(), name));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if vt != VT::Ang {
                return Err(format!("line {}: {} needs an ang argument (use ang(x)); got {:?}", crate::diag::cur_pos(), name, vt));
            }
            Ok(VT::Fixed)
        }
        "ang" => {
            if args.len() != 1 {
                return Err(format!("line {}: ang() takes one argument", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            match vt {
                VT::Int | VT::Fixed | VT::Ang => Ok(VT::Ang),
                _ => Err(format!("line {}: ang() needs int/fixed/ang, got {:?}", crate::diag::cur_pos(), vt)),
            }
        }
        "f32" => {
            if args.len() != 1 {
                return Err(format!("line {}: f32() takes one argument", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            match vt {
                VT::Int | VT::Fixed | VT::Ang | VT::F32 => Ok(VT::F32),
                _ => Err(format!("line {}: f32() needs int/fixed/ang/f32, got {:?}", crate::diag::cur_pos(), vt)),
            }
        }
        // v23.1: f64 cast (int/fixed/f32/f64 -> binary64, exact widenings,
        // correctly-rounded int/fixed conversions)
        "f64" => {
            if args.len() != 1 {
                return Err(format!("line {}: f64() takes one argument", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            match vt {
                VT::Int | VT::Fixed | VT::F32 | VT::F64 => Ok(VT::F64),
                _ => Err(format!("line {}: f64() needs int/fixed/f32/f64, got {:?}", crate::diag::cur_pos(), vt)),
            }
        }
        // v20: the EXACT correctly-rounded square root (softfloat; never a
        // hardware rsqrt approximation). v23.1: f64 arm.
        "fsqrt" => {
            if args.len() != 1 {
                return Err(format!("line {}: fsqrt() takes one argument", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if vt == VT::F32 { Ok(VT::F32) }
            else if vt == VT::F64 { Ok(VT::F64) }
            else { Err(format!("line {}: fsqrt() needs f32 or f64, got {:?} (cast with f32()/f64())", crate::diag::cur_pos(), vt)) }
        }
        // v20: |x| — sign-bit clear (exact). v23.1: f64 arm.
        "fabs" => {
            if args.len() != 1 {
                return Err(format!("line {}: fabs() takes one argument", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if vt == VT::F32 { Ok(VT::F32) }
            else if vt == VT::F64 { Ok(VT::F64) }
            else { Err(format!("line {}: fabs() needs f32 or f64, got {:?} (cast with f32()/f64())", crate::diag::cur_pos(), vt)) }
        }
        // ---------------- v23.1: vec4 builtins ----------------
        // vec4u8: four u8 lanes packed in ONE cell — a first-class value
        // (fits locals, globals, entity fields, arrays: anything u32-shaped).
        "v4u" => {
            if args.len() != 4 {
                return Err(format!("line {}: v4u(x, y, z, w) takes four int args (0..255)", crate::diag::cur_pos()));
            }
            for a in args {
                let vt = expr_type(a, env, f, r)?;
                if vt != VT::Int && vt != VT::Fixed {
                    return Err(format!("line {}: v4u lanes must be int (0..255), got {:?}", crate::diag::cur_pos(), vt));
                }
            }
            Ok(VT::Vec4U8)
        }
        "v4ux" | "v4uy" | "v4uz" | "v4uw" => {
            if args.len() != 1 {
                return Err(format!("line {}: {}(v) takes one vec4u8 argument", crate::diag::cur_pos(), name));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if vt != VT::Vec4U8 {
                return Err(format!("line {}: {}() needs a vec4u8 (make one with v4u()), got {:?}", crate::diag::cur_pos(), name, vt));
            }
            Ok(VT::Int)
        }
        "v4uadd" => {
            if args.len() != 2 {
                return Err(format!("line {}: v4uadd(a, b) takes two vec4u8 args", crate::diag::cur_pos()));
            }
            for a in args {
                let vt = expr_type(a, env, f, r)?;
                if vt != VT::Vec4U8 {
                    return Err(format!("line {}: v4uadd needs vec4u8 operands, got {:?}", crate::diag::cur_pos(), vt));
                }
            }
            Ok(VT::Vec4U8)
        }
        // vec4fixed: four Q24.8 lanes as a stack-immediate (constructor +
        // lane-wise arithmetic + dot). Store lanes individually or consume
        // immediately — a vec4fixed cannot live in one local (it is four).
        "v4f" => {
            if args.len() != 4 {
                return Err(format!("line {}: v4f(x, y, z, w) takes four fixed args", crate::diag::cur_pos()));
            }
            for a in args {
                let vt = expr_type(a, env, f, r)?;
                if vt != VT::Fixed && vt != VT::Int {
                    return Err(format!("line {}: v4f lanes must be fixed, got {:?}", crate::diag::cur_pos(), vt));
                }
            }
            Ok(VT::Vec4Fixed)
        }
        "v4fadd" | "v4fsub" | "v4fmul" => {
            if args.len() != 2 {
                return Err(format!("line {}: {}(a, b) takes two vec4fixed args", crate::diag::cur_pos(), name));
            }
            for a in args {
                let vt = expr_type(a, env, f, r)?;
                if vt != VT::Vec4Fixed {
                    return Err(format!("line {}: {}() needs vec4fixed operands (make one with v4f()), got {:?}", crate::diag::cur_pos(), name, vt));
                }
            }
            Ok(VT::Vec4Fixed)
        }
        "v4fdot" => {
            if args.len() != 2 {
                return Err(format!("line {}: v4fdot(a, b) takes two vec4fixed args", crate::diag::cur_pos()));
            }
            for a in args {
                let vt = expr_type(a, env, f, r)?;
                if vt != VT::Vec4Fixed {
                    return Err(format!("line {}: v4fdot needs vec4fixed operands, got {:?}", crate::diag::cur_pos(), vt));
                }
            }
            Ok(VT::Fixed)
        }
        "fixed" => {
            if args.len() != 1 {
                return Err(format!("line {}: fixed() takes one argument", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            match vt {
                // v23.1: f64 -> fixed (F642FIX, RNE + saturate)
                VT::Int | VT::Fixed | VT::F32 | VT::F64 => Ok(VT::Fixed),
                _ => Err(format!("line {}: fixed() needs int/fixed/f32/f64, got {:?}", crate::diag::cur_pos(), vt)),
            }
        }
        "int" => {
            if args.len() != 1 {
                return Err(format!("line {}: int() takes one argument", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            match vt {
                // v23.1: f64 -> int (F642I, truncate toward zero, saturate)
                VT::Int | VT::Fixed | VT::F32 | VT::F64 => Ok(VT::Int),
                _ => Err(format!("line {}: int() needs int/fixed/f32, got {:?}", crate::diag::cur_pos(), vt)),
            }
        }
        "rand" => {
            if args.len() != 1 {
                return Err(format!("line {}: rand() takes one int argument", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if vt != VT::Int {
                return Err(format!("line {}: rand() needs int argument, got {:?}", crate::diag::cur_pos(), vt));
            }
            Ok(VT::Int)
        }
        "anim" => {
            if args.len() != 2 || !matches!(args[0], Expr::Atom(_)) {
                return Err(format!("line {}: anim(#atom, t) takes an atom and an int", crate::diag::cur_pos()));
            }
            if let Expr::Atom(a) = &args[0] {
                r.domain_pos(r.anim_atoms, *a, "anim")?;
            }
            let vt = expr_type(&args[1], env, f, r)?;
            if vt != VT::Int {
                return Err(format!("line {}: anim() t argument must be int, got {:?}", crate::diag::cur_pos(), vt));
            }
            Ok(VT::Fixed)
        }
        "count" => {
            if args.len() != 1 {
                return Err(format!("line {}: count(Entity) takes one entity name", crate::diag::cur_pos()));
            }
            match &args[0] {
                Expr::Ident(ent) => {
                    if r.ent_index.contains_key(ent) { Ok(VT::Int) }
                    else { Err(format!("line {}: count() needs an entity type, got '{}'", crate::diag::cur_pos(), ent)) }
                }
                _ => Err(format!("line {}: count() needs an entity type name", crate::diag::cur_pos())),
            }
        }
        // v20 AGGREGATES (LINQ Sum/Min/Max): sum(Type, field), fmin/fmax.
        // One engine-side scan opcode — no per-entity VM dispatch. Empty
        // sets: sum 0, min 0x7FFFFFFF, max -2147483648 (the dist_nearest
        // sentinel convention).
        "sum" | "fmin" | "fmax" => {
            if args.len() != 2 {
                return Err(format!("line {}: {}(Entity, field) takes an entity name and a field name", crate::diag::cur_pos(), name));
            }
            let (ent, fld) = match (&args[0], &args[1]) {
                (Expr::Ident(e), Expr::Ident(fl)) => (e, fl),
                _ => return Err(format!("line {}: {}() needs literal names: {}(Entity, field)", crate::diag::cur_pos(), name, name)),
            };
            if env.iter().any(|(n, _)| n == ent) {
                return Err(format!("line {}: '{}' is shadowed by a local — {}() needs the entity type name", crate::diag::cur_pos(), ent, name));
            }
            let ei = *r.ent_index.get(ent)
                .ok_or_else(|| format!("line {}: {}() needs an entity type, got '{}'", crate::diag::cur_pos(), name, ent))?;
            let fvt = r.entities[ei].fields.iter().find(|x| &x.name == fld)
                .ok_or_else(|| format!("line {}: entity {} has no field '{}'", crate::diag::cur_pos(), ent, fld))?.vt;
            match fvt {
                VT::Fixed | VT::Int => Ok(fvt),
                _ => Err(format!("line {}: {}() needs a numeric field, '{}' is {:?}", crate::diag::cur_pos(), name, fld, fvt)),
            }
        }
        // v20 POOLS: plen(P) -> int (live rows), pfull(P) -> bool (count == cap).
        // The name must be an unshadowed POOL — a local hiding it is an error.
        "plen" | "pfull" => {
            if args.len() != 1 {
                return Err(format!("line {}: {}(Pool) takes one pool name", crate::diag::cur_pos(), name));
            }
            match &args[0] {
                Expr::Ident(pn) => {
                    if env.iter().any(|(n, _)| n == pn) {
                        return Err(format!("line {}: '{}' is shadowed by a local here — {}() needs the pool name",
                            crate::diag::cur_pos(), pn, name));
                    }
                    if r.pool_index.contains_key(pn) {
                        Ok(if name == "plen" { VT::Int } else { VT::Bool })
                    } else {
                        Err(format!("line {}: {}() needs a pool type, got '{}'", crate::diag::cur_pos(), name, pn))
                    }
                }
                _ => Err(format!("line {}: {}() needs a pool type name", crate::diag::cur_pos(), name)),
            }
        }
        // v21 DICTS: mget(D, k) -> the stored value (0 if absent — the cell
        // convention), mlen(D) -> live entry count (int).
        "mget" => {
            if args.len() != 2 || !matches!(&args[0], Expr::Ident(_)) {
                return Err(format!("line {}: mget(D, key) takes a dict name and a key", crate::diag::cur_pos()));
            }
            if let Expr::Ident(d) = &args[0] {
                if env.iter().any(|(n, _)| n == d) {
                    return Err(format!("line {}: '{}' is shadowed by a local — mget() needs the dict name", crate::diag::cur_pos(), d));
                }
                if !r.dict_index.contains_key(d) {
                    return Err(format!("line {}: mget of unknown dict '{}' (dict {} (N))", crate::diag::cur_pos(), d, d));
                }
            }
            let kvt = expr_type(&args[1], env, f, r)?;
            if !matches!(kvt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: mget key must be int or fixed, got {:?}", crate::diag::cur_pos(), kvt));
            }
            Ok(VT::Int) // raw cell: the game chooses the read type (like saved())
        }
        "mlen" => {
            if args.len() != 1 || !matches!(&args[0], Expr::Ident(_)) {
                return Err(format!("line {}: mlen(D) takes one dict name", crate::diag::cur_pos()));
            }
            if let Expr::Ident(d) = &args[0] {
                if env.iter().any(|(n, _)| n == d) {
                    return Err(format!("line {}: '{}' is shadowed by a local — mlen() needs the dict name", crate::diag::cur_pos(), d));
                }
                if !r.dict_index.contains_key(d) {
                    return Err(format!("line {}: mlen of unknown dict '{}'", crate::diag::cur_pos(), d));
                }
            }
            Ok(VT::Int)
        }
        // v22 NOISE (C# Mathf.PerlinNoise / UE noise nodes): noise1(t) and
        // noise2(x, y) -> Q24.8 in [0, 1.0). A splitmix32 hash lattice with
        // quintic-smooth interpolation — deterministic, zero tables, the
        // same fixed-point math as everything else.
        "noise1" => {
            if args.len() != 1 {
                return Err(format!("line {}: noise1(t) takes one arg (fixed or int)", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if !matches!(vt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: noise1 arg must be fixed or int, got {:?}", crate::diag::cur_pos(), vt));
            }
            Ok(VT::Fixed)
        }
        "noise2" => {
            if args.len() != 2 {
                return Err(format!("line {}: noise2(x, y) takes two args (fixed or int)", crate::diag::cur_pos()));
            }
            for a in args.iter() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: noise2 args must be fixed or int, got {:?}", crate::diag::cur_pos(), vt));
                }
            }
            Ok(VT::Fixed)
        }
        // v22 DICT ITERATION (C# foreach over Dictionary / C++ iterator):
        // mnext(D, cursor) -> the next live key in SLOT order (int; -1 when
        // exhausted). mnextv() -> that entry's value; mnextc() -> the cursor
        // to feed back. The canonical loop:
        //   let k = mnext(D, 0);
        //   while (k != -1) { ... mnextv() ...; k = mnext(D, mnextc()); }
        // Do NOT mdel inside the loop (backward-shift moves entries behind
        // the cursor) — the C# enumerator throws; LILA documents it.
        "mnext" => {
            if args.len() != 2 || !matches!(&args[0], Expr::Ident(_)) {
                return Err(format!("line {}: mnext(D, cursor) takes a dict name and a cursor (start at 0)", crate::diag::cur_pos()));
            }
            if let Expr::Ident(d) = &args[0] {
                if env.iter().any(|(n, _)| n == d) {
                    return Err(format!("line {}: '{}' is shadowed by a local — mnext() needs the dict name", crate::diag::cur_pos(), d));
                }
                if !r.dict_index.contains_key(d) {
                    return Err(format!("line {}: mnext of unknown dict '{}'", crate::diag::cur_pos(), d));
                }
            }
            let cvt = expr_type(&args[1], env, f, r)?;
            if !matches!(cvt, VT::Int) {
                return Err(format!("line {}: mnext cursor must be int (from mnextc() or 0), got {:?}", crate::diag::cur_pos(), cvt));
            }
            Ok(VT::Int)
        }
        "mnextv" | "mnextc" => {
            if !args.is_empty() {
                return Err(format!("line {}: {}() takes no args (reads the last mnext result)", crate::diag::cur_pos(), name));
            }
            Ok(VT::Int)
        }
        // v22 QUEUES/STACKS (C# Queue<T>.Dequeue / Stack<T>.Pop): qpop(Q) ->
        // the oldest entry (0 when empty, the cell convention); spop(S) ->
        // the newest; qlen/slen -> entry counts; speek(S) -> the top
        // without popping. Q/S are the queue/stack decls' hidden arrays.
        "qpop" | "qlen" | "spop" | "slen" | "speek" => {
            if args.len() != 1 || !matches!(&args[0], Expr::Ident(_)) {
                return Err(format!("line {}: {}(Q) takes one queue/stack name", crate::diag::cur_pos(), name));
            }
            if let Expr::Ident(a) = &args[0] {
                if env.iter().any(|(n, _)| n == a) {
                    return Err(format!("line {}: '{}' is shadowed by a local — {}() needs the queue/stack name", crate::diag::cur_pos(), a, name));
                }
                if !r.arr_index.contains_key(&(GLOBAL_ENT, a.clone())) {
                    return Err(format!("line {}: {} of unknown queue/stack '{}' (declare `{} (N)` at top level)", crate::diag::cur_pos(), name, a,
                        if name.starts_with('q') { "queue" } else { "stack" }));
                }
            }
            Ok(VT::Int)
        }
        // v22 ARRAY QUERIES: afind(A, val) -> first index or -1
        // (Array.IndexOf); acount(A, val) -> match count over the array.
        "afind" | "acount" => {
            if args.len() != 2 || !matches!(&args[0], Expr::Ident(_)) {
                return Err(format!("line {}: {}(arr, val) takes a global array name and a value", crate::diag::cur_pos(), name));
            }
            if let Expr::Ident(a) = &args[0] {
                if !r.arr_index.contains_key(&(GLOBAL_ENT, a.clone())) {
                    return Err(format!("line {}: {} of unknown global array '{}'", crate::diag::cur_pos(), name, a));
                }
            }
            let vvt = expr_type(&args[1], env, f, r)?;
            if !matches!(vvt, VT::Fixed | VT::Int | VT::Bool | VT::Ang | VT::F32) {
                return Err(format!("line {}: {} value must be a scalar, got {:?}", crate::diag::cur_pos(), name, vvt));
            }
            Ok(VT::Int)
        }
        // v21 ENGINE: frame() -> the 60Hz frame counter (int, wraps u32 at
        // ~2.27 years of continuous play). Time.frameCount, LILA way: a page-0
        // register read — snapshot/rewind-safe for free.
        "frame" => {
            if !args.is_empty() {
                return Err(format!("line {}: frame() takes no args (the 60Hz counter, page-0 register)", crate::diag::cur_pos()));
            }
            Ok(VT::Int)
        }
        // v21 QUERIES: ray(grid, gw, gh, x, y, ang, maxd) -> Q24.8 distance
        // to the first solid cell (nonzero) along the ray; 0x7FFFFFFF if none
        // within maxd. rayx()/rayy() read back the hit CELL coords (int).
        // Deterministic fixed-point Amanatides-Woo DDA, engine-side.
        "ray" => {
            if args.len() != 7 {
                return Err(format!("line {}: ray(grid, gw, gh, x, y, ang, maxd) takes seven args", crate::diag::cur_pos()));
            }
            match &args[0] {
                Expr::Ident(g) => {
                    if r.arr_index.get(&(GLOBAL_ENT, g.clone())).map_or(true, |&i| r.arrays[i].ent != GLOBAL_ENT) {
                        return Err(format!("line {}: ray grid '{}' is not a global array (grids are shared)", crate::diag::cur_pos(), g));
                    }
                }
                _ => return Err(format!("line {}: ray grid must be an array name", crate::diag::cur_pos())),
            }
            for (i, a) in args.iter().enumerate().take(3).skip(1) {
                let vt = expr_type(a, env, f, r)?;
                if vt != VT::Int {
                    return Err(format!("line {}: ray arg {} (gw/gh) must be int, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            for (i, a) in args.iter().enumerate().take(5).skip(3) {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: ray arg {} (x/y) must be fixed or int, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            match expr_type(&args[5], env, f, r)? {
                VT::Ang => {}
                VT::Int => {
                    if !matches!(&args[5], Expr::IntLit(_)) {
                        return Err(format!("line {}: ray ang must be ang-typed (or an int literal); use ang()", crate::diag::cur_pos()));
                    }
                }
                vt => return Err(format!("line {}: ray ang must be ang, got {:?}", crate::diag::cur_pos(), vt)),
            }
            let vt = expr_type(&args[6], env, f, r)?;
            if !matches!(vt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: ray maxd must be fixed or int, got {:?}", crate::diag::cur_pos(), vt));
            }
            Ok(VT::Fixed)
        }
        "rayx" | "rayy" => {
            if !args.is_empty() {
                return Err(format!("line {}: {}() takes no args (reads the last ray stash)", crate::diag::cur_pos(), name));
            }
            Ok(VT::Int)
        }
        // v21 NAVIGATION: astar(grid, gw, gh, path, sx, sy, tx, ty) -> int
        // waypoint count written into the path array ((x, y) int cell pairs,
        // start-adjacent first); -1 = unreachable, -2 = grid too large. The
        // engine-side planner is a deterministic binary-heap A* (tie-breaks
        // by node index — bit-exact on every runtime).
        "astar" => {
            if args.len() != 8 {
                return Err(format!("line {}: astar(grid, gw, gh, path, sx, sy, tx, ty) takes eight args", crate::diag::cur_pos()));
            }
            for (ai, what) in [(0usize, "grid"), (3usize, "path")] {
                match &args[ai] {
                    Expr::Ident(g) => {
                        if r.arr_index.get(&(GLOBAL_ENT, g.clone())).map_or(true, |&i| r.arrays[i].ent != GLOBAL_ENT) {
                            return Err(format!("line {}: astar {} '{}' is not a global array", crate::diag::cur_pos(), what, g));
                        }
                    }
                    _ => return Err(format!("line {}: astar {} must be an array name", crate::diag::cur_pos(), what)),
                }
            }
            for (i, a) in args.iter().enumerate() {
                if i == 0 || i == 3 { continue; }
                let vt = expr_type(a, env, f, r)?;
                if vt != VT::Int {
                    return Err(format!("line {}: astar arg {} must be int, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            Ok(VT::Int)
        }
        // v21 MATHF: the System.MathF / Unity Mathf parity set — all lower
        // to existing opcodes (pure arithmetic; opt::select may still fuse).
        // floor/ceil/round: Q24.8 grid ops (mask / bias+mask). sign: -1/0/+1.
        "floor" | "ceil" | "round" => {
            if args.len() != 1 {
                return Err(format!("line {}: {}(x) takes one arg", crate::diag::cur_pos(), name));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if vt != VT::Fixed {
                return Err(format!("line {}: {} needs a fixed arg (ints are already {}ed), got {:?}", crate::diag::cur_pos(), name, name, vt));
            }
            Ok(VT::Fixed)
        }
        "sign" => {
            if args.len() != 1 {
                return Err(format!("line {}: sign(x) takes one arg", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if !matches!(vt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: sign needs int or fixed, got {:?}", crate::diag::cur_pos(), vt));
            }
            Ok(vt)
        }
        // smoothstep(e0, e1, x) -> fixed: the 3t^2-2t^3 hermite ease.
        "smoothstep" => {
            if args.len() != 3 {
                return Err(format!("line {}: smoothstep(e0, e1, x) takes three args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: smoothstep arg {} must be int or fixed, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            Ok(VT::Fixed)
        }
        // move_to(cur, target, max_delta) -> fixed: Unity MoveTowards — step
        // cur toward target by at most max_delta. Works on angles too via
        // lerp_ang + delta_ang; this is the linear form.
        "move_to" => {
            if args.len() != 3 {
                return Err(format!("line {}: move_to(cur, target, max_delta) takes three args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: move_to arg {} must be int or fixed, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            Ok(VT::Fixed)
        }
        // repeat(t, len) / pingpong(t, len): Unity Mathf.Repeat / PingPong —
        // t - floor(t/len)*len (true modulo, negative-safe) and the triangle
        // fold len - |repeat(t, 2len) - len|.
        "repeat" | "pingpong" => {
            if args.len() != 2 {
                return Err(format!("line {}: {}(t, len) takes two args", crate::diag::cur_pos(), name));
            }
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: {} arg {} must be int or fixed, got {:?}", crate::diag::cur_pos(), name, i + 1, vt));
                }
            }
            Ok(VT::Fixed)
        }
        // delta_ang(a, b) -> ang: Unity DeltaAngle — the SIGNED smallest
        // rotation from a to b (-2048..2047 ang units), wrap-correct.
        "delta_ang" => {
            if args.len() != 2 {
                return Err(format!("line {}: delta_ang(a, b) takes two ang args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate() {
                match expr_type(a, env, f, r)? {
                    VT::Ang => {}
                    VT::Int => {
                        if !matches!(a, Expr::IntLit(_)) {
                            return Err(format!("line {}: delta_ang arg {} must be ang-typed (or an int literal); use ang()", crate::diag::cur_pos(), i + 1));
                        }
                    }
                    vt => return Err(format!("line {}: delta_ang arg {} must be ang, got {:?}", crate::diag::cur_pos(), i + 1, vt)),
                }
            }
            Ok(VT::Ang)
        }
        // lerp_ang(a, b, t) -> ang: wrap-aware angular lerp (turret aim).
        "lerp_ang" => {
            if args.len() != 3 {
                return Err(format!("line {}: lerp_ang(a, b, t) takes three args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate().take(2) {
                match expr_type(a, env, f, r)? {
                    VT::Ang => {}
                    VT::Int => {
                        if !matches!(a, Expr::IntLit(_)) {
                            return Err(format!("line {}: lerp_ang arg {} must be ang-typed (or an int literal); use ang()", crate::diag::cur_pos(), i + 1));
                        }
                    }
                    vt => return Err(format!("line {}: lerp_ang arg {} must be ang, got {:?}", crate::diag::cur_pos(), i + 1, vt)),
                }
            }
            let vt = expr_type(&args[2], env, f, r)?;
            if !matches!(vt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: lerp_ang t must be int or fixed (0.0..1.0), got {:?}", crate::diag::cur_pos(), vt));
            }
            Ok(VT::Ang)
        }
        // damp(cur, target, rate) -> fixed: Unity SmoothDamp-lite — the
        // frame-rate-independent exponential approach. rate is a LITERAL
        // (per-second); the compiler bakes k = 1 - e^(-rate/60) into the
        // constant pool (the decay kernel is build-time math, never runtime).
        "damp" => {
            if args.len() != 3 {
                return Err(format!("line {}: damp(cur, target, rate) takes three args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate().take(2) {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: damp arg {} must be int or fixed, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            match &args[2] {
                Expr::FixLit(_) | Expr::IntLit(_) => {}
                _ => return Err(format!("line {}: damp rate must be a LITERAL (per-second) — the compiler bakes 1-e^(-rate/60) into the constant pool", crate::diag::cur_pos())),
            }
            Ok(VT::Fixed)
        }
        // v7: SRAM persistence. save(ix, v) stores the RAW 32-bit value;
        // saved(ix) reads it back as int, savedf(ix) as fixed — the game
        // chooses the type at READ time (raw bits, no conversion emitted).
        "saved" | "savedf" => {
            if args.len() != 1 {
                return Err(format!("line {}: {}(ix) takes one int slot index (0..63)", crate::diag::cur_pos(), name));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            if vt != VT::Int {
                return Err(format!("line {}: {}() slot index must be int, got {:?}", crate::diag::cur_pos(), name, vt));
            }
            Ok(if name == "savedf" { VT::Fixed } else { VT::Int })
        }
        // v7: distance in Q24.8 — computed in i64 internally, so it cannot
        // overflow the way hand-written dx*dx + dy*dy does in big worlds.
        "dist" => {
            if args.len() != 4 {
                return Err(format!("line {}: dist(x1, y1, x2, y2) takes four args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: dist arg {} must be fixed or int, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            Ok(VT::Fixed)
        }
        // v7: screen-convention aim angle (0 = up, clockwise) of the vector
        // (dx, dy) — integer CORDIC, deterministic on both runtimes.
        "atan2" => {
            if args.len() != 2 {
                return Err(format!("line {}: atan2(dy, dx) takes two args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: atan2 arg {} must be fixed or int, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            Ok(VT::Ang)
        }
        // v8 OPTIMIZER subsystem 3: swept Minkowski interval test —
        // swept_hit(ax, ay, avx, avy, bx, by, hw, hh) -> bool. Compiled to a
        // SINGLE branchless opcode (OP_SWEPT); the exact per-axis 1D solve is
        // in opt::physics's docs and unit-tested there.
        "swept_hit" => {
            if args.len() != 8 {
                return Err(format!("line {}: swept_hit(ax, ay, avx, avy, bx, by, hw, hh) takes eight args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: swept_hit arg {} must be fixed or int, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            Ok(VT::Bool)
        }
        // ---------------- v11 3D ----------------
        // proj3(x, y, z) -> scale (Q24.8): perspective-project a world point
        // through the cam3 camera. Screen x/y are stashed; projx()/projy()
        // read them, projok() reports "in front of the camera". All fixed-
        // point integer math (deterministic on every runtime).
        "proj3" => {
            if args.len() != 3 {
                return Err(format!("line {}: proj3(x, y, z) takes three args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: proj3 arg {} must be fixed or int, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            Ok(VT::Fixed)
        }
        "projx" | "projy" => {
            if !args.is_empty() {
                return Err(format!("line {}: {}() takes no args (reads the last proj3 stash)", crate::diag::cur_pos(), name));
            }
            Ok(VT::Fixed)
        }
        "projok" => {
            if !args.is_empty() {
                return Err(format!("line {}: projok() takes no args", crate::diag::cur_pos()));
            }
            Ok(VT::Bool)
        }
        // alen(name) / alen(e.arr) -> the array's compile-time capacity.
        "alen" => {
            if args.len() != 1 {
                return Err(format!("line {}: alen() takes one array name", crate::diag::cur_pos()));
            }
            match &args[0] {
                Expr::Ident(name) => {
                    match r.arr_index.get(&(GLOBAL_ENT, name.clone()) ) {
                        Some(id) => {
                            if r.arrays[*id].ent != GLOBAL_ENT {
                                return Err(format!("line {}: '{}' is an entity array (use alen(e.{}))", crate::diag::cur_pos(), name, name));
                            }
                            Ok(VT::Int)
                        }
                        None => Err(format!("line {}: alen(): unknown global array '{}'", crate::diag::cur_pos(), name)),
                    }
                }
                Expr::Field(inner, fname) => {
                    if !matches!(&**inner, Expr::Ident(_)) {
                        return Err(format!("line {}: alen(): array base must be a variable", crate::diag::cur_pos()));
                    }
                    let v = if let Expr::Ident(v) = &**inner { v } else { unreachable!() };
                    let ei = match env.iter().find(|(n, _)| n == v).map(|(_, vt)| *vt) {
                        Some(VT::Ent(ei)) => ei,
                        _ => return Err(format!("line {}: '{}' is not an entity variable", crate::diag::cur_pos(), v)),
                    };
                    match r.arr_index.get(&(ei as u8, fname.clone())) {
                        Some(_) => Ok(VT::Int),
                        None => Err(format!("line {}: entity {} has no array '{}'", crate::diag::cur_pos(), r.entities[ei].name, fname)),
                    }
                }
                _ => Err(format!("line {}: alen() needs an array name", crate::diag::cur_pos())),
            }
        }
        // ---------------- v17: scalar math builtins ----------------
        // min/max/abs/clamp lower to branch diamonds on existing opcodes
        // (opt::select may still fuse the assignments); lerp is three fixed
        // ops. All are PURE (deterministic, no rand), each argument is
        // evaluated exactly once.
        "min" | "max" => {
            if args.len() != 2 {
                return Err(format!("line {}: {}(a, b) takes two args", crate::diag::cur_pos(), name));
            }
            let at = expr_type(&args[0], env, f, r)?;
            let bt = expr_type(&args[1], env, f, r)?;
            if !matches!(at, VT::Fixed | VT::Int) || !matches!(bt, VT::Fixed | VT::Int) {
                return Err(format!("line {}: {} needs int or fixed args, got {:?} and {:?}", crate::diag::cur_pos(), name, at, bt));
            }
            Ok(match (at, bt) {
                (VT::Fixed, _) | (_, VT::Fixed) => VT::Fixed,
                _ => VT::Int,
            })
        }
        "abs" => {
            if args.len() != 1 {
                return Err(format!("line {}: abs(x) takes one arg", crate::diag::cur_pos()));
            }
            let vt = expr_type(&args[0], env, f, r)?;
            match vt {
                VT::Fixed | VT::Int => Ok(vt),
                _ => Err(format!("line {}: abs needs int or fixed, got {:?}", crate::diag::cur_pos(), vt)),
            }
        }
        "clamp" => {
            if args.len() != 3 {
                return Err(format!("line {}: clamp(v, lo, hi) takes three args", crate::diag::cur_pos()));
            }
            let mut cls = VT::Int;
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: clamp arg {} must be int or fixed, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
                if vt == VT::Fixed { cls = VT::Fixed; }
            }
            Ok(cls)
        }
        "lerp" => {
            if args.len() != 3 {
                return Err(format!("line {}: lerp(a, b, t) takes three args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: lerp arg {} must be int or fixed (t is 0.0..1.0), got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            Ok(VT::Fixed)
        }
        // ---------------- v17: input edge detection ----------------
        // key_pressed(#k): true only on the frame the key went down;
        // key_released(#k): true only on the frame it came back up.
        // Engine-side press/release edge registers (page 0, snapshot-safe);
        // games that use them carry a v4 .libyte (old runners reject it
        // loudly instead of silently misreading the opcode).
        "key_pressed" | "key_released" => {
            if args.len() != 1 || !matches!(args[0], Expr::Atom(_)) {
                return Err(format!("line {}: {}(#atom) takes exactly one key atom", crate::diag::cur_pos(), name));
            }
            if let Expr::Atom(a) = &args[0] {
                r.domain_pos(r.keys, *a, "key")?;
            }
            Ok(VT::Bool)
        }
        // v17: dist_nearest(x, y, EntityType) -> Q24.8 distance to the nearest
        // LIVE entity of the type (engine-side i64 scan, deterministic).
        // 0x7FFFFFFF ("infinitely far") when none are alive — compare against
        // a sane threshold or check count() first.
        "dist_nearest" => {
            if args.len() != 3 {
                return Err(format!("line {}: dist_nearest(x, y, EntityType) takes three args", crate::diag::cur_pos()));
            }
            for (i, a) in args.iter().take(2).enumerate() {
                let vt = expr_type(a, env, f, r)?;
                if !matches!(vt, VT::Fixed | VT::Int) {
                    return Err(format!("line {}: dist_nearest arg {} must be fixed or int, got {:?}", crate::diag::cur_pos(), i + 1, vt));
                }
            }
            match &args[2] {
                Expr::Ident(ent_name) => {
                    let Some(&ei) = r.ent_index.get(ent_name) else {
                        return Err(format!("line {}: dist_nearest needs an entity type, got '{}'", crate::diag::cur_pos(), ent_name));
                    };
                    // the engine reads the type's x/y typed fields — require
                    // them exactly like the compiler's own integrator does
                    let e = &r.entities[ei];
                    for need in ["x", "y"] {
                        if !e.fields.iter().any(|fl| fl.name == need && fl.vt == VT::Fixed && !fl.cold) {
                            return Err(format!("line {}: dist_nearest: entity {} needs dense fixed fields 'x' and 'y' (position) to aim at", crate::diag::cur_pos(), e.name));
                        }
                    }
                    Ok(VT::Fixed)
                }
                _ => Err(format!("line {}: dist_nearest needs an entity type name as its third arg", crate::diag::cur_pos())),
            }
        }
        _ => {
            // v17 USER-FN CALLS IN EXPRESSIONS: `let d = helper(e);` —
            // builtins take precedence (a fn named `sin` is only reachable
            // via `call sin(...)` statements; the checker warns at decl).
            if let Some(&fi) = r.fn_index.get(name) {
                let target = &r.fns[fi];
                if !matches!(target.kind, FnKind::Scene | FnKind::Helper) {
                    return Err(format!("line {}: cannot call fn '{}' in an expression (it is auto-run)", crate::diag::cur_pos(), name));
                }
                // v23.1: draw-safety must gate EXPRESSION calls too — the
                // old gate lived only in Stmt::CallStmt, so a draw fn could
                // smuggle a spawning helper through `let d = f();` while
                // `call f();` was correctly rejected.
                if super::stmt::is_draw_fn(f) && !r.draw_safe[fi] {
                    return Err(format!(
                        "line {}: fn '{}' is not draw-safe (it spawns/kills/saves/goes-to or calls something that does) — draw fns may only call presentation helpers",
                        crate::diag::cur_pos(), name));
                }
                if target.params.len() != args.len() {
                    return Err(format!("line {}: fn '{}' takes {} args, got {}",
                        crate::diag::cur_pos(), name, target.params.len(), args.len()));
                }
                for (i, (pn, pvt)) in target.params.iter().enumerate() {
                    let avt = expr_type(&args[i], env, f, r)?;
                    super::stmt::check_call_arg(*pvt, avt, &format!("arg '{}' of {}", pn, name), crate::diag::cur_pos())?;
                    if matches!(pvt, VT::Ent(_)) && !matches!(args[i], Expr::Ident(_)) {
                        return Err(format!("line {}: entity arg '{}' of {} must be a variable", crate::diag::cur_pos(), pn, name));
                    }
                }
                let ret = target.ret.ok_or_else(|| format!(
                    "line {}: fn '{}' returns no value (add `return expr;` or call it as a statement)", crate::diag::cur_pos(), name))?;
                return Ok(ret);
            }
            Err(format!("line {}: unknown function '{}'", crate::diag::cur_pos(), name))
        }
    }
}

