//! ============================================================================
//! LILA OPTIMIZER — SUBSYSTEM 0: TIER PURITY FIXPOINT
//! ============================================================================
//!
//! The keystone of the tiered-compilation strategy (see the v23 positioning
//! whitepaper). Classifies every function as Tier 0 (provably pure) or
//! Tier 1 (touches heap / threads / exceptions / host-callbacks / Tier-1
//! types). The 11-subsystem optimizer stack gates on this classification:
//! subsystems 1, 3, 5, 6, 7, 8, 10 fire ONLY on Tier-0-pure functions;
//! subsystems 2, 4, 9, 11 are asset-level and unaffected.
//!
//! ## Definition
//!
//! A function is **Tier-0 pure** iff all three hold:
//!   1. It does not touch any Tier-1 type (signature params, return type,
//!      locals, field accesses, expression operands). In v23, NO Tier-1 types
//!      exist in the language — `is_tier1_type(vt)` always returns false.
//!      This is the SEAM where Tier-1 types (f64, box<T>, thread<T>,
//!      string, vec<T>, map<K,V>) will plug in when the roadmap lands.
//!   2. It does not transitively call any Tier-1 function. The impurity is
//!      viral — a Tier-0 fn that calls a Tier-1 fn becomes Tier-1.
//!   3. It does not call any registered host callback. In v23, no host-
//!      callback mechanism exists in the language — `calls_host_callback(f)`
//!      always returns false. This is the SEAM where Step 6 of the roadmap
//!      (host callback registry) will plug in.
//!
//! ## Algorithm
//!
//! Same shape as the existing `checker::stmt::compute_draw_safe` fixpoint
//! (the v17 draw-fn purity proof) and the `forge::tables` pure-fn → table
//! promotion fixpoint. Monotone: once demoted to Tier-1, never promoted.
//! Converges in O(n) rounds where n = fn count (in practice 2-3 rounds).
//!
//! ## Soundness
//!
//! Tier-0 purity is a syntactic + call-graph property, fully decidable at
//! compile time. The optimizer's preconditions (no aliasing, no suspension,
//! no side effects) are met by construction when the function is Tier-0-pure.
//! The proof is the optimizer's existing soundness argument, restated at the
//! tier level — see each subsystem's docs for its specific preconditions.
//!
//! ## v23 Status
//!
//! In v23, with no Tier-1 types and no host-callback mechanism, EVERY
//! function is Tier-0-pure by construction. This pass therefore classifies
//! every function as Tier-0 and is a no-op for the optimizer's behavior.
//! The value of shipping this pass in v23 is:
//!   - The infrastructure exists when Tier-1 types land.
//!   - The fixpoint is exercised against every demo in the v23 suite,
//!     proving convergence and soundness on real code.
//!   - The OptReport includes the tier-purity line, making the contract
//!     visible to developers.

use crate::ast::*;
use crate::checker::{Ctx, FnInfo, VT};
use std::collections::HashMap;

/// The tier of a function. Determines which optimizer subsystems fire.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Tier {
    /// Tier 0 — provably pure. All 11 optimizer subsystems may fire.
    Tier0,
    /// Tier 1 — touches heap / threads / exceptions / host-callbacks.
    /// Only basic optimization (DCE, simple const-fold) fires.
    Tier1,
}

impl Tier {
    /// True if this tier is Tier 0 (eligible for full optimization).
    pub fn is_tier0(self) -> bool { self == Tier::Tier0 }
}

/// Per-function tier purity report. Indexed parallel to `ctx.fns`.
#[derive(Debug, Clone)]
pub struct TierPurityReport {
    /// Per-fn tier (indexed by fn index in `ctx.fns`).
    pub tiers: Vec<Tier>,
    /// Number of fixpoint rounds needed to converge.
    pub rounds: u32,
    /// Count of Tier-0-pure functions.
    pub tier0_count: usize,
    /// Count of Tier-1 functions.
    pub tier1_count: usize,
    /// Names of functions demoted to Tier 1 (for the build report).
    pub demoted: Vec<String>,
}

impl TierPurityReport {
    /// True iff fn `fi` is Tier 0.
    pub fn is_tier0(&self, fi: usize) -> bool {
        self.tiers.get(fi).map(|t| t.is_tier0()).unwrap_or(false)
    }
}

// ============================================================================
// SEAM: Tier-1 type predicate
// ============================================================================
//
// This is the SINGLE POINT where Tier-1 types plug into the compiler. When
// the tiered-architecture roadmap adds `f64`, `box<T>`, `thread<T>`,
// `string`, `vec<T>`, `map<K,V>` to the language, this predicate returns
// true for those VT variants. Until then, every VT is Tier-0-pure.
//
// The predicate is consulted by:
//   - `fn_touches_tier1` (signature + body scan)
//   - The future Tier-1 type-checker (when it lands)
//
// Adding a Tier-1 type is a ONE-LINE change here: extend the match. The
// fixpoint, the call-graph walk, the gate hooks, and the build report all
// pick it up automatically.

/// Is this value type a Tier-1 type?
///
/// v23.6 TIER FLIP: `VT::F64` is now **Tier-0**. The full f64 runtime path
/// landed across v23.1–v23.6 (softfloat binary64, the 0xA0–0xB0 opcodes,
/// wide arrays/params/globals/entity fields, f64 pool fields on the v7 wire
/// format, and baked-table f64 returns via `__ret64`), and both AOT
/// backends lower the f64 family natively (as calls to the bridge's
/// exported softfloat helpers — bit-identical to the interpreter by
/// construction). f64-touching functions therefore compile natively:
///   - The bit-width synthesis (subsystem 1) never narrows them (f64 fails
///     every `matches!(vt, VT::Int)` gate by construction)
///   - The SoA repack (subsystem 1b) packs 64-bit fields (proven bit math)
///   - The SEL superoptimization (subsystem 6) refuses multi-cell values
///   - The FSM synthesis (subsystem 5) accepts f64 guards (1-cell bools)
///   - The physics rewrite (subsystem 3) is VT-gated for defense in depth
/// `thread<T>` REMAINS the one Tier-1 type (aliasing the optimizer cannot
/// prove disjoint at the fn level).
pub fn is_tier1_type(vt: VT) -> bool {
    match vt {
        // Tier-0 types (the v23 type system):
        VT::Fixed | VT::Int | VT::Bool | VT::Ang | VT::F32 => false,
        VT::Ent(_) | VT::Pool(_) => false, // entity/pool handles, not pointers
        // v23 STEP 5: SIMD vector types are Tier-0 — they're pure data
        // (no aliasing, no heap, no suspension). The SoA repacker detects
        // 4 consecutive same-type fields and emits vec4 layout. The AOT
        // backend lowers vec4 ops to SSE/NEON. The tier purity fixpoint
        // keeps vec4-touching fns Tier-0 — they get full optimization.
        VT::Vec4Fixed | VT::Vec4U8 => false,
        // v23.6 TIER FLIP: f64 is Tier-0 — fully lowered end-to-end
        // (checker + codegen + VM + both AOT backends + forge/tables).
        VT::F64 => false,
        // The remaining Tier-1 type: thread<T>. Threads introduce aliasing
        // that the optimizer can't prove disjoint at the fn level. The
        // borrow-checker-style disjointness proof (extends subsystem 10)
        // fires at the call site — if two threads touch disjoint fields,
        // they run in parallel; if not, they run sequentially. But the
        // fn that SPAWNS the thread is Tier-1 (it can't be optimized
        // under the determinism contract because the thread's behavior
        // is observable).
        VT::Thread(_) => true,
        // When more Tier-1 types land, add them here:
        // VT::Box(_) => true,
        // VT::String => true,
        // VT::Vec(_) => true,
        // VT::Map(_, _) => true,
    }
}

// ============================================================================
// SEAM: Host-callback predicate
// ============================================================================
//
// In v23, LILA source code cannot call back into the host. The host calls
// into LILA via the pointer-overlay ABI (lila_overlay_install, etc.), but
// there is no `extern "host"` call form in the language. This predicate
// therefore always returns false.
//
// When Step 6 of the roadmap lands (host-callback registry), this predicate
// walks the fn body for host-callback call sites — same shape as the existing
// `walk_calls` for user fns. The fixpoint picks them up automatically; the
// optimizer gates fire on the new classification.

/// Does this function call any registered host callback?
///
/// In v23, always returns false — no host-callback mechanism exists.
/// When Step 6 of the tiered roadmap lands (host-callback registry), this
/// predicate walks the fn body for host-callback call sites.
pub fn calls_host_callback(_f: &FnInfo) -> bool {
    false
}

// ============================================================================
// THE FIXPOINT
// ============================================================================

/// Compute the per-function tier purity via a monotone fixpoint.
///
/// Same shape as `checker::stmt::compute_draw_safe`:
///   1. Initialize every fn as Tier0.
///   2. Walk each fn's signature + body for Tier-1 types; demote to Tier1
///      if any are found.
///   3. Walk each fn's calls; if any callee is Tier1, demote caller to
///      Tier1 (transitive — the impurity is viral).
///   4. Repeat 2-3 until no changes (monotone convergence).
///
/// Soundness: Tier-0 purity is a syntactic + call-graph property, fully
/// decidable at compile time. The optimizer's preconditions (no aliasing,
/// no suspension, no side effects) are met by construction when the
/// function is Tier-0-pure.
pub fn compute_tier_purity(ctx: &Ctx) -> TierPurityReport {
    let n = ctx.fns.len();
    let mut tiers = vec![Tier::Tier0; n];
    let mut rounds = 0u32;

    // Build name -> index map (only helpers/scenes are callable from user
    // code — auto-run fns like init/update/draw are not callable, but
    // including them in the map is harmless because they can't appear as
    // call targets anyway.)
    let name_to_idx: HashMap<&str, usize> = ctx.fns.iter()
        .enumerate()
        .map(|(i, f)| (f.name.as_str(), i))
        .collect();

    // Round 0: per-fn body + signature scan (no transitive closure yet).
    // This catches direct Tier-1-type usage. The transitive closure below
    // catches indirect usage via calls.
    for (i, f) in ctx.fns.iter().enumerate() {
        if fn_touches_tier1(f) {
            tiers[i] = Tier::Tier1;
        }
    }

    // Transitive closure: until no change.
    let mut changed = true;
    while changed {
        changed = false;
        rounds += 1;
        for (i, f) in ctx.fns.iter().enumerate() {
            if tiers[i] == Tier::Tier1 { continue; }
            // Walk every call this fn makes; if any callee is Tier1, demote.
            let mut demote = false;
            crate::ast::walk_call_names_stmts(&f.body, &mut |name| {
                if let Some(&callee_idx) = name_to_idx.get(name) {
                    if tiers[callee_idx] == Tier::Tier1 {
                        demote = true;
                    }
                }
            });
            if demote {
                tiers[i] = Tier::Tier1;
                changed = true;
            }
        }
    }

    let tier0_count = tiers.iter().filter(|t| t.is_tier0()).count();
    let tier1_count = n - tier0_count;
    let demoted: Vec<String> = ctx.fns.iter().enumerate()
        .filter(|(i, _)| tiers[*i] == Tier::Tier1)
        .map(|(_, f)| f.name.clone())
        .collect();

    TierPurityReport {
        tiers,
        rounds,
        tier0_count,
        tier1_count,
        demoted,
    }
}

// ============================================================================
// PER-FN BODY + SIGNATURE SCAN
// ============================================================================

/// Does the function touch any Tier-1 type in its signature or body, or
/// call any host callback? (Direct usage — transitive usage is caught by
/// the fixpoint walk.)
fn fn_touches_tier1(f: &FnInfo) -> bool {
    // Signature: parameters and return type.
    for (_, vt) in &f.params {
        if is_tier1_type(*vt) { return true; }
    }
    if let Some(vt) = f.ret {
        if is_tier1_type(vt) { return true; }
    }
    // Host callbacks (when they exist — none in v23).
    if calls_host_callback(f) { return true; }

    // Body: walk statements + expressions for Tier-1-typed locals, field
    // accesses, etc. In v23 this walk finds nothing because is_tier1_type
    // returns false for every VT — but the walk is exercised by every demo
    // in the v23 suite, proving it converges and is sound on real code.
    let mut found = false;
    walk_stmts_for_tier1(&f.body, &mut || { found = true; });
    found
}

fn walk_stmts_for_tier1(stmts: &[Stmt], found: &mut impl FnMut()) {
    for s in stmts {
        match s {
            // v23.2 SPANS: positional wrapper — look through.
            Stmt::At { inner, .. } => walk_stmts_for_tier1(std::slice::from_ref(inner), found),
            Stmt::Let(_, e) => { walk_expr_for_tier1(e, found); }
            Stmt::Assign(target, _, e) => {
                walk_expr_for_tier1(target, found);
                walk_expr_for_tier1(e, found);
            }
            Stmt::If(c, a, b) => {
                walk_expr_for_tier1(c, found);
                walk_stmts_for_tier1(a, found);
                walk_stmts_for_tier1(b, found);
            }
            Stmt::While(c, b) => {
                walk_expr_for_tier1(c, found);
                walk_stmts_for_tier1(b, found);
            }
            Stmt::For(_, _, b) | Stmt::ForNum(_, _, _, b) | Stmt::ForMask(_, _, _, b) => {
                walk_stmts_for_tier1(b, found);
            }
            Stmt::Switch(scrut, arms, dflt) => {
                walk_expr_for_tier1(scrut, found);
                for (_, body) in arms { walk_stmts_for_tier1(body, found); }
                if let Some(d) = dflt { walk_stmts_for_tier1(d, found); }
            }
            Stmt::Spawn(_, inits) => {
                for (_, e) in inits { walk_expr_for_tier1(e, found); }
            }
            Stmt::Kill(e) => { walk_expr_for_tier1(e, found); }
            Stmt::Cam3(a, b, c, d, e) => {
                for x in [a, b, c, d, e] { walk_expr_for_tier1(x, found); }
            }
            Stmt::Draw3d { n, x, y, z, yaw, rgba, .. } => {
                for x in [n, x, y, z, yaw, rgba] { walk_expr_for_tier1(x, found); }
            }
            Stmt::Draw3DI { nv, ni, x, y, z, yaw, rgba, .. } => {
                for x in [nv, ni, x, y, z, yaw, rgba] { walk_expr_for_tier1(x, found); }
            }
            Stmt::QuatAA { off, ax, ay, az, ang, .. } => {
                for x in [off, ax, ay, az, ang] { walk_expr_for_tier1(x, found); }
            }
            Stmt::QMul { doff, aoff, boff, .. } => {
                for x in [doff, aoff, boff] { walk_expr_for_tier1(x, found); }
            }
            Stmt::M4QT { moff, qoff, tx, ty, tz, .. } => {
                for x in [moff, qoff, tx, ty, tz] { walk_expr_for_tier1(x, found); }
            }
            Stmt::M4Mul { doff, aoff, boff, .. } => {
                for x in [doff, aoff, boff] { walk_expr_for_tier1(x, found); }
            }
            Stmt::SkinV { voff, moff, x, y, z, .. } => {
                for x in [voff, moff, x, y, z] { walk_expr_for_tier1(x, found); }
            }
            Stmt::M4Look { moff, ex, ey, ez, tx, ty, tz, .. } => {
                for x in [moff, ex, ey, ez, tx, ty, tz] { walk_expr_for_tier1(x, found); }
            }
            Stmt::CallStmt(name, args) => {
                // The call itself is handled by `walk_calls` in the fixpoint.
                // Here we walk argument expressions for Tier-1-typed values.
                let _ = name;
                for a in args { walk_expr_for_tier1(a, found); }
            }
            Stmt::CallTable(table, key, var) => {
                let _ = (table, var);
                walk_expr_for_tier1(key, found);
            }
            Stmt::Return(Some(e)) => { walk_expr_for_tier1(e, found); }
            Stmt::Wait(e) => { walk_expr_for_tier1(e, found); }
            Stmt::Save(ix, val) => {
                walk_expr_for_tier1(ix, found);
                walk_expr_for_tier1(val, found);
            }
            Stmt::Camera(x, y) => {
                walk_expr_for_tier1(x, found);
                walk_expr_for_tier1(y, found);
            }
            Stmt::Draw(_, x, y, rot, scale, rgba) => {
                for x in [x, y, rot, scale, rgba] { walk_expr_for_tier1(x, found); }
            }
            Stmt::DrawText(_, x, y, rgba) => {
                for x in [x, y, rgba] { walk_expr_for_tier1(x, found); }
            }
            Stmt::DrawNum(v, x, y, rgba) => {
                for x in [v, x, y, rgba] { walk_expr_for_tier1(x, found); }
            }
            Stmt::DrawNumZ(v, _, x, y, rgba) => {
                for x in [v, x, y, rgba] { walk_expr_for_tier1(x, found); }
            }
            Stmt::PoolPush(_, inits) => {
                for (_, e) in inits { walk_expr_for_tier1(e, found); }
            }
            Stmt::PoolRemove(e) => { walk_expr_for_tier1(e, found); }
            Stmt::MapPut(_, key, val) => {
                walk_expr_for_tier1(key, found);
                walk_expr_for_tier1(val, found);
            }
            Stmt::MapDel(_, key) => { walk_expr_for_tier1(key, found); }
            Stmt::QPush(_, val) | Stmt::SPush(_, val) => { walk_expr_for_tier1(val, found); }
            Stmt::AFill(_, val) => { walk_expr_for_tier1(val, found); }
            Stmt::ACopy(_, _, n) => { walk_expr_for_tier1(n, found); }
            Stmt::AShuf(_, n) => { walk_expr_for_tier1(n, found); }
            // v23 STEP 8: try/catch and throw are Tier-1 statements.
            // Any fn that uses them demotes to Tier-1. The walk still
            // recurses into the body for completeness (future Tier-1
            // types in the body would also demote), but the try/catch
            // itself is the demotion trigger.
            Stmt::TryCatch { body, catch_body, .. } => {
                found(); // try/catch demotes the fn to Tier-1
                walk_stmts_for_tier1(body, found);
                walk_stmts_for_tier1(catch_body, found);
            }
            Stmt::Throw(e) => {
                found(); // throw demotes the fn to Tier-1
                walk_expr_for_tier1(e, found);
            }
            // Engine-intrinsic statements with no Tier-1-typed operands:
            Stmt::Sfx(_) | Stmt::Music(_) | Stmt::StopMusic | Stmt::Shake(_)
            | Stmt::Goto(_) | Stmt::FsmStep(_) | Stmt::Break | Stmt::Continue
            | Stmt::MusicVol(_) | Stmt::GotoState(_) | Stmt::Emit(_)
            | Stmt::PSort(_, _, _) | Stmt::State(_, _) | Stmt::Return(None) => {}
        }
    }
}

fn walk_expr_for_tier1(e: &Expr, found: &mut impl FnMut()) {
    match e {
        Expr::Unary(_, inner) | Expr::Field(inner, _) => walk_expr_for_tier1(inner, found),
        Expr::Index(a, b) => {
            walk_expr_for_tier1(a, found);
            walk_expr_for_tier1(b, found);
        }
        Expr::Binary(_, a, b) => {
            walk_expr_for_tier1(a, found);
            walk_expr_for_tier1(b, found);
        }
        Expr::Ternary(c, a, b) => {
            walk_expr_for_tier1(c, found);
            walk_expr_for_tier1(a, found);
            walk_expr_for_tier1(b, found);
        }
        Expr::Call(_, args) => {
            for a in args { walk_expr_for_tier1(a, found); }
        }
        Expr::Intrin(_, _, args, _) => {
            for a in args { walk_expr_for_tier1(a, found); }
        }
        // v23.6 TIER FLIP: f64 literals no longer demote — the f64 family
        // is fully lowered end-to-end and f64 fns compile natively.
        Expr::F64Lit(_) => {}
        // Terminals: literals, idents, atoms — no Tier-1 types here in v23.
        Expr::IntLit(_) | Expr::FixLit(_) | Expr::F32Lit(_)
        | Expr::BoolLit(_) | Expr::Atom(_) | Expr::Ident(_) => {}
    }
}

// ============================================================================
// UNIT TESTS
// ============================================================================
//
// These tests prove the fixpoint's four key properties:
//   (a) A pure Tier-0 fn (no Tier-1 types, no calls) is classified Tier 0.
//   (b) A fn touching Tier-1 types is classified Tier 1.
//       — Cannot be tested directly in v23 because no Tier-1 types exist.
//         Instead, we test the predicate `is_tier1_type` directly to lock
//         the v23 contract (everything is Tier 0).
//   (c) A fn calling a Tier-1 fn transitively demotes.
//       — Cannot be tested directly in v23 for the same reason. Instead,
//         we test the fixpoint convergence with a synthetic call graph
//         where we manually inject Tier-1 demotion and verify the viral
//         property.
//   (d) The fixpoint converges (bounded rounds, monotone).

#[cfg(test)]
mod tests {
    use super::*;
    use crate::checker::{Ctx, FnInfo, FnKind, VT};
    use crate::ast::{Stmt, Expr};

    /// Build a minimal Ctx with the given fns. Other Ctx fields are empty.
    fn minimal_ctx(fns: Vec<FnInfo>) -> Ctx {
        let mut ctx = Ctx {
            atom_names: vec![],
            game: crate::ast::GameDecl {
                title: String::new(), width: 512, height: 512, wrap: true,
                world_w: None, world_h: None, capacity: None, optimize: false,
                mem_mb: None, reflection: false,
            },
            sound: vec![], keys: vec![], texts: vec![], scenes: vec![],
            sprites: vec![], music: vec![], sfx: vec![], anims: vec![],
            entities: vec![], globals: vec![], globals_bits: 0, arrays: vec![], baked: vec![],
            pools: vec![], dicts: vec![], typed_fields: vec![], fns,
            ret64_slot: vec![],
            tables: vec![], fsms: vec![],
            ent_index: HashMap::new(), global_index: HashMap::new(),
            tf_index: HashMap::new(), draw_safe_ctx: vec![],
            arr_index: HashMap::new(), pool_index: HashMap::new(),
            dict_index: HashMap::new(), signals: vec![],
            signal_index: HashMap::new(), fn_index: HashMap::new(),
            scene_atom_ids: vec![], sprite_atoms: vec![],
            music_atoms: vec![], anim_atoms: vec![],
            tier_purity_ctx: None,
        };
        // Rebuild fn_index map
        for (i, f) in ctx.fns.iter().enumerate() {
            ctx.fn_index.insert(f.name.clone(), i);
        }
        ctx
    }

    fn helper_fn(name: &str, body: Vec<Stmt>) -> FnInfo {
        FnInfo {
            name: name.to_string(),
            params: vec![],
            body,
            kind: FnKind::Helper,
            entity: None,
            ret: None,
            line: 1,
        }
    }

    #[test]
    fn test_v23_type_tier_classification() {
        // v23.6 TIER FLIP: F64 is Tier-0 (fully lowered end-to-end; f64 fns
        // compile natively in both AOT backends). All other VTs are Tier-0
        // too, except the reserved thread<T>.
        assert!(!is_tier1_type(VT::Fixed));
        assert!(!is_tier1_type(VT::Int));
        assert!(!is_tier1_type(VT::Bool));
        assert!(!is_tier1_type(VT::Ang));
        assert!(!is_tier1_type(VT::F32));
        assert!(!is_tier1_type(VT::Ent(0)));
        assert!(!is_tier1_type(VT::Pool(0)));
        // v23.6: f64 is Tier-0 — natively compiled.
        assert!(!is_tier1_type(VT::F64), "f64 must be Tier-0 since v23.6");
        // v23 STEP 5: SIMD vector types are Tier-0 (pure data, no aliasing).
        assert!(!is_tier1_type(VT::Vec4Fixed), "vec4fixed must be Tier-0");
        assert!(!is_tier1_type(VT::Vec4U8), "vec4u8 must be Tier-0");
        // thread<T> stays the one Tier-1 type.
        assert!(is_tier1_type(VT::Thread(0)), "thread<T> must stay Tier-1");
    }

    #[test]
    fn test_v23_no_host_callbacks() {
        // In v23, no host-callback mechanism exists. This test LOCKS the
        // v23 contract.
        let f = helper_fn("test", vec![]);
        assert!(!calls_host_callback(&f));
    }

    #[test]
    fn test_pure_fn_is_tier0() {
        // A fn with an empty body and no params is Tier 0.
        let ctx = minimal_ctx(vec![
            helper_fn("pure_empty", vec![]),
        ]);
        let report = compute_tier_purity(&ctx);
        assert_eq!(report.tier0_count, 1);
        assert_eq!(report.tier1_count, 0);
        assert!(report.is_tier0(0));
    }

    #[test]
    fn test_fixpoint_converges() {
        // Three fns in a call chain: a -> b -> c. None touch Tier-1 types,
        // so all should be Tier 0 after the fixpoint converges.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "a".to_string(),
                params: vec![], body: vec![Stmt::CallStmt("b".to_string(), vec![])],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
            FnInfo {
                name: "b".to_string(),
                params: vec![], body: vec![Stmt::CallStmt("c".to_string(), vec![])],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
            FnInfo {
                name: "c".to_string(),
                params: vec![], body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert_eq!(report.tier0_count, 3);
        assert_eq!(report.tier1_count, 0);
        // Convergence in 1 round (no demotions, single pass confirms).
        assert!(report.rounds >= 1);
    }

    #[test]
    fn test_viral_demotion_via_synthetic_tier1() {
        // Simulate the "viral demotion" property: if `b` is Tier 1, then
        // `a` (which calls `b`) must also be Tier 1.
        //
        // In v23 we can't make `b` Tier 1 via the language (no Tier-1 types
        // exist), so we manually inject the demotion by overriding the
        // initial classification. This proves the fixpoint's viral property.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "a".to_string(),
                params: vec![], body: vec![Stmt::CallStmt("b".to_string(), vec![])],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
            FnInfo {
                name: "b".to_string(),
                params: vec![], body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);

        // First, prove both are Tier 0 in v23.
        let report = compute_tier_purity(&ctx);
        assert!(report.is_tier0(0));
        assert!(report.is_tier0(1));

        // Now simulate what would happen if `b` were Tier 1 (e.g. it
        // touched a `box<T>` type when Tier-1 types land). We do this by
        // manually setting the initial tier of `b` to Tier 1 and re-running
        // JUST the transitive closure part of the fixpoint. If the fixpoint
        // is correct, `a` must demote to Tier 1 because it calls `b`.
        let mut tiers = vec![Tier::Tier0; 2];
        tiers[1] = Tier::Tier1; // simulate `b` touching a Tier-1 type

        // Run the transitive closure loop (extracted from compute_tier_purity).
        let name_to_idx: HashMap<&str, usize> = ctx.fns.iter()
            .enumerate()
            .map(|(i, f)| (f.name.as_str(), i))
            .collect();
        let mut changed = true;
        while changed {
            changed = false;
            for (i, f) in ctx.fns.iter().enumerate() {
                if tiers[i] == Tier::Tier1 { continue; }
                let mut demote = false;
                crate::ast::walk_call_names_stmts(&f.body, &mut |name| {
                    if let Some(&callee_idx) = name_to_idx.get(name) {
                        if tiers[callee_idx] == Tier::Tier1 {
                            demote = true;
                        }
                    }
                });
                if demote {
                    tiers[i] = Tier::Tier1;
                    changed = true;
                }
            }
        }

        // Verify `a` was virally demoted.
        assert_eq!(tiers[0], Tier::Tier1, "a must demote because it calls b (Tier 1)");
        assert_eq!(tiers[1], Tier::Tier1, "b stays Tier 1");
    }

    #[test]
    fn test_mutual_recursion_converges() {
        // Mutual recursion: a calls b, b calls a. Both empty bodies otherwise.
        // The fixpoint must converge (not loop forever) and classify both
        // as Tier 0 (no Tier-1 types touched).
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "a".to_string(),
                params: vec![], body: vec![Stmt::CallStmt("b".to_string(), vec![])],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
            FnInfo {
                name: "b".to_string(),
                params: vec![], body: vec![Stmt::CallStmt("a".to_string(), vec![])],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert_eq!(report.tier0_count, 2);
        assert_eq!(report.tier1_count, 0);
        // Convergence bounded — the fixpoint doesn't loop forever on cycles.
        assert!(report.rounds < 10, "fixpoint should converge in <10 rounds, got {}", report.rounds);
    }

    #[test]
    fn test_empty_ctx() {
        // Edge case: no fns at all. The pass must not panic.
        let ctx = minimal_ctx(vec![]);
        let report = compute_tier_purity(&ctx);
        assert_eq!(report.tier0_count, 0);
        assert_eq!(report.tier1_count, 0);
        assert_eq!(report.tiers.len(), 0);
    }

    #[test]
    fn test_report_demoted_list() {
        // The `demoted` field of the report lists Tier-1 fn names.
        // In v23, with no f64 usage, it should be empty.
        let ctx = minimal_ctx(vec![
            helper_fn("a", vec![]),
            helper_fn("b", vec![]),
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(report.demoted.is_empty(), "no f64 usage, demoted list should be empty");
    }

    #[test]
    fn test_thread_param_demotes_fn_to_tier1() {
        // v23.6: thread<T> is the one remaining Tier-1 type — a fn with a
        // thread param is classified Tier-1, proving the tier purity
        // machinery still works end-to-end on a real Tier-1 type.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "thread_fn".to_string(),
                params: vec![("t".to_string(), VT::Thread(0))],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
            FnInfo {
                name: "pure_fn".to_string(),
                params: vec![],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(!report.is_tier0(0), "thread_fn must be Tier-1");
        assert!(report.is_tier0(1), "pure_fn must be Tier-0");
        assert_eq!(report.tier1_count, 1);
        assert_eq!(report.tier0_count, 1);
        assert_eq!(report.demoted, vec!["thread_fn".to_string()]);
    }

    #[test]
    fn test_f64_param_stays_tier0() {
        // v23.6 TIER FLIP: a fn with an f64 param compiles NATIVELY (Tier-0)
        // — the f64 family is fully lowered in both AOT backends.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "f64_fn".to_string(),
                params: vec![("x".to_string(), VT::F64)],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(report.is_tier0(0), "f64_fn must be Tier-0 (native) since v23.6");
        assert_eq!(report.tier1_count, 0);
    }

    #[test]
    fn test_f64_return_stays_tier0() {
        // v23.6: a fn that returns f64 rides the baked __ret64 table and
        // compiles NATIVELY (Tier-0) in both AOT backends.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "f64_ret".to_string(),
                params: vec![],
                body: vec![],
                kind: FnKind::Helper, entity: None,
                ret: Some(VT::F64), line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(report.is_tier0(0), "f64_ret must be Tier-0 (native) since v23.6");
        assert_eq!(report.tier1_count, 0);
    }

    #[test]
    fn test_f64_literal_in_body_stays_tier0() {
        // v23.6 TIER FLIP: a fn that uses an f64 literal (the `d` suffix
        // form) stays Tier-0 — natively compiled with bridge-helper f64 ops.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "uses_f64_literal".to_string(),
                params: vec![],
                body: vec![Stmt::Let("x".to_string(), Expr::F64Lit(0x4000000000000000))],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(report.is_tier0(0), "uses_f64_literal must be Tier-0 (native) since v23.6");
        assert_eq!(report.tier1_count, 0);
    }

    #[test]
    fn test_vec4_types_stay_tier0() {
        // v23 STEP 5: vec4 types are Tier-0 — the tier purity fixpoint
        // keeps vec4-touching fns Tier-0 so the optimizer + AOT backend
        // can lower them to SSE/NEON. This proves the SIMD strategy:
        // the optimizer fires fully on vec4 code (bit-width synthesis,
        // SoA repack, etc.) and the AOT backend emits vector ops.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "vec4_fn".to_string(),
                params: vec![("v".to_string(), VT::Vec4Fixed)],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
            FnInfo {
                name: "vec4u8_fn".to_string(),
                params: vec![("v".to_string(), VT::Vec4U8)],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(report.is_tier0(0), "vec4fixed fn must stay Tier-0");
        assert!(report.is_tier0(1), "vec4u8 fn must stay Tier-0");
        assert_eq!(report.tier1_count, 0, "vec4 types don't demote");
        assert_eq!(report.tier0_count, 2);
    }

    #[test]
    fn test_debug_bridge_does_not_affect_tier_purity() {
        // v23 STEP 6: The debugger/profiler bridge (lila_set_breakpoint,
        // lila_inspect_local, Chrome tracing events) is a runtime-side
        // feature — it doesn't add any tier-1 types or change the tier
        // purity classification. This test proves the bridge is invisible
        // to the compiler: a fn that doesn't touch Tier-1 types stays
        // Tier-0 regardless of whether the debug bridge is linked.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "pure_fn".to_string(),
                params: vec![],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(report.is_tier0(0), "pure fn stays Tier-0 (debug bridge is invisible)");
        assert_eq!(report.tier1_count, 0);
    }

    #[test]
    fn test_thread_type_demotes_to_tier1() {
        // v23 STEP 7: thread<T> is a Tier-1 type. Any fn with a thread<T>
        // param is demoted to Tier-1. The borrow-checker-style disjointness
        // proof (extends subsystem 10) fires at the call site to prove
        // two threads touch disjoint fields — but the spawning fn is
        // always Tier-1.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "spawns_thread".to_string(),
                params: vec![("t".to_string(), VT::Thread(0))],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
            FnInfo {
                name: "pure_fn".to_string(),
                params: vec![],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(!report.is_tier0(0), "spawns_thread must be Tier-1");
        assert!(report.is_tier0(1), "pure_fn stays Tier-0");
        assert_eq!(report.tier1_count, 1);
        assert_eq!(report.demoted, vec!["spawns_thread".to_string()]);
    }

    #[test]
    fn test_thread_viral_demotion() {
        // v23 STEP 7: if `a` calls `b` and `b` takes a thread<T> param,
        // then `a` is also Tier-1 (the impurity is viral).
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "a".to_string(),
                params: vec![],
                body: vec![Stmt::CallStmt("b".to_string(), vec![])],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
            FnInfo {
                name: "b".to_string(),
                params: vec![("t".to_string(), VT::Thread(0))],
                body: vec![],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(!report.is_tier0(0), "a must demote (calls b which is Tier-1)");
        assert!(!report.is_tier0(1), "b must be Tier-1");
        assert_eq!(report.tier1_count, 2);
    }

    #[test]
    fn test_trycatch_demotes_to_tier1() {
        // v23 STEP 8: a fn with a try/catch statement is Tier-1.
        // Tier-0 fns cannot throw — the tier purity fixpoint guarantees
        // this, so the optimizer can assume no exceptions in Tier-0 code.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "uses_try".to_string(),
                params: vec![],
                body: vec![Stmt::TryCatch {
                    body: vec![],
                    catch_var: "e".to_string(),
                    catch_body: vec![],
                }],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(!report.is_tier0(0), "uses_try must be Tier-1");
        assert_eq!(report.tier1_count, 1);
        assert_eq!(report.demoted, vec!["uses_try".to_string()]);
    }

    #[test]
    fn test_throw_demotes_to_tier1() {
        // v23 STEP 8: a fn with a throw statement is Tier-1.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "throws".to_string(),
                params: vec![],
                body: vec![Stmt::Throw(Expr::IntLit(42))],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(!report.is_tier0(0), "throws must be Tier-1");
        assert_eq!(report.tier1_count, 1);
    }

    #[test]
    fn test_tier0_fn_has_no_trycatch_or_throw() {
        // v23 STEP 8: A Tier-0 fn (no try/catch, no throw, no Tier-1 types)
        // stays Tier-0. This proves the optimizer can safely assume no
        // exceptions in Tier-0 code — the soundness argument for the
        // zero-cost unwind table strategy.
        let ctx = minimal_ctx(vec![
            FnInfo {
                name: "pure_fn".to_string(),
                params: vec![],
                body: vec![Stmt::Let("x".to_string(), Expr::IntLit(1))],
                kind: FnKind::Helper, entity: None, ret: None, line: 1,
            },
        ]);
        let report = compute_tier_purity(&ctx);
        assert!(report.is_tier0(0), "pure_fn stays Tier-0 (no try/catch/throw)");
        assert_eq!(report.tier1_count, 0);
    }
}
