//! LILA AST — raw parse output (pre-type-check).

#[derive(Debug, Clone, PartialEq)]
pub enum Ty {
    Fixed,
    UInt(u8),  // bit width 1..=16 (u1 = bool-ish but distinct)
    SInt(u8),
    Bool,
    Ang,
    Entity(String),
    /// v23.2 STRUCTS: a user-declared record. PURELY A PARSE-TIME SHELL —
    /// synth::lower_structs flattens every struct-typed global/array/entity
    /// field into scalar fields with dotted names ("pos.x") BEFORE the
    /// checker runs, so no later stage ever sees this variant (one asserts
    /// loudly if one does). Flattening is the transparent-memory doctrine
    /// applied to records: zero new opcodes, zero runtime bytes beyond the
    /// fields themselves, bit-identical determinism.
    Struct(String),
    /// v20: software-IEEE binary32 (deterministic soft-float in the VM —
    /// the opt-in escape hatch for standard physics equations; Q24.8 stays
    /// the default number system).
    F32,
    /// v23 TIER-1: software-IEEE binary64. The FIRST Tier-1 type — functions
    /// that use it are demoted to Tier-1 by the tier purity fixpoint and
    /// skipped by the optimizer. Codegen currently rejects it; this proves
    /// the tier purity machinery works end-to-end without shipping incomplete
    /// runtime support. When the full f64 runtime lands (softfloat.zig
    /// extended to binary64, new opcodes, libyte v6), the codegen error
    /// is removed and f64 becomes a fully usable Tier-1 type.
    F64,
    /// v23 STEP 5: SIMD vector types — 4-wide packed values that map to
    /// SSE/NEON when AOT-compiled. These are TIER-0 types (pure data, no
    /// aliasing) — the SoA repacker detects 4 consecutive same-type fields
    /// and emits vec4 layout. The tier purity fixpoint keeps them Tier-0.
    Vec4Fixed, // 4 × Q24.8 fixed = 128 bits (one SSE register)
    Vec4U8,    // 4 × u8 = 32 bits (the SoA hot segment)
    /// v23 STEP 7: user-visible thread type. `thread<T>` spawns a host
    /// thread that runs fn T. The tier purity fixpoint demotes any fn
    /// that uses thread<T> to Tier-1 (threads introduce aliasing that
    /// the optimizer can't prove disjoint). The borrow-checker-style
    /// disjointness proof (extends subsystem 10) fires at the call site
    /// to prove two threads touch disjoint fields — if so, they run in
    /// parallel; if not, they run sequentially (still safe, just slower).
    Thread(String), // the fn name that the thread runs
}

#[derive(Debug, Clone)]
pub struct GameDecl {
    pub title: String,
    pub width: u32,
    pub height: u32,
    pub wrap: bool,
    /// v7: simulation bounds (world > screen = scrolling world with camera).
    /// None = world == screen (v1 behavior, byte-compatible).
    pub world_w: Option<u32>,
    pub world_h: Option<u32>,
    /// v2: game-declared capacity — entity slots per type the game needs.
    /// None = engine default (512). Written into a v2 .libyte header; the
    /// runtime rejects the file (ERR_LIMIT_ENTITIES) if its build profile
    /// is smaller, so capacity mismatches are loud, never silent.
    pub capacity: Option<u32>,
    /// v8 OPTIMIZER mandate: `game { optimize: true }` opts this game into
    /// the full compile-time pipeline (bit-width synthesis + cache-line SoA
    /// repacking). Off by default: legacy games keep byte-identical output.
    pub optimize: bool,
    /// v20 SCALE: `game { capacity { mem: N } }` — the flat-image memory tier
    /// (MB) the game is built for. None = engine default (2MB). Written into
    /// the v5 header; the loader validates against the build profile
    /// (ERR_LIMIT_MEM). Bigger tiers grow the pool plane (dynamic side
    /// tables live in the image tail).
    pub mem_mb: Option<u32>,
    /// v20 REFLECTION: `game { reflection: true }` ships the NAMES trailer
    /// (entity/field/fn/pool names) — host editors get real labels for the
    /// typed-field registry. Legacy loaders ignore the trailer (it rides
    /// after every section they read); legacy games never set the flag, so
    /// their bytes stay identical.
    pub reflection: bool,
}

#[derive(Debug, Clone)]
pub struct FieldDecl {
    pub name: String,
    pub ty: Ty,
    pub default_int: Option<i64>, // raw literal (fixed already Q24.8; f32 = IEEE bits)
    pub default_fix: Option<i32>,
    pub default_bool: Option<bool>,
    pub cold: bool,
}

/// v11 ARRAYS (TArray/List<T> analog) — fixed-capacity, zero-alloc, i32-cell
/// aggregates declared with `arr <ty>[<cap>] <name>;` inside `global { }`
/// (game-wide arrays: meshes, waypoint paths, grids) or an entity block
/// (per-instance arrays: trails, inventories). Capacity is a compile-time
/// constant: the checker PROVES literal indices in range, the runtime wraps
/// dynamic indices (mask if power-of-two cap, else modulo) — the same
/// "no trap paths" contract as div-by-zero and spawn budgets.
///
/// v17 TWO-DIMENSIONAL ARRAYS: `arr fixed[8][8] grid;` declares a row-major
/// grid. `dims` is empty for 1-D (legacy) or holds the per-axis extents;
/// `cap` is ALWAYS the product (total cells) so the wire format and the
/// runtime plane layout are unchanged — the compiler combines indices
/// (`grid[i][j]` -> cell `i*W + j`, each axis wrapped on its own extent) and
/// proves literal indices per axis.
#[derive(Debug, Clone)]
pub struct ArrDecl {
    pub name: String,
    pub elem: Ty, // scalar element type (Entity arrays are forbidden)
    pub cap: u32, // TOTAL element count (product of dims), 1..=16384
    pub dims: Vec<u32>, // v17: per-axis extents (empty = 1-D legacy)
    pub line: u32,
}

/// v23.2 STRUCTS — a user-declared record (C struct / C# record analog).
/// LOWERED AWAY by synth::lower_structs before the checker runs: every
/// struct-typed global, array, or entity field is flattened into scalar
/// fields with dotted names ("pos.x"), and every `v.x` / `path[i].y`
/// access is rewritten to the flattened identifier. The dotted spelling
/// cannot collide with any user identifier ('.' is not an ident char).
/// Nested structs are not supported (fields must be scalar) — flat records
/// keep the transparent-memory layout provable.
/// v23.2 MESH IMPORT — a Wavefront-OBJ triangle list embedded into a
/// global fixed array at COMPILE time. Lowered by synth::lower_meshes into
/// a generated `__mesh_<name>()` fn of constant ST_GARR assignments (data
/// as code — the wire format, loader, and runtime never learn meshes
/// existed). Compile-time quantization (round to Q24.8) means the same
/// .obj + same compiler = bit-identical bytes: determinism is preserved by
/// construction, not by runtime discipline.
#[derive(Debug, Clone)]
pub struct MeshDecl {
    pub name: String,   // becomes the global fixed[] array + __mesh_<name> fn
    pub path: String,   // .obj path, relative to the entry source file
    pub scale: Option<i32>, // Q24.8 scale factor applied before quantize
    pub line: u32,
}

#[derive(Debug, Clone)]
pub struct StructDecl {
    pub name: String,
    pub fields: Vec<FieldDecl>,
    pub line: u32,
}

#[derive(Debug, Clone)]
pub struct MixinDecl {
    pub name: String,
    pub fields: Vec<FieldDecl>,
    /// v20 MIXINS: `mixin body { use movable, mass: u8 }` — mixins may
    /// compose other mixins (cycles rejected). Resolved by synth::expand
    /// before checking, exactly like prefab parents.
    pub uses: Vec<String>,
    pub line: u32,
}

/// v20 SIGNALS — the C# event/delegate analog, the LILA way.
/// `signal #death { boom_flash, drop_loot }` binds a #atom to a list of
/// 0-param helper fns fired in declaration order by `emit #death;`.
/// PURELY compile-time: the fn list rides the EMIT opcode's extra words —
/// the runtime has no signal registry, no dispatch table, no new sections.
#[derive(Debug, Clone)]
pub struct SignalDecl {
    pub atom: u16,
    pub handlers: Vec<String>,
    pub line: u32,
}

/// v20 POOLS — the C# List&lt;T&gt; / C++ std::vector analog, the LILA way.
/// A `pool Trail (256) { x: fixed  life: u8 = 30 }` declares a dynamic
/// append-only SoA side table: rows grow to the declared capacity inside
/// the flat memory image (a dedicated plane), handles are u32
/// (gen&lt;&lt;20 | idx) exactly like entities, and `push` / `remove` (swap) /
/// `for (t: Trail)` / `plen` / `pfull` are the whole API. Because the plane
/// is part of c.mem, snapshots, rewind and the wyhash chain capture pool
/// state with the same 2MB memcpy as everything else.
#[derive(Debug, Clone)]
pub struct PoolDecl {
    pub name: String,
    pub cap: u32,
    pub fields: Vec<FieldDecl>,
    pub line: u32,
}

#[derive(Debug, Clone)]
pub struct EntityDecl {
    pub name: String,
    pub fields: Vec<FieldDecl>,
    /// v8 OPTIMIZER: fsm this entity drives. The checker synthesizes a
    /// minimum-width `fsm_state` bitfield into the schema (e.g. 5 states ->
    /// u3) and opt::fsm bakes the transition table.
    pub fsm: Option<String>,
    /// v10 PREFABS (Unity prefab analog): `entity FastDrone from Drone {
    /// ... }` inherits every parent field at compile time; the child's own
    /// blocks override defaults (same name = same type, new value) and may
    /// append fields. Resolved by synth::expand before checking — the
    /// checker/codegen/runtime never see inheritance at all.
    pub from: Option<String>,
    /// v10 PARTICLES: per-entity slot capacity override (the `(192)` in
    /// `particles #boomfx (192) { ... }`). The checker uses it instead of
    /// game.capacity for this type's max_live.
    pub max_live_override: Option<u32>,
    /// v11 ARRAYS: per-instance arrays (`arr fixed[16] trail;` inside the
    /// entity block). Stored in a dedicated per-type plane OUTSIDE the 32B
    /// dense rows — arrays never touch the bit-packed field layout.
    pub arrs: Vec<ArrDecl>,
    /// v20 MIXINS (C++ composition / Unity component analog):
    /// `entity Enemy { use movable, hp: u8 }` splices the mixin's fields
    /// into this entity at compile time (use order first, then own fields;
    /// duplicates are a pointed error). Pure authoring sugar — zero runtime
    /// bytes, the SoA layout sees one flat field list.
    pub uses: Vec<String>,
    /// v21 BODY (Unity Rigidbody2D-lite): `body { gravity: 0.25 bounce: 0.5
    /// drag: 0.02 }` — compiler-synthesized dynamics. The synthesized update
    /// prologue applies gravity + drag (semi-implicit Euler, BEFORE the
    /// engine's pos += vel integration) and the next frame's prologue reflects
    /// out-of-bounds positions with the restitution factor. Pure bytecode —
    /// there is no physics engine in the runtime, the physics IS the game's
    /// own update code. Requires a non-wrapping world (bounce needs walls).
    pub body: Option<BodyDecl>,
}

/// v21: `body { gravity: fixed  bounce: fixed  drag: fixed }` — all optional
/// (default 0), literals only (they are baked into the synthesized code).
#[derive(Debug, Clone, Default)]
pub struct BodyDecl {
    pub gravity: Option<i32>, // Q24.8 bits
    pub bounce: Option<i32>,  // Q24.8 bits
    pub drag: Option<i32>,    // Q24.8 bits
    pub line: u32,
}

/// v21 DICTS: `dict Kills (256)` — deterministic u32->u32 open-addressing
/// table in the flat image tail (C# Dictionary / C++ unordered_map, LILA
/// style: power-of-two capacity, linear probing, backward-shift deletion,
/// splitmix hashing — all engine-side, all snapshot-safe). mput/mget/mdel/
/// mlen are the whole API. Keys 0xFFFFFFFF are reserved (the empty marker).
#[derive(Debug, Clone)]
pub struct DictDecl {
    pub name: String,
    pub cap: u32, // slots (power of two, checker-enforced)
    pub line: u32,
}

/// v21 COLLIDE (Unity OnCollisionEnter2D analog): `collide Bullet vs Rock
/// (14) { hit_bullet_rock }` — gameplay synthesis lowers it to the nested
/// live-scan loop + circle test + handler call appended to update(). The
/// handler is a user fn taking the two entity types as params. Pure AST —
/// there is NO collision machinery in the runtime.
///
/// v22 CONTACT EDGES: `enter` / `exit` after the radius select Unity's
/// OnCollisionEnter2D / OnCollisionExit2D semantics (UE BeginOverlap /
/// EndOverlap). Enter fires the handler ONCE when contact begins (2 params:
/// a, b — the first touching partner); exit fires ONCE when the LAST contact
/// is lost (1 param: a — the departed partner is unreachable by design,
/// there are no dangling refs to kill). Lowered via a synthesized `touch`
/// counter field on A — still zero runtime.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CollMode { Stay, Enter, Exit }

#[derive(Debug, Clone)]
pub struct CollideDecl {
    pub a: String,
    pub b: String,
    pub radius: u32, // combined hit circle, whole pixels
    pub handler: String,
    pub mode: CollMode, // v22: Stay (fires every touching frame) | Enter | Exit
    pub line: u32,
}

/// v21 LEVELS (Unity Tilemap-lite): `level #arena { grid [ "..XX.." ... ]
/// legend { X: place_rock } }` — ASCII placement. Each non-dot cell calls its
/// legend fn with (col, row) int args at init time; the fn decides what to
/// spawn and where. Synthesized into plain `call fn(c, r);` statements — the
/// runtime never knows a level existed.
#[derive(Debug, Clone)]
pub struct LevelDecl {
    pub atom: u16,
    pub grid: Vec<String>,
    pub legend: Vec<(char, String)>,
    pub line: u32,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Pat { Flat, Noise }

#[derive(Debug, Clone)]
pub struct PolyDecl {
    pub pts: Vec<(i32, i32)>,
    pub fill: u32,
    pub grad: Option<u32>,
    pub add: bool,
    pub pat: Pat,
}

#[derive(Debug, Clone)]
pub struct SpriteDecl {
    pub atom: u16,
    pub polys: Vec<PolyDecl>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Wave { Square, Tri, Noise, Saw }

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Step {
    Note(u8), // semitone index 0..=95 (0 = C1)
    Hold,
    Silence,
    Hit, // noise hit marker 'x'
}

#[derive(Debug, Clone)]
pub struct VoiceDecl {
    pub wave: Wave,
    pub steps: Vec<Step>,
    pub vol: u8,
}

#[derive(Debug, Clone)]
pub struct MusicDecl {
    pub atom: u16,
    pub bpm: u32,
    pub voices: Vec<VoiceDecl>,
}

#[derive(Debug, Clone)]
pub struct SfxDecl {
    pub atom: u16,
    pub wave: Wave,
    pub freq: i32,
    pub sweep: i32,
    pub decay: i32,
    pub vol: u32,
    /// v8 OPTIMIZER: build-time audio-synthesis source. When present, the
    /// compiler READS the .wav AT BUILD TIME (dev-time only — the player's
    /// runtime never sees a file), fits an O(1) f(t) model to the PCM and
    /// bakes the fitted parameters into the .libyte. The string is an asset
    /// PATH, not a runtime string — the no-runtime-strings rule is intact:
    /// nothing here survives into the bytecode except numbers.
    pub from: Option<String>,
}

/// v10 PARTICLES — Niagara/VFX-Graph analog as a COMPILE-TIME emitter.
/// A `particles #boomfx (192) { ... }` block is not a runtime subsystem:
/// synth::expand lowers it into an ordinary entity type + `emit_X` helper +
/// `update(X)` + `draw(X)` fn trio, and the rest of the pipeline (SoA
/// packing, spawn budgets, integration, draw pass) treats them like
/// hand-written code. Zero runtime bytes, zero new opcodes.
#[derive(Debug, Clone)]
pub struct ParticleDecl {
    pub atom: u16,
    /// live-particle slot capacity
    pub cap: u32,
    /// sprite drawn per particle (atom in the sprite domain)
    pub sprite: u16,
    /// particle lifetime in frames (ttl counts down from here)
    pub life: u32,
    /// initial speed, Q24.8 px/frame
    pub speed_fix: i32,
    /// speed jitter 0..1 in Q8 (0 = constant speed)
    pub jitter_q8: u32,
    /// velocity retention per frame in Q8 (256 = no drag)
    pub drag_q8: u32,
    /// downward acceleration, Q24.8 px/frame^2
    pub grav_fix: i32,
    /// particles spawned per emit()
    pub burst: u32,
    /// base RGB tint (alpha computed from ttl when fade)
    pub color: u32,
    /// scale + alpha fade linearly over the lifetime
    pub fade: bool,
}

/// v8 OPTIMIZER SUBSYSTEM 5 — AI state machines.
/// Parsed verbatim; the compiler (opt::fsm) enumerates states, compiles every
/// guard to a predicate program, and synthesizes the bit-plane transition
/// table T[state][events] that the runtime consults with ONE shift+mask.
#[derive(Debug, Clone)]
pub struct FsmDecl {
    pub atom: u16,
    pub name: String,
    /// (state name, guard list) — guard = (predicate expr, target state name)
    pub states: Vec<(String, Vec<(Expr, String)>)>,
    pub line: u32,
}

#[derive(Debug, Clone)]
pub struct AnimDecl {
    pub atom: u16,
    pub keys: Vec<(u32, i32)>, // (t frames, value Q24.8)
}

#[derive(Debug, Clone)]
pub struct TableDecl {
    pub name: String,
    pub entries: Vec<(u8, String)>,
}

/// v8 OPTIMIZER intrinsic — emitted ONLY by compiler passes (never parsed).
/// It is the unchecked-intrinsics channel between the metaprogramming passes
/// and codegen: the pass has already proven operand types, so codegen uses
/// the fixed result type below instead of re-deriving it.
/// The checker rejects these if one ever leaks into user code (defensive).
pub const INTR_BIT01: u16 = 1;      // (bool) -> int 0/1        [no-op at VM level]
pub const INTR_FSM_NEXT: u16 = 2;   // (em, state) -> next state via bit-plane table
pub const INTR_COLL_MASK: u16 = 3;  // (cx, cy) -> u32 live-slot bitmask (Galois lanes)
pub const INTR_SEL: u16 = 4;        // (cond, then_val, else_val) -> branchless cond-move

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum UnOp { Neg, Not }

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum BinOp {
    Add, Sub, Mul, Div, Mod,
    And, Or, Xor, Shl, Shr,
    Eq, Ne, Lt, Gt, Le, Ge,
    LAnd, LOr,
}

#[derive(Debug, Clone)]
pub enum Expr {
    IntLit(u32),
    FixLit(i32),
    /// v20: f32 literal — raw IEEE binary32 bits (the VM value model).
    F32Lit(u32),
    /// v23 TIER-1: f64 literal — raw IEEE binary64 bits. Marks the fn as
    /// Tier-1 (see opt::tier). Codegen currently rejects this; the tier
    /// purity fixpoint and optimizer gates fire correctly end-to-end.
    F64Lit(u64),
    BoolLit(bool),
    Atom(u16),
    Ident(String),
    Field(Box<Expr>, String),
    /// v11 ARRAYS: `name[i]` (global array) or `e.name[i]` (entity array).
    /// The checker resolves the base to an array id and enforces the element
    /// type; literal indices are bounds-PROVEN at compile time.
    Index(Box<Expr>, Box<Expr>),
    Unary(UnOp, Box<Expr>),
    Binary(BinOp, Box<Expr>, Box<Expr>),
    /// v17: `cond ? a : b` — lazy ternary (only the taken arm evaluates,
    /// exactly like an if/else). Types: cond bool, arms must unify (int
    /// widens to fixed like every other value context).
    Ternary(Box<Expr>, Box<Expr>, Box<Expr>),
    Call(String, Vec<Expr>), // builtins: key sin cos ang fixed int rand anim count swept_hit
                             // v17: also USER fns (helpers/scene) with return values
    /// optimizer-only intrinsic (see INTR_* consts). aux = opcode context
    /// (fsm table index / entity type), consts carry folded immediates.
    Intrin(u16, u16, Vec<Expr>, Vec<i32>),
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum AssignOp { Set, Add, Sub, Mul, Div, Mod, And, Or, Xor, Shl, Shr }


#[derive(Debug, Clone)]
pub enum Stmt {
    Let(String, Expr),
    Assign(Expr, AssignOp, Expr),
    If(Expr, Vec<Stmt>, Vec<Stmt>), // else-if chains nest If in the else vec
    While(Expr, Vec<Stmt>),
    For(String, String, Vec<Stmt>), // (var, entity type, body)
    /// v17: `for (i: A..B) { ... }` — integer counting loop, half-open range
    /// (A inclusive, B exclusive), step +1. Both bounds are evaluated ONCE
    /// before the first iteration and must be int-typed; the loop variable
    /// is a fresh Int local for the body's scope.
    ForNum(String, Expr, Expr, Vec<Stmt>),
    /// v17: `break;` — exit the innermost enclosing loop.
    Break,
    /// v17: `continue;` — next iteration of the innermost enclosing loop.
    Continue,
    /// v17: `switch (x) { 0: {...} 1|2: {...} default: {...} }` — lowered to
    /// an if/else chain (scrutinee evaluated ONCE into a temp). Each arm's
    /// label list is one or more literals — (raw value, is_fixed_literal);
    /// an int label against a fixed scrutinee widens (`v << 8`) exactly like
    /// the `==` operator does. `default` runs when no arm matches. No
    /// fallthrough.
    Switch(Expr, Vec<(Vec<(i64, bool)>, Vec<Stmt>)>, Option<Vec<Stmt>>),
    Spawn(String, Vec<(String, Expr)>),
    Kill(Expr),
    Sfx(u16),
    Music(u16),
    StopMusic,
    Shake(u32),                               // screen-shake amplitude (px, literal)
    /// v11 3D: `cam3(x, y, z, yaw, pitch);` — position the 3D camera (fixed
    /// xyz + ang yaw/pitch). Registers live in page 0 of flat memory, so
    /// snapshots/rewind/rollback capture them with the standard 2MB memcpy.
    Cam3(Expr, Expr, Expr, Expr, Expr),
    /// v11 3D: `draw3d(mesh, n, x, y, z, yaw, rgba);` — software mesh pass.
    /// `mesh` names a GLOBAL array holding packed local-space vertices
    /// (3 fixed per vertex). The ENGINE transforms (yaw+translate), views,
    /// perspective-projects, backface-culls, near-clips, depth-sorts and
    /// rasterizes — the Burst pattern: Lila orchestrates, native code crunches.
    Draw3d {
        arr: String,
        n: Expr,
        x: Expr,
        y: Expr,
        z: Expr,
        yaw: Expr,
        rgba: Expr,
    },
    /// v12 ARTICULATION — mat4/quat builtins ON TOP OF ARRAYS. A mat4 is 16
    /// consecutive fixed cells (column-major, translation in cells 12..14),
    /// a quat is 4 consecutive cells (x, y, z, w) of a GLOBAL array. Each
    /// statement is ONE native VM opcode: the game orchestrates the rig,
    /// the engine crunches the math (the Burst pattern that keeps Lila
    /// games lightweight without a floating-point unit anywhere).
    ///   quat_aa(q, off, ax, ay, az, ang) — q[off..off+3] = axis-angle quat
    ///   qmul(d, doff, a, aoff, b, boff)  — d = a*b (Hamilton)
    ///   m4qt(m, moff, q, qoff, tx, ty, tz) — M = T(t) * R(q) in one op
    ///   m4mul(d, doff, a, aoff, b, boff) — d = a*b (d may alias a or b)
    ///   skinv(v, voff, m, moff, x, y, z) — v[voff..+2] = M * (x,y,z,1)
    QuatAA {
        q: String,
        off: Expr,
        ax: Expr,
        ay: Expr,
        az: Expr,
        ang: Expr,
    },
    QMul {
        d: String,
        doff: Expr,
        a: String,
        aoff: Expr,
        b: String,
        boff: Expr,
    },
    M4QT {
        m: String,
        moff: Expr,
        q: String,
        qoff: Expr,
        tx: Expr,
        ty: Expr,
        tz: Expr,
    },
    M4Mul {
        d: String,
        doff: Expr,
        a: String,
        aoff: Expr,
        b: String,
        boff: Expr,
    },
    SkinV {
        v: String,
        voff: Expr,
        m: String,
        moff: Expr,
        x: Expr,
        y: Expr,
        z: Expr,
    },
    /// v12 INDEXED MESH PASS: `draw3di(verts, nv, idx, ni, x, y, z, yaw,
    /// rgba);` — verts is a global array of 3 fixed per vertex (shared
    /// vertex buffer, animated by skinv), idx a global array of vertex
    /// indices (3 per tri). The engine transforms/views/projects/culls/
    /// sorts/rasterizes exactly like draw3d, but triangles address the
    /// shared vertices — the GPU vertex/index-buffer vocabulary, and the
    /// shape every articulated/skinned model is submitted in.
    Draw3DI {
        verts: String,
        nv: Expr,
        idx: String,
        ni: Expr,
        x: Expr,
        y: Expr,
        z: Expr,
        yaw: Expr,
        rgba: Expr,
    },
    Camera(Expr, Expr),                       // v7: aim the viewport at a world point (fixed, fixed)
    MusicVol(u32),                            // v7: master music volume 0..16 (literal)
    Save(Expr, Expr),                         // v7: save(ix, value) -> SRAM slot 0..63
    Goto(u16),
    Draw(u16, Expr, Expr, Expr, Expr, Expr), // sprite, x, y, rot, scale, rgba
    DrawText(u16, Expr, Expr, Expr),        // text atom, x, y, rgba
    DrawNum(Expr, Expr, Expr, Expr),        // value, x, y, rgba
    CallStmt(String, Vec<Expr>),
    CallTable(String, Box<Expr>, String), // table name, key expr, entity var name
    /// v17 RETURN VALUES: `return;` (None) or `return expr;` (Some).
    /// A fn with ANY valued return gets a return type (inferred by unifying
    /// all of them; int widens to fixed); void `return;` in a valued fn means
    /// `return 0;` and falling off the end returns 0 (matching the language's
    /// forgiving arithmetic style). Auto-run fns (init/update/draw/table)
    /// cannot return values — the value would be discarded silently.
    Return(Option<Expr>),
    /// v17 3D: `m4look(m, off, ex, ey, ez, tx, ty, tz);` — build a view matrix
    /// that looks from eye (ex,ey,ez) at target (tx,ty,tz) with +Z up
    /// (the engine's handedness), stored column-major at m[off..off+15].
    /// One native opcode — aims rigs, turrets and planar shadows without
    /// hand-rolled trig. Gameplay-side only (like the rest of the rig math).
    M4Look {
        m: String,
        moff: Expr,
        ex: Expr,
        ey: Expr,
        ez: Expr,
        tx: Expr,
        ty: Expr,
        tz: Expr,
    },
    /// v8 OPTIMIZER: `fsm_step(#name);` — parsed form. The checker validates
    /// placement (entity fn, entity drives that fsm); opt::fsm REWRITES it
    /// into the branchless event-mask + FSM_NEXT form before codegen.
    FsmStep(u16),
    /// optimizer-only: iterate the live slots named by a Galois lane mask.
    /// (var, entity type, mask local name, body). Never parsed; produced by
    /// opt::physics when it compiles a collision loop to immediate bitmasks.
    ForMask(String, String, String, Vec<Stmt>),
    /// v20 POOLS: `push Trail { x: 1.0, life: 30 };` — append a row (fields
    /// evaluated in written order, unlisted fields get their defaults).
    /// Denial when full is silent-ish (a diagnostics counter), exactly like
    /// entity spawn budgets. Gameplay-side only.
    PoolPush(String, Vec<(String, Expr)>),
    /// v20 POOLS: `remove(t);` — gen-checked swap-remove of the row the
    /// handle points at. Stale handles are a no-op (soft-land, like kill).
    PoolRemove(Expr),
    /// v20 COROUTINES: `state hunt { ... }` — a per-frame re-entering
    /// behavior segment of the entity's update fn. Lowered by states::expand
    /// (pre-check) into a switch over the synthesized `st: u8` field.
    State(String, Vec<Stmt>),
    /// v20 COROUTINES: `wait(30);` — suspend this entity's state body for
    /// 30 frames, then resume AFTER this statement. Direct child of a state
    /// block only (phase splitting is top-level).
    Wait(Expr),
    /// v20 COROUTINES: `-> hunt;` — transition to a state (any depth inside
    /// the state's control flow). The synthesized field write + early return.
    GotoState(String),
    /// v20 SIGNALS: `emit #death;` — fire the signal's handler fns in
    /// declaration order. Gameplay-side only (handlers may mutate).
    Emit(u16),
    /// v21 DICTS: `mput(Kills, key, val);` — insert/overwrite a row.
    /// Gameplay-side only.
    MapPut(String, Expr, Expr),
    /// v21 DICTS: `mdel(Kills, key);` — remove a row (missing key: no-op).
    MapDel(String, Expr),
    /// v21 SORT: `psort(Trail, score);` / `psort(Trail, score, 1);` — stable
    /// engine-side radix sort of the pool's live rows by the field key
    /// (0 = ascending, 1 = descending). Iteration order after the sort IS the
    /// key order; existing row handles go stale (gens move with rows).
    PSort(String, String, u8),
    /// v21 ARCADE: `draw_numz(v, digits, x, y, rgba);` — zero-padded integer
    /// (the scoreboard form of draw_num). Draw-fn only.
    DrawNumZ(Expr, u32, Expr, Expr, Expr),
    /// v22 QUEUES: `qpush(Q, val);` — ring append onto a queue decl's hidden
    /// array (cell 0 = head, cell 1 = tail, data = 2 + i % dcap). Full table
    /// drops the value (the soft-land contract). Gameplay-side only.
    QPush(String, Expr),
    /// v22 STACKS: `spush(S, val);` — LIFO append. Full drops the value.
    SPush(String, Expr),
    /// v22 ARRAYS: `afill(A, val);` — fill the whole array (Array.Fill /
    /// memset). Gameplay-side only.
    AFill(String, Expr),
    /// v22 ARRAYS: `acopy(dst, src, n);` — copy the first n cells
    /// (Array.Copy / memcpy, clamped to both capacities). Gameplay-side only.
    ACopy(String, String, Expr),
    /// v22 ARRAYS: `ashuffle(A, n);` — Fisher-Yates over the first n cells
    /// driven by the hashed LCG chain (Random.Shuffle / std::shuffle,
    /// deterministic: the rand register is snapshot/rewind state).
    AShuf(String, Expr),
    /// v23 STEP 8: `try { ... } catch (e) { ... }` — exception handling.
    /// Tier-1 statement. The tier purity fixpoint demotes any fn that
    /// uses TryCatch to Tier-1 (Tier-0 fns cannot throw — the fixpoint
    /// guarantees this, so the optimizer can assume no exceptions).
    /// Codegen lowers this to zero-cost unwind tables (the catch block
    /// is registered as an unwind target; if no exception fires, the
    /// cost is one table entry per try, zero runtime overhead).
    TryCatch {
        body: Vec<Stmt>,
        catch_var: String,
        catch_body: Vec<Stmt>,
    },
    /// v23 STEP 8: `throw expr;` — raise an exception. Tier-1 statement.
    /// The expr is evaluated and passed to the nearest enclosing catch.
    /// Tier-0 fns cannot throw (the tier purity fixpoint rejects `throw`
    /// in Tier-0 fns — they'd be demoted to Tier-1 first).
    Throw(Expr),

    /// v23.2 SPANS: a parsed statement tagged with the (line, col) of its
    /// FIRST token. The parser wraps every statement it emits; every walker
    /// (checker, codegen, optimizer passes, purity walks) forwards through
    /// it, so semantic errors report the STATEMENT's position instead of
    /// the enclosing fn's line. One variant instead of per-variant span
    /// fields — leaf match arms are untouched, and the ~15 recursive
    /// walkers each grow a single forwarding arm.
    At {
        line: u32,
        col: u32,
        inner: Box<Stmt>,
    },
}

impl Stmt {
    /// Unwrap `At` layers to the real statement (spans are positional
    /// metadata, never semantics). Any semantic question about a statement
    /// ("is this a spawn?", "is this return-valued?") must look THROUGH it.
    pub fn inner(&self) -> &Stmt {
        match self {
            Stmt::At { inner, .. } => inner.inner(),
            other => other,
        }
    }
}

#[derive(Debug, Clone)]
pub struct FnDecl {
    pub name: String,
    pub params: Vec<(String, Ty)>,
    pub body: Vec<Stmt>,
    pub line: u32,
    /// v21 TIMERS (Unity InvokeRepeating analog): `fn tick() every 32 { }` —
    /// gameplay synthesis prepends a modulo guard call into update(). The
    /// value is the period in frames (1..=65535, literal). None = ordinary fn.
    pub every: Option<u32>,
}

#[derive(Debug, Clone, Default)]
pub struct Program {
    pub game: Option<GameDecl>,
    pub sound_atoms: Vec<u16>,
    pub key_atoms: Vec<u16>,
    pub text_atoms: Vec<(u16, String)>,
    pub scene_atoms: Vec<(u16, String)>, // (atom, fn name)
    pub sprites: Vec<SpriteDecl>,
    pub music: Vec<MusicDecl>,
    pub sfx: Vec<SfxDecl>,
    pub anims: Vec<AnimDecl>,
    pub entities: Vec<EntityDecl>,
    pub globals: Vec<FieldDecl>,
    pub tables: Vec<TableDecl>,
    pub fsms: Vec<FsmDecl>,
    /// v10 PARTICLES: declarative emitters (see ParticleDecl). Lowered to
    /// entities + fns by synth::expand before the checker runs.
    pub particles: Vec<ParticleDecl>,
    /// v20 MIXINS: `mixin movable { x: fixed ... }` — named field groups
    /// spliced into entities via `use`. Resolved (and removed) by
    /// synth::expand before the checker runs.
    pub mixins: Vec<MixinDecl>,
    /// v23.2 STRUCTS: parse-time only; emptied by synth::lower_structs.
    pub structs: Vec<StructDecl>,
    /// v23.2 MESH IMPORT: parse-time only; emptied by synth::lower_meshes.
    pub meshes: Vec<MeshDecl>,
    /// v23.5 MESH BAKING (v6 wire format): lower_meshes no longer emits one
    /// constant ST_GARR per cell (3 instr/cell — capped a mesh at ~150 tris
    /// under the 8192-instruction budget). The quantized cells instead ride
    /// the v6 BAKED COLD-DATA trailer; the loader copies them straight into
    /// the GARR plane before init() runs. Zero instructions, zero init-time
    /// work; the cap becomes the GARR plane itself (~1819 tris at 128 KB).
    /// (array name, Q24.8 cells) — resolved to array ids by the checker.
    pub baked: Vec<(String, Vec<i32>)>,
    /// v8 OPTIMIZER SUBSYSTEM 2 — SDF shape programs parsed from `sdf` blocks.
    /// Dev-time assets: `lilac build` ignores them (the .libyte never carries
    /// them), `lilac shader` symbolically compiles them to WGSL.
    pub sdfs: Vec<crate::opt::sdf::SdfDecl>,
    pub fns: Vec<FnDecl>,
    /// v11 ARRAYS: game-wide arrays from `global { arr ... }`.
    pub garrs: Vec<ArrDecl>,
    /// v20 POOLS: dynamic append-only side tables (see PoolDecl).
    pub pools: Vec<PoolDecl>,
    /// v20 SIGNALS: compile-time event bindings (see SignalDecl).
    pub signals: Vec<SignalDecl>,
    /// v21 DICTS: deterministic u32->u32 tables (see DictDecl).
    pub dicts: Vec<DictDecl>,
    /// v21 COLLIDE declarations (see CollideDecl) — lowered by gameplay::expand.
    pub collides: Vec<CollideDecl>,
    /// v21 LEVELS: ASCII placement grids (see LevelDecl) — lowered by
    /// gameplay::expand.
    pub levels: Vec<LevelDecl>,
}

// ============================================================================
// v23.1 — SHARED CALL-GRAPH WALKER (single-sourced, TOTAL)
// ============================================================================
// The tier purity fixpoint (opt/tier.rs) and the draw-safety fixpoint
// (checker/stmt.rs) both need "every fn this body calls". They each carried
// a hand-rolled walker that visited ONLY `Stmt::CallStmt` — a call in
// EXPRESSION position (`let d = helper(e);`, `x = f() * 2;`, an argument
// inside another call) was invisible to both. That is exactly the drift
// hand-rolled walkers produce, so the walker now lives here once, is
// exhaustive over `Stmt` (no `_ => {}` arm — a new variant is a compile
// error here), and recurses through every expression position including
// assignment targets (an index expression may contain a call).
//
// The `#[allow]`-free exhaustiveness is the point: the compiler's own
// regression for walker drift.

pub fn walk_call_names_stmts<'a>(stmts: &'a [Stmt], f: &mut impl FnMut(&'a str)) {
    for s in stmts {
        walk_call_names_stmt(s, f);
    }
}

fn walk_call_names_expr<'a>(e: &'a Expr, f: &mut impl FnMut(&'a str)) {
    match e {
        Expr::Call(name, args) => {
            f(name);
            for a in args {
                walk_call_names_expr(a, f);
            }
        }
        Expr::Unary(_, a) | Expr::Field(a, _) => walk_call_names_expr(a, f),
        Expr::Index(a, b) | Expr::Binary(_, a, b) => {
            walk_call_names_expr(a, f);
            walk_call_names_expr(b, f);
        }
        Expr::Ternary(c, a, b) => {
            walk_call_names_expr(c, f);
            walk_call_names_expr(a, f);
            walk_call_names_expr(b, f);
        }
        Expr::Intrin(_, _, args, _) => {
            for a in args {
                walk_call_names_expr(a, f);
            }
        }
        Expr::IntLit(_) | Expr::FixLit(_) | Expr::F32Lit(_) | Expr::F64Lit(_)
        | Expr::BoolLit(_) | Expr::Atom(_) | Expr::Ident(_) => {}
    }
}

fn walk_call_names_stmt<'a>(s: &'a Stmt, f: &mut impl FnMut(&'a str)) {
    match s {
        Stmt::Let(_, e) => walk_call_names_expr(e, f),
        Stmt::Assign(target, _, val) => {
            walk_call_names_expr(target, f);
            walk_call_names_expr(val, f);
        }
        Stmt::If(cond, a, b) => {
            walk_call_names_expr(cond, f);
            walk_call_names_stmts(a, f);
            walk_call_names_stmts(b, f);
        }
        Stmt::While(cond, b) => {
            walk_call_names_expr(cond, f);
            walk_call_names_stmts(b, f);
        }
        Stmt::For(_, _, b) | Stmt::ForMask(_, _, _, b) | Stmt::State(_, b) => {
            walk_call_names_stmts(b, f);
        }
        Stmt::ForNum(_, a, b, body) => {
            walk_call_names_expr(a, f);
            walk_call_names_expr(b, f);
            walk_call_names_stmts(body, f);
        }
        Stmt::Break | Stmt::Continue => {}
        Stmt::Switch(scrut, arms, dflt) => {
            walk_call_names_expr(scrut, f);
            for (_, body) in arms {
                walk_call_names_stmts(body, f);
            }
            if let Some(d) = dflt {
                walk_call_names_stmts(d, f);
            }
        }
        Stmt::Spawn(_, inits) => {
            for (_, e) in inits {
                walk_call_names_expr(e, f);
            }
        }
        Stmt::Kill(e) | Stmt::PoolRemove(e) | Stmt::Wait(e) | Stmt::Throw(e) => {
            walk_call_names_expr(e, f)
        }
        Stmt::Sfx(_) | Stmt::Music(_) | Stmt::StopMusic | Stmt::Shake(_)
        | Stmt::Goto(_) | Stmt::FsmStep(_) | Stmt::MusicVol(_)
        | Stmt::GotoState(_) | Stmt::Emit(_) | Stmt::PSort(_, _, _) => {}
        Stmt::Cam3(a, b, c, d, e) => {
            for x in [a, b, c, d, e] {
                walk_call_names_expr(x, f);
            }
        }
        Stmt::Draw3d { n, x, y, z, yaw, rgba, .. } => {
            for x2 in [n, x, y, z, yaw, rgba] {
                walk_call_names_expr(x2, f);
            }
        }
        Stmt::QuatAA { off, ax, ay, az, ang, .. } => {
            for x in [off, ax, ay, az, ang] {
                walk_call_names_expr(x, f);
            }
        }
        Stmt::QMul { doff, aoff, boff, .. }
        | Stmt::M4Mul { doff, aoff, boff, .. } => {
            for x in [doff, aoff, boff] {
                walk_call_names_expr(x, f);
            }
        }
        Stmt::M4QT { moff, qoff, tx, ty, tz, .. } => {
            for x in [moff, qoff, tx, ty, tz] {
                walk_call_names_expr(x, f);
            }
        }
        Stmt::SkinV { voff, moff, x, y, z, .. } => {
            for x2 in [voff, moff, x, y, z] {
                walk_call_names_expr(x2, f);
            }
        }
        Stmt::Draw3DI { nv, ni, x, y, z, yaw, rgba, .. } => {
            for x2 in [nv, ni, x, y, z, yaw, rgba] {
                walk_call_names_expr(x2, f);
            }
        }
        Stmt::Camera(a, b) | Stmt::Save(a, b) => {
            walk_call_names_expr(a, f);
            walk_call_names_expr(b, f);
        }
        Stmt::Draw(_, x, y, rot, scale, rgba) => {
            for x2 in [x, y, rot, scale, rgba] {
                walk_call_names_expr(x2, f);
            }
        }
        Stmt::DrawText(_, x, y, rgba) => {
            for x2 in [x, y, rgba] {
                walk_call_names_expr(x2, f);
            }
        }
        Stmt::DrawNum(v, x, y, rgba) => {
            for x2 in [v, x, y, rgba] {
                walk_call_names_expr(x2, f);
            }
        }
        Stmt::DrawNumZ(v, _, x, y, rgba) => {
            for x2 in [v, x, y, rgba] {
                walk_call_names_expr(x2, f);
            }
        }
        Stmt::CallStmt(name, args) => {
            f(name);
            for a in args {
                walk_call_names_expr(a, f);
            }
        }
        Stmt::CallTable(_, key, _) => walk_call_names_expr(key, f),
        Stmt::Return(Some(e)) => walk_call_names_expr(e, f),
        Stmt::Return(None) => {}
        Stmt::M4Look { moff, ex, ey, ez, tx, ty, tz, .. } => {
            for x in [moff, ex, ey, ez, tx, ty, tz] {
                walk_call_names_expr(x, f);
            }
        }
        Stmt::PoolPush(_, inits) => {
            for (_, e) in inits {
                walk_call_names_expr(e, f);
            }
        }
        Stmt::MapPut(_, k, v) => {
            walk_call_names_expr(k, f);
            walk_call_names_expr(v, f);
        }
        Stmt::MapDel(_, k) => walk_call_names_expr(k, f),
        Stmt::QPush(_, v) | Stmt::SPush(_, v) => walk_call_names_expr(v, f),
        Stmt::AFill(_, v) => walk_call_names_expr(v, f),
        Stmt::ACopy(_, _, n) => walk_call_names_expr(n, f),
        Stmt::AShuf(_, n) => walk_call_names_expr(n, f),
        Stmt::TryCatch { body, catch_body, .. } => {
            walk_call_names_stmts(body, f);
            walk_call_names_stmts(catch_body, f);
        }
        // v23.2 SPANS: positional wrapper — pure metadata, look through.
        Stmt::At { inner, .. } => walk_call_names_stmt(inner, f),
    }
}
