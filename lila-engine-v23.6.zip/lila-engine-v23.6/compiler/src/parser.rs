//! LILA parser — recursive descent, Pratt expressions.
//! Keywords are matched by identifier TEXT (lexer is keyword-free).

use crate::ast::*;
use crate::lexer::Tok;

pub struct Parser {
    toks: Vec<(Tok, u32, u32)>,
    pos: usize,
    pub atom_names: Vec<String>,
    /// v23.2 ERROR RECOVERY: parse errors collected instead of aborting at
    /// the first one. parse_program/parse_block record + resync; callers
    /// drain after the parse (a non-empty list means the AST is partial —
    /// never check or codegen it).
    pub errors: Vec<String>,
    /// v23.2 STRUCTS: names seen so far — `parse_field_type` resolves a
    /// non-keyword ident to Ty::Struct iff it names a declared struct.
    /// Declaration-before-use, enforced at parse time with a clean error.
    struct_names: std::collections::HashSet<String>,
}

impl Parser {
    pub fn new(toks: Vec<(Tok, u32, u32)>, atom_names: Vec<String>) -> Self {
        Parser { toks, pos: 0, atom_names, errors: Vec::new(), struct_names: std::collections::HashSet::new() }
    }

    fn peek(&self) -> &Tok { &self.toks[self.pos].0 }
    fn line(&self) -> u32 { self.toks[self.pos].1 }
    fn col(&self) -> u32 { self.toks[self.pos].2 }
    fn peek_at(&self, off: usize) -> &Tok { &self.toks[std::cmp::min(self.pos + off, self.toks.len() - 1)].0 }

    fn next(&mut self) -> Tok { let t = self.toks[self.pos].0.clone(); self.pos += 1; t }

    fn is_kw(&self, s: &str) -> bool {
        matches!(self.peek(), Tok::Ident(name) if name == s)
    }

    fn eat_kw(&mut self, s: &str) -> bool {
        if self.is_kw(s) { self.pos += 1; true } else { false }
    }

    fn err(&self, msg: &str) -> String {
        format!("parse error at line {}:{}: {} (found {:?})", self.line(), self.col(), msg, self.peek())
    }

    fn expect(&mut self, t: Tok) -> Result<(), String> {
        if *self.peek() == t { self.pos += 1; Ok(()) }
        else { Err(self.err(&format!("expected {:?}", t))) }
    }

    fn expect_ident(&mut self) -> Result<String, String> {
        match self.next() {
            Tok::Ident(s) => Ok(s),
            other => Err(format!("parse error at line {}:{}: expected identifier, found {:?}", self.line(), self.col(), other)),
        }
    }

    fn expect_atom(&mut self) -> Result<u16, String> {
        match self.next() {
            Tok::Atom(a) => Ok(a),
            other => Err(format!("parse error at line {}:{}: expected #atom, found {:?}", self.line(), self.col(), other)),
        }
    }

    fn accept_semi_or_comma(&mut self) {
        // newline-separated items: separators optional
        if matches!(self.peek(), Tok::Semi | Tok::Comma) { self.pos += 1; }
    }

    // ---------------- top level ----------------

    /// Keywords that can start a top-level declaration (the recovery
    /// resync targets).
    const TOP_LEVEL_KWS: [&'static str; 26] = [
        "game", "sound", "key", "text", "scene", "sprite", "music", "sfx",
        "anim", "entity", "particles", "mixin", "pool", "dict", "queue",
        "stack", "collide", "level", "signal", "global", "table", "fsm", "sdf", "fn",
        "struct", "mesh",
    ];

    /// Skip forward to the next plausibly-parseable top-level declaration:
    /// balanced braces/parens/brackets are stepped over; at depth 0 a decl
    /// keyword (or EOF) stops the scan. Returns false at EOF.
    fn sync_top_level(&mut self) -> bool {
        let mut depth: i32 = 0;
        while !matches!(self.peek(), Tok::Eof) {
            if depth == 0 {
                if let Tok::Ident(name) = self.peek() {
                    if Self::TOP_LEVEL_KWS.contains(&name.as_str()) {
                        return true;
                    }
                }
            }
            match self.peek() {
                Tok::LBrace | Tok::LParen | Tok::LBracket => depth += 1,
                Tok::RBrace | Tok::RParen | Tok::RBracket => {
                    if depth > 0 { depth -= 1; }
                }
                _ => {}
            }
            self.pos += 1;
        }
        false
    }

    /// Skip to just past the end of a broken statement: a depth-0 Semi is
    /// consumed and stops the scan; a depth-0 RBrace stops WITHOUT being
    /// consumed (the enclosing block still closes). Returns false at EOF.
    fn sync_stmt(&mut self) -> bool {
        let mut depth: i32 = 0;
        while !matches!(self.peek(), Tok::Eof) {
            match self.peek() {
                Tok::LBrace | Tok::LParen | Tok::LBracket => depth += 1,
                Tok::Semi if depth == 0 => { self.pos += 1; return true; }
                Tok::RBrace if depth == 0 => return true,
                Tok::RBrace | Tok::RParen | Tok::RBracket => {
                    if depth > 0 { depth -= 1; }
                }
                _ => {}
            }
            self.pos += 1;
        }
        false
    }

    pub fn parse_program(&mut self) -> Result<Program, String> {
        let mut p = Program::default();
        while !matches!(self.peek(), Tok::Eof) {
            // v23.2 ERROR RECOVERY: each declaration parses independently —
            // a failure is recorded, the parser resyncs to the next top-level
            // keyword, and the round continues so ONE compile reports every
            // syntax error instead of the first.
            let res: Result<(), String> =
                if self.eat_kw("game") { self.parse_game(&mut p) }
            else if self.eat_kw("sound") { self.parse_sound(&mut p) }
            else if self.eat_kw("key") { self.parse_key(&mut p) }
            else if self.eat_kw("text") { self.parse_text(&mut p) }
            else if self.eat_kw("scene") { self.parse_scene(&mut p) }
            else if self.eat_kw("sprite") { self.parse_sprite(&mut p) }
            else if self.eat_kw("music") { self.parse_music(&mut p) }
            else if self.eat_kw("sfx") && matches!(self.peek(), Tok::Atom(_)) { self.parse_sfx(&mut p) }
            else if self.eat_kw("anim") { self.parse_anim(&mut p) }
            else if self.eat_kw("entity") { self.parse_entity(&mut p) }
            else if self.eat_kw("particles") && matches!(self.peek(), Tok::Atom(_)) { self.parse_particles(&mut p) }
            else if self.eat_kw("mixin") { self.parse_mixin(&mut p) }
            else if self.eat_kw("pool") { self.parse_pool(&mut p) }
            else if self.eat_kw("dict") { self.parse_dict(&mut p) }
            else if self.eat_kw("queue") { self.parse_queue_stack(&mut p, true) }
            else if self.eat_kw("stack") { self.parse_queue_stack(&mut p, false) }
            else if self.eat_kw("collide") { self.parse_collide(&mut p) }
            else if self.eat_kw("level") && matches!(self.peek(), Tok::Atom(_)) { self.parse_level(&mut p) }
            else if self.eat_kw("signal") && matches!(self.peek(), Tok::Atom(_)) { self.parse_signal(&mut p) }
            else if self.eat_kw("global") { self.parse_global(&mut p) }
            else if self.eat_kw("table") { self.parse_table(&mut p) }
            else if self.eat_kw("fsm") && matches!(self.peek(), Tok::Atom(_)) { self.parse_fsm().map(|f| p.fsms.push(f)) }
            else if self.eat_kw("sdf") && matches!(self.peek(), Tok::Atom(_)) { self.parse_sdf().map(|d| p.sdfs.push(d)) }
            else if self.eat_kw("fsm") || self.eat_kw("sdf") {
                Err(self.err("fsm/sdf need a #name"))
            }
            else if self.eat_kw("fn") { self.parse_fn().map(|f| p.fns.push(f)) }
            // v23.2 STRUCTS: user records — flattened away by synth before
            // the checker sees anything.
            else if self.eat_kw("struct") { self.parse_struct(&mut p) }
            // v23.2 MESH IMPORT: `mesh cube from "pyramid.obj" scale 1.0;`
            else if self.eat_kw("mesh") { self.parse_mesh(&mut p) }
            else { Err(self.err("expected a top-level declaration")) };
            if let Err(e) = res {
                self.errors.push(e);
                if !self.sync_top_level() { break; }
            }
        }
        Ok(p)
    }

    fn parse_game(&mut self, p: &mut Program) -> Result<(), String> {
        let mut g = GameDecl { title: String::new(), width: 512, height: 512, wrap: true,
                               world_w: None, world_h: None, capacity: None, optimize: false,
                               mem_mb: None, reflection: false };
        self.expect(Tok::LBrace)?;
        while !matches!(self.peek(), Tok::RBrace) {
            let k = self.expect_ident()?;
            if k == "capacity" && matches!(self.peek(), Tok::LBrace) {
                // capacity { entities: N } — how many live entities per
                // type this game is built for (drives the engine build
                // profile; default 512). Brace form: no colon.
                self.next(); // consume LBrace
                while !matches!(self.peek(), Tok::RBrace) {
                    let ck = self.expect_ident()?;
                    self.expect(Tok::Colon)?;
                    match ck.as_str() {
                        "entities" => {
                            let v = self.parse_int_pt()? as u32;
                            g.capacity = Some(v);
                        }
                        // v20 SCALE: the memory tier (flat image size, MB).
                        // 0 = the engine default. The loader checks it against
                        // the build profile — loud, never silent.
                        "mem" => {
                            let v = self.parse_int_pt()? as u32;
                            g.mem_mb = Some(v);
                        }
                        other => return Err(format!("line {}:{}: unknown capacity field '{}'", self.line(), self.col(), other)),
                    }
                    self.accept_semi_or_comma();
                }
                self.expect(Tok::RBrace)?;
                self.accept_semi_or_comma();
                continue;
            }
            self.expect(Tok::Colon)?;
            match k.as_str() {
                "title" => {
                    g.title = match self.next() {
                        Tok::Str(s) => s,
                        other => return Err(format!("line {}:{}: title needs a string, found {:?}", self.line(), self.col(), other)),
                    };
                }
                "width" => g.width = self.parse_int_pt()? as u32,
                "height" => g.height = self.parse_int_pt()? as u32,
                "wrap" => g.wrap = self.expect_bool()?,
                // v8 OPTIMIZER: opt into the full compile-time pipeline
                // (bit-width synthesis + cache-line SoA repacking). Default
                // false: legacy games keep byte-identical .libyte output.
                "optimize" => g.optimize = self.expect_bool()?,
                // v20 REFLECTION: ship the names trailer (host-side labels)
                "reflection" => g.reflection = self.expect_bool()?,
                // v7: simulation bounds — a world larger than the screen is a
                // scrolling world driven by camera(x, y). Defaults: world == screen.
                "world_w" => {
                    let v = self.parse_int_pt()? as u32;
                    g.world_w = Some(v);
                }
                "world_h" => {
                    let v = self.parse_int_pt()? as u32;
                    g.world_h = Some(v);
                }
                other => return Err(format!("line {}:{}: unknown game field '{}'", self.line(), self.col(), other)),
            }
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        p.game = Some(g);
        Ok(())
    }

    fn parse_sound(&mut self, p: &mut Program) -> Result<(), String> {
        self.expect(Tok::LBrace)?;
        while !matches!(self.peek(), Tok::RBrace) {
            p.sound_atoms.push(self.expect_atom()?);
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        Ok(())
    }

    fn parse_key(&mut self, p: &mut Program) -> Result<(), String> {
        self.expect(Tok::LBrace)?;
        while !matches!(self.peek(), Tok::RBrace) {
            p.key_atoms.push(self.expect_atom()?);
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        Ok(())
    }

    fn parse_text(&mut self, p: &mut Program) -> Result<(), String> {
        self.expect(Tok::LBrace)?;
        while !matches!(self.peek(), Tok::RBrace) {
            let a = self.expect_atom()?;
            self.expect(Tok::Colon)?;
            let s = match self.next() {
                Tok::Str(s) => s,
                other => return Err(format!("line {}:{}: text atom needs a string, found {:?}", self.line(), self.col(), other)),
            };
            p.text_atoms.push((a, s));
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        Ok(())
    }

    fn parse_scene(&mut self, p: &mut Program) -> Result<(), String> {
        self.expect(Tok::LBrace)?;
        while !matches!(self.peek(), Tok::RBrace) {
            let a = self.expect_atom()?;
            self.expect(Tok::Colon)?;
            let f = self.expect_ident()?;
            p.scene_atoms.push((a, f));
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        Ok(())
    }

    fn parse_int_pt(&mut self) -> Result<i32, String> {
        let mut sign = 1i64;
        if matches!(self.peek(), Tok::Minus) { self.pos += 1; sign = -1; }
        match self.next() {
            Tok::Int(v) => Ok((sign * v as i64) as i32),
            other => Err(format!("line {}:{}: expected integer coordinate, found {:?}", self.line(), self.col(), other)),
        }
    }

    fn parse_sprite(&mut self, p: &mut Program) -> Result<(), String> {
        let atom = self.expect_atom()?;
        self.expect(Tok::LParen)?;
        // hit radius: syntactic (documented grammar `sprite #x (12)`) but
        // unused by the engine — collision radii are data fields now.
        // Consumed and validated, never stored.
        let _radius = match self.next() {
            Tok::Int(v) => v,
            other => return Err(format!("line {}:{}: sprite hit radius expected, found {:?}", self.line(), self.col(), other)),
        };
        self.expect(Tok::RParen)?;
        self.expect(Tok::LBrace)?;
        let mut polys = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            if !self.eat_kw("poly") { return Err(self.err("expected 'poly' in sprite body")); }
            self.expect(Tok::LBracket)?;
            let mut pts = Vec::new();
            while !matches!(self.peek(), Tok::RBracket) {
                let x = self.parse_int_pt()?;
                self.expect(Tok::Comma)?;
                let y = self.parse_int_pt()?;
                pts.push((x, y));
                if matches!(self.peek(), Tok::Comma) { self.pos += 1; }
            }
            self.expect(Tok::RBracket)?;
            if pts.len() < 3 { return Err(self.err("poly needs at least 3 points")); }
            let mut poly = PolyDecl { pts, fill: 0xFFFFFFFF, grad: None, add: false, pat: Pat::Flat };
            loop {
                if self.eat_kw("fill") {
                    self.expect(Tok::Colon)?;
                    poly.fill = self.expect_hex()?;
                } else if self.eat_kw("grad") {
                    self.expect(Tok::Colon)?;
                    poly.grad = Some(self.expect_hex()?);
                } else if self.eat_kw("add") {
                    self.expect(Tok::Colon)?;
                    poly.add = self.expect_bool()?;
                } else if self.eat_kw("pat") {
                    self.expect(Tok::Colon)?;
                    let w = self.expect_ident()?;
                    poly.pat = match w.as_str() {
                        "flat" => Pat::Flat,
                        "noise" => Pat::Noise,
                        other => return Err(format!("unknown pattern '{}'", other)),
                    };
                } else { break; }
            }
            polys.push(poly);
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        p.sprites.push(SpriteDecl { atom, polys });
        Ok(())
    }

    fn expect_hex(&mut self) -> Result<u32, String> {
        match self.next() {
            Tok::Int(v) => Ok(v),
            other => Err(format!("line {}:{}: expected hex color literal, found {:?}", self.line(), self.col(), other)),
        }
    }

    fn expect_bool(&mut self) -> Result<bool, String> {
        match self.next() {
            Tok::Ident(s) if s == "true" => Ok(true),
            Tok::Ident(s) if s == "false" => Ok(false),
            other => Err(format!("line {}:{}: expected true/false, found {:?}", self.line(), self.col(), other)),
        }
    }

    fn parse_note_step(&mut self) -> Result<Step, String> {
        match self.next() {
            Tok::Dot => Ok(Step::Silence),
            Tok::Minus => Ok(Step::Hold),
            Tok::Ident(s) if s == "x" => Ok(Step::Hit),
            Tok::Ident(s) => {
                // note like C4, E2, B8
                let bytes = s.as_bytes();
                if bytes.len() < 2 || bytes.len() > 2 {
                    return Err(format!("line {}:{}: bad note '{}' (use e.g. C4)", self.line(), self.col(), s));
                }
                let semi = match bytes[0] {
                    b'C' => 0, b'D' => 2, b'E' => 4, b'F' => 5,
                    b'G' => 7, b'A' => 9, b'B' => 11,
                    _ => return Err(format!("line {}:{}: bad note letter in '{}'", self.line(), self.col(), s)),
                };
                let oct = (bytes[1] as char).to_digit(10).unwrap_or(0);
                if !(1..=8).contains(&oct) {
                    return Err(format!("line {}:{}: bad octave in '{}' (1..8)", self.line(), self.col(), s));
                }
                Ok(Step::Note((((oct - 1) * 12) + semi) as u8))
            }
            other => Err(format!("line {}:{}: bad music step, found {:?}", self.line(), self.col(), other)),
        }
    }

    fn parse_music(&mut self, p: &mut Program) -> Result<(), String> {
        let atom = self.expect_atom()?;
        let mut bpm = 120u32;
        let mut voices = Vec::new();
        self.expect(Tok::LBrace)?;
        while !matches!(self.peek(), Tok::RBrace) {
            let kw = self.expect_ident()?;
            self.expect(Tok::Colon)?;
            match kw.as_str() {
                "bpm" => {
                    bpm = match self.next() {
                        Tok::Int(v) => v,
                        other => return Err(format!("line {}:{}: bpm needs int, found {:?}", self.line(), self.col(), other)),
                    };
                }
                "square" | "tri" | "noise" | "saw" => {
                    let wave = match kw.as_str() {
                        "square" => Wave::Square, "tri" => Wave::Tri,
                        "noise" => Wave::Noise, _ => Wave::Saw,
                    };
                    let mut vol = 12u8;
                    self.expect(Tok::LBracket)?;
                    let mut steps = Vec::new();
                    while !matches!(self.peek(), Tok::RBracket) {
                        steps.push(self.parse_note_step()?);
                    }
                    // format contract: the runtime stores 16 steps per voice
                    // (40B voice slot) — reject loudly at parse time
                    if steps.len() > 16 {
                        return Err(format!("line {}:{}: music voice '{}' has {} steps (max 16 per voice)",
                            self.line(), self.col(), kw, steps.len()));
                    }
                    self.expect(Tok::RBracket)?;
                    // optional trailing vol: N before separator
                    if self.eat_kw("vol") {
                        self.expect(Tok::Colon)?;
                        vol = match self.next() {
                            Tok::Int(v) if v <= 15 => v as u8,
                            _ => return Err(format!("line {}:{}: vol must be 0..15", self.line(), self.col())),
                        };
                    }
                    voices.push(VoiceDecl { wave, steps, vol });
                }
                other => return Err(format!("line {}:{}: unknown music field '{}'", self.line(), self.col(), other)),
            }
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        p.music.push(MusicDecl { atom, bpm, voices });
        Ok(())
    }

    fn parse_sfx(&mut self, p: &mut Program) -> Result<(), String> {
        let atom = self.expect_atom()?;
        let mut d = SfxDecl { atom, wave: Wave::Square, freq: 440, sweep: 0, decay: 20, vol: 10, from: None };
        self.expect(Tok::LBrace)?;
        while !matches!(self.peek(), Tok::RBrace) {
            let k = self.expect_ident()?;
            self.expect(Tok::Colon)?;
            match k.as_str() {
                "wave" => {
                    let w = self.expect_ident()?;
                    d.wave = match w.as_str() {
                        "square" => Wave::Square, "tri" => Wave::Tri,
                        "noise" => Wave::Noise, "saw" => Wave::Saw,
                        other => return Err(format!("line {}:{}: unknown wave '{}'", self.line(), self.col(), other)),
                    };
                }
                "freq" => d.freq = self.parse_int_pt()?,
                "sweep" => d.sweep = self.parse_int_pt()?,
                "decay" => d.decay = self.parse_int_pt()?,
                "vol" => {
                    let v = self.parse_int_pt()?;
                    if !(0..=15).contains(&v) { return Err(format!("line {}:{}: sfx vol must be 0..15", self.line(), self.col())); }
                    d.vol = v as u32;
                }
                // v8 OPTIMIZER subsystem 4: build-time WAV synthesis source.
                // The path is read ONCE at compile time; the .libyte carries
                // only the fitted parameters (no strings, no samples).
                "from" => {
                    let s = match self.next() {
                        Tok::Str(s) => s,
                        other => return Err(format!("line {}:{}: sfx from: needs a path string, found {:?}", self.line(), self.col(), other)),
                    };
                    d.from = Some(s);
                }
                other => return Err(format!("line {}:{}: unknown sfx field '{}'", self.line(), self.col(), other)),
            }
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        p.sfx.push(d);
        Ok(())
    }

    fn parse_anim(&mut self, p: &mut Program) -> Result<(), String> {
        let atom = self.expect_atom()?;
        self.expect(Tok::LBrace)?;
        if !self.eat_kw("keys") { return Err(self.err("anim needs 'keys:'")); }
        self.expect(Tok::Colon)?;
        self.expect(Tok::LBracket)?;
        let mut keys = Vec::new();
        while !matches!(self.peek(), Tok::RBracket) {
            self.expect(Tok::LParen)?;
            let t = match self.next() {
                Tok::Int(v) => v,
                other => return Err(format!("line {}:{}: anim key time expected, found {:?}", self.line(), self.col(), other)),
            };
            self.expect(Tok::Comma)?;
            let mut sign = 1i64;
            if matches!(self.peek(), Tok::Minus) { self.pos += 1; sign = -1; }
            let val = match self.next() {
                Tok::Int(v) => sign * v as i64,
                Tok::Fix(f) => f as i64,
                other => return Err(format!("line {}:{}: anim key value expected, found {:?}", self.line(), self.col(), other)),
            };
            self.expect(Tok::RParen)?;
            keys.push((t, val as i32));
            if matches!(self.peek(), Tok::Comma) { self.pos += 1; }
        }
        self.expect(Tok::RBracket)?;
        self.expect(Tok::RBrace)?;
        if keys.is_empty() { return Err(self.err("anim needs at least one key")); }
        // monotone t check
        for w in keys.windows(2) {
            if w[1].0 <= w[0].0 { return Err(self.err("anim key times must be strictly increasing")); }
        }
        p.anims.push(AnimDecl { atom, keys });
        Ok(())
    }

    fn parse_field_type(&mut self) -> Result<Ty, String> {
        let name = self.expect_ident()?;
        match name.as_str() {
            "fixed" => Ok(Ty::Fixed),
            "f32" => Ok(Ty::F32),
            "f64" => Ok(Ty::F64), // v23 TIER-1: marks the fn/type as Tier-1
            "vec4fixed" => Ok(Ty::Vec4Fixed), // v23 STEP 5: SIMD type, Tier-0
            "vec4u8" => Ok(Ty::Vec4U8),       // v23 STEP 5: SIMD type, Tier-0
            "thread" => {
                // v23.1 HONEST GATE: thread<T> was scaffolding — the type
                // parsed and laid out, but NO spawn/join/await statement
                // ever existed, so a thread<T> handle could never be
                // produced. A loud rejection beats a dead type (re-enable
                // when the VM gains a real job API).
                Err("the thread<T> type is reserved for a future version (no spawn/join exists yet) — the engine's parallel systems run automatically on proven-disjoint update groups".to_string())
            }
            "bool" => Ok(Ty::Bool),
            "ang" => Ok(Ty::Ang),
            "u" => Ok(Ty::UInt(0)),  // 0 = infer marker
            "s" => Ok(Ty::SInt(0)),
            other => {
                if let Some(digits) = other.strip_prefix('u') {
                    let w: u8 = digits.parse().map_err(|_| format!("bad width in '{}'", other))?;
                    if !(1..=16).contains(&w) { return Err(format!("u{} width out of range 1..16", w)); }
                    return Ok(Ty::UInt(w));
                }
                if let Some(digits) = other.strip_prefix('s') {
                    let w: u8 = digits.parse().map_err(|_| format!("bad width in '{}'", other))?;
                    if !(1..=16).contains(&w) { return Err(format!("s{} width out of range 1..16", w)); }
                    return Ok(Ty::SInt(w));
                }
                // v23.2 STRUCTS: a declared struct name wins over the entity
                // fallback (a name may not be both — synth rejects dupes).
                if self.struct_names.contains(&name) {
                    return Ok(Ty::Struct(name));
                }
                Ok(Ty::Entity(name)) // entity-typed helper param — checker validates
            }
        }
    }

    fn parse_field(&mut self) -> Result<FieldDecl, String> {
        let cold = self.eat_kw("cold");
        let name = self.expect_ident()?;
        self.expect(Tok::Colon)?;
        let ty = self.parse_field_type()?;
        let mut f = FieldDecl { name, ty, default_int: None, default_fix: None, default_bool: None, cold };
        if matches!(self.peek(), Tok::Eq) {
            self.pos += 1;
            match self.next() {
                Tok::Int(v) => f.default_int = Some(v as i64),
                Tok::Fix(v) => f.default_fix = Some(v),
                Tok::F32(bits) => f.default_int = Some(bits as i64), // raw IEEE bits
                // v23 TIER-1: f64 default. Stored as raw IEEE bits.
                // The low 32 bits ride default_int (the existing field);
                // the high 32 bits would need a new field — for now, only
                // the low bits are stored (sufficient for the tier purity
                // machinery to fire; full f64 codegen is the next step).
                Tok::F64(bits) => f.default_int = Some(bits as i64),
                Tok::Ident(s) if s == "true" => f.default_bool = Some(true),
                Tok::Ident(s) if s == "false" => f.default_bool = Some(false),
                Tok::Minus => match self.next() {
                    Tok::Int(v) => f.default_int = Some(-(v as i64)),
                    Tok::Fix(v) => f.default_fix = Some(-v),
                    other => return Err(format!("line {}:{}: bad default value, found {:?}", self.line(), self.col(), other)),
                },
                other => return Err(format!("line {}:{}: bad default value, found {:?}", self.line(), self.col(), other)),
            }
        }
        self.accept_semi_or_comma();
        Ok(f)
    }

    fn parse_entity(&mut self, p: &mut Program) -> Result<(), String> {
        let name = self.expect_ident()?;
        // v10 PREFABS: `entity FastDrone from Drone { ... }` — the parent is
        // resolved (and the fields merged) by synth::expand after the whole
        // file is parsed, so declaration order is free like everything else.
        let from = if self.is_kw("from") {
            self.pos += 1;
            Some(self.expect_ident()?)
        } else {
            None
        };
        self.expect(Tok::LBrace)?;
        let mut fields = Vec::new();
        let mut arrs = Vec::new();
        let mut fsm: Option<String> = None;
        let mut uses: Vec<String> = Vec::new();
        let mut body_decl: Option<BodyDecl> = None;
        while !matches!(self.peek(), Tok::RBrace) {
            // v8 OPTIMIZER: `fsm: #name` binds a state machine to this entity.
            // Disambiguated from a field literally named `fsm` by the #atom.
            if self.is_kw("fsm") && matches!(self.peek_at(1), Tok::Colon) && matches!(self.peek_at(2), Tok::Atom(_)) {
                self.pos += 2;
                let a = self.expect_atom()?;
                fsm = Some(self.atom_names.get(a as usize).cloned()
                    .ok_or_else(|| format!("line {}:{}: bad fsm atom", self.line(), self.col()))?);
                self.accept_semi_or_comma();
                continue;
            }
            // v20 MIXINS: `use movable` — splice a field group. A field
            // literally named `use` still works (`use: fixed` — the colon
            // disambiguates, same trick as `fsm:`).
            if self.is_kw("use") && matches!(self.peek_at(1), Tok::Ident(_)) {
                self.pos += 1;
                uses.push(self.expect_ident()?);
                self.accept_semi_or_comma();
                continue;
            }
            // v11 ARRAYS: `arr fixed[16] trail;` inside an entity block = a
            // per-instance array (its own plane, not a bit-packed field).
            if self.is_kw("arr") {
                arrs.push(self.parse_arr()?);
                continue;
            }
            // v21 BODY: `body { gravity: 0.25 bounce: 0.5 drag: 0.02 }` — the
            // Rigidbody2D-lite dynamics block (fields with colons, so a field
            // literally named `body` still parses fine).
            if self.is_kw("body") && matches!(self.peek_at(1), Tok::LBrace) {
                self.pos += 1; // consume 'body'
                let (bl, bc) = (self.line(), self.col());
                self.expect(Tok::LBrace)?;
                let mut bd = BodyDecl { line: self.line(), ..Default::default() };
                while !matches!(self.peek(), Tok::RBrace) {
                    let k = self.expect_ident()?;
                    self.expect(Tok::Colon)?;
                    let neg = if matches!(self.peek(), Tok::Minus) { self.pos += 1; true } else { false };
                    let v = match self.next() {
                        Tok::Fix(v) => v,
                        Tok::Int(v) => (v as i32) << 8, // whole-number literals are fine too
                        other => return Err(format!("line {}:{}: body '{}' needs a fixed literal, found {:?}", bl, bc, k, other)),
                    };
                    let v = if neg { -v } else { v };
                    match k.as_str() {
                        "gravity" => bd.gravity = Some(v),
                        "bounce" => {
                            if v < 0 || v > 256 { return Err(format!("line {}:{}: body bounce is 0.0..1.0", bl, bc)); }
                            bd.bounce = Some(v);
                        }
                        "drag" => {
                            if v < 0 || v > 256 { return Err(format!("line {}:{}: body drag is 0.0..1.0", bl, bc)); }
                            bd.drag = Some(v);
                        }
                        other => return Err(format!("line {}:{}: unknown body field '{}' (gravity / bounce / drag)", bl, bc, other)),
                    }
                    self.accept_semi_or_comma();
                }
                self.expect(Tok::RBrace)?;
                self.accept_semi_or_comma();
                body_decl = Some(bd);
                continue;
            }
            fields.push(self.parse_field()?);
        }
        self.expect(Tok::RBrace)?;
        p.entities.push(EntityDecl { name, fields, fsm, from, max_live_override: None, arrs, uses, body: body_decl });
        Ok(())
    }

    /// v11 ARRAYS: `arr <ty>[<cap>] <name>;` — element type, compile-time
    /// capacity, no default (zero-initialized). Used in global + entity blocks.
    /// v12: array arguments accept a plain global name or an `e.name`
    /// dotted form; the CHECKER rejects anything that isn't a global array
    /// with a precise message (rig storage is shared, not per-instance).
    fn parse_arr_ref(&mut self) -> Result<String, String> {
        let base = self.expect_ident()?;
        if matches!(self.peek(), Tok::Dot) {
            self.pos += 1;
            let arr = self.expect_ident()?;
            return Ok(format!("{}.{}", base, arr));
        }
        Ok(base)
    }

    fn parse_arr(&mut self) -> Result<ArrDecl, String> {
        let (line, col) = (self.line(), self.col());
        self.pos += 1; // consume 'arr'
        // v22: `u32` / `s32` are legal ONLY as array element types (raw
        // 32-bit cells — the queue substrate and general int buffers).
        // SoA fields keep the 1..=16 width contract; arrays are raw cells
        // anyway so width 32 costs nothing and packs nothing.
        let elem = if self.is_kw("u32") { self.pos += 1; Ty::UInt(32) }
            else if self.is_kw("s32") { self.pos += 1; Ty::SInt(32) }
            else { self.parse_field_type()? };
        self.expect(Tok::LBracket)?;
        let cap = match self.next() {
            Tok::Int(v) if v >= 1 && v <= 16384 => v,
            other => return Err(format!("line {}:{}: array capacity must be an integer literal 1..=16384, found {:?}", line, col, other)),
        };
        self.expect(Tok::RBracket)?;
        // v17 TWO-DIMENSIONAL ARRAYS: an optional second extent makes this a
        // row-major grid (`arr fixed[8][8] grid;`). The stored capacity is
        // the PRODUCT — the wire format and runtime plane are unchanged.
        let mut dims: Vec<u32> = Vec::new();
        if matches!(self.peek(), Tok::LBracket) {
            self.pos += 1;
            let d2 = match self.next() {
                Tok::Int(v) if v >= 1 && v <= 16384 => v,
                other => return Err(format!("line {}:{}: second array extent must be an integer literal 1..=16384, found {:?}", line, col, other)),
            };
            self.expect(Tok::RBracket)?;
            dims.push(cap);
            dims.push(d2);
            if (dims[0] as u64) * (dims[1] as u64) > 16384 {
                return Err(format!("line {}:{}: total array size {}x{} exceeds 16384 cells", line, col, cap, d2));
            }
        }
        let name = self.expect_ident()?;
        self.accept_semi_or_comma();
        let total = if dims.is_empty() { cap } else { dims[0] * dims[1] };
        Ok(ArrDecl { name, elem, cap: total, dims, line })
    }

    /// v10 PARTICLES: `particles #boomfx (192) { sprite: #p  life: 22
    /// speed: 1.8  drag: 0.92 ... }` — parsed into a ParticleDecl and lowered
    /// to an entity + emit/update/draw fns by synth::expand.
    fn parse_particles(&mut self, p: &mut Program) -> Result<(), String> {
        let atom = self.expect_atom()?;
        self.expect(Tok::LParen)?;
        let cap = self.parse_int_pt()? as u32;
        self.expect(Tok::RParen)?;
        self.expect(Tok::LBrace)?;
        let mut sprite: Option<u16> = None;
        let (mut life, mut speed_fix, mut jitter_q8) = (24u32, 384i32, 128u32);
        let (mut drag_q8, mut grav_fix, mut burst) = (256u32, 0i32, 8u32);
        let (mut color, mut fade) = (0xFFFFFFu32, true);
        while !matches!(self.peek(), Tok::RBrace) {
            let k = self.expect_ident()?;
            self.expect(Tok::Colon)?;
            match k.as_str() {
                "sprite" => sprite = Some(self.expect_atom()?),
                "life" => life = self.parse_int_pt()? as u32,
                "speed" => match self.next() {
                    Tok::Fix(v) => speed_fix = v,
                    Tok::Int(v) => speed_fix = (v as i32) * 256,
                    other => return Err(format!("line {}:{}: bad speed, found {:?}", self.line(), self.col(), other)),
                },
                "jitter" => match self.next() {
                    // Tok::Fix carries raw Q8 (0.6 -> 154): clamp to 0..256
                    Tok::Fix(v) => jitter_q8 = v.clamp(0, 256) as u32,
                    other => return Err(format!("line {}:{}: bad jitter, found {:?}", self.line(), self.col(), other)),
                },
                "drag" => match self.next() {
                    // Tok::Fix carries raw Q8 (0.93 -> 238): clamp to 0..256
                    Tok::Fix(v) => drag_q8 = v.clamp(0, 256) as u32,
                    other => return Err(format!("line {}:{}: bad drag, found {:?}", self.line(), self.col(), other)),
                },
                "grav" => match self.next() {
                    Tok::Fix(v) => grav_fix = v,
                    Tok::Int(v) => grav_fix = (v as i32) * 256,
                    Tok::Minus => match self.next() {
                        Tok::Fix(v) => grav_fix = -v,
                        Tok::Int(v) => grav_fix = -(v as i32) * 256,
                        other => return Err(format!("line {}:{}: bad grav, found {:?}", self.line(), self.col(), other)),
                    },
                    other => return Err(format!("line {}:{}: bad grav, found {:?}", self.line(), self.col(), other)),
                },
                "burst" => burst = self.parse_int_pt()? as u32,
                "color" => match self.next() {
                    Tok::Int(v) => color = v & 0xFFFFFF,
                    other => return Err(format!("line {}:{}: bad color, found {:?}", self.line(), self.col(), other)),
                },
                "fade" => match self.next() {
                    Tok::Ident(s) if s == "true" => fade = true,
                    Tok::Ident(s) if s == "false" => fade = false,
                    other => return Err(format!("line {}:{}: bad fade, found {:?}", self.line(), self.col(), other)),
                },
                other => return Err(format!("line {}:{}: unknown particles field '{}' (sprite life speed jitter drag grav burst color fade)", self.line(), self.col(), other)),
            }
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        let sprite = sprite.ok_or_else(|| {
            format!("line {}:{}: particles #{} needs a `sprite: #name`", self.line(), self.col(),
                self.atom_names.get(atom as usize).map(|s| s.as_str()).unwrap_or("?"))
        })?;
        if cap < 16 || cap > 65535 {
            return Err(format!("line {}:{}: particles capacity {} out of range 16..=65535", self.line(), self.col(), cap));
        }
        if life == 0 || life > 255 { return Err(format!("line {}:{}: particles life {} out of range 1..=255", self.line(), self.col(), life)); }
        if burst == 0 || burst > 64 { return Err(format!("line {}:{}: particles burst {} out of range 1..=64", self.line(), self.col(), burst)); }
        p.particles.push(crate::ast::ParticleDecl {
            atom, cap, sprite, life, speed_fix, jitter_q8, drag_q8, grav_fix, burst, color, fade,
        });
        Ok(())
    }

    /// v20 MIXINS: `mixin movable { x: fixed  y: fixed ... }` — a named
    /// field group. Entities pull it in with `use movable`. Mixins may
    /// compose other mixins (`use` inside the block). Everything is spliced
    /// away by synth::expand before the checker runs: zero runtime bytes.
    fn parse_mixin(&mut self, p: &mut Program) -> Result<(), String> {
        let line = self.line();
        let name = self.expect_ident()?;
        self.expect(Tok::LBrace)?;
        let mut fields = Vec::new();
        let mut uses = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            if self.is_kw("use") && matches!(self.peek_at(1), Tok::Ident(_)) {
                self.pos += 1;
                uses.push(self.expect_ident()?);
                self.accept_semi_or_comma();
                continue;
            }
            fields.push(self.parse_field()?);
        }
        self.expect(Tok::RBrace)?;
        p.mixins.push(MixinDecl { name, fields, uses, line });
        Ok(())
    }

    /// v23.2 STRUCTS: `struct Vec3 { x: fixed, y: fixed, z: fixed }` — a
    /// user-declared record. Fields are the same field-decl grammar as
    /// entities/mixins (scalar types + defaults). Lowered away entirely by
    /// synth::lower_structs; the parser only records the name so
    /// `parse_field_type` can resolve `Vec3` to Ty::Struct and so a
    /// struct/entity name clash errors here (clean message, no downstream
    /// confusion).
    fn parse_struct(&mut self, p: &mut Program) -> Result<(), String> {
        let line = self.line();
        let name = self.expect_ident()?;
        if self.struct_names.contains(&name) {
            return Err(format!("line {}: duplicate struct '{}'", line, name));
        }
        if p.entities.iter().any(|e| e.name == name) || p.mixins.iter().any(|m| m.name == name) {
            return Err(format!("line {}: '{}' is already an entity/mixin — struct and entity names must not collide", line, name));
        }
        self.expect(Tok::LBrace)?;
        let mut fields = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            let f = self.parse_field()?;
            if matches!(f.ty, Ty::Struct(_)) {
                return Err(format!("line {}: struct field '{}': nested structs are not supported (flat records only)", line, f.name));
            }
            if let Ty::Entity(e) = &f.ty {
                return Err(format!("line {}: struct field '{}': entity references inside structs are not supported ('{}')", line, f.name, e));
            }
            fields.push(f);
        }
        self.expect(Tok::RBrace)?;
        if fields.is_empty() {
            return Err(format!("line {}: struct '{}' has no fields", line, name));
        }
        self.struct_names.insert(name.clone());
        p.structs.push(StructDecl { name, fields, line });
        Ok(())
    }

    /// v23.2 MESH IMPORT: `mesh <name> from "<path>" [scale <n>];` — the
    /// .obj is parsed and quantized at COMPILE time by synth::lower_meshes
    /// (relative to the entry source's directory). The array capacity is
    /// derived from the mesh (triangles * 18 fixed cells); a name clash
    /// with another global/array errors here.
    fn parse_mesh(&mut self, p: &mut Program) -> Result<(), String> {
        let line = self.line();
        let name = self.expect_ident()?;
        if !self.is_kw("from") {
            return Err(format!("line {}: mesh '{}' needs `from \"file.obj\"`", line, name));
        }
        self.pos += 1; // consume 'from'
        let path = match self.next() {
            Tok::Str(s) => s,
            other => return Err(format!("line {}: mesh '{}' path must be a quoted string, found {:?}", line, name, other)),
        };
        let mut scale: Option<i32> = None;
        if self.is_kw("scale") {
            self.pos += 1;
            scale = Some(match self.next() {
                Tok::Fix(v) => v,
                Tok::Int(v) => (v as i32) * 256,
                Tok::Minus => match self.next() {
                    Tok::Fix(v) => -v,
                    Tok::Int(v) => -(v as i32) * 256,
                    other => return Err(format!("line {}: mesh '{}' scale must be a number, found {:?}", line, name, other)),
                },
                other => return Err(format!("line {}: mesh '{}' scale must be a number, found {:?}", line, name, other)),
            });
        }
        self.accept_semi_or_comma();
        p.meshes.push(MeshDecl { name, path, scale, line });
        Ok(())
    }

    fn parse_global(&mut self, p: &mut Program) -> Result<(), String> {
        self.expect(Tok::LBrace)?;
        while !matches!(self.peek(), Tok::RBrace) {
            // v11 ARRAYS: `arr fixed[64] stars;` — game-wide arrays (meshes,
            // paths, grids) living in their own flat-memory region.
            if self.is_kw("arr") {
                p.garrs.push(self.parse_arr()?);
                continue;
            }
            p.globals.push(self.parse_field()?);
        }
        self.expect(Tok::RBrace)?;
        Ok(())
    }

    /// v20 POOLS: `pool Trail (256) { x: fixed  life: u8 = 30 }` — dynamic
    /// append-only side table (C# List<T> / C++ std::vector, LILA style).
    /// The (cap) is the row capacity the engine build must provide (like
    /// entity capacity: checked at load, loud on mismatch). Fields are
    /// full 32-bit cells (fixed/uN/sN/bool/ang) with defaults applied on
    /// push for unlisted inits.
    fn parse_pool(&mut self, p: &mut Program) -> Result<(), String> {
        let line = self.line();
        let name = self.expect_ident()?;
        self.expect(Tok::LParen)?;
        let cap = self.parse_int_pt()? as u32;
        self.expect(Tok::RParen)?;
        self.expect(Tok::LBrace)?;
        let mut fields = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            fields.push(self.parse_field()?);
        }
        self.expect(Tok::RBrace)?;
        p.pools.push(PoolDecl { name, cap, fields, line });
        Ok(())
    }

    /// v21 DICTS: `dict Kills (256)` — deterministic u32->u32 table.
    /// Capacity is the slot count (power of two, checker-enforced; runtime
    /// rejects overflow of the image tail with ERR_LIMIT_DICTS).
    fn parse_dict(&mut self, p: &mut Program) -> Result<(), String> {
        let line = self.line();
        let name = self.expect_ident()?;
        self.expect(Tok::LParen)?;
        let cap = self.parse_int_pt()? as u32;
        self.expect(Tok::RParen)?;
        self.accept_semi_or_comma();
        p.dicts.push(DictDecl { name, cap, line });
        Ok(())
    }

    /// v21 COLLIDE: `collide Bullet vs Rock (14) { hit_bullet_rock };` — the
    /// radius is a whole-pixel literal (combined hit circle).
    /// v22 CONTACT EDGES: an optional `enter` / `exit` keyword after the
    /// radius selects OnCollisionEnter2D / OnCollisionExit2D semantics
    /// (the bare form keeps v21's fire-every-touching-frame Stay).
    fn parse_collide(&mut self, p: &mut Program) -> Result<(), String> {
        let line = self.line();
        let a = self.expect_ident()?;
        if !self.eat_kw("vs") {
            return Err(format!("line {}:{}: collide needs 'vs' — `collide Bullet vs Rock (12) {{ handler }}'", self.line(), self.col()));
        }
        let b = self.expect_ident()?;
        self.expect(Tok::LParen)?;
        let radius = self.parse_int_pt()? as u32;
        self.expect(Tok::RParen)?;
        let mode = if self.eat_kw("enter") {
            crate::ast::CollMode::Enter
        } else if self.eat_kw("exit") {
            crate::ast::CollMode::Exit
        } else {
            crate::ast::CollMode::Stay
        };
        self.expect(Tok::LBrace)?;
        let handler = self.expect_ident()?;
        self.expect(Tok::RBrace)?;
        self.accept_semi_or_comma();
        p.collides.push(CollideDecl { a, b, radius, handler, mode, line });
        Ok(())
    }

    /// v22 QUEUES + STACKS (C# Queue<T>/Stack<T>, C++ std::queue/std::stack,
    /// the LILA way): `queue Q (64);` / `stack S (64);` — PURE SUGAR. The
    /// decl lowers immediately to a plain global array `arr u32[cap+2]`:
    /// cell 0 = head counter, cell 1 = tail counter, data = cells 2.. in a
    /// modulo ring. Zero-init means head == tail == 0 = empty, so there is
    /// NO init code, NO new schema, NO runtime bytes — the queue/stack ops
    /// are the only writers. Counters are raw u32 (wrap-safe ring math:
    /// len = tail -% head stays correct across the 2^32 wrap, the same
    /// 2.2-years-at-60Hz contract as the frame counter).
    fn parse_queue_stack(&mut self, p: &mut Program, is_queue: bool) -> Result<(), String> {
        let (line, kind) = (self.line(), if is_queue { "queue" } else { "stack" });
        let name = self.expect_ident()?;
        self.expect(Tok::LParen)?;
        let data_cap = self.parse_int_pt()? as u32;
        self.expect(Tok::RParen)?;
        self.accept_semi_or_comma();
        if data_cap < 1 || data_cap > 16382 {
            return Err(format!("line {}: {} '{}' capacity must be 1..=16382 (got {})", line, kind, name, data_cap));
        }
        // raw u32 cells: the widest legal element type (queues carry any
        // scalar raw — ints natively, fixed values as their Q24.8 bits)
        p.garrs.push(ArrDecl {
            name, elem: Ty::UInt(32), cap: data_cap + 2, dims: Vec::new(), line,
        });
        Ok(())
    }

    /// v21 LEVELS: `level #arena { grid [ "..XX..", "......" ] legend
    /// { X: place_rock, O: place_orb } }` — rows are strings of single
    /// characters; '.' (and space) = empty, any other char must be in the
    /// legend.
    fn parse_level(&mut self, p: &mut Program) -> Result<(), String> {
        let line = self.line();
        let atom = self.expect_atom()?;
        self.expect(Tok::LBrace)?;
        let mut grid: Vec<String> = Vec::new();
        let mut legend: Vec<(char, String)> = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            let k = self.expect_ident()?;
            match k.as_str() {
                "grid" => {
                    self.expect(Tok::LBracket)?;
                    while !matches!(self.peek(), Tok::RBracket) {
                        match self.next() {
                            Tok::Str(s) => grid.push(s),
                            other => return Err(format!("line {}:{}: grid rows must be strings, found {:?}", self.line(), self.col(), other)),
                        }
                        self.accept_semi_or_comma();
                    }
                    self.expect(Tok::RBracket)?;
                }
                "legend" => {
                    self.expect(Tok::LBrace)?;
                    while !matches!(self.peek(), Tok::RBrace) {
                        // keys: a single-character identifier (the DSL's
                        // natural form, like table keys) or a 1-char string
                        let ch = match self.next() {
                            Tok::Ident(s) if s.chars().count() == 1 => s.chars().next().unwrap(),
                            Tok::Str(s) if s.chars().count() == 1 => s.chars().next().unwrap(),
                            other => return Err(format!("line {}:{}: legend keys are single characters, found {:?}",
                                self.line(), self.col(), other)),
                        };
                        self.expect(Tok::Colon)?;
                        let f = self.expect_ident()?;
                        legend.push((ch, f));
                        self.accept_semi_or_comma();
                    }
                    self.expect(Tok::RBrace)?;
                }
                other => return Err(format!("line {}:{}: unknown level field '{}' (grid / legend)", self.line(), self.col(), other)),
            }
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        self.accept_semi_or_comma();
        p.levels.push(LevelDecl { atom, grid, legend, line });
        Ok(())
    }

    /// v20 SIGNALS: `signal #death { boom_flash, drop_loot }` — bind an
    /// atom to a list of handler fn names (fired in this order by emit).
    fn parse_signal(&mut self, p: &mut Program) -> Result<(), String> {
        let line = self.line();
        let atom = self.expect_atom()?;
        self.expect(Tok::LBrace)?;
        let mut handlers = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            handlers.push(self.expect_ident()?);
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        p.signals.push(SignalDecl { atom, handlers, line });
        Ok(())
    }

    fn parse_table(&mut self, p: &mut Program) -> Result<(), String> {
        let name = self.expect_ident()?;
        self.expect(Tok::LBrace)?;
        let mut entries = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            let key = match self.next() {
                Tok::Int(v) if v <= 255 => v as u8,
                other => return Err(format!("line {}:{}: table key must be 0..255, found {:?}", self.line(), self.col(), other)),
            };
            self.expect(Tok::Colon)?;
            let f = self.expect_ident()?;
            entries.push((key, f));
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        p.tables.push(TableDecl { name, entries });
        Ok(())
    }

    fn parse_fn(&mut self) -> Result<FnDecl, String> {
        let line = self.line(); // v17: the fn KEYWORD line (was captured after
        // the body — semantic errors pointed at the closing brace)
        let name = self.expect_ident()?;
        self.expect(Tok::LParen)?;
        let mut params = Vec::new();
        while !matches!(self.peek(), Tok::RParen) {
            let pn = self.expect_ident()?;
            self.expect(Tok::Colon)?;
            let ty = self.parse_field_type()?;
            params.push((pn, ty));
            if matches!(self.peek(), Tok::Comma) { self.pos += 1; }
        }
        self.expect(Tok::RParen)?;
        // v21 TIMERS: `fn tick() every 32 { ... }` — InvokeRepeating, LILA
        // style. gameplay::expand prepends the modulo-guard call into update.
        let mut every: Option<u32> = None;
        if self.is_kw("every") {
            self.pos += 1;
            let (fl, fc) = (self.line(), self.col());
            let v = match self.next() {
                Tok::Int(v) if v >= 1 && v <= 65535 => v,
                other => return Err(format!("line {}:{}: every needs an integer literal 1..=65535 frames, found {:?}", fl, fc, other)),
            };
            every = Some(v);
        }
        let body = self.parse_block()?;
        Ok(FnDecl { name, params, body, line, every })
    }

    // ---------------- v8 OPTIMIZER declarations ----------------

    /// fsm #name {
    ///     STATE { guard -> TARGET, guard -> TARGET }
    ///     ...
    /// }
    /// Guards are expressions over the owning entity's fields (implicit self),
    /// globals, and key() — the checker validates them in entity context.
    fn parse_fsm(&mut self) -> Result<FsmDecl, String> {
        let atom = self.expect_atom()?;
        // the fsm NAME is the #atom name (same convention as sdf blocks —
        // `fsm #guard { ... }`); no separate identifier is required.
        let name = self.atom_names.get(atom as usize).cloned()
            .ok_or_else(|| format!("line {}:{}: unknown fsm atom", self.line(), self.col()))?;
        self.expect(Tok::LBrace)?;
        let mut states: Vec<(String, Vec<(Expr, String)>)> = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            let sname = self.expect_ident()?;
            self.expect(Tok::LBrace)?;
            let mut guards = Vec::new();
            while !matches!(self.peek(), Tok::RBrace) {
                let pred = self.parse_expr()?;
                self.expect(Tok::Arrow)?;
                let target = self.expect_ident()?;
                guards.push((pred, target));
                self.accept_semi_or_comma();
            }
            self.expect(Tok::RBrace)?;
            states.push((sname, guards));
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        let line = self.line();
        Ok(FsmDecl { atom, name, states, line })
    }

    /// sdf #name { ... } — shape programs (see opt/sdf.rs for the pass docs).
    fn parse_sdf(&mut self) -> Result<crate::opt::sdf::SdfDecl, String> {
        use crate::opt::sdf::{SdfDecl, Shape, V3};
        let atom = self.expect_atom()?;
        let (line, col) = (self.line(), self.col());
        let name = self.atom_names.get(atom as usize).cloned()
            .ok_or_else(|| format!("line {}:{}: unknown sdf atom", line, col))?;
        self.expect(Tok::LBrace)?;
        let mut kids: Vec<Shape> = Vec::new(); // top-level implicit union
        let mut color = 0x33AAFFu32;
        let mut glow = 0.5f32;
        let mut eye = V3::new(0.0, 1.2, -3.4);
        let mut look = V3::zero();
        let mut hud = false;
        while !matches!(self.peek(), Tok::RBrace) {
            let kw = self.expect_ident()?;
            match kw.as_str() {
                "sphere" => {
                    self.expect(Tok::LBrace)?;
                    let (mut r, mut c) = (1.0f32, V3::zero());
                    self.sdf_params(|s, key| match key {
                        "r" => { r = s.sdf_f32()?; Ok(()) }
                        "at" => { c = s.sdf_v3()?; Ok(()) }
                        other => Err(format!("unknown sphere field '{}'", other)),
                    })?;
                    kids.push(Shape::Sphere { c, r });
                }
                "box" => {
                    self.expect(Tok::LBrace)?;
                    let (mut half, mut c, mut round) = (V3::new(0.5, 0.5, 0.5), V3::zero(), 0.0f32);
                    self.sdf_params(|s, key| match key {
                        "r" => { half = s.sdf_v3()?; Ok(()) }
                        "at" => { c = s.sdf_v3()?; Ok(()) }
                        "round" => { round = s.sdf_f32()?; Ok(()) }
                        other => Err(format!("unknown box field '{}'", other)),
                    })?;
                    kids.push(Shape::Box { c, half, round });
                }
                "torus" => {
                    self.expect(Tok::LBrace)?;
                    let (mut major, mut minor, mut c) = (0.7f32, 0.12f32, V3::zero());
                    self.sdf_params(|s, key| match key {
                        "r" => { major = s.sdf_f32()?; Ok(()) }
                        "t" => { minor = s.sdf_f32()?; Ok(()) }
                        "at" => { c = s.sdf_v3()?; Ok(()) }
                        other => Err(format!("unknown torus field '{}'", other)),
                    })?;
                    kids.push(Shape::Torus { c, major, minor });
                }
                "capsule" => {
                    self.expect(Tok::LBrace)?;
                    let (mut a, mut b, mut r) = (V3::zero(), V3::new(0.0, 1.0, 0.0), 0.25f32);
                    self.sdf_params(|s, key| match key {
                        "a" => { a = s.sdf_v3()?; Ok(()) }
                        "b" => { b = s.sdf_v3()?; Ok(()) }
                        "r" => { r = s.sdf_f32()?; Ok(()) }
                        other => Err(format!("unknown capsule field '{}'", other)),
                    })?;
                    kids.push(Shape::Capsule { a, b, r });
                }
                "plane" => {
                    self.expect(Tok::LBrace)?;
                    let mut y = -1.0f32;
                    self.sdf_params(|s, key| match key {
                        "y" => { y = s.sdf_f32()?; Ok(()) }
                        other => Err(format!("unknown plane field '{}'", other)),
                    })?;
                    kids.push(Shape::Plane { y });
                }
                "union" | "smooth_union" | "sub" | "isect" | "smooth_sub" | "twist" | "repeat" => {
                    let inner = self.parse_sdf_op(&kw)?;
                    kids.push(inner);
                }
                "color" => { self.expect(Tok::Colon)?; color = self.expect_hex()?; }
                "glow" => { self.expect(Tok::Colon)?; glow = self.sdf_f32()?; }
                "hud" => { self.expect(Tok::Colon)?; hud = self.expect_bool()?; }
                "eye" => { self.expect(Tok::Colon)?; eye = self.sdf_v3()?; }
                "look" => { self.expect(Tok::Colon)?; look = self.sdf_v3()?; }
                "smooth" => {
                    // top-level smoothness: rewrites the implicit union into a
                    // smooth union with the declared k
                    self.expect(Tok::Colon)?;
                    let k = self.sdf_f32()?;
                    let merged = std::mem::take(&mut kids);
                    kids.push(Shape::SmoothUnion { k, kids: merged });
                }
                other => return Err(format!("line {}:{}: unknown sdf field '{}'", self.line(), self.col(), other)),
            }
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        let root: Shape = match kids.len() {
            0 => return Err(format!("line {}:{}: sdf {}: no shapes", line, col, name)),
            1 => kids.pop().unwrap(),
            _ => Shape::Union(kids),
        };
        Ok(SdfDecl { name, root, color, glow, eye, look, hud })
    }

    /// Parse an operator block: union { ... } / smooth_union { k: .. ... } /
    /// twist { k: .. <shape> } / repeat { x: .. <shape> } etc.
    fn parse_sdf_op(&mut self, kw: &str) -> Result<crate::opt::sdf::Shape, String> {
        use crate::opt::sdf::{Shape, V3};
        self.expect(Tok::LBrace)?;
        let mut kids: Vec<Shape> = Vec::new();
        let mut k = 0.3f32;
        let mut cell = V3::zero();
        while !matches!(self.peek(), Tok::RBrace) {
            if self.is_kw("k") && matches!(self.peek_at(1), Tok::Colon) {
                self.pos += 2;
                k = self.sdf_f32()?;
                self.accept_semi_or_comma();
                continue;
            }
            if self.is_kw("x") && matches!(self.peek_at(1), Tok::Colon)
                || self.is_kw("y") && matches!(self.peek_at(1), Tok::Colon)
                || self.is_kw("z") && matches!(self.peek_at(1), Tok::Colon) {
                let axis = match self.next() {
                    Tok::Ident(a) => a,
                    _ => unreachable!(),
                };
                self.expect(Tok::Colon)?;
                let v = self.sdf_f32()?;
                match axis.as_str() {
                    "x" => cell.x = v,
                    "y" => cell.y = v,
                    _ => cell.z = v,
                }
                self.accept_semi_or_comma();
                continue;
            }
            let inner_kw = self.expect_ident()?;
            let shape = match inner_kw.as_str() {
                "sphere" => {
                    self.expect(Tok::LBrace)?;
                    let (mut r, mut c) = (1.0f32, V3::zero());
                    self.sdf_params(|s, key| match key {
                        "r" => { r = s.sdf_f32()?; Ok(()) }
                        "at" => { c = s.sdf_v3()?; Ok(()) }
                        other => Err(format!("unknown sphere field '{}'", other)),
                    })?;
                    Shape::Sphere { c, r }
                }
                "box" => {
                    self.expect(Tok::LBrace)?;
                    let (mut half, mut c, mut round) = (V3::new(0.5, 0.5, 0.5), V3::zero(), 0.0f32);
                    self.sdf_params(|s, key| match key {
                        "r" => { half = s.sdf_v3()?; Ok(()) }
                        "at" => { c = s.sdf_v3()?; Ok(()) }
                        "round" => { round = s.sdf_f32()?; Ok(()) }
                        other => Err(format!("unknown box field '{}'", other)),
                    })?;
                    Shape::Box { c, half, round }
                }
                "torus" => {
                    self.expect(Tok::LBrace)?;
                    let (mut major, mut minor, mut c) = (0.7f32, 0.12f32, V3::zero());
                    self.sdf_params(|s, key| match key {
                        "r" => { major = s.sdf_f32()?; Ok(()) }
                        "t" => { minor = s.sdf_f32()?; Ok(()) }
                        "at" => { c = s.sdf_v3()?; Ok(()) }
                        other => Err(format!("unknown torus field '{}'", other)),
                    })?;
                    Shape::Torus { c, major, minor }
                }
                "capsule" => {
                    self.expect(Tok::LBrace)?;
                    let (mut a, mut b, mut r) = (V3::zero(), V3::new(0.0, 1.0, 0.0), 0.25f32);
                    self.sdf_params(|s, key| match key {
                        "a" => { a = s.sdf_v3()?; Ok(()) }
                        "b" => { b = s.sdf_v3()?; Ok(()) }
                        "r" => { r = s.sdf_f32()?; Ok(()) }
                        other => Err(format!("unknown capsule field '{}'", other)),
                    })?;
                    Shape::Capsule { a, b, r }
                }
                "plane" => {
                    self.expect(Tok::LBrace)?;
                    let mut y = -1.0f32;
                    self.sdf_params(|s, key| match key {
                        "y" => { y = s.sdf_f32()?; Ok(()) }
                        other => Err(format!("unknown plane field '{}'", other)),
                    })?;
                    Shape::Plane { y }
                }
                "union" | "smooth_union" | "sub" | "isect" | "smooth_sub" | "twist" | "repeat" => {
                    self.parse_sdf_op(&inner_kw)?
                }
                other => return Err(format!("line {}:{}: unknown sdf shape '{}'", self.line(), self.col(), other)),
            };
            kids.push(shape);
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        let shape = match kw {
            "union" => Shape::Union(kids),
            "smooth_union" => Shape::SmoothUnion { k, kids },
            "sub" => if kids.len() == 2 {
                let b = kids.pop().unwrap();
                let a = kids.pop().unwrap();
                Shape::Sub(Box::new(a), Box::new(b))
            } else { return Err(format!("line {}:{}: sub needs exactly 2 shapes", self.line(), self.col())) },
            "isect" => if kids.len() == 2 {
                let b = kids.pop().unwrap();
                let a = kids.pop().unwrap();
                Shape::Isect(Box::new(a), Box::new(b))
            } else { return Err(format!("line {}:{}: isect needs exactly 2 shapes", self.line(), self.col())) },
            "smooth_sub" => if kids.len() == 2 {
                let b = kids.pop().unwrap();
                let a = kids.pop().unwrap();
                Shape::SmoothSub { k, a: Box::new(a), b: Box::new(b) }
            } else { return Err(format!("line {}:{}: smooth_sub needs exactly 2 shapes", self.line(), self.col())) },
            "twist" => if kids.len() == 1 {
                Shape::Twist { k, kid: Box::new(kids.pop().unwrap()) }
            } else { return Err(format!("line {}:{}: twist needs exactly 1 shape", self.line(), self.col())) },
            "repeat" => if kids.len() == 1 {
                Shape::Repeat { cell, kid: Box::new(kids.pop().unwrap()) }
            } else { return Err(format!("line {}:{}: repeat needs exactly 1 shape", self.line(), self.col())) },
            other => return Err(format!("line {}:{}: unknown sdf op '{}'", self.line(), self.col(), other)),
        };
        Ok(shape)
    }

    /// key: value / key: (a, b, c) pairs inside a shape block.
    fn sdf_params(&mut self, mut f: impl FnMut(&mut Self, &str) -> Result<(), String>) -> Result<(), String> {
        while !matches!(self.peek(), Tok::RBrace) {
            let key = self.expect_ident()?;
            self.expect(Tok::Colon)?;
            f(self, &key)?;
            self.accept_semi_or_comma();
        }
        self.expect(Tok::RBrace)?;
        Ok(())
    }

    /// Float literal in sdf context (Int or Fix tokens, optional minus).
    fn sdf_f32(&mut self) -> Result<f32, String> {
        let mut sign = 1.0f32;
        if matches!(self.peek(), Tok::Minus) {
            self.pos += 1;
            sign = -1.0;
        }
        match self.next() {
            Tok::Int(v) => Ok(sign * v as f32),
            Tok::Fix(v) => Ok(sign * (v as f32 / 256.0)),
            other => Err(format!("line {}:{}: expected number, found {:?}", self.line(), self.col(), other)),
        }
    }

    /// (x, y, z) tuple of numbers.
    fn sdf_v3(&mut self) -> Result<crate::opt::sdf::V3, String> {
        self.expect(Tok::LParen)?;
        let x = self.sdf_f32()?;
        self.expect(Tok::Comma)?;
        let y = self.sdf_f32()?;
        self.expect(Tok::Comma)?;
        let z = self.sdf_f32()?;
        self.expect(Tok::RParen)?;
        Ok(crate::opt::sdf::V3::new(x, y, z))
    }

    // ---------------- statements ----------------

    fn parse_block(&mut self) -> Result<Vec<Stmt>, String> {
        self.expect(Tok::LBrace)?;
        let mut out = Vec::new();
        while !matches!(self.peek(), Tok::RBrace) {
            // v23.2 ERROR RECOVERY: a broken statement is recorded, the
            // parser skips to the next Semi / the enclosing RBrace, and the
            // block keeps parsing — every syntax error in the fn reports in
            // one round.
            match self.parse_stmt() {
                Ok(s) => out.push(s),
                Err(e) => {
                    self.errors.push(e);
                    if !self.sync_stmt() { break; }
                }
            }
        }
        self.expect(Tok::RBrace)?;
        Ok(out)
    }

    /// v23.2 SPANS: every parsed statement is wrapped in `Stmt::At` carrying
    /// the (line, col) of its first token, so checker/codegen errors point
    /// at the statement instead of the enclosing fn. The single call site
    /// (parse_block) keeps the wrapper impossible to forget.
    fn parse_stmt(&mut self) -> Result<Stmt, String> {
        let line = self.line();
        let col = self.col();
        let inner = self.parse_stmt_inner()?;
        Ok(Stmt::At { line, col, inner: Box::new(inner) })
    }

    fn parse_stmt_inner(&mut self) -> Result<Stmt, String> {
        // v23.1: try/catch/throw — REAL exception lowering (a VM handler
        // stack; see codegen + vm OP_TRY/OP_TRY_END/OP_THROW). Previously
        // the AST variants existed but were UNPARSEABLE and the codegen
        // was an admitted stub.
        if self.eat_kw("try") {
            let body = self.parse_block()?;
            if !self.eat_kw("catch") {
                return Err("`try` must be followed by `catch (err) { ... }`".to_string());
            }
            self.expect(Tok::LParen)?;
            let catch_var = self.expect_ident()?;
            self.expect(Tok::RParen)?;
            let catch_body = self.parse_block()?;
            return Ok(Stmt::TryCatch { body, catch_var, catch_body });
        }
        if self.eat_kw("throw") {
            let e = self.parse_expr()?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Throw(e));
        }
        if self.eat_kw("let") {
            let name = self.expect_ident()?;
            self.expect(Tok::Eq)?;
            let e = self.parse_expr()?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Let(name, e));
        }
        if self.eat_kw("if") { return self.parse_if(); }
        if self.eat_kw("while") {
            let cond = self.parse_expr()?;
            let body = self.parse_block()?;
            return Ok(Stmt::While(cond, body));
        }
        if self.eat_kw("for") {
            self.expect(Tok::LParen)?;
            let var = self.expect_ident()?;
            self.expect(Tok::Colon)?;
            // v17 disambiguation: `for (i: Rock)` iterates entities;
            // `for (i: 0..n)` counts integers. A literal start (or a unary
            // minus, or an identifier followed by `..`) selects the numeric
            // form; everything else is the entity iteration.
            let numeric = matches!(self.peek(), Tok::Int(_) | Tok::Fix(_) | Tok::Minus)
                || (matches!(self.peek(), Tok::Ident(_))
                    && matches!(self.peek_at(1), Tok::Range));
            if numeric {
                let from = self.parse_expr()?;
                self.expect(Tok::Range)?;
                let to = self.parse_expr()?;
                self.expect(Tok::RParen)?;
                // v20: optional `where (cond)` filter — LINQ Where. It is a
                // pure guard: the body is wrapped in a plain if so every
                // downstream pass (checker, optimizer, codegen) is unchanged.
                if self.is_kw("where") && matches!(self.peek_at(1), Tok::LParen) {
                    self.pos += 1;
                    self.expect(Tok::LParen)?;
                    let cond = self.parse_expr()?;
                    self.expect(Tok::RParen)?;
                    let body = self.parse_block()?;
                    return Ok(Stmt::ForNum(var, from, to, vec![Stmt::If(cond, body, vec![])]));
                }
                let body = self.parse_block()?;
                return Ok(Stmt::ForNum(var, from, to, body));
            }
            let ent = self.expect_ident()?;
            self.expect(Tok::RParen)?;
            // v20: optional `where (cond)` filter over the loop variable —
            // `for (e: Enemy) where (e.hp < 3) { ... }`. Sugar for wrapping
            // the body in an if; iteration ORDER (slot order) is untouched.
            if self.is_kw("where") && matches!(self.peek_at(1), Tok::LParen) {
                self.pos += 1;
                self.expect(Tok::LParen)?;
                let cond = self.parse_expr()?;
                self.expect(Tok::RParen)?;
                let body = self.parse_block()?;
                return Ok(Stmt::For(var, ent, vec![Stmt::If(cond, body, vec![])]));
            }
            let body = self.parse_block()?;
            return Ok(Stmt::For(var, ent, body));
        }
        // v17 LOOP CONTROL: break;/continue; — target the innermost enclosing
        // loop (checker rejects them outside loops).
        if self.is_kw("break") && matches!(self.peek_at(1), Tok::Semi) {
            self.pos += 2;
            return Ok(Stmt::Break);
        }
        if self.is_kw("continue") && matches!(self.peek_at(1), Tok::Semi) {
            self.pos += 2;
            return Ok(Stmt::Continue);
        }
        // v17: `switch (x) { 0: {...} 1|2: {...} default: {...} }` — lowered
        // to an if/else chain at codegen (scrutinee evaluated once).
        if self.is_kw("switch") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let scrutinee = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::LBrace)?;
            let mut arms: Vec<(Vec<(i64, bool)>, Vec<Stmt>)> = Vec::new();
            let mut default: Option<Vec<Stmt>> = None;
            while !matches!(self.peek(), Tok::RBrace) {
                if self.is_kw("default") && matches!(self.peek_at(1), Tok::Colon) {
                    self.pos += 2;
                    default = Some(self.parse_block()?);
                    continue;
                }
                let mut labels: Vec<(i64, bool)> = Vec::new();
                loop {
                    let neg = if matches!(self.peek(), Tok::Minus) { self.pos += 1; true } else { false };
                    let lv = match self.next() {
                        Tok::Int(v) => (v as i64, false),
                        Tok::Fix(v) => (v as i64, true), // raw Q24.8 bits
                        other => return Err(format!("line {}:{}: switch arm needs literal labels (int or fixed), found {:?}",
                            self.line(), self.col(), other)),
                    };
                    labels.push(if neg { (-lv.0, lv.1) } else { lv });
                    if matches!(self.peek(), Tok::Pipe) { self.pos += 1; } else { break; }
                }
                self.expect(Tok::Colon)?;
                let body = self.parse_block()?;
                arms.push((labels, body));
            }
            self.expect(Tok::RBrace)?;
            return Ok(Stmt::Switch(scrutinee, arms, default));
        }
        if self.eat_kw("spawn") {
            let ent = self.expect_ident()?;
            let mut inits = Vec::new();
            if matches!(self.peek(), Tok::LBrace) {
                self.pos += 1;
                while !matches!(self.peek(), Tok::RBrace) {
                    let f = self.expect_ident()?;
                    self.expect(Tok::Colon)?;
                    let e = self.parse_expr()?;
                    inits.push((f, e));
                    if matches!(self.peek(), Tok::Comma) { self.pos += 1; }
                }
                self.expect(Tok::RBrace)?;
            }
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Spawn(ent, inits));
        }
        if self.eat_kw("kill") {
            let e = self.parse_expr()?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Kill(e));
        }
        // v20 POOLS: `push Trail { x: 1.0, life: 30 };` — append a row.
        // Mirrors spawn's init-list form (fields in written order, defaults
        // for the rest). `push Trail;` (no inits) is valid too.
        if self.eat_kw("push") {
            let pool = self.expect_ident()?;
            let mut inits = Vec::new();
            if matches!(self.peek(), Tok::LBrace) {
                self.pos += 1;
                while !matches!(self.peek(), Tok::RBrace) {
                    let f = self.expect_ident()?;
                    self.expect(Tok::Colon)?;
                    let e = self.parse_expr()?;
                    inits.push((f, e));
                    if matches!(self.peek(), Tok::Comma) { self.pos += 1; }
                }
                self.expect(Tok::RBrace)?;
            }
            self.expect(Tok::Semi)?;
            return Ok(Stmt::PoolPush(pool, inits));
        }
        // v20 POOLS: `remove(t);` — gen-checked swap-remove by handle.
        if self.eat_kw("remove") {
            let e = self.parse_expr()?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::PoolRemove(e));
        }
        // v21 DICTS: `mput(D, key, val);` — insert or overwrite.
        if self.is_kw("mput") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let d = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let k = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let v = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::MapPut(d, k, v));
        }
        // v21 DICTS: `mdel(D, key);` — remove (missing key: no-op).
        if self.is_kw("mdel") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let d = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let k = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::MapDel(d, k));
        }
        // v21 SORT: `psort(Pool, field);` / `psort(Pool, field, 1);` —
        // stable engine-side radix sort by the field key (3rd arg: 0 asc,
        // 1 desc; default 0).
        if self.is_kw("psort") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let pool = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let field = self.expect_ident()?;
            let mut dir: u8 = 0;
            if matches!(self.peek(), Tok::Comma) {
                self.pos += 1;
                dir = match self.next() {
                    Tok::Int(v) if v <= 1 => v as u8,
                    other => return Err(format!("line {}:{}: psort direction is 0 (ascending) or 1 (descending), found {:?}", self.line(), self.col(), other)),
                };
            }
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::PSort(pool, field, dir));
        }
        // v22 QUEUES: `qpush(Q, val);` — FIFO ring append.
        if self.is_kw("qpush") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let q = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let v = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::QPush(q, v));
        }
        // v22 STACKS: `spush(S, val);` — LIFO append.
        if self.is_kw("spush") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let s = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let v = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::SPush(s, v));
        }
        // v22 ARRAYS: `afill(A, val);` — fill the whole array (memset).
        if self.is_kw("afill") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let a = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let v = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::AFill(a, v));
        }
        // v22 ARRAYS: `acopy(dst, src, n);` — copy the first n cells.
        if self.is_kw("acopy") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let d = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let s = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let n = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::ACopy(d, s, n));
        }
        // v22 ARRAYS: `ashuffle(A, n);` — deterministic Fisher-Yates.
        if self.is_kw("ashuffle") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let a = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let n = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::AShuf(a, n));
        }
        // v21 ARCADE: draw_numz(v, digits, x, y, rgba); — zero-padded draw.
        if self.is_kw("draw_numz") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let v = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let (dl, dc) = (self.line(), self.col());
            let digits = match self.next() {
                Tok::Int(v) if v >= 1 && v <= 9 => v,
                other => return Err(format!("line {}:{}: draw_numz digits must be a literal 1..=9, found {:?}", dl, dc, other)),
            };
            self.expect(Tok::Comma)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let rgba = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::DrawNumZ(v, digits, x, y, rgba));
        }
        // v20 COROUTINES: `state hunt { ... }` — only meaningful inside
        // update(e: T); states::expand validates placement + lowers.
        if self.is_kw("state") && matches!(self.peek_at(1), Tok::Ident(_)) {
            self.pos += 1;
            let name = self.expect_ident()?;
            let body = self.parse_block()?;
            return Ok(Stmt::State(name, body));
        }
        // v20 COROUTINES: `wait(n);` — suspend the state body n frames.
        if self.is_kw("wait") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let e = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Wait(e));
        }
        // v20 COROUTINES: `-> hunt;` — state transition (the v8 guard arrow
        // token, statement-position).
        if matches!(self.peek(), Tok::Arrow) {
            self.pos += 1;
            let name = self.expect_ident()?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::GotoState(name));
        }
        // v20 SIGNALS: `emit #death;` — fire the handlers in order.
        if self.eat_kw("emit") {
            let a = self.expect_atom()?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Emit(a));
        }
        if self.eat_kw("return") {
            // v17 RETURN VALUES: `return;` or `return expr;`
            if matches!(self.peek(), Tok::Semi) {
                self.pos += 1;
                return Ok(Stmt::Return(None));
            }
            let e = self.parse_expr()?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Return(Some(e)));
        }
        // v8 OPTIMIZER subsystem 5: fsm_step(#name); — the whole AI tick in
        // one statement; expanded branchlessly by opt::fsm before codegen.
        if self.is_kw("fsm_step") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let a = self.expect_atom()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::FsmStep(a));
        }
        // v10 PARTICLES: emit(#name, x, y); — sugar for a call to the
        // synthesized `emit_<name>` helper. Lowered HERE (parser level) so
        // the checker/codegen only ever see an ordinary helper call.
        if self.is_kw("emit") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let a = self.expect_atom()?;
            let mut args = Vec::new();
            while matches!(self.peek(), Tok::Comma) {
                self.pos += 1;
                args.push(self.parse_expr()?);
            }
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            let name = self.atom_names.get(a as usize).cloned()
                .ok_or_else(|| format!("line {}:{}: bad emit atom", self.line(), self.col()))?;
            return Ok(Stmt::CallStmt(format!("emit_{}", name), args));
        }
        if self.eat_kw("call") {
            let name = self.expect_ident()?;
            if matches!(self.peek(), Tok::LBracket) {
                // call table[key](ent);
                self.pos += 1;
                let key = self.parse_expr()?;
                self.expect(Tok::RBracket)?;
                self.expect(Tok::LParen)?;
                let ent = self.expect_ident()?;
                self.expect(Tok::RParen)?;
                self.expect(Tok::Semi)?;
                return Ok(Stmt::CallTable(name, Box::new(key), ent));
            }
            self.expect(Tok::LParen)?;
            let mut args = Vec::new();
            while !matches!(self.peek(), Tok::RParen) {
                args.push(self.parse_expr()?);
                if matches!(self.peek(), Tok::Comma) { self.pos += 1; }
            }
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::CallStmt(name, args));
        }
        // atom-keyword statements
        if self.is_kw("sfx") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let a = self.expect_atom()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Sfx(a));
        }
        if self.is_kw("music") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let a = self.expect_atom()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Music(a));
        }
        if self.is_kw("stop_music") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::StopMusic);
        }
        if self.is_kw("shake") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let (line, col) = (self.line(), self.col());
            let amp = match self.next() {
                Tok::Int(v) => v,
                other => return Err(format!("line {}:{}: shake amplitude must be an integer literal 0..255, found {:?}", line, col, other)),
            };
            if amp > 255 {
                return Err(format!("line {}:{}: shake amplitude out of range 0..255: {}", line, col, amp));
            }
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Shake(amp as u32));
        }
        if self.is_kw("cam3") && matches!(self.peek_at(1), Tok::LParen) {
            // v11 3D: cam3(x, y, z, yaw, pitch) — position the 3D camera.
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let z = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let yaw = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let pitch = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Cam3(x, y, z, yaw, pitch));
        }
        if self.is_kw("draw3d") && matches!(self.peek_at(1), Tok::LParen) {
            // v11 3D: draw3d(mesh, n, x, y, z, yaw, rgba) — the engine-side
            // mesh pipeline over a global vertex array (see ast::Stmt::Draw3d).
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let arr = self.expect_ident()?;
            self.expect(Tok::Comma)?;
            let n = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let z = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let yaw = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let rgba = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Draw3d { arr, n, x, y, z, yaw, rgba });
        }
        if self.is_kw("draw3di") && matches!(self.peek_at(1), Tok::LParen) {
            // v12: draw3di(verts, nv, idx, ni, x, y, z, yaw, rgba) — the
            // INDEXED mesh pass over a shared vertex buffer + index buffer.
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let verts = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let nv = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let idx = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let ni = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let z = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let yaw = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let rgba = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Draw3DI { verts, nv, idx, ni, x, y, z, yaw, rgba });
        }
        // v12 ARTICULATION: quat_aa / qmul / m4qt / m4mul / skinv — mat4 &
        // quat builtins over global arrays (see ast::Stmt for the layouts).
        // All array arguments are plain names resolved by the checker; every
        // other argument is a full expression.
        if self.is_kw("quat_aa") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let q = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let off = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let ax = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let ay = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let az = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let ang = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::QuatAA { q, off, ax, ay, az, ang });
        }
        if self.is_kw("qmul") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let d = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let doff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let a = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let aoff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let b = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let boff = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::QMul { d, doff, a, aoff, b, boff });
        }
        if self.is_kw("m4qt") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let m = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let moff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let q = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let qoff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let tx = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let ty = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let tz = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::M4QT { m, moff, q, qoff, tx, ty, tz });
        }
        if self.is_kw("m4mul") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let d = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let doff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let a = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let aoff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let b = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let boff = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::M4Mul { d, doff, a, aoff, b, boff });
        }
        if self.is_kw("skinv") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let v = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let voff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let m = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let moff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let z = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::SkinV { v, voff, m, moff, x, y, z });
        }
        // v17 3D: m4look(m, off, ex, ey, ez, tx, ty, tz); — aim a matrix at
        // a target point (engine handedness, +Z up). One native opcode.
        if self.is_kw("m4look") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let m = self.parse_arr_ref()?;
            self.expect(Tok::Comma)?;
            let moff = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let ex = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let ey = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let ez = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let tx = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let ty = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let tz = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::M4Look { m, moff, ex, ey, ez, tx, ty, tz });
        }
        if self.is_kw("camera") && matches!(self.peek_at(1), Tok::LParen) {
            // v7: camera(x, y) — aim the viewport center at a world point.
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Camera(x, y));
        }
        if self.is_kw("music_vol") && matches!(self.peek_at(1), Tok::LParen) {
            // v7: music_vol(n) — master music volume 0..16 (16 = full).
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let (line, col) = (self.line(), self.col());
            let vol = match self.next() {
                Tok::Int(v) => v,
                other => return Err(format!("line {}:{}: music_vol must be an integer literal 0..16, found {:?}", line, col, other)),
            };
            if vol > 16 {
                return Err(format!("line {}:{}: music_vol out of range 0..16: {}", line, col, vol));
            }
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::MusicVol(vol as u32));
        }
        if self.is_kw("save") && matches!(self.peek_at(1), Tok::LParen) {
            // v7: save(ix, value) — persist a raw 32-bit value to SRAM slot ix.
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let ix = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let v = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Save(ix, v));
        }
        if self.is_kw("goto") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let a = self.expect_atom()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Goto(a));
        }
        if self.is_kw("draw") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let spr = self.expect_atom()?;
            self.expect(Tok::Comma)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let rot = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let scale = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let rgba = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::Draw(spr, x, y, rot, scale, rgba));
        }
        if self.is_kw("draw_text") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let a = self.expect_atom()?;
            self.expect(Tok::Comma)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let rgba = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::DrawText(a, x, y, rgba));
        }
        if self.is_kw("draw_num") && matches!(self.peek_at(1), Tok::LParen) {
            self.pos += 1;
            self.expect(Tok::LParen)?;
            let v = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let x = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let y = self.parse_expr()?;
            self.expect(Tok::Comma)?;
            let rgba = self.parse_expr()?;
            self.expect(Tok::RParen)?;
            self.expect(Tok::Semi)?;
            return Ok(Stmt::DrawNum(v, x, y, rgba));
        }
        // assignment: lvalue (=|+=|-=|*=|/=|%=|&=||=|^=|<<=|>>=) expr ;
        let target = self.parse_lvalue()?;
        let op = match self.next() {
            Tok::Eq => AssignOp::Set,
            Tok::PlusEq => AssignOp::Add,
            Tok::MinusEq => AssignOp::Sub,
            Tok::StarEq => AssignOp::Mul,
            Tok::SlashEq => AssignOp::Div,
            Tok::PercentEq => AssignOp::Mod,
            Tok::AmpEq => AssignOp::And,
            Tok::PipeEq => AssignOp::Or,
            Tok::CaretEq => AssignOp::Xor,
            Tok::ShlEq => AssignOp::Shl,
            Tok::ShrEq => AssignOp::Shr,
            other => return Err(format!("line {}:{}: expected assignment operator, found {:?} (bare expressions are not statements)", self.line(), self.col(), other)),
        };
        let val = self.parse_expr()?;
        self.expect(Tok::Semi)?;
        Ok(Stmt::Assign(target, op, val))
    }

    fn parse_lvalue(&mut self) -> Result<Expr, String> {
        let name = self.expect_ident()?;
        let mut e = Expr::Ident(name);
        self.parse_postfix(&mut e)?;
        Ok(e)
    }

    /// Shared postfix chain: `.field` and v11 `[index]` (array element).
    /// Used by both lvalues (`a[i] = v`, `e.trail[i] += v`) and expressions.
    fn parse_postfix(&mut self, e: &mut Expr) -> Result<(), String> {
        loop {
            if matches!(self.peek(), Tok::Dot) {
                self.pos += 1;
                let f = self.expect_ident()?;
                *e = Expr::Field(Box::new(e.clone()), f);
            } else if matches!(self.peek(), Tok::LBracket) {
                self.pos += 1;
                let ix = self.parse_expr()?;
                self.expect(Tok::RBracket)?;
                *e = Expr::Index(Box::new(e.clone()), Box::new(ix));
            } else {
                return Ok(());
            }
        }
    }

    fn parse_if(&mut self) -> Result<Stmt, String> {
        let cond = self.parse_expr()?;
        let then_b = self.parse_block()?;
        let mut else_b = Vec::new();
        if self.eat_kw("else") {
            if self.is_kw("if") {
                self.pos += 1;
                else_b.push(self.parse_if()?);
            } else {
                else_b = self.parse_block()?;
            }
        }
        Ok(Stmt::If(cond, then_b, else_b))
    }

    // ---------------- expressions (Pratt) ----------------

    fn parse_expr(&mut self) -> Result<Expr, String> {
        // v17 TERNARY: lowest precedence, right-associative. Only the taken
        // arm evaluates (lowered to JZ/JMP exactly like if/else).
        let cond = self.parse_bin(1)?;
        if matches!(self.peek(), Tok::Question) {
            self.pos += 1;
            let then_e = self.parse_bin(1)?; // middle arm: parenthesize to nest
            self.expect(Tok::Colon)?;
            let else_e = self.parse_expr()?; // right-associative
            return Ok(Expr::Ternary(Box::new(cond), Box::new(then_e), Box::new(else_e)));
        }
        Ok(cond)
    }

    fn tok_prec(&self) -> Option<(u8, BinOp)> {
        let op = match self.peek() {
            Tok::OrOr => BinOp::LOr,
            Tok::AndAnd => BinOp::LAnd,
            Tok::EqEq => BinOp::Eq, Tok::NotEq => BinOp::Ne,
            Tok::Lt => BinOp::Lt, Tok::Gt => BinOp::Gt,
            Tok::Le => BinOp::Le, Tok::Ge => BinOp::Ge,
            Tok::Amp => BinOp::And, Tok::Pipe => BinOp::Or, Tok::Caret => BinOp::Xor,
            Tok::Shl => BinOp::Shl, Tok::Shr => BinOp::Shr,
            Tok::Plus => BinOp::Add, Tok::Minus => BinOp::Sub,
            Tok::Star => BinOp::Mul, Tok::Slash => BinOp::Div, Tok::Percent => BinOp::Mod,
            _ => return None,
        };
        let prec = match op {
            BinOp::LOr => 1,
            BinOp::LAnd => 2,
            BinOp::Eq | BinOp::Ne | BinOp::Lt | BinOp::Gt | BinOp::Le | BinOp::Ge => 3,
            BinOp::And | BinOp::Or | BinOp::Xor => 4,
            BinOp::Shl | BinOp::Shr => 5,
            BinOp::Add | BinOp::Sub => 6,
            BinOp::Mul | BinOp::Div | BinOp::Mod => 7,
        };
        Some((prec, op))
    }

    fn parse_bin(&mut self, min_prec: u8) -> Result<Expr, String> {
        let mut lhs = self.parse_unary()?;
        loop {
            if let Some((prec, op)) = self.tok_prec() {
                if prec >= min_prec {
                    self.pos += 1;
                    let rhs = self.parse_bin(prec + 1)?;
                    lhs = Expr::Binary(op, Box::new(lhs), Box::new(rhs));
                    continue;
                }
            }
            break;
        }
        Ok(lhs)
    }

    fn parse_unary(&mut self) -> Result<Expr, String> {
        if matches!(self.peek(), Tok::Minus) {
            self.pos += 1;
            let e = self.parse_unary()?;
            // constant-fold negative literals
            return Ok(match e {
                Expr::IntLit(v) => Expr::IntLit((-(v as i64)) as u32),
                Expr::FixLit(v) => Expr::FixLit(-v),
                // v20: negate = flip the sign bit (exact, IEEE)
                Expr::F32Lit(bits) => Expr::F32Lit(bits ^ 0x8000_0000),
                other => Expr::Unary(UnOp::Neg, Box::new(other)),
            });
        }
        if matches!(self.peek(), Tok::Not) {
            self.pos += 1;
            let e = self.parse_unary()?;
            return Ok(match e {
                Expr::BoolLit(b) => Expr::BoolLit(!b),
                other => Expr::Unary(UnOp::Not, Box::new(other)),
            });
        }
        self.parse_primary()
    }

    fn parse_primary(&mut self) -> Result<Expr, String> {
        // v23.2: capture the token's OWN position before consuming — the old
        // code consumed via next() then errored with the FOLLOWING token's
        // position, so "unexpected token" errors pointed one token late.
        let (line0, col0) = (self.line(), self.col());
        let mut e = match self.next() {
            Tok::Int(v) => Expr::IntLit(v),
            Tok::Fix(v) => Expr::FixLit(v),
            Tok::F32(bits) => Expr::F32Lit(bits),
            Tok::F64(bits) => Expr::F64Lit(bits), // v23 TIER-1: f64 literal
            Tok::Atom(a) => Expr::Atom(a),
            Tok::LParen => {
                let inner = self.parse_expr()?;
                self.expect(Tok::RParen)?;
                inner
            }
            Tok::Ident(name) => {
                if name == "true" { Expr::BoolLit(true) }
                else if name == "false" { Expr::BoolLit(false) }
                else if matches!(self.peek(), Tok::LParen) {
                    self.pos += 1;
                    let mut args = Vec::new();
                    while !matches!(self.peek(), Tok::RParen) {
                        args.push(self.parse_expr()?);
                        if matches!(self.peek(), Tok::Comma) { self.pos += 1; }
                    }
                    self.expect(Tok::RParen)?;
                    Expr::Call(name, args)
                } else {
                    Expr::Ident(name)
                }
            }
            other => return Err(format!("line {}:{}: unexpected token in expression: {:?}", line0, col0, other)),
        };
        // postfix field access + v11 array indexing
        self.parse_postfix(&mut e)?;
        Ok(e)
    }
}
