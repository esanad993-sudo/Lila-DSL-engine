//! v20 DREAMTRACE — read a DRM1 branch-evidence map produced by the
//! dream self-play and cross-reference it with the cartridge, so a
//! human sees WHICH branches were never exercised across everything
//! the search ever played.
//!
//! Honest scope: this is EVIDENCE, not proof. A site untouched across
//! N minutes of guided self-play is a review candidate (dead code,
//! unreachable difficulty, or just an under-explored corner) — the same
//! epistemic status any PGO profile has. The proof-grade tools remain
//! the hash chain and the replay.
//!
//! DRM1 layout (little endian, see runtime/src/cover.zig):
//!   "DRM1" | u32 version | u32 n_sites | u64 events
//!   | u32 taken[n_sites] | u32 not_taken[n_sites] | u8 map[65536]

use crate::disasm;

pub const CONDITIONAL: &[&str] = &[
    "JZ",
    "JNZ",
    "FOR_BGN",
    "FOR_ADV",
    "FOR_MASK_BGN",
    "FOR_MASK_ADV",
    "GOTO",
];

pub const CONTROL_FLOW: &[(&str, &str)] = &[
    ("JMP", "jump (unconditional)"),
    ("JZ", "branch (jump if zero)"),
    ("JNZ", "branch (jump if nonzero)"),
    ("FOR_BGN", "entity loop head"),
    ("FOR_ADV", "entity loop advance"),
    ("FOR_MASK_BGN", "lane-scan loop head"),
    ("FOR_MASK_ADV", "lane-scan loop advance"),
    ("GOTO", "scene dispatch"),
    ("CALL_TBL", "dispatch-table call"),
    ("RET", "return"),
    ("CALL_FN", "function call"),
    ("RET_V", "valued return"),
];

pub struct DreamMap {
    pub n_sites: u32,
    pub events: u64,
    pub taken: Vec<u32>,
    pub not_taken: Vec<u32>,
}

pub fn parse_drm1(bytes: &[u8]) -> Result<DreamMap, String> {
    if bytes.len() < 20 || &bytes[0..4] != b"DRM1" {
        return Err("bad magic (not a DRM1 dream map)".into());
    }
    let ver = u32::from_le_bytes(bytes[4..8].try_into().unwrap());
    if ver != 1 {
        return Err(format!("unsupported DRM1 version {}", ver));
    }
    let n_sites = u32::from_le_bytes(bytes[8..12].try_into().unwrap());
    let events = u64::from_le_bytes(bytes[12..20].try_into().unwrap());
    let need = 20 + n_sites as usize * 8;
    if bytes.len() < need {
        return Err(format!(
            "truncated: header wants {} site pairs, {} bytes present (need {})",
            n_sites,
            bytes.len(),
            need + 65536
        ));
    }
    let mut taken = Vec::with_capacity(n_sites as usize);
    let mut not_taken = Vec::with_capacity(n_sites as usize);
    for i in 0..n_sites as usize {
        taken.push(u32::from_le_bytes(bytes[20 + i * 4..24 + i * 4].try_into().unwrap()));
    }
    let base = 20 + n_sites as usize * 4;
    for i in 0..n_sites as usize {
        not_taken.push(u32::from_le_bytes(bytes[base + i * 4..base + i * 4 + 4].try_into().unwrap()));
    }
    Ok(DreamMap { n_sites, events, taken, not_taken })
}

pub struct Site {
    pub pc: u32,
    pub mnemonic: String,
    pub fn_label: String,
    pub taken: u32,
    pub not_taken: u32,
}

/// Parse the disassembly into (pc, mnemonic, fn label) triples for the
/// control-flow opcodes, then join with the DRM1 counters.
fn collect_sites(cart: &[u8]) -> Result<Vec<Site>, String> {
    let text = disasm::disasm(cart)?;
    let mut out: Vec<Site> = Vec::new();
    let mut fn_label = String::from("?");
    for line in text.lines() {
        let line = line.trim_start();
        // "  fn[ 1] update[type 2]:" sets the context; "  fn[0] update:" too
        if line.starts_with("fn[") {
            if let Some(colon) = line.find(':') {
                fn_label = line[..colon].trim().to_string();
            }
            continue;
        }
        // instruction lines: "12 JZ 4, 0, 0  ; -> 16"
        let mut it = line.split_whitespace();
        let idx: u32 = match it.next().and_then(|t| t.parse().ok()) {
            Some(v) => v,
            None => continue,
        };
        let mn = match it.next() {
            Some(m) => m.to_string(),
            None => continue,
        };
        if CONTROL_FLOW.iter().any(|(m, _)| *m == mn) {
            out.push(Site { pc: idx, mnemonic: mn, fn_label: fn_label.clone(), taken: 0, not_taken: 0 });
        }
    }
    Ok(out)
}

pub fn report(cart: &[u8], map_bytes: &[u8]) -> Result<String, String> {
    let map = parse_drm1(map_bytes)?;
    let mut sites = collect_sites(cart)?;

    // join counters by pc
    let mut observed = 0u32;
    let mut both = 0u32;
    let mut one = 0u32;
    let mut never = 0u32;
    for s in sites.iter_mut() {
        let (t, f) = if (s.pc as usize) < map.taken.len() {
            (map.taken[s.pc as usize], map.not_taken[s.pc as usize])
        } else {
            (0, 0)
        };
        s.taken = t;
        s.not_taken = f;
        if t + f > 0 {
            observed += 1;
            if t > 0 && f > 0 {
                both += 1;
            } else {
                one += 1;
            }
        } else {
            never += 1;
        }
    }

    let mut out = String::new();
    out.push_str("== dreamtrace: branch evidence from self-play ==\n");
    out.push_str(&format!(
        "map: {} events over {} site slots | cartridge control-flow sites: {} ({} observed, {} both-sides, {} one-sided, {} never executed)\n",
        map.events,
        map.n_sites,
        sites.len(),
        observed,
        both,
        one,
        never
    ));
    if sites.is_empty() {
        out.push_str("no control-flow sites in this cartridge\n");
        return Ok(out);
    }

    // one-sided + never-executed are the actionable evidence.
    // "One-sided" is only meaningful for CONDITIONAL sites — an unconditional
    // JMP/RET is one-sided by definition, not by evidence.
    out.push_str("\n-- one-sided CONDITIONAL branches (the dark side is UNTESTED code) --\n");
    let mut any = false;
    for s in sites
        .iter()
        .filter(|s| CONDITIONAL.contains(&s.mnemonic.as_str()))
        .filter(|s| s.taken + s.not_taken > 0 && (s.taken == 0 || s.not_taken == 0))
    {
        let dir = if s.taken > 0 { "always taken" } else { "never taken" };
        out.push_str(&format!(
            "  pc {:>4} {:<12} in {:<24} {} ({}x)\n",
            s.pc,
            s.mnemonic,
            s.fn_label,
            dir,
            s.taken + s.not_taken
        ));
        any = true;
    }
    if !any {
        out.push_str("  (none — every observed conditional fired both ways)\n");
    }

    out.push_str("\n-- never-executed control-flow sites (evidence, not proof: the search never got here) --\n");
    out.push_str("  note: init() runs before the search starts recording; its sites show as never-executed by design.\n");
    let mut any = false;
    for s in sites.iter().filter(|s| s.taken + s.not_taken == 0) {
        out.push_str(&format!("  pc {:>4} {:<12} in {}\n", s.pc, s.mnemonic, s.fn_label));
        any = true;
    }
    if !any {
        out.push_str("  (none — every control-flow site fired at least once)\n");
    }

    // hot sites for orientation
    out.push_str("\n-- hottest sites (orientation only) --\n");
    let mut hot: Vec<&Site> = sites.iter().filter(|s| s.taken + s.not_taken > 0).collect();
    hot.sort_by(|a, b| (b.taken + b.not_taken).cmp(&(a.taken + a.not_taken)));
    for s in hot.iter().take(8) {
        out.push_str(&format!(
            "  pc {:>4} {:<12} in {:<24} taken {} / not {}\n",
            s.pc, s.mnemonic, s.fn_label, s.taken, s.not_taken
        ));
    }
    Ok(out)
}
