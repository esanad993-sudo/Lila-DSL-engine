//! ============================================================================
//! FORGE — SUBSYSTEM A4: AUDIO DECISION LAYER (synth or sample — measured)
//! ============================================================================
//!
//! opt::audio (subsystem 4) already fits a .wav to an O(1) FM / additive
//! synth program and prints the residual. FORGE closes the loop:
//!
//!   1. ANALYZE beyond the fit: loop candidate (autocorrelation on the
//!      amplitude envelope — repeating music becomes a pattern loop, not a
//!      40-second sample), silence head/tail (imported samples always have
//!      them), and DC offset.
//!   2. DECIDE by the platform card: residual <= synth_max_residual ->
//!      SYNTH (the v17 way: ~10 bytes of parameters, zero sample RAM);
//!      otherwise -> IMA ADPCM 4:1 (a real codec, hand-rolled below, ~230
//!      lines, zero dependencies).
//!   3. VERIFY: the ADPCM path decodes back and measures SNR against the
//!      original — the number is PRINTED, like every forge residual. A
//!      decision below the card's SNR floor is rejected and the raw PCM16
//!      ships instead (with a loud note). Never a silent surprise.
//!
//! What the host gets: either synth params (already in the .libyte — no
//! host bytes at all) or a compact sample bank entry in the forgepack.

use crate::opt::audio::{self, FittedModel, Pcm};

// ---------------- analysis ----------------

#[derive(Debug, Clone, PartialEq)]
pub struct AudioFacts {
    pub sr: u32,
    pub samples: usize,
    pub seconds: f32,
    /// leading silence, samples (first sample above 1% of peak)
    pub lead_silence: usize,
    /// trailing silence, samples
    pub tail_silence: usize,
    /// best loop candidate in samples (None = no repetition worth looping:
    /// autocorrelation peak below 0.6 of energy)
    pub loop_len: Option<usize>,
    /// loop confidence 0..1
    pub loop_score: f32,
    /// DC offset (mean), -1..1
    pub dc: f32,
}

pub fn analyze(p: &Pcm) -> AudioFacts {
    let s = &p.samples;
    let n = s.len();
    let peak = s.iter().fold(0.0f32, |m, v| m.max(v.abs())).max(1e-9);
    let thresh = peak * 0.01;
    let lead = s.iter().take_while(|&&v| v.abs() < thresh).count();
    let tail = s.iter().rev().take_while(|&&v| v.abs() < thresh).count();
    let dc = if n == 0 { 0.0 } else { s.iter().sum::<f32>() / n as f32 };
    // envelope autocorrelation: 100 Hz envelope, lag search 0.25..10 s
    let env_sr = 100usize;
    let dec = (p.sr as usize / env_sr).max(1);
    let env: Vec<f32> = (0..n / dec)
        .map(|k| {
            let a = k * dec;
            let b = (a + dec).min(n);
            s[a..b].iter().map(|v| v.abs()).sum::<f32>() / (b - a).max(1) as f32
        })
        .collect();
    let energy: f32 = env.iter().map(|v| v * v).sum();
    let mut best: Option<(usize, f32)> = None;
    if energy > 1e-9 && env.len() > 64 {
        let min_lag = env_sr / 4; // 0.25 s
        let max_lag = (env_sr * 10).min(env.len() / 2); // 10 s
        for lag in min_lag..max_lag {
            let mut c = 0.0f32;
            for k in 0..(env.len() - lag) {
                c += env[k] * env[k + lag];
            }
            let score = c / energy;
            if best.is_none() || score > best.unwrap().1 {
                best = Some((lag, score));
            }
        }
    }
    let (loop_len, loop_score) = match best {
        Some((lag, score)) if score > 0.6 => (Some(lag * dec), score),
        _ => (None, best.map(|(_, s)| s).unwrap_or(0.0)),
    };
    AudioFacts {
        sr: p.sr,
        samples: n,
        seconds: n as f32 / p.sr.max(1) as f32,
        lead_silence: lead,
        tail_silence: tail,
        loop_len,
        loop_score,
        dc,
    }
}

// ---------------- IMA ADPCM (reference codec, hand-rolled) ----------------

const STEP_TABLE: [i16; 89] = [
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66,
    73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408,
    449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,
    2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630,
    9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
    32767,
];
const INDEX_TABLE: [i8; 16] = [-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8];

/// Encode mono i16 PCM to IMA ADPCM nibble stream. Block layout: 2-byte
/// predictor + 2-byte step index + 4-bit nibbles. 4:1 compression.
pub fn adpcm_encode(pcm: &[i16]) -> Vec<u8> {
    let mut out = Vec::with_capacity(4 + pcm.len() / 2);
    let mut predictor: i16 = 0;
    let mut index: i32 = 0;
    out.extend_from_slice(&predictor.to_le_bytes());
    out.extend_from_slice(&(index as u16).to_le_bytes());
    let mut nibbles: Vec<u8> = Vec::with_capacity(pcm.len());
    for &s in pcm {
        let step = STEP_TABLE[index as usize] as i32;
        let mut diff = s as i32 - predictor as i32;
        let sign = if diff < 0 { 0x8 } else { 0x0 };
        if diff < 0 {
            diff = -diff;
        }
        // classic IMA assignment, matching the decoder EXACTLY:
        // bit2 = step, bit1 = step/2, bit0 = step/4, plus base step/8.
        // (Greedy largest-first; delta_q is rebuilt from the bits so the
        // encoder's predictor follows the decoder's bit for bit.)
        let mut code = 0u8;
        for (bit, w) in [(2usize, step), (1, step / 2), (0, step / 4)] {
            if diff >= w {
                code |= 1 << bit;
                diff -= w;
            }
        }
        let delta_q = step / 8
            + if code & 4 != 0 { step } else { 0 }
            + if code & 2 != 0 { step / 2 } else { 0 }
            + if code & 1 != 0 { step / 4 } else { 0 };
        let nib = code;
        // reconstruct exactly as the decoder will (encoder follows decoder)
        let mut recon = predictor as i32 + (if sign != 0 { -delta_q } else { delta_q });
        recon = recon.clamp(-32768, 32767);
        predictor = recon as i16;
        // step index follows the standard table
        index = (index as i32 + INDEX_TABLE[(nib & 0x7) as usize] as i32).clamp(0, 88);
        nibbles.push(nib | sign);
    }
    // pack nibble pairs
    for pair in nibbles.chunks(2) {
        let lo = pair[0] & 0x0F;
        let hi = if pair.len() > 1 { pair[1] & 0x0F } else { 0 };
        out.push(lo | (hi << 4));
    }
    out
}

/// Decode the stream from adpcm_encode (verification + host reference).
pub fn adpcm_decode(data: &[u8]) -> Vec<i16> {
    if data.len() < 4 {
        return Vec::new();
    }
    let mut predictor = i16::from_le_bytes([data[0], data[1]]) as i32;
    let mut index = u16::from_le_bytes([data[2], data[3]]) as usize;
    let n_nibbles = (data.len() - 4) * 2;
    let mut out = Vec::with_capacity(n_nibbles);
    for i in 0..n_nibbles {
        let byte = data[4 + i / 2];
        let nib = if i % 2 == 0 { byte & 0x0F } else { byte >> 4 };
        let step = STEP_TABLE[index.min(88)] as i32;
        let mut delta = step / 8;
        if nib & 0x01 != 0 {
            delta += step / 4;
        }
        if nib & 0x02 != 0 {
            delta += step / 2;
        }
        if nib & 0x04 != 0 {
            delta += step;
        }
        predictor += if nib & 0x08 != 0 { -delta } else { delta };
        predictor = predictor.clamp(-32768, 32767);
        index = (index as i32 + INDEX_TABLE[(nib & 0x07) as usize] as i32).clamp(0, 88) as usize;
        out.push(predictor as i16);
    }
    out
}

/// SNR in dB of decoded vs original (both i16 mono).
pub fn snr_db(original: &[i16], decoded: &[i16]) -> f32 {
    let n = original.len().min(decoded.len());
    if n == 0 {
        return f32::NEG_INFINITY;
    }
    let mut sig = 0.0f64;
    let mut err = 0.0f64;
    for i in 0..n {
        let s = original[i] as f64;
        let d = decoded[i] as f64;
        sig += s * s;
        err += (s - d) * (s - d);
    }
    if err <= 1e-12 {
        return 96.0; // above 16-bit measurement floor
    }
    (10.0 * (sig / err).log10()) as f32
}

// ---------------- v19: HRM — the harmonic loop voice ----------------
//
// The v18 gap: a SUSTAINED tone (menu hum, pad, engine drone) cannot be a
// chip voice (the engine's model is attack + linear decay) and correctly
// demoted to ADPCM — a codec spending 4 bits/sample forever to encode a
// signal that is mathematically ~24 numbers. HRM closes the gap: project
// the signal onto its harmonic series (Goertzel-style sin/cos inner
// products at h*f0 — exact DFT-at-frequency, no FFT needed), keep the top-K
// partials, model attack + infinite sustain, and VERIFY by re-synthesizing
// and measuring SNR against the original — the same discipline as every
// other forge decision. A decaying pluck or a melody with note changes fits
// poorly and demotes to ADPCM; a steady loop fits at 30+ dB and ships as
// ~60 bytes. (Sustained tones at "theoretical maximum" are partial tables,
// not samples.)

#[derive(Debug, Clone, PartialEq)]
pub struct HarmonicVoice {
    pub f0: f32,
    /// harmonic number, amplitude (0..1 of full scale), phase (0..2pi)
    pub partials: Vec<(u16, f32, f32)>,
    /// linear attack in samples, 0 for an already-on source
    pub attack: u32,
    /// one-shot play length in samples (host may loop past it)
    pub play_len: u32,
}

/// Fundamental by fine autocorrelation: best period in [sr/2000, sr/20]
/// with parabolic peak refinement (20 Hz..2 kHz covers musical drones).
fn est_f0(s: &[f32], sr: u32) -> Option<f32> {
    let n = s.len();
    if n < 1024 {
        return None;
    }
    let min_p = (sr as usize / 2000).max(16);
    let max_p = (sr as usize / 20).min(n / 3);
    if max_p <= min_p {
        return None;
    }
    // remove DC for period detection
    let mean = s.iter().sum::<f32>() / n as f32;
    let x: Vec<f32> = s.iter().map(|v| v - mean).collect();
    let mut best_p = 0usize;
    let mut best_r = f32::NEG_INFINITY;
    let mut rcache = vec![f32::NEG_INFINITY; max_p - min_p + 1];
    for p in min_p..=max_p {
        let m = n - p;
        let mut c = 0.0f64;
        let mut e1 = 0.0f64;
        let mut e2 = 0.0f64;
        for i in 0..m {
            c += x[i] as f64 * x[i + p] as f64;
            e1 += (x[i] * x[i]) as f64;
            e2 += (x[i + p] * x[i + p]) as f64;
        }
        let r = (c / (e1 * e2).sqrt().max(1e-12)) as f32;
        rcache[p - min_p] = r;
        if r > best_r {
            best_r = r;
            best_p = p;
        }
    }
    if best_p == 0 || best_r < 0.55 {
        return None; // not periodic enough to be a drone
    }
    // subharmonic avoidance: every integer multiple of the true period is a
    // near-tie at r=1, and the cosine is FLAT near its peak (a plain
    // threshold grabs the shoulder of the peak, not its apex — measured:
    // 220 Hz read as 222). Select the FIRST LOCAL MAXIMUM within 0.01 of
    // the global best: that is the fundamental's own apex.
    {
        let thresh = best_r - 0.01;
        best_p = 0;
        for k in 1..rcache.len() - 1 {
            if rcache[k] >= thresh && rcache[k] >= rcache[k - 1] && rcache[k] >= rcache[k + 1] {
                best_p = min_p + k;
                break;
            }
        }
        if best_p == 0 {
            return None;
        }
    }
    // parabolic refine on the correlation around best_p
    let corr_at = |p: usize| -> f32 {
        if p < min_p || p > max_p || p == 0 {
            return f32::NEG_INFINITY;
        }
        let m = n - p;
        let mut c = 0.0f64;
        for i in 0..m {
            c += x[i] as f64 * x[i + p] as f64;
        }
        (c / m as f64) as f32
    };
    let ym = corr_at(best_p);
    let yp = corr_at(best_p + 1);
    let yl = corr_at(best_p.saturating_sub(1));
    let denom = yl - 2.0 * ym + yp;
    let shift = if denom.abs() > 1e-12 { (0.5 * (yl - yp) / denom).clamp(-1.0, 1.0) } else { 0.0 };
    let period = best_p as f32 + shift;
    if period <= 0.0 {
        return None;
    }
    Some(sr as f32 / period)
}

/// Fit the harmonic model over the (trimmed) signal. Returns None when no
/// periodic fundamental exists; the SNR gate is the caller's verification.
pub fn fit_harmonic(s: &[f32], sr: u32, max_partials: usize) -> Option<HarmonicVoice> {
    let n = s.len();
    if n < 2048 {
        return None;
    }
    let f0 = est_f0(s, sr)?;
    let w0 = 2.0 * std::f32::consts::PI * f0 / sr as f32;
    // amplitude envelope in f0-period windows: attack = samples until the
    // envelope first reaches 90% of its mean over the sustain region
    let period = (sr as f32 / f0).round() as usize;
    let n_win = n / period.max(1);
    if n_win < 3 {
        return None;
    }
    let mut env = Vec::with_capacity(n_win);
    for k in 0..n_win {
        let a = k * period;
        let b = (a + period).min(n);
        let rms = (s[a..b].iter().map(|v| (v * v) as f64).sum::<f64>() / (b - a).max(1) as f64).sqrt();
        env.push(rms as f32);
    }
    let sustain_level = {
        // mean of the second half (past any attack)
        let h = &env[n_win / 2..];
        h.iter().sum::<f32>() / h.len().max(1) as f32
    };
    if sustain_level < 1e-4 {
        return None;
    }
    let mut attack_win = 0usize;
    for (k, &e) in env.iter().enumerate() {
        if e >= sustain_level * 0.9 {
            attack_win = k;
            break;
        }
    }
    let attack = (attack_win * period) as u32;
    // harmonic projection over the sustain region (skip the attack so the
    // fit targets the steady state)
    let fit_from = (attack as usize).min(n / 4);
    let fit_len = n - fit_from;
    // ---- frequency refinement (phase-slope): the autocorrelation estimate
    // is only sample-integer accurate; 0.1 Hz of error over a second of
    // projection window destroys the fit (measured: 42 dB -> 12 dB). The
    // phase measured over two half-windows rotates at exactly the frequency
    // error rate, so the difference IS the correction. One pass, exact.
    let ref_partial = {
        // the loudest harmonic by a quick coarse projection of the first 8
        let mut best_h = 1usize;
        let mut best_e = 0.0f64;
        for h in 1..=8 {
            let mut a = 0.0f64;
            let mut b = 0.0f64;
            for i in fit_from..n {
                let ph = w0 * h as f32 * i as f32;
                a += s[i] as f64 * ph.cos() as f64;
                b += s[i] as f64 * ph.sin() as f64;
            }
            let e = a * a + b * b;
            if e > best_e {
                best_e = e;
                best_h = h;
            }
        }
        best_h
    };
    let half = (fit_from + n) / 2;
    let proj_at = |f: f32, from: usize, to: usize| -> (f64, f64) {
        let w = 2.0 * std::f32::consts::PI * f * ref_partial as f32 / sr as f32;
        let mut a = 0.0f64;
        let mut b = 0.0f64;
        for i in from..to {
            a += s[i] as f64 * (w * i as f32).cos() as f64;
            b += s[i] as f64 * (w * i as f32).sin() as f64;
        }
        (a, b)
    };
    // window centers (absolute sample indexes)
    let c1 = ((fit_from + half) / 2) as f32;
    let c2 = ((half + n) / 2) as f32;
    let (a1, b1) = proj_at(f0, fit_from, half);
    let (a2, b2) = proj_at(f0, half, n);
    let ph1 = a1.atan2(b1);
    let ph2 = a2.atan2(b2);
    let mut dphi = (ph2 - ph1) as f64;
    while dphi > std::f32::consts::PI as f64 {
        dphi -= 2.0 * std::f32::consts::PI as f64;
    }
    while dphi < -std::f32::consts::PI as f64 {
        dphi += 2.0 * std::f32::consts::PI as f64;
    }
    // the phase advance across the window centers, divided by the partial's
    // harmonic number, is the frequency error (in Hz)
    let df = if c2 > c1 {
        dphi as f32 / (2.0 * std::f32::consts::PI * (c2 - c1) * ref_partial as f32) * sr as f32
    } else {
        0.0
    };
    let f0 = if df.abs() < 5.0 { f0 + df } else { f0 };
    let w0 = 2.0 * std::f32::consts::PI * f0 / sr as f32;
    let mut partials_raw: Vec<(u16, f32, f32)> = Vec::new();
    let mut h = 1usize;
    while h as f32 * f0 < sr as f32 / 2.0 && h <= 96 {
        // exact DFT-at-frequency: a_h, b_h inner products
        let mut a = 0.0f64;
        let mut b = 0.0f64;
        for i in fit_from..n {
            let ph = w0 * h as f32 * i as f32;
            a += s[i] as f64 * ph.cos() as f64;
            b += s[i] as f64 * ph.sin() as f64;
        }
        let a = (a * 2.0 / fit_len as f64) as f32;
        let b = (b * 2.0 / fit_len as f64) as f32;
        let amp = (a * a + b * b).sqrt();
        // s ~ amp*sin(wt + phase): with a = amp*sin(phase), b = amp*cos(phase)
        // the projection gives phase = atan2(a, b)
        let phase = a.atan2(b);
        partials_raw.push((h as u16, amp, phase));
        h += 1;
    }
    // keep the top-K by amplitude
    partials_raw.sort_by(|x, y| y.1.partial_cmp(&x.1).unwrap_or(std::cmp::Ordering::Equal));
    partials_raw.truncate(max_partials);
    partials_raw.sort_by_key(|p| p.0);
    if partials_raw.is_empty() {
        return None;
    }
    Some(HarmonicVoice { f0, partials: partials_raw, attack, play_len: n as u32 })
}

/// Reference synthesizer (the host's ~30-line implementation, exactly).
pub fn synthesize_harmonic(v: &HarmonicVoice, sr: u32) -> Vec<i16> {
    let n = v.play_len as usize;
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        let t = i as f32;
        let env = if (i as u32) < v.attack && v.attack > 0 {
            i as f32 / v.attack as f32
        } else {
            1.0
        };
        let mut x = 0.0f32;
        for &(h, amp, phase) in &v.partials {
            x += amp * (2.0 * std::f32::consts::PI * h as f32 * v.f0 / sr as f32 * t + phase).sin();
        }
        out.push((x * env).clamp(-1.0, 1.0).mul_add(32767.0, 0.0) as i16);
    }
    out
}

/// HRM1 section payload: the whole voice in ~60 bytes.
pub fn emit_harmonic(v: &HarmonicVoice, sr: u32) -> Vec<u8> {
    let mut o = Vec::with_capacity(16 + v.partials.len() * 7);
    o.extend_from_slice(&sr.to_le_bytes());
    o.extend_from_slice(&v.f0.to_le_bytes());
    o.extend_from_slice(&(v.partials.len() as u8).to_le_bytes());
    o.extend_from_slice(&v.attack.to_le_bytes());
    o.extend_from_slice(&v.play_len.to_le_bytes());
    for &(h, amp, phase) in &v.partials {
        o.extend_from_slice(&h.to_le_bytes());
        o.extend_from_slice(&((amp.clamp(0.0, 1.0) * 32767.0) as i16).to_le_bytes());
        let ph = ((phase / (2.0 * std::f32::consts::PI)).rem_euclid(1.0) * 65535.0).round() as u16;
        o.extend_from_slice(&ph.to_le_bytes());
    }
    o
}

// ---------------- decision ----------------

#[derive(Debug, Clone)]
pub enum AudioDecision {
    /// O(1) synth program — zero sample bytes (the .libyte carries params)
    Synth { model: FittedModel, residual: f32, equation: String },
    /// v19 harmonic loop voice — partial table in the forgepack, ~60 bytes,
    /// infinite sustain, the sustained-tone gap ADPCM used to eat
    Harmonic { bytes: usize, snr_db: f32, partials: usize, f0: f32, loop_len: Option<usize> },
    /// 4:1 IMA ADPCM sample bank entry in the forgepack
    Adpcm { bytes: usize, snr_db: f32, loop_len: Option<usize> },
    /// raw PCM16 (ADPCM verification failed the card's SNR floor)
    Pcm16 { bytes: usize, reason: String },
}

#[derive(Debug, Clone)]
pub struct AudioPolicy {
    /// worst fit residual (fraction of original RMS) that still goes synth
    pub synth_max_residual: f32,
    /// worst ADPCM SNR (dB) that still goes ADPCM
    pub adpcm_min_snr_db: f32,
    /// v19: worst HRM SNR (dB) that still ships a harmonic loop voice
    pub hrm_min_snr_db: f32,
    /// v19: partial budget for the harmonic voice
    pub hrm_max_partials: usize,
}

impl Default for AudioPolicy {
    fn default() -> Self {
        AudioPolicy {
            synth_max_residual: 0.35,
            adpcm_min_snr_db: 24.0,
            hrm_min_snr_db: 20.0,
            hrm_max_partials: 24,
        }
    }
}

/// Whole decision for one wav. Trims silence first (imported samples
/// always carry it; silence is not a sound, it is a mistake).
pub fn forge_audio(name: &str, wav: &[u8], policy: &AudioPolicy) -> Result<(AudioDecision, AudioFacts), String> {
    let pcm = audio::parse_wav(wav)?;
    let facts0 = analyze(&pcm);
    // trim lead/tail silence for BOTH paths
    let keep_from = facts0.lead_silence.min(pcm.samples.len().saturating_sub(1));
    let keep_to = pcm.samples.len().saturating_sub(facts0.tail_silence);
    let mut trimmed = Pcm { sr: pcm.sr, samples: pcm.samples[keep_from..keep_to].to_vec() };
    if trimmed.samples.len() < 32 {
        trimmed = Pcm { sr: pcm.sr, samples: pcm.samples.clone() }; // all-silence sample: keep, report
    }
    let facts = analyze(&trimmed);

    // i16 rendering (SNR measured against what the player hears)
    let to_i16 = |v: f32| (v.clamp(-1.0, 1.0) * 32767.0).round() as i16;
    let pcm16: Vec<i16> = trimmed.samples.iter().map(|&v| to_i16(v)).collect();

    // 1. synth fit first (the v17 path)
    if let Ok(fit) = audio::fit(name, &trimmed) {
        if fit.residual <= policy.synth_max_residual {
            return Ok((
                AudioDecision::Synth { model: fit.model, residual: fit.residual, equation: fit.equation },
                facts0,
            ));
        }
    }
    // 1.5 v19 HRM: sustained periodic tones -> partial table. Tried BEFORE
    // ADPCM: 60 bytes of numbers beats 4 bits/sample forever. The SNR gate
    // IS the verification — a decaying pluck or a melody fits poorly and
    // falls through to the codec, exactly like v18 did.
    if facts.seconds >= 0.3 {
        if let Some(voice) = fit_harmonic(&trimmed.samples, trimmed.sr, policy.hrm_max_partials) {
            let synth = synthesize_harmonic(&voice, trimmed.sr);
            let snr = snr_db(&pcm16, &synth);
            if snr >= policy.hrm_min_snr_db {
                return Ok((
                    AudioDecision::Harmonic {
                        bytes: emit_harmonic(&voice, trimmed.sr).len(),
                        snr_db: snr,
                        partials: voice.partials.len(),
                        f0: voice.f0,
                        loop_len: facts.loop_len,
                    },
                    facts0,
                ));
            }
        }
    }
    // 2. ADPCM + verify
    let enc = adpcm_encode(&pcm16);
    let dec = adpcm_decode(&enc);
    let snr = snr_db(&pcm16, &dec);
    if snr >= policy.adpcm_min_snr_db {
        return Ok((
            AudioDecision::Adpcm { bytes: enc.len(), snr_db: snr, loop_len: facts.loop_len },
            facts0,
        ));
    }
    // 3. raw PCM16 fallback — loud, never silent
    Ok((
        AudioDecision::Pcm16 {
            bytes: pcm16.len() * 2,
            reason: format!("ADPCM SNR {:.1} dB below floor {:.1} dB", snr, policy.adpcm_min_snr_db),
        },
        facts0,
    ))
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    fn wav_bytes(pcm: &[i16], sr: u32) -> Vec<u8> {
        let mut o = Vec::new();
        o.extend_from_slice(b"RIFF");
        let data_len = (pcm.len() * 2) as u32;
        o.extend_from_slice(&(36 + data_len).to_le_bytes());
        o.extend_from_slice(b"WAVE");
        o.extend_from_slice(b"fmt ");
        o.extend_from_slice(&16u32.to_le_bytes());
        o.extend_from_slice(&1u16.to_le_bytes()); // PCM
        o.extend_from_slice(&1u16.to_le_bytes()); // mono
        o.extend_from_slice(&sr.to_le_bytes());
        o.extend_from_slice(&(sr * 2).to_le_bytes());
        o.extend_from_slice(&2u16.to_le_bytes());
        o.extend_from_slice(&16u16.to_le_bytes());
        o.extend_from_slice(b"data");
        o.extend_from_slice(&data_len.to_le_bytes());
        for s in pcm {
            o.extend_from_slice(&s.to_le_bytes());
        }
        o
    }

    fn sine(freq: f32, secs: f32, sr: u32) -> Vec<i16> {
        let n = (secs * sr as f32) as usize;
        (0..n)
            .map(|i| ((freq * 2.0 * std::f32::consts::PI * i as f32 / sr as f32).sin() * 20000.0) as i16)
            .collect()
    }

    #[test]
    fn adpcm_roundtrip_clean_tone() {
        let pcm = sine(440.0, 0.5, 44100);
        let enc = adpcm_encode(&pcm);
        assert!(enc.len() < pcm.len() / 2 + 8); // ~4:1
        let dec = adpcm_decode(&enc);
        assert_eq!(dec.len(), pcm.len());
        let snr = snr_db(&pcm, &dec);
        assert!(snr > 24.0, "SNR {} dB", snr);
    }

    #[test]
    fn adpcm_silence_is_stable() {
        let pcm = vec![0i16; 4410];
        let dec = adpcm_decode(&adpcm_encode(&pcm));
        assert!(dec.iter().all(|&v| v.abs() < 8));
    }

    #[test]
    fn pure_sine_goes_synth() {
        // the engine's voice model is attack + LINEAR DECAY — a sustained
        // tone is NOT expressible and correctly demotes to ADPCM. So the
        // synth fixture must decay, exactly like the engine's own wavfit
        // fixtures do.
        let sr = 44100usize;
        let dur = 0.25f32;
        let n = (sr as f32 * dur) as usize;
        let pcm: Vec<i16> = (0..n)
            .map(|i| {
                let t = i as f32 / sr as f32;
                let env = (1.0 - t / dur).max(0.0); // linear decay
                ((880.0 * 2.0 * std::f32::consts::PI * t).sin() * env * 20000.0) as i16
            })
            .collect();
        let wav = wav_bytes(&pcm, 44100);
        let (d, facts) = forge_audio("ping", &wav, &AudioPolicy::default()).unwrap();
        match d {
            AudioDecision::Synth { residual, .. } => assert!(residual < 0.35, "residual {}", residual),
            other => panic!("expected Synth, got {:?}", other),
        }
        assert!(facts.seconds > 0.2 && facts.seconds < 0.3);
    }

    #[test]
    fn sustained_tone_demotes_to_adpcm() {
        // a NON-decaying tone cannot be a chip voice: the decision layer
        // must fall through to ADPCM (and it verifies at > 30 dB).
        let wav = wav_bytes(&sine(880.0, 0.25, 44100), 44100);
        let (d, _facts) = forge_audio("hum", &wav, &AudioPolicy::default()).unwrap();
        match d {
            AudioDecision::Adpcm { snr_db, .. } => assert!(snr_db > 30.0, "snr {}", snr_db),
            other => panic!("expected Adpcm, got {:?}", other),
        }
    }

    #[test]
    fn noise_goes_codec_not_synth() {
        // white noise: FM/additive fit residual will be terrible -> ADPCM/PCM
        let mut v = 12345u32;
        let pcm: Vec<i16> = (0..44100 / 2)
            .map(|_| {
                v = v.wrapping_mul(1664525).wrapping_add(1013904223);
                ((v >> 16) as i16 as f32 / 65535.0 * 30000.0) as i16
            })
            .collect();
        let wav = wav_bytes(&pcm, 44100);
        let (d, _facts) = forge_audio("hiss", &wav, &AudioPolicy::default()).unwrap();
        match d {
            AudioDecision::Synth { .. } => panic!("noise should not fit a synth model"),
            AudioDecision::Harmonic { .. } => panic!("noise should not fit a harmonic model"),
            AudioDecision::Adpcm { snr_db, .. } => assert!(snr_db > 14.0, "snr {}", snr_db),
            AudioDecision::Pcm16 { .. } => {}
        }
    }

    #[test]
    fn silence_trim_reported() {
        let mut pcm = vec![0i16; 4410]; // 0.1 s of silence
        pcm.extend_from_slice(&sine(300.0, 0.2, 44100));
        pcm.extend_from_slice(&[0i16; 4410]);
        let wav = wav_bytes(&pcm, 44100);
        let (_d, facts) = forge_audio("padded", &wav, &AudioPolicy::default()).unwrap();
        // the returned facts describe the SOURCE (trim already happened inside)
        assert!(facts.lead_silence >= 4400);
        assert!(facts.tail_silence >= 4400);
        assert!(facts.seconds > 0.28); // 0.1 + 0.2 + 0.1 s source
    }

    // ---------------- v19 HRM ----------------

    fn harmonic_tone(f0: f32, secs: f32, sr: u32, partials: &[(usize, f32)]) -> Vec<i16> {
        let n = (secs * sr as f32) as usize;
        (0..n)
            .map(|i| {
                let t = i as f32;
                let attack = (0.02 * sr as f32).min(secs * sr as f32 * 0.5); // 20 ms ramp
                let env = if t < attack { t / attack } else { 1.0 };
                let mut x = 0.0f32;
                for &(h, a) in partials {
                    x += a * (2.0 * std::f32::consts::PI * h as f32 * f0 / sr as f32 * t).sin();
                }
                (x * env * 20000.0) as i16
            })
            .collect()
    }

    #[test]
    fn sustained_tone_goes_harmonic() {
        // the v18 gap, closed: a NON-decaying tone with harmonics is a
        // partial table, not an ADPCM sample bank entry
        let pcm = harmonic_tone(220.0, 1.0, 44100, &[(1, 1.0), (2, 0.5), (3, 0.25), (4, 0.12)]);
        let wav = wav_bytes(&pcm, 44100);
        let (d, _facts) = forge_audio("hum", &wav, &AudioPolicy::default()).unwrap();
        match d {
            AudioDecision::Harmonic { snr_db, partials, f0, bytes, .. } => {
                assert!(snr_db > 20.0, "snr {}", snr_db);
                assert!(f0 > 200.0 && f0 < 240.0, "f0 {}", f0);
                assert!(partials >= 4, "partials {}", partials);
                // ~15 header + 4 partials x 6 B — vastly under ADPCM's 4:1
                assert!(bytes < 200, "bytes {}", bytes);
            }
            other => panic!("expected Harmonic, got {:?}", other),
        }
    }

    #[test]
    fn decaying_pluck_stays_synth_or_codec() {
        // a linear-decay sine is EXACTLY the engine's voice model (attack +
        // linear decay) — it belongs to Synth, not HRM. To prove HRM demotion,
        // use a signal neither model can hold: a two-note melody (sustained
        // 440 then 660 — no single f0, no decay envelope).
        let sr = 44100usize;
        let n_a = sr * 2 / 5;
        let n_b = sr * 2 / 5;
        let mut pcm = Vec::with_capacity(n_a + n_b);
        for i in 0..n_a {
            let t = i as f32 / sr as f32;
            let env = (t / 0.01).min(1.0);
            pcm.push(((440.0 * 2.0 * std::f32::consts::PI * t).sin() * env * 20000.0) as i16);
        }
        for i in 0..n_b {
            let t = i as f32 / sr as f32;
            pcm.push(((660.0 * 2.0 * std::f32::consts::PI * t).sin() * 20000.0) as i16);
        }
        let wav = wav_bytes(&pcm, 44100);
        let (d, _facts) = forge_audio("melody", &wav, &AudioPolicy::default()).unwrap();
        match d {
            AudioDecision::Harmonic { .. } => panic!("a two-note melody must not ship as one harmonic voice"),
            _ => {}
        }
    }

    #[test]
    fn emit_harmonic_is_compact() {
        let v = HarmonicVoice {
            f0: 220.0,
            partials: vec![(1, 0.5, 0.0), (2, 0.25, 1.0), (3, 0.12, 2.0)],
            attack: 882,
            play_len: 44100,
        };
        let b = emit_harmonic(&v, 44100);
        assert_eq!(b.len(), 4 + 4 + 1 + 4 + 4 + 3 * 6);
    }

    #[test]
    fn est_f0_finds_the_period() {
        let sr = 44100u32;
        let s: Vec<f32> = (0..sr / 2)
            .map(|i| (330.0 * 2.0 * std::f32::consts::PI * i as f32 / sr as f32).sin() * 0.5)
            .collect();
        let f0 = est_f0(&s, sr).expect("periodic");
        // 330 Hz or a subharmonic family member — both reproduce the signal
        let ratio = 330.0 / f0;
        assert!((ratio - 1.0).abs() < 0.02 || (ratio - 2.0).abs() < 0.02 || (ratio - 3.0).abs() < 0.02,
            "f0 {} vs 330", f0);
    }
}

