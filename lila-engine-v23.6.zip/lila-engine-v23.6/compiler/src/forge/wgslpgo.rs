//! ============================================================================
//! FORGE — SUBSYSTEM A8 (v19): SHADER PGO — the loop trip count becomes a
//! measured constant
//! ============================================================================
//!
//!   THE CLAIM: the emitted WGSL tracer is branchless with a FIXED march
//!   loop (STEPS = 96 — a hand-picked safety number). But the camera path is
//!   a pure function of time, time is the frame counter, and the frame
//!   counter is corpus-recorded: the exact set of rays the shader will ever
//!   march is KNOWN at forge time. March them here, on the CPU, with the
//!   same math the shader uses, and the loop trip count stops being a guess
//!   and becomes the MAXIMUM THE CORPUS CAN PROVE — plus a margin for GPU
//!   FP variance. This is profile-guided optimization for raymarching:
//!   96 steps becomes 31 (or whatever the art actually needs), a straight
//!   ~3x cut of the shader's inner loop, with a verification pass proving
//!   the specialized count reproduces the reference hit set bit-for-bit
//!   on every sampled ray.
//!
//!   WHY THIS IS SOUND: the march is monotone — t only grows or freezes on
//!   hit; once a ray hits (hitm = 1) t freezes forever, and once t passes
//!   MAX_DIST the miss is final (or the ray was frozen inside geometry,
//!   which is also terminal). So each ray has a "settling step" after which
//!   no further iteration can change the image. STEPS = max settling step
//!   over the sampled corpus rays + margin covers them all.
//!
//!   THE MIRROR DISCIPLINE: the CPU marcher below evaluates the SAME folded
//!   tree through the SAME node formulas the WGSL emitter emits (distance
//!   components only — gradients cannot change march dynamics), with the
//!   same EPS/MAX_DIST/camera construction. If the emitter's formulas ever
//!   drift from these, the tests catch it (a march disagreement flips the
//!   verify count).

use crate::opt::sdf::{Shape, SdfDecl, V3};

const STEPS_DEFAULT: u32 = 96; // the reference budget the generic verb emits
const MAX_DIST: f32 = 40.0;
const EPS: f32 = 0.0008;

// ---------------- the CPU mirror of the emitted node distance math ----------------

fn eval_dist(s: &Shape, p: V3) -> f32 {
    match s {
        Shape::Sphere { c, r } => {
            let q = V3::new(p.x - c.x, p.y - c.y, p.z - c.z);
            let l = (q.x * q.x + q.y * q.y + q.z * q.z).sqrt();
            l - r
        }
        Shape::Box { c, half, round } => {
            let rd = round.max(1e-5);
            let q0 = [
                (p.x - c.x).abs() - half.x + rd,
                (p.y - c.y).abs() - half.y + rd,
                (p.z - c.z).abs() - half.z + rd,
            ];
            let mx = [q0[0].max(0.0), q0[1].max(0.0), q0[2].max(0.0)];
            let d_out = (mx[0] * mx[0] + mx[1] * mx[1] + mx[2] * mx[2]).sqrt();
            let d_in = q0[0].max(q0[1].max(q0[2])).min(0.0);
            d_out + d_in - rd
        }
        Shape::Torus { c, major, minor } => {
            let q = V3::new(p.x - c.x, p.y - c.y, p.z - c.z);
            let rxz = (q.x * q.x + q.z * q.z).sqrt();
            let t2x = rxz - major;
            (t2x * t2x + q.y * q.y).sqrt() - minor
        }
        Shape::Capsule { a, b, r } => {
            let ba = V3::new(b.x - a.x, b.y - a.y, b.z - a.z);
            let pa = V3::new(p.x - a.x, p.y - a.y, p.z - a.z);
            let d = ba.x * pa.x + ba.y * pa.y + ba.z * pa.z;
            let bb = ba.x * ba.x + ba.y * ba.y + ba.z * ba.z;
            let h = (d / bb.max(1e-12)).clamp(0.0, 1.0);
            let qx = pa.x - ba.x * h;
            let qy = pa.y - ba.y * h;
            let qz = pa.z - ba.z * h;
            (qx * qx + qy * qy + qz * qz).sqrt() - r
        }
        Shape::Plane { y } => p.y - y,
        Shape::Union(kids) => kids.iter().map(|k| eval_dist(k, p)).fold(f32::INFINITY, f32::min),
        Shape::Sub(a, b) => eval_dist(a, p).max(-eval_dist(b, p)),
        Shape::Isect(a, b) => eval_dist(a, p).max(eval_dist(b, p)),
        Shape::SmoothUnion { k, kids } => {
            // running polynomial smin, exactly the emitted form
            let mut it = kids.iter();
            let mut d = match it.next() {
                Some(first) => eval_dist(first, p),
                None => return f32::INFINITY,
            };
            for kid in it {
                let c = eval_dist(kid, p);
                let h = (0.5 + 0.5 * (c - d) / *k).clamp(0.0, 1.0);
                d = c + (d - c) * h - k * h * (1.0 - h);
            }
            d
        }
        Shape::SmoothSub { k, a, b } => {
            let na = -eval_dist(a, p);
            let bb = eval_dist(b, p);
            let h = (0.5 + 0.5 * (bb - na) / *k).clamp(0.0, 1.0);
            let dm = bb + (na - bb) * h - k * h * (1.0 - h);
            -dm
        }
        Shape::Twist { k, kid } => {
            let a = k * p.y;
            let (ca, sa) = (a.cos(), a.sin());
            let q = V3::new(ca * p.x + sa * p.z, p.y, -sa * p.x + ca * p.z);
            eval_dist(kid, q)
        }
        Shape::Repeat { cell, kid } => {
            let mut q = p;
            if cell.x != 0.0 {
                q.x = p.x - cell.x * (p.x / cell.x).round();
            }
            if cell.y != 0.0 {
                q.y = p.y - cell.y * (p.y / cell.y).round();
            }
            if cell.z != 0.0 {
                q.z = p.z - cell.z * (p.z / cell.z).round();
            }
            eval_dist(kid, q)
        }
    }
}

// ---------------- the march mirror ----------------

/// One ray through the SAME camera construction fs() uses.
fn ray(decl: &SdfDecl, time_s: f32, ndc_x: f32, ndc_y: f32) -> (V3, V3) {
    let ang = time_s * 0.35;
    let (s_, c_) = (ang.sin(), ang.cos());
    let e = &decl.eye;
    let l = &decl.look;
    let ro = V3::new(
        l.x + (e.x - l.x) * c_ - (e.z - l.z) * s_,
        l.y + (e.y - l.y),
        l.z + (e.x - l.x) * s_ + (e.z - l.z) * c_,
    );
    let fw = V3::new(l.x - ro.x, l.y - ro.y, l.z - ro.z);
    let fl = (fw.x * fw.x + fw.y * fw.y + fw.z * fw.z).sqrt();
    let fw = V3::new(fw.x / fl, fw.y / fl, fw.z / fl);
    // rt = normalize(cross(fw, (0,1,0))) = (fw.z, 0, -fw.x)/len
    let rtl = (fw.z * fw.z + fw.x * fw.x).sqrt().max(1e-9);
    let rt = V3::new(fw.z / rtl, 0.0, -fw.x / rtl);
    // up = cross(rt, fw)
    let up = V3::new(
        rt.y * fw.z - rt.z * fw.y,
        rt.z * fw.x - rt.x * fw.z,
        rt.x * fw.y - rt.y * fw.x,
    );
    let mut rd = V3::new(
        fw.x * 1.6 + rt.x * ndc_x + up.x * ndc_y,
        fw.y * 1.6 + rt.y * ndc_x + up.y * ndc_y,
        fw.z * 1.6 + rt.z * ndc_x + up.z * ndc_y,
    );
    let rl = (rd.x * rd.x + rd.y * rd.y + rd.z * rd.z).sqrt();
    rd = V3::new(rd.x / rl, rd.y / rl, rd.z / rl);
    (ro, rd)
}

/// March one ray exactly like the WGSL loop. Returns (hit, t, required_steps):
/// required_steps is the settling iteration count after which the image
/// cannot change (hit registers, t passes MAX_DIST, or the march freezes
/// inside geometry).
pub fn march(decl: &SdfDecl, time_s: f32, ndc_x: f32, ndc_y: f32, cap: u32) -> (bool, f32, u32) {
    let (ro, rd) = ray(decl, time_s, ndc_x, ndc_y);
    let mut t = 0.05f32;
    let mut hitm = false;
    let mut required = cap;
    for i in 0..cap {
        let pos = V3::new(ro.x + rd.x * t, ro.y + rd.y * t, ro.z + rd.z * t);
        let d = eval_dist(&decl.root, pos);
        let m = d < EPS * t.max(1.0) && d > -EPS * 64.0;
        let was_hit = hitm;
        hitm = hitm || m;
        // t advance: freezes on hit (was_hit guards the same-step order: the
        // WGSL freezes with the UPDATED hitm — on the registering step t does
        // NOT advance)
        let adv = if hitm {
            0.0
        } else if d < -EPS * 64.0 {
            0.0
        } else {
            d
        };
        t += adv;
        if !was_hit && !hitm && adv == 0.0 && t < MAX_DIST {
            // frozen inside geometry with no hit: terminal miss
            required = i + 1;
            break;
        }
        if hitm || t >= MAX_DIST {
            required = i + 1;
            break;
        }
    }
    let hit = hitm && t < MAX_DIST;
    (hit, t, required)
}

// ---------------- the PGO pass ----------------

#[derive(Debug, Clone, PartialEq)]
pub struct WgslPgo {
    pub name: String,
    /// the measured trip count to emit
    pub steps: u32,
    /// max settling step observed across all sampled rays
    pub max_required: u32,
    /// rays marched (times x NDC samples)
    pub rays: u32,
    /// rays whose specialized march disagreed with the reference (must be 0)
    pub diffs: u32,
}

/// Sample the camera path over the corpus seconds (or one orbit period when
/// no corpus exists), march every ray at the reference budget, then verify a
/// specialized count reproduces the reference hit set exactly.
///
/// NDC sampling covers up to 2.4 aspect (21:9) — ndc.x spans +-2.4.
pub fn specialize(decl: &SdfDecl, corpus_seconds: f32) -> WgslPgo {
    // orbit period = 2pi/0.35 ~ 17.95s; cover at least one full orbit plus
    // the corpus duration (the path repeats, but the corpus tells us how
    // long the game actually runs)
    let orbit = 2.0 * std::f32::consts::PI / 0.35;
    let span = corpus_seconds.max(orbit);
    let n_times = 40u32;
    let xs = 25u32; // over [-2.4, 2.4]
    let ys = 13u32; // over [-1, 1]
    let mut max_required = 0u32;
    let mut rays = 0u32;
    // collect (hit, t) at reference for verification
    let mut reference: Vec<(bool, f32)> = Vec::with_capacity((n_times * xs * ys) as usize);
    for ti in 0..n_times {
        let time = span * ti as f32 / n_times as f32;
        for iy in 0..ys {
            for ix in 0..xs {
                let ndc_x = -2.4 + 4.8 * ix as f32 / (xs - 1) as f32;
                let ndc_y = -1.0 + 2.0 * iy as f32 / (ys - 1) as f32;
                let (hit, t, req) = march(decl, time, ndc_x, ndc_y, STEPS_DEFAULT);
                max_required = max_required.max(req);
                reference.push((hit, t));
                rays += 1;
            }
        }
    }
    // specialized count: the proof plus a 15% + 8-step margin for GPU FP
    // variance (the CPU march and the GPU march agree to within a step; the
    // margin absorbs the last-ulp differences between FP implementations)
    let steps = (((max_required as f32 * 1.15).ceil() as u32) + 8).clamp(8, STEPS_DEFAULT);
    // verify: every sampled ray must reproduce the reference hit and t
    let mut diffs = 0u32;
    let mut k = 0usize;
    for ti in 0..n_times {
        let time = span * ti as f32 / n_times as f32;
        for iy in 0..ys {
            for ix in 0..xs {
                let ndc_x = -2.4 + 4.8 * ix as f32 / (xs - 1) as f32;
                let ndc_y = -1.0 + 2.0 * iy as f32 / (ys - 1) as f32;
                let (hit, t, _) = march(decl, time, ndc_x, ndc_y, steps);
                let (rhit, rt) = reference[k];
                k += 1;
                if hit != rhit || (hit && (t - rt).abs() > 2.0 * EPS) {
                    diffs += 1;
                }
            }
        }
    }
    WgslPgo { name: decl.name.clone(), steps, max_required, rays, diffs }
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    fn sphere_decl(eye_dist: f32) -> SdfDecl {
        SdfDecl {
            name: "test".into(),
            root: Shape::Sphere { c: V3::new(0.0, 0.0, 0.0), r: 1.0 },
            color: 0x66CCFF,
            glow: 0.4,
            eye: V3::new(eye_dist, 1.5, eye_dist),
            look: V3::new(0.0, 0.0, 0.0),
            hud: false,
        }
    }

    #[test]
    fn eval_dist_sphere_exact() {
        let s = Shape::Sphere { c: V3::new(1.0, 2.0, 3.0), r: 0.5 };
        assert!((eval_dist(&s, V3::new(1.0, 2.0, 3.0)) + 0.5).abs() < 1e-6);
        assert!((eval_dist(&s, V3::new(3.0, 2.0, 3.0)) - 1.5).abs() < 1e-6);
    }

    #[test]
    fn eval_dist_box_corners() {
        let s = Shape::Box { c: V3::zero(), half: V3::new(1.0, 1.0, 1.0), round: 0.0 };
        assert!(eval_dist(&s, V3::new(0.0, 0.0, 0.0)) < -0.99); // inside ~-1
        assert!((eval_dist(&s, V3::new(2.0, 0.0, 0.0)) - 1.0).abs() < 1e-6);
        // diagonal: nearest point is the corner (1,1,0) — q0=(2,3,-1),
        // d_out = sqrt(4+9), d_in = 0
        assert!((eval_dist(&s, V3::new(3.0, 4.0, 0.0)) - (2.0f32 * 2.0 + 3.0 * 3.0).sqrt()).abs() < 1e-5);
    }

    #[test]
    fn march_hits_center_ray() {
        let d = sphere_decl(4.0);
        let (hit, t, req) = march(&d, 0.0, 0.0, 0.0, 96);
        assert!(hit, "center ray must hit the sphere");
        assert!(t > 2.0 && t < 5.0);
        assert!(req < 96);
    }

    #[test]
    fn march_misses_far_ray() {
        let d = sphere_decl(4.0);
        // straight up past the sphere (camera looks at origin from the side)
        let (hit, _t, _r) = march(&d, 0.0, 0.0, 1.0, 96);
        // ndc straight up with fw*1.6 bias may still hit — use an extreme x
        let (hit2, _t2, _r2) = march(&d, 0.0, 2.4, 0.9, 96);
        assert!(!hit || !hit2, "at least one extreme ray should miss");
    }

    #[test]
    fn specialize_cuts_steps_and_verifies() {
        let d = sphere_decl(4.0);
        let pgo = specialize(&d, 0.0);
        assert!(pgo.steps < 96, "a close sphere should need far fewer than 96 steps, got {}", pgo.steps);
        assert!(pgo.steps >= pgo.max_required, "steps must cover the max settling step");
        assert_eq!(pgo.diffs, 0, "the specialized count must reproduce the reference exactly");
        assert!(pgo.rays > 10000);
    }

    #[test]
    fn far_camera_is_its_own_measurement() {
        // sphere tracing is adaptive: far cameras march big empty strides
        // and settle FASTER than close grazing cameras. The invariant to
        // test is not a direction — it is that each specialization covers
        // its own max settling step and reproduces the reference exactly.
        let near = specialize(&sphere_decl(4.0), 0.0);
        let far = specialize(&sphere_decl(38.0), 0.0);
        assert!(near.steps >= near.max_required);
        assert!(far.steps >= far.max_required);
        assert_eq!(near.diffs, 0);
        assert_eq!(far.diffs, 0);
        assert!(near.steps > 0 && far.steps > 0);
    }

    #[test]
    fn smooth_union_and_sub_mirror() {
        // a blob carved by subtraction — the emitted-form mirror must agree
        // with plain math at a few sample points (smin is exact far from the
        // blend region)
        let a = Shape::Sphere { c: V3::new(-1.0, 0.0, 0.0), r: 1.0 };
        let b = Shape::Sphere { c: V3::new(1.0, 0.0, 0.0), r: 1.0 };
        let u = Shape::SmoothUnion { k: 0.2, kids: vec![a.clone(), b.clone()] };
        // far away, smin == min
        assert!((eval_dist(&u, V3::new(5.0, 0.0, 0.0)) - 3.0).abs() < 1e-4);
        let sub = Shape::SmoothSub { k: 0.2, a: Box::new(a), b: Box::new(b) };
        // inside a (center), far from b's surface: distance ~ -(-1) ...
        // d = -smin(-a, b): at (-1,0,0): a=-1, b=-1... just sanity check sign
        let d = eval_dist(&sub, V3::new(-1.0, 0.0, 0.0));
        assert!(d < 0.0, "inside the carved region, got {}", d);
        let d_out = eval_dist(&sub, V3::new(4.0, 0.0, 0.0));
        assert!(d_out > 0.0);
    }

    #[test]
    fn twist_repeat_eval_runs() {
        let kid = Shape::Sphere { c: V3::zero(), r: 0.5 };
        let tw = Shape::Twist { k: 0.3, kid: Box::new(kid.clone()) };
        assert!(eval_dist(&tw, V3::new(0.0, 0.0, 0.0)) < 0.0);
        let rp = Shape::Repeat { cell: V3::new(4.0, 0.0, 4.0), kid: Box::new(kid) };
        // (9,0,0) folds to (1,0,0): distance 0.5
        assert!((eval_dist(&rp, V3::new(9.0, 0.0, 0.0)) - 0.5).abs() < 1e-4);
    }
}
