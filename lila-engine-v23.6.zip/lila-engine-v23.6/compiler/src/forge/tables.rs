//! ============================================================================
//! FORGE — SUBSYSTEM B7 (v19): TABLES — code becomes data
//! ============================================================================
//!
//!   THE CLAIM: a deterministic game is a pure function. The theoretical
//!   maximum of code optimization is not compiling the code faster — it is
//!   NOT RUNNING THE CODE AT ALL. This module finds every fn in the game
//!   whose result provably depends only on its (narrow) arguments, and
//!   ships its DOMAIN as data. At install time the REAL VM executes the fn
//!   once per domain entry and caches the values in a side table; after
//!   that every call is a load instead of a program.
//!
//!   WHY THIS IS SOUND HERE AND NOWHERE ELSE:
//!     * Purity is PROVEN, not assumed: an interprocedural fixpoint over
//!       the AST. A tableable fn may touch params, locals and constants —
//!       nothing else. No global/entity/array reads (they change), no
//!       draws/audio/rng/scene effects (they mutate), no entity iteration
//!       (the live-set is hashed state). The v18 report-only scan allowed
//!       global reads; v19 does not — a table is a REPLACEMENT for the fn,
//!       so it must reproduce it on every frame, not just at bake time.
//!     * The domain comes from REAL EXECUTION: the runner mines actual
//!       argument values across the replay corpus (the same discipline as
//!       usage mining — the pipeline knows how the game CALLS the fn, not
//!       just how it is written). Without a mine file the domain falls
//!       back to the declared integer width (u8/s8 only).
//!     * The VALUES are baked by the VM itself at install — there is no
//!       second implementation of your logic anywhere. The pack carries
//!       20 bytes of decisions per table, not kilobytes of answers.
//!     * The probe is bounds-checked: an argument outside the dense domain
//!       falls through to the REAL call. The table is a cache, not a
//!       contract. Worst case (all misses) the game runs exactly as it
//!       always did.
//!     * HASH NEUTRAL BY CONSTRUCTION: the VM's stack/frames/pc/ret_val
//!       are threadlocal and OUTSIDE the hashed 2MB. A hit performs the
//!       same stack pops and the same ret_val store as the real call's
//!       OP_RET_V would; a pure fn touches nothing else. The hash chain
//!       cannot tell the difference — proven end-to-end by replaying the
//!       corpus with tables installed: `--replay movie --tables pack`
//!       must reproduce every recorded hash bit-for-bit.
//!
//!   THE PIPELINE (documented in FORGE.md §"the loop"):
//!     lilac forge game.lila                     -> report + game.minelist
//!     runner game.libyte --replay movie.lir \
//!            --mine game.minelist --mine-out game.mine
//!     lilac forge game.lila --mine-file game.mine -> pack now carries TBL1
//!     runner game.libyte --replay movie.lir --tables game.forgepack
//!                                              -> 300/300 hashes MATCH
//!

use crate::ast::{Expr, Program, Stmt, UnOp};

// ---------------- the mine file (empirical domains) ----------------

/// One mined fn: observed argument ranges across the whole corpus.
#[derive(Debug, Clone, PartialEq)]
pub struct MinedFn {
    pub fn_idx: u16,
    /// observed per-arg dense range [lo..=hi] (up to the 4 the ABI allows;
    /// promotion only ever uses the first 2)
    pub lo: [i32; 4],
    pub hi: [i32; 4],
    pub calls: u64,
}

/// "MINE" — u16 n, then per fn: u16 idx, u8 nargs,
/// per arg: i32 lo, i32 hi, u64 calls (calls counted at the call site).
#[derive(Debug, Clone, Default, PartialEq)]
pub struct MineFile {
    pub fns: Vec<MinedFn>,
}

pub fn parse_mine(bytes: &[u8]) -> Result<MineFile, String> {
    let bad = |m: &str| format!("mine file: {}", m);
    if bytes.len() < 6 || &bytes[0..4] != b"MINE" {
        return Err(bad("not a MINE file (run the runner with --mine)"));
    }
    let n = u16::from_le_bytes([bytes[4], bytes[5]]) as usize;
    let mut out = MineFile::default();
    let mut p = 6usize;
    for _ in 0..n {
        if p + 4 > bytes.len() {
            return Err(bad("truncated record header"));
        }
        let fn_idx = u16::from_le_bytes([bytes[p], bytes[p + 1]]);
        let nargs = (bytes[p + 2] as usize).min(4);
        p += 3;
        let mut lo = [0i32; 4];
        let mut hi = [0i32; 4];
        for a in 0..nargs {
            if p + 16 > bytes.len() {
                return Err(bad("truncated arg record"));
            }
            lo[a] = i32::from_le_bytes(bytes[p..p + 4].try_into().unwrap());
            hi[a] = i32::from_le_bytes(bytes[p + 4..p + 8].try_into().unwrap());
            p += 16;
        }
        out.fns.push(MinedFn { fn_idx, lo, hi, calls: 0 });
    }
    Ok(out)
}

fn emit_mine(fns: &[MinedFn]) -> Vec<u8> {
    // (test-only writer; the RUNNER is the real producer — it always
    // records both arg slots per fn, arity comes from the cartridge)
    let mut o = Vec::with_capacity(6 + fns.len() * 36);
    o.extend_from_slice(b"MINE");
    o.extend_from_slice(&(fns.len() as u16).to_le_bytes());
    for f in fns {
        o.extend_from_slice(&f.fn_idx.to_le_bytes());
        o.push(2);
        for a in 0..2 {
            o.extend_from_slice(&f.lo[a].to_le_bytes());
            o.extend_from_slice(&f.hi[a].to_le_bytes());
            o.extend_from_slice(&f.calls.to_le_bytes());
        }
    }
    o
}

// ---------------- purity: the interprocedural fixpoint ----------------

/// State for one fn during the fixpoint: whether every reachable effect is
/// a pure computation over params/locals/constants.
#[derive(Debug, Clone, PartialEq)]
pub struct Purity {
    pub name: String,
    pub pure: bool,
    pub reason: Option<String>,
}

/// The scope stack during a body walk: params first, then Let/For/ForNum
/// bindings. An Ident that is NOT a local resolves to a global or an entity
/// array — a state read, which tables must reject.
struct Scope<'a> {
    stack: Vec<&'a str>,
}

impl<'a> Scope<'a> {
    fn has(&self, name: &str) -> bool {
        self.stack.iter().any(|s| *s == name)
    }
}

/// Pure expression check. `pure_fns` is the CURRENT fixpoint approximation.
fn expr_pure(e: &Expr, scope: &Scope, pure_fns: &dyn Fn(&str) -> bool, why: &mut Option<String>) -> bool {
    match e {
        Expr::IntLit(_) | Expr::FixLit(_) | Expr::F32Lit(_) | Expr::F64Lit(_) | Expr::BoolLit(_) | Expr::Atom(_) => true,
        Expr::Ident(n) => {
            if scope.has(n) {
                true
            } else {
                *why = Some(format!("reads global '{}'", n));
                false
            }
        }
        Expr::Field(base, _) => {
            *why = Some(format!("reads entity field '{}'", field_name(base)));
            false
        }
        Expr::Index(base, _) => {
            *why = Some(format!(
                "reads array '{}'",
                match &**base {
                    Expr::Ident(n) => n.clone(),
                    other => field_name(other),
                }
            ));
            false
        }
        Expr::Unary(UnOp::Neg | UnOp::Not, inner) => expr_pure(inner, scope, pure_fns, why),
        Expr::Binary(_, a, b) => expr_pure(a, scope, pure_fns, why) && expr_pure(b, scope, pure_fns, why),
        Expr::Ternary(c, a, b) => {
            expr_pure(c, scope, pure_fns, why) && expr_pure(a, scope, pure_fns, why) && expr_pure(b, scope, pure_fns, why)
        }
        Expr::Call(name, args) => {
            // math-only builtins; everything else (key, rand, count, frame,
            // swept_hit, dist_nearest...) reads hashed state. v23.6: the
            // type casts (f64/f32/fixed/int) are deterministic value
            // conversions — pure by definition (an f64-returning fn's body
            // is full of them).
            const PURE_BUILTINS: &[&str] = &["sin", "cos", "ang", "min", "max", "abs", "clamp", "lerp",
                                             "f64", "f32", "fixed", "int"];
            if !PURE_BUILTINS.contains(&name.as_str()) && !pure_fns(name) {
                *why = Some(format!("calls non-pure fn '{}'", name));
                return false;
            }
            args.iter().all(|a| expr_pure(a, scope, pure_fns, why))
        }
        Expr::Intrin(..) => {
            *why = Some("uses an optimizer intrinsic".into());
            false
        }
    }
}

fn field_name(base: &Expr) -> String {
    match base {
        Expr::Ident(n) => n.clone(),
        _ => "<expr>".into(),
    }
}

/// Statement check. `scope` carries the visible locals; assignments may ONLY
/// target locals. Returns purity of the whole block.
fn stmt_pure<'p>(s: &'p Stmt, scope: &mut Scope<'p>, pure_fns: &dyn Fn(&str) -> bool, why: &mut Option<String>) -> bool {
    // v23.2 SPANS: positional wrapper is never a purity event — look through.
    if let Stmt::At { inner, .. } = s {
        return stmt_pure(inner, scope, pure_fns, why);
    }
    match s {
        Stmt::Let(n, e) => {
            let ok = expr_pure(e, scope, pure_fns, why);
            scope.stack.push(n.as_str());
            ok
        }
        Stmt::Assign(target, _, val) => {
            let val_ok = expr_pure(val, scope, pure_fns, why);
            let target_ok = match target {
                Expr::Ident(n) if scope.has(n) => true,
                Expr::Ident(n) => {
                    *why = Some(format!("writes global '{}'", n));
                    false
                }
                _ => {
                    *why = Some("writes an entity field or array".into());
                    false
                }
            };
            val_ok && target_ok
        }
        Stmt::If(c, a, b) => {
            expr_pure(c, scope, pure_fns, why)
                && block_pure(a, scope, pure_fns, why)
                && block_pure(b, scope, pure_fns, why)
        }
        Stmt::While(c, b) => expr_pure(c, scope, pure_fns, why) && block_pure(b, scope, pure_fns, why),
        Stmt::ForNum(n, a, b, body) => {
            // half-open range [A, B): both bounds must be state-free, and the
            // loop var is a fresh local inside the body
            let ok = expr_pure(a, scope, pure_fns, why) && expr_pure(b, scope, pure_fns, why);
            scope.stack.push(n.as_str());
            let body_ok = block_pure(body, scope, pure_fns, why);
            scope.stack.pop();
            ok && body_ok
        }
        Stmt::Switch(x, arms, default) => {
            if !expr_pure(x, scope, pure_fns, why) {
                return false;
            }
            for (_, body) in arms {
                if !block_pure(body, scope, pure_fns, why) {
                    return false;
                }
            }
            if let Some(d) = default {
                if !block_pure(d, scope, pure_fns, why) {
                    return false;
                }
            }
            true
        }
        Stmt::Return(Some(e)) => expr_pure(e, scope, pure_fns, why),
        Stmt::Return(None) | Stmt::Break | Stmt::Continue => true,
        Stmt::CallStmt(name, args) => {
            const PURE_BUILTINS: &[&str] = &["sin", "cos", "ang", "min", "max", "abs", "clamp", "lerp"];
            if !PURE_BUILTINS.contains(&name.as_str()) && !pure_fns(name) {
                *why = Some(format!("calls non-pure fn '{}'", name));
                return false;
            }
            args.iter().all(|a| expr_pure(a, scope, pure_fns, why))
        }
        // For(String,..): iterates the LIVE entities of a type — the live set
        // is hashed state, the result depends on it. Not a table.
        _ => {
            *why = Some("touches state (draw/spawn/entity/audio/camera/...)".into());
            false
        }
    }
}

fn block_pure<'p>(stmts: &'p [Stmt], scope: &mut Scope<'p>, pure_fns: &dyn Fn(&str) -> bool, why: &mut Option<String>) -> bool {
    // scope discipline: a nested block's Lets leak outward within the same fn
    // body — that matches the checker's flat-local model (codegen allocates
    // one locals frame per fn).
    stmts.iter().all(|s| stmt_pure(s, scope, pure_fns, why))
}

/// The fixpoint: start optimistic, iterate to a least fixed point.
pub fn purity_fixpoint(prog: &Program) -> Vec<Purity> {
    let names: Vec<&str> = prog.fns.iter().map(|f| f.name.as_str()).collect();
    // initial approximation: everything pure (the fixpoint only removes)
    let mut pure: Vec<bool> = vec![true; prog.fns.len()];
    loop {
        let mut changed = false;
        for (i, f) in prog.fns.iter().enumerate() {
            if !pure[i] {
                continue;
            }
            let cur: Vec<bool> = pure.clone();
            let is = |n: &str| -> bool {
                match names.iter().position(|x| *x == n) {
                    Some(k) => cur[k],
                    None => false, // not a user fn (or unknown) -> impure
                }
            };
            let mut scope = Scope { stack: f.params.iter().map(|p| p.0.as_str()).collect() };
            let mut why = None;
            if !block_pure(&f.body, &mut scope, &is, &mut why) {
                pure[i] = false;
                changed = true;
                let _ = why; // reason captured per-fn below on the final pass
            }
        }
        if !changed {
            break;
        }
    }
    // final pass to capture the human-readable reason
    prog.fns
        .iter()
        .enumerate()
        .map(|(i, f)| {
            if pure[i] {
                return Purity { name: f.name.clone(), pure: true, reason: None };
            }
            let mut why = None;
            let is = |n: &str| -> bool {
                match names.iter().position(|x| *x == n) {
                    Some(k) => pure[k],
                    None => false,
                }
            };
            let mut scope = Scope { stack: f.params.iter().map(|p| p.0.as_str()).collect() };
            let _ = block_pure(&f.body, &mut scope, &is, &mut why);
            Purity { name: f.name.clone(), pure: false, reason: why }
        })
        .collect()
}

// ---------------- the plan: candidates -> domains -> TBL1 payloads ----------------

#[derive(Debug, Clone, PartialEq)]
pub struct TablePlan {
    pub fn_idx: u16,
    pub name: String,
    pub n_args: u8,
    /// dense per-arg domains (inclusive)
    pub lo: [i32; 2],
    pub hi: [i32; 2],
    pub entries: u64,
    /// why this fn was or was not promoted (printed; the manifest records it)
    pub status: TableStatus,
    /// the TBL1 pack payload (domains only — the VM bakes the values)
    pub payload: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum TableStatus {
    Promoted { spot_verify: bool },
    Skipped(&'static str),
    /// reported but not promoted: needs mining evidence first
    NeedsMine,
}

/// Per-table entry budget (product of domain widths). A table is a CACHE;
/// beyond this the bake cost stops being trivial.
pub const MAX_ENTRIES_PER_TABLE: u64 = 4096;
/// Total entries across the whole pack (runtime arena is 64K * 4B).
pub const MAX_ENTRIES_TOTAL: u64 = 65536;

/// Decide the promotion set.
///
/// `fn_table` is the CARTRIDGE fn table (name, nparams) in wire order — the
/// same order codegen emitted records in, so index i here IS fn_idx i there.
/// `ret64` is the baked-table f64 return channel (array id + per-fn slots);
/// an f64-returning fn is tableable since v23.6 — its (lo, hi) result pair
/// rides `__ret64[slot]` on BOTH the real-call path and the probe-hit path,
/// so the hashed image stays bit-identical (see tables.zig).
/// `mine` is the optional empirical-domain file.
pub fn plan(prog: &Program, fn_table: &[(String, u8)], ret64: Option<&(u16, Vec<Option<u16>>)>, mine: Option<&MineFile>) -> Vec<TablePlan> {
    let purity = purity_fixpoint(prog);
    // name -> cartridge index (post-synth prog.fns order == ctx.fns order ==
    // cartridge records order; the same order BuildReport captured)
    let mut idx_of: std::collections::HashMap<&str, u16> = std::collections::HashMap::new();
    for (i, (n, _)) in fn_table.iter().enumerate() {
        idx_of.insert(n.as_str(), i as u16);
    }
    let mine_of: std::collections::HashMap<u16, &MinedFn> = mine
        .map(|m| m.fns.iter().map(|f| (f.fn_idx, f)).collect())
        .unwrap_or_default();

    let mut out = Vec::new();
    let mut total: u64 = 0;
    for f in &prog.fns {
        let Some(&fi) = idx_of.get(f.name.as_str()) else { continue };
        let pur = purity.iter().find(|p| p.name == f.name);
        let Some(pur) = pur else { continue };
        let params = &f.params;
        // only value-returning fns (void fns have nothing to cache; the probe
        // would set ret_val where the real call would not). Syntactic signal:
        // at least one `return expr;` — a valued fn with only implicit
        // fallthrough returns a constant 0 and is not worth a table anyway.
        let valued = f.body.iter().any(|s| matches!(s.inner(), Stmt::Return(Some(_))));
        if !valued {
            continue;
        }
        if !pur.pure {
            continue;
        }
        let n_args = params.len();
        // v23.5: f64 params move TWO cells — the (a0,a1)-keyed probe would
        // key half a value. Skip loudly (the probe's spot-verify canary
        // would also catch it, but a skipped bake is cheaper than a dead
        // table). v23.6: f64 RETURNS are fine — the (lo, hi) result rides
        // __ret64[slot] on every path (see the payload's ret_wide fields).
        if params.iter().any(|(_, pt)| *pt == crate::ast::Ty::F64) {
            out.push(TablePlan {
                fn_idx: fi,
                name: f.name.clone(),
                n_args: n_args as u8,
                lo: [0; 2],
                hi: [0; 2],
                entries: 0,
                status: TableStatus::Skipped("f64 params move 2 cells — not tableable"),
                payload: Vec::new(),
            });
            continue;
        }
        if n_args == 0 || n_args > 2 {
            out.push(TablePlan {
                fn_idx: fi,
                name: f.name.clone(),
                n_args: n_args as u8,
                lo: [0; 2],
                hi: [0; 2],
                entries: 0,
                status: TableStatus::Skipped("arity not 1 or 2"),
                payload: Vec::new(),
            });
            continue;
        }
        // domain: mined first, declared width fallback (u8/s8 only)
        let mut lo = [0i32; 2];
        let mut hi = [0i32; 2];
        let mut have_domain = false;
        if let Some(m) = mine_of.get(&fi) {
            for a in 0..n_args {
                lo[a] = m.lo[a];
                hi[a] = m.hi[a];
            }
            have_domain = hi[0] >= lo[0] && (n_args == 1 || hi[1] >= lo[1]);
        }
        if !have_domain && n_args == 1 {
            if let Some((_, ty)) = params.first() {
                match ty {
                    crate::ast::Ty::UInt(8) => {
                        lo[0] = 0;
                        hi[0] = 255;
                        have_domain = true;
                    }
                    crate::ast::Ty::SInt(8) => {
                        lo[0] = -128;
                        hi[0] = 127;
                        have_domain = true;
                    }
                    _ => {}
                }
            }
        }
        if !have_domain {
            out.push(TablePlan {
                fn_idx: fi,
                name: f.name.clone(),
                n_args: n_args as u8,
                lo: [0; 2],
                hi: [0; 2],
                entries: 0,
                status: TableStatus::NeedsMine,
                payload: Vec::new(),
            });
            continue;
        }
        let w0 = (hi[0] as i64 - lo[0] as i64 + 1) as u64;
        let w1 = if n_args == 2 { (hi[1] as i64 - lo[1] as i64 + 1) as u64 } else { 1 };
        let entries = w0 * w1;
        if entries > MAX_ENTRIES_PER_TABLE || total + entries > MAX_ENTRIES_TOTAL {
            out.push(TablePlan {
                fn_idx: fi,
                name: f.name.clone(),
                n_args: n_args as u8,
                lo,
                hi,
                entries,
                status: TableStatus::Skipped("domain exceeds entry budget"),
                payload: Vec::new(),
            });
            continue;
        }
        total += entries;
        // spot-verify small tables on first hits (defense in depth on top of
        // the compile-time purity proof — see FORGE.md)
        let spot_verify = entries <= 512;
        // v23.6: f64-return fns ride the baked __ret64 table — the payload
        // carries (ret_wide, ret_arr, ret_slot) so the runtime's bake reads
        // the pair and every probe hit rewrites it (hash-neutral: the real
        // call writes the same cells). A fn returns f64 IFF the checker gave
        // it a __ret64 slot (the AST has no ret annotations — inference is
        // checker-side; the slots ARE the fact).
        let ret_slot: Option<u16> = ret64.as_ref().and_then(|(_, slots)| slots.get(fi as usize).copied().flatten());
        let ret_wide = ret_slot.is_some();
        let (ret_arr, ret_slot) = if ret_wide {
            match ret64.as_ref() {
                Some((arr, _)) => (*arr, ret_slot.unwrap_or(0)),
                None => {
                    out.push(TablePlan {
                        fn_idx: fi,
                        name: f.name.clone(),
                        n_args: n_args as u8,
                        lo, hi,
                        entries,
                        status: TableStatus::Skipped("f64 return without a __ret64 slot (a lilac bug — please report)"),
                        payload: Vec::new(),
                    });
                    continue;
                }
            }
        } else { (0u16, 0u16) };
        let mut p = Vec::with_capacity(8 + f.name.len());
        p.push(f.name.len() as u8);
        p.extend_from_slice(f.name.as_bytes());
        p.extend_from_slice(&fi.to_le_bytes());
        p.push(n_args as u8);
        for a in 0..n_args {
            p.extend_from_slice(&lo[a].to_le_bytes());
            p.extend_from_slice(&hi[a].to_le_bytes());
        }
        p.push(spot_verify as u8);
        // v23.6 appended trailer: ret_wide u8, ret_arr u16, ret_slot u16.
        // Older runtimes stop reading at spot_verify and ignore these bytes;
        // the new runtime reads them when present (always, for one shape).
        p.push(ret_wide as u8);
        p.extend_from_slice(&ret_arr.to_le_bytes());
        p.extend_from_slice(&ret_slot.to_le_bytes());
        out.push(TablePlan {
            fn_idx: fi,
            name: f.name.clone(),
            n_args: n_args as u8,
            lo,
            hi,
            entries,
            status: TableStatus::Promoted { spot_verify },
            payload: p,
        });
    }
    out
}

/// The minelist the runner consumes: fn indices worth mining (pure, valued,
/// arity 1-2, no default domain). One index per line.
pub fn minelist(prog: &Program, fn_table: &[(String, u8)], ret64: Option<&(u16, Vec<Option<u16>>)>) -> Vec<u16> {
    plan(prog, fn_table, ret64, None)
        .into_iter()
        .filter(|t| matches!(t.status, TableStatus::NeedsMine | TableStatus::Promoted { .. }))
        .filter(|t| t.n_args >= 1 && t.n_args <= 2)
        .map(|t| t.fn_idx)
        .collect()
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    fn prog_of(src: &str) -> Program {
        let (toks, atom_names) = crate::lexer::Lexer::new(src).tokenize().unwrap();
        let mut p = crate::parser::Parser::new(toks, atom_names);
        p.parse_program().unwrap()
    }

    #[test]
    fn mine_roundtrip() {
        let f = vec![MinedFn { fn_idx: 7, lo: [3, 0, 0, 0], hi: [100, 0, 0, 0], calls: 0 }];
        let b = emit_mine(&f);
        let m = parse_mine(&b).unwrap();
        assert_eq!(m.fns.len(), 1);
        assert_eq!(m.fns[0].fn_idx, 7);
        assert_eq!((m.fns[0].lo[0], m.fns[0].hi[0]), (3, 100));
    }

    #[test]
    fn parse_mine_rejects_garbage() {
        assert!(parse_mine(b"JUNK99").is_err());
        assert!(parse_mine(b"MINE1\xFF").is_err());
    }

    #[test]
    fn purity_local_math_is_pure() {
        let p = prog_of(
            "fn ease(x: u8) { let t = x; let y = t * 2; if (y > 100) { return 100; } return y; }",
        );
        let pur = purity_fixpoint(&p);
        assert!(pur[0].pure, "got {:?}", pur[0].reason);
    }

    #[test]
    fn purity_global_read_is_not() {
        let p = prog_of("global { hp: u8 }\nfn f(x: u8) { return hp + x; }");
        let pur = purity_fixpoint(&p);
        assert!(!pur.iter().find(|x| x.name == "f").unwrap().pure);
    }

    #[test]
    fn purity_interprocedural() {
        let p = prog_of(
            "fn g(x: u8) { return x + 1; }\nfn f(x: u8) { return g(x * 2); }",
        );
        let pur = purity_fixpoint(&p);
        assert!(pur.iter().find(|x| x.name == "g").unwrap().pure);
        assert!(pur.iter().find(|x| x.name == "f").unwrap().pure);
    }

    #[test]
    fn purity_tainted_callee_poisons_caller() {
        let p = prog_of(
            "global { hp: u8 }\nfn g(x: u8) { return hp; }\nfn f(x: u8) { return g(x); }",
        );
        let pur = purity_fixpoint(&p);
        assert!(!pur.iter().find(|x| x.name == "g").unwrap().pure);
        assert!(!pur.iter().find(|x| x.name == "f").unwrap().pure);
    }

    #[test]
    fn purity_impure_builtin_call_is_not() {
        let p = prog_of("fn f(x: u8) { return x + key_down(3); }");
        assert!(!purity_fixpoint(&p)[0].pure);
    }

    #[test]
    fn purity_entity_read_is_not() {
        let p = prog_of(
            "entity Bullet { x: i16, y: i16 }\nfn f(b: u16) { return b.x; }",
        );
        assert!(!purity_fixpoint(&p)[0].pure);
    }

    #[test]
    fn purity_fornum_is_pure_entityfor_is_not() {
        let p = prog_of(
            "entity B { x: i16, y: i16 }\n\
             fn pure_loop(n: u8) { let s = 0; for (i: 0..n) { s = s + i; } return s; }\n\
             fn ent_loop() { let c = 0; for (b: B) { c = c + 1; } return c; }",
        );
        let pur = purity_fixpoint(&p);
        assert!(pur.iter().find(|x| x.name == "pure_loop").unwrap().pure);
        assert!(!pur.iter().find(|x| x.name == "ent_loop").unwrap().pure);
    }

    #[test]
    fn purity_switch_and_ternary() {
        let p = prog_of(
            "fn band(v: u8) { switch (v) { 0: { return 1; } 1|2: { return 2; } default: { return 3; } } }",
        );
        assert!(purity_fixpoint(&p)[0].pure);
    }

    #[test]
    fn plan_promotes_u8_default_domain() {
        let p = prog_of("fn hp_color(hp: u8) { if (hp < 26) { return 0xF04040FF; } return 0x40F060FF; }");
        let ft = vec![("hp_color".to_string(), 1u8)];
        let plan = plan(&p, &ft, None, None);
        assert_eq!(plan.len(), 1);
        match &plan[0].status {
            TableStatus::Promoted { .. } => {}
            other => panic!("expected promoted, got {:?}", other),
        }
        assert_eq!(plan[0].entries, 256);
        assert_eq!(plan[0].lo[0], 0);
        assert_eq!(plan[0].hi[0], 255);
        // payload: 1+8 name + 2 idx + 1 nargs + 8 domain + 1 flag
        //          + v23.6 ret trailer (1 ret_wide + 2 ret_arr + 2 ret_slot)
        assert_eq!(plan[0].payload.len(), 1 + 8 + 2 + 1 + 8 + 1 + 5);
        assert_eq!(&plan[0].payload[1..9], b"hp_color");
    }

    #[test]
    fn plan_uses_mined_dense_domain() {
        let p = prog_of("fn f(x: u16) { return x + 1; }");
        let ft = vec![("f".to_string(), 1u8)];
        let mine = MineFile {
            fns: vec![MinedFn { fn_idx: 0, lo: [10, 0, 0, 0], hi: [133, 0, 0, 0], calls: 9 }],
        };
        let plan = plan(&p, &ft, None, Some(&mine));
        match &plan[0].status {
            TableStatus::Promoted { .. } => {}
            other => panic!("expected promoted, got {:?}", other),
        }
        assert_eq!(plan[0].entries, 124);
    }

    #[test]
    fn plan_wide_domain_without_mine_needs_mining() {
        let p = prog_of("fn f(x: u16) { return x + 1; }");
        let ft = vec![("f".to_string(), 1u8)];
        let plan = plan(&p, &ft, None, None);
        assert!(matches!(plan[0].status, TableStatus::NeedsMine));
    }

    #[test]
    fn plan_two_args_multiply() {
        let p = prog_of("fn f(x: u8, y: u8) { return x + y; }");
        let ft = vec![("f".to_string(), 2u8)];
        let mine = MineFile {
            fns: vec![MinedFn { fn_idx: 0, lo: [0, 0, 0, 0], hi: [15, 15, 0, 0], calls: 5 }],
        };
        let plan = plan(&p, &ft, None, Some(&mine));
        assert!(matches!(plan[0].status, TableStatus::Promoted { .. }));
        assert_eq!(plan[0].entries, 256);
    }

    #[test]
    fn plan_rejects_too_wide_mined_domain() {
        let p = prog_of("fn f(x: u16, y: u16) { return x + y; }");
        let ft = vec![("f".to_string(), 2u8)];
        let mine = MineFile {
            fns: vec![MinedFn { fn_idx: 0, lo: [0, 0, 0, 0], hi: [3000, 3000, 0, 0], calls: 5 }],
        };
        let plan = plan(&p, &ft, None, Some(&mine));
        assert!(matches!(plan[0].status, TableStatus::Skipped(_)));
    }

    #[test]
    fn plan_skips_void_fns() {
        // a pure fn with no valued return has nothing to cache
        let p = prog_of("fn v(x: u8) { let y = x; }");
        let ft = vec![("v".to_string(), 1u8)];
        assert!(plan(&p, &ft, None, None).is_empty());
    }

    #[test]
    fn minelist_lists_needs_mine() {
        let p = prog_of("fn f(x: u16) { return x + 1; }");
        let ft = vec![("f".to_string(), 1u8)];
        let list = minelist(&p, &ft, None);
        assert_eq!(list, vec![0u16]);
    }
}
