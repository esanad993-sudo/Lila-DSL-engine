//! ============================================================================
//! FORGE — SUBSYSTEM A5: CORPUS (recorded playtests as exact measurements)
//! ============================================================================
//!
//! THE DETERMINISM DIVIDEND: because every LILA timeline is bit-identical
//! everywhere, a recorded movie is not a "sample" of gameplay — it IS the
//! gameplay, exactly. Every `runner --record` file is a bit-exact,
//! infinitely re-verifiable measurement. Other engines profile by
//! interrupting threads and hoping; LILA profiles by replaying ground
//! truth. (Branch-level coverage instrumentation is the planned 1.1 — the
//! movies below already carry the input timeline it needs.)
//!
//! Format (runtime/src/runner.zig): "LIR1" magic, u32 frame count, then
//! 12 bytes per frame: u32 input mask + u64 state hash.
//!
//! What FORGE extracts today:
//!   - input coverage: which of the 32 input bits EVER fire (a game where
//!     bit 7 never fires across 4,000 playtests is telling you something)
//!   - input entropy / distinct masks (how many game STATES does input
//!     actually distinguish — netcode fan-out planning)
//!   - movie duration stats (how long games actually run: budgets for
//!     history rings, replay buffers, savestate slots)
//!   - corpus digest: one hash over all (input, state-hash) pairs — the
//!     manifest pins it, so a "sealed" build can prove WHICH playtests
//!     its decisions were made against.

#[derive(Debug, Clone, PartialEq)]
pub struct Movie {
    pub frames: usize,
    pub inputs: Vec<u32>,
    pub hashes: Vec<u64>,
}

pub fn parse_movie(bytes: &[u8]) -> Result<Movie, String> {
    if bytes.len() < 8 || &bytes[0..4] != b"LIR1" {
        return Err("not an LIR1 movie".into());
    }
    let n = u32::from_le_bytes([bytes[4], bytes[5], bytes[6], bytes[7]]) as usize;
    let need = 8 + n * 12;
    if bytes.len() < need {
        return Err(format!("movie truncated: {} of {} bytes", bytes.len(), need));
    }
    let mut inputs = Vec::with_capacity(n);
    let mut hashes = Vec::with_capacity(n);
    for f in 0..n {
        let o = 8 + f * 12;
        inputs.push(u32::from_le_bytes([bytes[o], bytes[o + 1], bytes[o + 2], bytes[o + 3]]));
        let mut h = [0u8; 8];
        h.copy_from_slice(&bytes[o + 4..o + 12]);
        hashes.push(u64::from_le_bytes(h));
    }
    Ok(Movie { frames: n, inputs, hashes })
}

#[derive(Debug, Clone, PartialEq)]
pub struct CorpusStats {
    pub movies: usize,
    pub total_frames: usize,
    /// seconds of gameplay at 60 Hz
    pub total_seconds: f32,
    /// bit i set = input bit i fired in at least one frame
    pub input_bits_used: u32,
    /// fraction of the 32 input bits that ever fire
    pub input_coverage: f32,
    /// distinct input masks across the corpus
    pub distinct_masks: usize,
    /// longest single movie, frames
    pub longest_movie: usize,
    /// mean movie length, frames
    pub mean_movie: f32,
    /// per-input-bit frame counts (index 0..32)
    pub bit_frame_counts: [u32; 32],
    /// digest over every (input, hash) pair — pins decisions to evidence
    pub digest: u64,
}

fn fnv64(bytes: &[u8]) -> u64 {
    let mut h: u64 = 0xcbf29ce484222325;
    for &b in bytes {
        h ^= b as u64;
        h = h.wrapping_mul(0x100000001b3);
    }
    h
}

pub fn stats(movies: &[Movie]) -> CorpusStats {
    let mut bits = [0u32; 32];
    let mut masks = std::collections::HashSet::new();
    let mut total = 0usize;
    let mut longest = 0usize;
    let mut digest_in: Vec<u8> = Vec::new();
    for m in movies {
        total += m.frames;
        longest = longest.max(m.frames);
        for (&inp, &h) in m.inputs.iter().zip(m.hashes.iter()) {
            masks.insert(inp);
            for b in 0..32 {
                if inp & (1 << b) != 0 {
                    bits[b] += 1;
                }
            }
            digest_in.extend_from_slice(&inp.to_le_bytes());
            digest_in.extend_from_slice(&h.to_le_bytes());
        }
    }
    let used: u32 = bits.iter().enumerate().filter(|(_, &c)| c > 0).count() as u32 * 0
        | bits
            .iter()
            .enumerate()
            .fold(0u32, |acc, (b, &c)| if c > 0 { acc | (1 << b) } else { acc });
    CorpusStats {
        movies: movies.len(),
        total_frames: total,
        total_seconds: total as f32 / 60.0,
        input_bits_used: used.count_ones(),
        input_coverage: used.count_ones() as f32 / 32.0,
        distinct_masks: masks.len(),
        longest_movie: longest,
        mean_movie: if movies.is_empty() { 0.0 } else { total as f32 / movies.len() as f32 },
        bit_frame_counts: bits,
        digest: fnv64(&digest_in),
    }
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    fn movie(frames: &[(u32, u64)]) -> Vec<u8> {
        let mut o = Vec::new();
        o.extend_from_slice(b"LIR1");
        o.extend_from_slice(&(frames.len() as u32).to_le_bytes());
        for &(i, h) in frames {
            o.extend_from_slice(&i.to_le_bytes());
            o.extend_from_slice(&h.to_le_bytes());
        }
        o
    }

    #[test]
    fn parse_roundtrip() {
        let bytes = movie(&[(1, 0xAA), (3, 0xBB), (0, 0xCC)]);
        let m = parse_movie(&bytes).unwrap();
        assert_eq!(m.frames, 3);
        assert_eq!(m.inputs, vec![1, 3, 0]);
        assert_eq!(m.hashes, vec![0xAA, 0xBB, 0xCC]);
    }

    #[test]
    fn rejects_garbage_and_truncation() {
        assert!(parse_movie(b"NOPE").is_err());
        let bytes = movie(&[(1, 2), (3, 4)]);
        assert!(parse_movie(&bytes[..bytes.len() - 1]).is_err());
    }

    #[test]
    fn stats_coverage() {
        let m1 = parse_movie(&movie(&[(1, 10), (2, 11), (1, 12)])).unwrap();
        let m2 = parse_movie(&movie(&[(5, 20)])).unwrap();
        let s = stats(&[m1, m2]);
        assert_eq!(s.movies, 2);
        assert_eq!(s.total_frames, 4);
        // bits 0, 1, 2 used
        assert_eq!(s.input_bits_used, 3);
        assert_eq!(s.input_coverage, 3.0 / 32.0);
        assert_eq!(s.distinct_masks, 3);
        assert_eq!(s.longest_movie, 3);
        assert_eq!(s.bit_frame_counts[0], 3);
        assert!(s.digest != 0);
    }

    #[test]
    fn digest_distinguishes_corpora() {
        let a = parse_movie(&movie(&[(1, 10)])).unwrap();
        let b = parse_movie(&movie(&[(1, 11)])).unwrap();
        assert_ne!(stats(&[a]).digest, stats(&[b]).digest);
    }
}
