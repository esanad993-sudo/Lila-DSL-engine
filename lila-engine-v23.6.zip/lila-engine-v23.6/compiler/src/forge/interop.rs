//! ============================================================================
//! forge/interop.rs — v23 BRIDGE EMITTER (--emit-bridges)
//! ============================================================================
//!
//! THE POINTER-OVERLAY CONTRACT (see hosting/INTEGRATION.md "v23"):
//!
//!   The host engine (Unreal C++, Unity C#, plain C) allocates the entity
//!   arrays ITSELF — a TArray<FLilaEnemyRow> / NativeArray<LilaEnemyRow> /
//!   malloc'd block — and hands LILA the raw pointer. LILA's Zig runtime
//!   wraps that memory as the mirror surface of its dense SoA rows: every
//!   tick, the entity bridge writes live slots straight into the host's
//!   buffer IN PLACE. No marshalling, no copies at the boundary, no
//!   per-field FFI calls — one branchless lane scatter per type.
//!
//! THIS FILE is why that is safe: the layouts the runtime writes through
//! are GENERATED HERE, from the same post-SoA `Ctx` that produced the
//! .libyte schema. The Rust compiler is the single source of truth; the
//! emitted headers carry static asserts (C) and runtime asserts (C#) that
//! fail the host build the moment a schema change drifted the layout, and
//! `lila_overlay_install` re-derives the layout from the loaded cartridge
//! and REFUSES a stale buffer (FNV-1a layout hash, the same discipline as
//! lila_tables_install's stale-pack check).
//!
//! THE ROW LAYOUT (identical bytes in .h, .cs and the Zig overlay):
//!
//!   - lane 0 is always `lila_meta`: u32, bit0 = alive, bits 4..15 = the
//!     slot generation (the same (gen, idx) pair the handle system uses;
//!     the ARRAY INDEX of the row IS the entity slot index)
//!   - then every DENSE entity field, in FINAL field order — the
//!     access-density order opt::soa computed (x/y/vx/vx first), or
//!     declaration order for legacy (non-optimize) games
//!   - per-field lane sizes:
//!       fixed Q24.8   -> float   (4B)  exact: value * 2^-8, no rounding loss
//!       f32           -> float   (4B)  the raw IEEE-754 bits, reinterpreted
//!       int/bool/ang  -> u8/i8, u16/i16, u32/i32  (bits rounded up to a
//!                        byte multiple; signed lanes follow the registry's
//!                        signed flag)
//!   - cold fields STAY BEHIND the typed-field pull API (lila_field_read):
//!     the overlay row is the hot register window, and it stays minimal.
//!
//! DETERMINISM (the two red lines hold):
//!   - the overlay is an EXPORT SURFACE: LILA reads its flat image and
//!     writes host memory. Engine memory is never touched by a flush, so
//!     the wyhash chain, snapshots and rollback are bit-identical with or
//!     without overlays installed (pinned by test_v23.zig).
//!   - the import path (`lila_overlay_spawn_from`) quantizes host floats
//!     through the SAME f*256 truncation as lila_f_to_q, at host-chosen
//!     points (boot / level load): a spawn is a simulation event, hashed
//!     and snapshot-safe like any other. No float ever lands in a
//!     simulation word unquantized.
//!
//! Usage:
//!   lilac build game.lila --emit-bridges            # next to the .libyte
//!   lilac build game.lila --emit-bridges Source/Lila # into a directory

use crate::ast::*;
use crate::checker::{Ctx, VT};

// ----------------------------------------------------------------------------
// the shared layout model
// ----------------------------------------------------------------------------

/// One host-side lane: where a dense field lands in the interop row.
pub struct LaneRow {
    pub name: String,
    /// wire value-type code (mirrors libyte.rs: Fixed=0 Int=1 Bool=2 Ang=3 F32=4)
    pub vt: u8,
    pub bits: u8,
    pub signed: bool,
    /// bit offset inside the engine's dense row (identity of the source field)
    pub off_bits: u16,
    /// lane size in bytes: 1, 2 or 4
    pub size: u32,
    /// byte offset of the lane inside the interop row (after lila_meta)
    pub off: u32,
}

/// One entity type's interop row layout.
pub struct TypeLayout {
    pub name: String,
    /// entity type index == lila_overlay_install's `type`
    pub index: usize,
    pub lanes: Vec<LaneRow>,
    /// sizeof(struct) including the 4-byte lila_meta lane
    pub row_size: u32,
    /// declared max live entities (the host's allocation hint)
    pub max_live: u32,
}

fn wire_vt(vt: &VT) -> u8 {
    match vt {
        VT::Fixed => 0,
        VT::Int => 1,
        VT::Bool => 2,
        VT::F32 => 4,
        _ => 3, // ang (entity fields are never Ent/Pool — checker guarantees)
    }
}

fn lane_size(vt: &VT, bits: u8) -> u32 {
    match vt {
        VT::Fixed | VT::F32 => 4,
        _ => {
            if bits <= 8 { 1 } else if bits <= 16 { 2 } else { 4 }
        }
    }
}

/// FNV-1a 32 — tiny, dependency-free, and mirrored byte-for-byte in
/// runtime/src/overlay.zig. This is the stale-code tripwire: the compiler
/// stamps it into both emitted files, the runtime recomputes it from the
/// loaded cartridge's typed-field registry, and `lila_overlay_install`
/// refuses the buffer when they disagree.
pub fn layout_hash(types: &[TypeLayout]) -> u32 {
    let mut h: u32 = 0x811c_9dc5;
    fn mix(h: u32, b: u8) -> u32 {
        (h ^ b as u32).wrapping_mul(0x0100_0193)
    }
    h = mix(h, types.len() as u8);
    for ty in types {
        h = mix(h, ty.lanes.len() as u8);
        h = mix(h, ty.row_size as u8);
        h = mix(h, (ty.row_size >> 8) as u8);
        for l in &ty.lanes {
            h = mix(h, l.vt);
            h = mix(h, l.size as u8);
            h = mix(h, if l.signed { 1 } else { 0 });
            h = mix(h, l.bits);
            h = mix(h, (l.off_bits & 0xFF) as u8);
            h = mix(h, (l.off_bits >> 8) as u8);
        }
    }
    h
}

/// Build every entity type's interop layout from the FINAL post-SoA Ctx.
/// Dense fields only, in registry order (which is `ctx.entities[t].fields`
/// order — rebuild_registry pushes exactly that sequence).
pub fn layouts(ctx: &Ctx) -> Vec<TypeLayout> {
    let mut out = Vec::new();
    for (ei, e) in ctx.entities.iter().enumerate() {
        let mut lanes = Vec::new();
        let mut off: u32 = 4; // lane 0 is lila_meta
        for f in e.fields.iter().filter(|f| !f.cold) {
            let size = lane_size(&f.vt, f.bits);
            lanes.push(LaneRow {
                name: f.name.clone(),
                vt: wire_vt(&f.vt),
                bits: f.bits,
                signed: f.signed,
                off_bits: f.off_bits,
                size,
                off,
            });
            off += size;
        }
        out.push(TypeLayout {
            name: e.name.clone(),
            index: ei,
            lanes,
            row_size: off,
            max_live: e.max_live as u32,
        });
    }
    out
}

// ----------------------------------------------------------------------------
// name helpers
// ----------------------------------------------------------------------------

/// Enemy / big_rock -> LilaEnemyRow / LilaBigRockRow
fn pascal(name: &str) -> String {
    let mut s = String::new();
    let mut cap = true;
    for ch in name.chars() {
        if ch == '_' {
            cap = true;
        } else if cap {
            s.extend(ch.to_uppercase());
            cap = false;
        } else {
            s.push(ch);
        }
    }
    s
}

/// C / C# reserved words get an `_l` suffix IN BOTH emitted files so the
/// layouts can never drift apart over an escaping difference.
fn safe_ident(name: &str) -> String {
    const KEYWORDS: &[&str] = &[
        // shared C/C++/C# hazards a game field could plausibly hit
        "bool", "break", "case", "char", "const", "continue", "default", "do",
        "double", "else", "enum", "float", "for", "goto", "if", "int", "long",
        "new", "object", "return", "short", "signed", "sizeof", "static",
        "struct", "switch", "this", "typedef", "union", "unsigned", "void",
        "volatile", "while", "string", "base", "lock", "event", "in", "out",
        "ref", "byte", "sbyte", "uint", "ulong", "ushort", "null", "true",
        "false", "fixed", "value", "params", "readonly", "sealed", "stackalloc",
        "using", "virtual", "async", "await", "extern", "internal", "private",
        "protected", "public", "override", "class", "delegate", "interface",
        "namespace", "operator", "get", "set",
    ];
    if KEYWORDS.contains(&name) {
        format!("{}_l", name)
    } else {
        name.to_string()
    }
}

fn c_type(size: u32, signed: bool) -> &'static str {
    match (size, signed) {
        (1, false) => "uint8_t",
        (1, true) => "int8_t",
        (2, false) => "uint16_t",
        (2, true) => "int16_t",
        _ => {
            if signed { "int32_t" } else { "uint32_t" }
        }
    }
}

/// The C member type for a lane: fixed and f32 lanes are FLOATS (the flush
/// writes converted f32 / raw IEEE bits); int lanes are sized integers.
fn c_lane_type(l: &LaneRow) -> &'static str {
    match l.vt {
        0 | 4 => "float",
        _ => c_type(l.size, l.signed),
    }
}

fn cs_type(size: u32, signed: bool) -> &'static str {
    match (size, signed) {
        (1, false) => "byte",
        (1, true) => "sbyte",
        (2, false) => "ushort",
        (2, true) => "short",
        _ => {
            if signed { "int" } else { "uint" }
        }
    }
}

/// The C# member type for a lane (must mirror c_lane_type exactly).
fn cs_lane_type(l: &LaneRow) -> &'static str {
    match l.vt {
        0 | 4 => "float",
        _ => cs_type(l.size, l.signed),
    }
}

fn lane_comment(l: &LaneRow) -> String {
    match l.vt {
        0 => "fixed Q24.8 -> f32 (exact x256 domain)".to_string(),
        4 => "f32 (raw IEEE-754 bits)".to_string(),
        _ => format!("int lane: {} bits", l.bits),
    }
}

// ----------------------------------------------------------------------------
// the emitters
// ----------------------------------------------------------------------------

#[derive(Debug)]
pub struct InteropReport {
    pub types: usize,
    pub lanes: usize,
    pub hash: u32,
}

/// Build the layouts, stamp the hash, and write LilaInterop.h + LilaInterop.cs
/// into `dir` (created if missing). Called from compile_source AFTER the
/// optimizer passes — the Ctx field order is final at that point.
pub fn emit(ctx: &Ctx, dir: &str) -> Result<InteropReport, String> {
    let types = layouts(ctx);
    let hash = layout_hash(&types);
    let lanes: usize = types.iter().map(|t| t.lanes.len()).sum();

    let dir_path = std::path::Path::new(dir);
    std::fs::create_dir_all(dir_path)
        .map_err(|e| format!("--emit-bridges: cannot create '{}': {}", dir, e))?;

    let h_path = dir_path.join("LilaInterop.h");
    std::fs::write(&h_path, emit_header(ctx, &types, hash))
        .map_err(|e| format!("--emit-bridges: cannot write '{}': {}", h_path.display(), e))?;
    let cs_path = dir_path.join("LilaInterop.cs");
    std::fs::write(&cs_path, emit_csharp(ctx, &types, hash))
        .map_err(|e| format!("--emit-bridges: cannot write '{}': {}", cs_path.display(), e))?;

    Ok(InteropReport { types: types.len(), lanes, hash })
}

fn banner(ctx: &Ctx, hash: u32) -> String {
    format!(
        "// GENERATED by lilac v23 --emit-bridges from '{}' — DO NOT EDIT BY HAND.\n\
         // Regenerate with:  lilac build <game>.lila --emit-bridges <this-dir>\n\
         // The Rust compiler is the layout source of truth: these structs match\n\
         // the cartridge's post-SoA dense rows bit-for-bit (layout hash 0x{:08X}).\n",
        if ctx.game.title.is_empty() { "<game>" } else { ctx.game.title.as_str() },
        hash
    )
}

fn emit_header(ctx: &Ctx, types: &[TypeLayout], hash: u32) -> String {
    use std::fmt::Write;
    let mut o = String::new();
    let _ = writeln!(o, "{}", banner(ctx, hash));
    let _ = write!(o,
        "//\n\
         // THE POINTER-OVERLAY ABI (see lila.h \"v23 / ABI 5\"): allocate an array of\n\
         // these rows yourself (TArray<FLilaEnemyRow>, NativeArray<LilaEnemyRow>,\n\
         // malloc — anything contiguous), then either:\n\
         //\n\
         //   lila_overlay_install(LILA_ENEMY_TYPE, (uint8_t*)rows, sizeof(FLilaEnemyRow),\n\
         //                        count, LILA_INTEROP_LAYOUT_HASH);\n\
         //   ... per frame: lila_input_set(...); lila_overlay_tick();\n\
         //\n\
         // or, for single-type games, the one-call form:\n\
         //\n\
         //   lila_tick_pipeline((uint8_t*)rows, count);\n\
         //\n\
         // Row i mirrors entity slot i: bit0 of lila_meta = alive, bits 4..15 =\n\
         // slot generation (stale rows are unambiguous, like handles). Little-\n\
         // endian hosts only (UE/Unity targets are LE). Cold fields stay behind\n\
         // the lila_field_read pull API — this row is the hot register window.\n\
         //\n\
         // DRIFT IS A BUILD ERROR: every struct below carries static asserts on\n\
         // its exact size and every lane offset. If they fire, a schema change\n\
         // happened without regenerating this file.\n\
         #ifndef LILA_INTEROP_H\n\
         #define LILA_INTEROP_H\n\n\
         #include <stdint.h>\n\
         #include <stddef.h>\n\n\
         #define LILA_INTEROP_ABI 5\n\
         #define LILA_INTEROP_TYPES {}\n\
         #define LILA_INTEROP_LAYOUT_HASH 0x{:08X}u\n\n",
        types.len(), hash);

    for ty in types {
        let sname = format!("Lila{}Row", pascal(&ty.name));
        let _ = write!(o, "#pragma pack(push, 1)\ntypedef struct {}_ {{\n", sname);
        let _ = write!(o, "    uint32_t lila_meta;   /* bit0 alive, bits 4..15 slot generation */\n");
        for l in &ty.lanes {
            let id = safe_ident(&l.name);
            let _ = write!(o, "    {} {:<10} /* +{:>3} */ /* {} */\n",
                c_lane_type(l), format!("{};", id), l.off, lane_comment(l));
        }
        let _ = write!(o, "}} {};\n#pragma pack(pop)\n", sname);
        // size + per-lane offset asserts
        let _ = write!(o, "#if defined(__cplusplus)\n\
             static_assert(sizeof({s}) == {n}, \"LILA interop layout drift (regenerate LilaInterop.h)\");\n\
             #else\n\
             _Static_assert(sizeof({s}) == {n}, \"LILA interop layout drift (regenerate LilaInterop.h)\");\n\
             #endif\n",
            s = sname, n = ty.row_size);
        for l in &ty.lanes {
            let id = safe_ident(&l.name);
            let _ = write!(o, "#if defined(__cplusplus)\n\
                 static_assert(offsetof({s}, {m}) == {o_}, \"LILA interop lane drift (regenerate LilaInterop.h)\");\n\
                 #else\n\
                 _Static_assert(offsetof({s}, {m}) == {o_}, \"LILA interop lane drift (regenerate LilaInterop.h)\");\n\
                 #endif\n",
                s = sname, m = id, o_ = l.off);
        }
        let _ = write!(o, "#define LILA_{}_TYPE {}\n", pascal(&ty.name).to_uppercase(), ty.index);
        let _ = write!(o, "#define LILA_{}_ROW_BYTES {}\n", pascal(&ty.name).to_uppercase(), ty.row_size);
        let _ = write!(o, "#define LILA_{}_MAX_LIVE {}\n\n", pascal(&ty.name).to_uppercase(), ty.max_live);
    }
    o.push_str("#endif /* LILA_INTEROP_H */\n");
    o
}

fn emit_csharp(ctx: &Ctx, types: &[TypeLayout], hash: u32) -> String {
    use std::fmt::Write;
    let mut o = String::new();
    let _ = writeln!(o, "{}", banner(ctx, hash));
    let _ = write!(o,
        "// Unity side of the pointer-overlay ABI: pair this file with LilaBridge.cs\n\
         // (lila_overlay_install / lila_overlay_tick / lila_tick_pipeline) and keep\n\
         // the row array in UNMANAGED memory — NativeArray<T>(Allocator.Persistent)\n\
         // or UnsafeUtility.Malloc — so the C# GC never tracks a single row.\n\
         //\n\
         // [StructLayout(Pack = 1)] kills every managed padding: these structs are\n\
         // byte-for-byte the C ones in LilaInterop.h. Call LilaInteropLayout.Validate()\n\
         // once at boot — it throws on layout drift (stale generated file).\n\
         \n\
         using System;\n\
         using System.Runtime.InteropServices;\n\n\
         namespace Lila\n\
         {{\n\
             public static class LilaInteropLayout\n\
             {{\n\
                 public const uint Abi = 5;\n\
                 public const int Types = {};\n\
                 public const uint LayoutHash = 0x{:08X}u;\n\n\
                 /// <summary>Throws InvalidOperationException on layout drift.\n\
                 /// Call once at boot (Awake) before any overlay install.</summary>\n\
                 public static void Validate()\n\
                 {{\n",
        types.len(), hash);

    for ty in types {
        let sname = format!("Lila{}Row", pascal(&ty.name));
        let _ = write!(o, "                    if (Marshal.SizeOf(typeof({})) != {}) Throw(\"{}\");\n",
            sname, ty.row_size, sname);
        for l in &ty.lanes {
            let id = safe_ident(&l.name);
            let _ = write!(o, "                    if (Marshal.OffsetOf(typeof({}), \"{}\").ToInt64() != {}) Throw(\"{}.{}\");\n",
                sname, id, l.off, sname, id);
        }
    }
    o.push_str(
        "                }\n\n\
         \x20               static void Throw(string what)\n\
         \x20               {\n\
         \x20                   throw new InvalidOperationException(what + \": LILA interop layout drift — regenerate LilaInterop.cs (lilac build --emit-bridges)\");\n\
         \x20               }\n\
         \x20           }\n\n");

    for ty in types {
        let sname = format!("Lila{}Row", pascal(&ty.name));
        let _ = write!(o, "    [StructLayout(LayoutKind.Sequential, Pack = 1)]\n    public struct {} // {} bytes; array index == entity slot\n    {{\n        public uint lila_meta; // bit0 alive, bits 4..15 slot generation\n",
            sname, ty.row_size);
        for l in &ty.lanes {
            let id = safe_ident(&l.name);
            let _ = write!(o, "        public {} {}; // {} (byte {})\n",
                cs_lane_type(l), id, lane_comment(l), l.off);
        }
        let _ = write!(o,
            "    }}\n\n    public static class {}Info\n    {{\n        public const int Type = {};\n        public const int RowBytes = {};\n        public const int MaxLive = {};\n    }}\n",
            pascal(&ty.name), ty.index, ty.row_size, ty.max_live);
    }
    o.push_str("}\n");
    o
}

// ----------------------------------------------------------------------------
// tests
// ----------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    fn ctx_of(src: &str) -> Ctx {
        let toks = crate::lexer::Lexer::new(src).tokenize().unwrap().0;
        let mut p = crate::parser::Parser::new(toks, Vec::new());
        let prog = p.parse_program().unwrap();
        let atoms = std::mem::take(&mut p.atom_names);
        crate::checker::check(&prog, atoms, &Default::default()).unwrap()
    }

    #[test]
    fn lane_sizing_follows_the_contract() {
        let mut types = layouts(&ctx_of(
            "game { optimize: true }\n\
             entity E { x: fixed  y: fixed  hp: u8 = 3  rot: ang = 0  big: s16 = 0  cold bio: u8 = 0 }\n\
             fn init() { }\n",
        ));
        assert_eq!(types.len(), 1);
        let t = types.remove(0);
        // dense fields only — the cold field is excluded
        assert_eq!(t.lanes.iter().filter(|l| l.name == "bio").count(), 0);
        // fixed -> 4B float lanes, u8/ang -> 1-2B int lanes, meta is 4B
        let x = t.lanes.iter().find(|l| l.name == "x").unwrap();
        assert_eq!((x.size, x.vt), (4, 0));
        let hp = t.lanes.iter().find(|l| l.name == "hp").unwrap();
        assert_eq!((hp.size, hp.vt), (1, 1));
        let big = t.lanes.iter().find(|l| l.name == "big").unwrap();
        assert_eq!((big.size, big.signed as u8), (2, 1));
        // row_size = meta + sum(lane sizes)
        let sum: u32 = 4 + t.lanes.iter().map(|l| l.size).sum::<u32>();
        assert_eq!(t.row_size, sum);
    }

    #[test]
    fn layout_hash_is_order_sensitive_and_stable() {
        let a = layouts(&ctx_of(
            "game { optimize: false }\n\
             entity A { x: fixed  hp: u8 = 1 }\nentity B { y: fixed }\nfn init() { }\n",
        ));
        let b = layouts(&ctx_of(
            "game { optimize: false }\n\
             entity A { hp: u8 = 1  x: fixed }\nentity B { y: fixed }\nfn init() { }\n",
        ));
        assert_eq!(layout_hash(&a), layout_hash(&a)); // stable
        assert_ne!(layout_hash(&a), layout_hash(&b)); // field order matters
    }

    #[test]
    fn emitted_files_carry_the_hash_and_asserts() {
        let dir = std::env::temp_dir().join("lila_v23_interop");
        let _ = std::fs::remove_dir_all(&dir);
        let ctx = ctx_of(
            "game { title: \"T\"  optimize: false }\n\
             entity Drone { x: fixed  y: fixed  hp: u8 = 3 }\nfn init() { }\n",
        );
        let rep = emit(&ctx, dir.to_str().unwrap()).unwrap();
        assert_eq!(rep.types, 1);
        let h = std::fs::read_to_string(dir.join("LilaInterop.h")).unwrap();
        let cs = std::fs::read_to_string(dir.join("LilaInterop.cs")).unwrap();
        assert!(h.contains(&format!("0x{:08X}u", rep.hash)));
        assert!(cs.contains(&format!("0x{:08X}u", rep.hash)));
        assert!(h.contains("typedef struct LilaDroneRow_"));
        assert!(h.contains("_Static_assert(sizeof(LilaDroneRow) == 13")); // 4 meta + 4 x + 4 y + 1 hp
        assert!(cs.contains("public struct LilaDroneRow"));
        assert!(cs.contains("Validate()"));
        // both files must agree on the meta lane doc
        assert!(h.contains("lila_meta") && cs.contains("lila_meta"));
    }
}
