//! ============================================================================
//! FORGE — SUBSYSTEM A6: LOGIC & USAGE (the whole-game view)
//! ============================================================================
//!
//! FORGE's asset decisions are not made in isolation — they are made
//! against the CODE THAT DRAWS THE ASSETS. This is the piece no other
//! asset pipeline has: an importer sees a PNG; FORGE sees "a PNG that is
//! only ever drawn 64 pixels wide by these five call sites."
//!
//!   1. USAGE MINING: walk every draw call (`draw`, `draw3d`, `draw3di`,
//!      particles) and collect conservative on-screen size bounds per
//!      sprite atom: literal scale factors, particle travel (speed x life),
//!      and the screen/world dimensions as the hard ceiling. Conservative
//!      means NEVER an underestimate — underestimating loses detail;
//!      overestimating just keeps some. The texture pass then clamps
//!      resolution to these bounds (the resolution IS the compression).
//!
//!   2. PURE-FN TABLE CANDIDATES: a fn with no side effects whose
//!      parameters are narrow ints (total domain <= 2^18) is a table
//!      waiting to be precomputed. v18 ANALYZES and reports candidates
//!      (the opt-in emission rewrite is planned for 19 — codegen stays
//!      untouched in v18, byte-identical cartridges guaranteed).
//!
//!   3. ENTITY-MIX REPORT: per-entity spawn capacities + FSM bindings —
//!      the same numbers opt::arena proved, re-stated in the forge report
//!      next to the asset decisions they inform (mesh budgeting).

use crate::ast::{Expr, Program, Stmt};

// ---------------- 1. usage mining ----------------

#[derive(Debug, Clone, PartialEq)]
pub struct UsageBounds {
    /// sprite atom -> (max_w_px, max_h_px) — conservative ceiling
    pub sprite: std::collections::HashMap<u16, (u32, u32)>,
    /// smallest bound found across ALL sprites (default for unmapped)
    pub screen: (u32, u32),
}

/// Walk the program's statements and collect every sprite-size fact we can
/// prove WITHOUT interpreting: literal scales, particle travel bounds, and
/// the screen as the hard ceiling (nothing draws larger than the viewport).
pub fn mine_usage(prog: &Program) -> UsageBounds {
    let screen = match &prog.game {
        Some(g) => {
            let (ww, wh) = (g.world_w.unwrap_or(g.width), g.world_h.unwrap_or(g.height));
            (ww.max(g.width), wh.max(g.height))
        }
        None => (320, 240),
    };
    let mut out = UsageBounds { sprite: std::collections::HashMap::new(), screen };
    let mut bump = |atom: u16, (w, h): (u32, u32)| {
        let e = out.sprite.entry(atom).or_insert((1, 1));
        e.0 = e.0.max(w);
        e.1 = e.1.max(h);
    };
    // particles: the engine draws `sprite` at radius = speed * life
    // (travel bound), fade-shrunk but never larger than at spawn.
    for p in &prog.particles {
        let span = ((p.speed_fix as i64 * p.life as i64) / 256) as i64; // px
        let bound = span.clamp(1, 1 << 20) as u32 * 2;
        bump(p.sprite, (bound.min(screen.0).max(1), bound.min(screen.1).max(1)));
    }
    // walk statements for literal-scaled draw calls
    let mut visit = |stmts: &[Stmt]| {
        walk_stmts(stmts, &mut |s: &Stmt| {
            if let Stmt::Draw(atom, _, _, _, scale, _) = s {
                let lit = lit_of(scale).unwrap_or(256); // default 1.0x
                let f = |ceil: u32| -> u32 {
                    let s = (lit as f32 / 256.0).max(1.0) * 1.42; // rotation diag
                    ((ceil as f32 * s).ceil() as u32).clamp(1, 1 << 20)
                };
                bump(*atom, (f(screen.0), f(screen.1)));
            }
        });
    };
    for f in &prog.fns {
        visit(&f.body);
    }
    for sc in &prog.scene_atoms {
        let _ = sc;
    }
    // table dispatch bodies + scene fns are inside prog.fns already (the
    // checker flattens them); particles were handled above.
    out
}

fn walk_stmts(stmts: &[Stmt], f: &mut dyn FnMut(&Stmt)) {
    for s in stmts {
        f(s);
        match s {
            // v23.2 SPANS: positional wrapper — the callback saw it, now
            // recurse into the real statement so variants classify right.
            Stmt::At { inner, .. } => {
                walk_stmts(std::slice::from_ref(inner), f);
            }
            Stmt::If(_, a, b) => {
                walk_stmts(a, f);
                walk_stmts(b, f);
            }
            Stmt::While(_, b) => walk_stmts(b, f),
            Stmt::For(_, _, b) => walk_stmts(b, f),
            Stmt::ForNum(_, _, _, b) => walk_stmts(b, f),
            Stmt::Switch(_, arms, default) => {
                for (_, body) in arms {
                    walk_stmts(body, f);
                }
                if let Some(d) = default {
                    walk_stmts(d, f);
                }
            }
            Stmt::ForMask(_, _, _, b) => walk_stmts(b, f),
            _ => {}
        }
    }
}

/// Pull a literal out of an expression (ints and fixed literals both feed
/// scale bounds; anything else is unknown -> caller uses the default).
fn lit_of(e: &Expr) -> Option<i64> {
    match e {
        Expr::IntLit(v) => Some(*v as i64),
        Expr::FixLit(v) => Some(*v as i64),
        Expr::Unary(crate::ast::UnOp::Neg, inner) => lit_of(inner).map(|v| -v),
        _ => None,
    }
}

// ---------------- 2. pure-fn table candidates ----------------

#[derive(Debug, Clone, PartialEq)]
pub struct TableCandidate {
    pub name: String,
    /// total domain size (product of narrow-int param domains)
    pub entries: u64,
    pub params: Vec<String>,
}

/// Side-effect scan for one fn body. Purity here means: no global/entity
/// writes, no spawns/kills, no audio/scene side effects, no draws. Reads
/// are fine (a table precomputed at build time replays the same reads).
fn is_pure(stmts: &[Stmt]) -> bool {
    let mut pure = true;
    walk_stmts(stmts, &mut |s: &Stmt| {
        match s {
            Stmt::Assign(_, _, _) => pure = false,
            Stmt::Spawn(_, _) => pure = false,
            Stmt::Kill(_) => pure = false,
            Stmt::Sfx(_) | Stmt::Music(_) | Stmt::StopMusic => pure = false,
            Stmt::Shake(_) => pure = false,
            Stmt::Goto(_) => pure = false,
            Stmt::Draw(..) => pure = false,
            Stmt::DrawText(..) => pure = false,
            Stmt::DrawNum(..) => pure = false,
            Stmt::Draw3d { .. } => pure = false,
            Stmt::Draw3DI { .. } => pure = false,
            Stmt::Camera(_, _) | Stmt::Cam3(..) => pure = false,
            Stmt::MusicVol(_) => pure = false,
            Stmt::Save(_, _) => pure = false,
            Stmt::CallStmt(name, _) => {
                // user fns may be pure; builtins that read input or time are
                // NOT table-stable (the precomputed value would fork). This
                // is the conservative read: only whitelisted math builtins.
                if !matches!(name.as_str(), "sin" | "cos" | "ang" | "min" | "max" | "abs" | "swept_hit") {
                    // unknown user fn: conservatively impure for v18's
                    // report (interprocedural purity is the 19 refinement)
                    pure = false;
                }
            }
            Stmt::CallTable(..) => pure = false,
            Stmt::FsmStep(_) => pure = false,
            _ => {}
        }
    });
    pure
}

/// Collect fns whose bodies are side-effect free and whose parameter list
/// is entirely narrow ints with a small total domain.
pub fn table_candidates(prog: &Program) -> Vec<TableCandidate> {
    let mut out = Vec::new();
    for f in &prog.fns {
        if !is_pure(&f.body) {
            continue;
        }
        let mut entries: u64 = 1;
        let mut params = Vec::new();
        let mut ok = true;
        for (pname, ty) in &f.params {
            let bits = match ty {
                crate::ast::Ty::UInt(b) | crate::ast::Ty::SInt(b) if *b <= 8 => *b as u64,
                _ => {
                    ok = false;
                    break;
                }
            };
            params.push(pname.clone());
            entries = entries.saturating_mul(1u64 << bits);
        }
        if ok && entries > 1 && entries <= (1 << 18) {
            out.push(TableCandidate { name: f.name.clone(), entries, params });
        }
    }
    out
}

// ---------------- 3. entity-mix report ----------------

#[derive(Debug, Clone, PartialEq)]
pub struct EntityMix {
    pub name: String,
    pub fields: usize,
    pub fsm: Option<String>,
    pub max_live: Option<u32>,
    /// from the player's perspective: how many of these exist at once
    pub likely_live: Option<u32>,
}

pub fn entity_mix(prog: &Program) -> Vec<EntityMix> {
    prog.entities
        .iter()
        .map(|e| EntityMix {
            name: e.name.clone(),
            fields: e.fields.len(),
            fsm: e.fsm.clone(),
            max_live: e.max_live_override,
            likely_live: None,
        })
        .collect()
}

// ---------------- tests ----------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_program_gets_screen_ceiling() {
        let p = Program::default();
        let u = mine_usage(&p);
        assert_eq!(u.screen, (320, 240)); // no game decl -> default
    }

    #[test]
    fn literal_scale_mining() {
        // build a program with one fn containing a draw with scale 2.0 (512)
        let src = "game { title: \"t\" width: 320 height: 240 }\n\
             sprite #ship (12) { poly [ 0,-12, 8,10, 0,5, -8,10 ] fill: 0x66CCFF }\n\
             fn update() { draw(#ship, 100, 100, 0, 2.0, 0xFFFFFFFF); }";
        let (toks, atom_names) = crate::lexer::Lexer::new(src).tokenize().unwrap();
        let mut p = crate::parser::Parser::new(toks, atom_names);
        let prog = p.parse_program().unwrap();
        let u = mine_usage(&prog);
        let (w, h) = u.sprite.get(&0).copied().unwrap_or((0, 0));
        // 320 * 2.0 * 1.42 rotation factor
        assert!(w >= 320 * 2, "got {}x{}", w, h);
    }
}
