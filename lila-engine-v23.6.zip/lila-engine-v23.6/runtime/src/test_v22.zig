//! runtime/src/test_v22.zig — v22 DETERMINISTIC COLLECTIONS runtime tests.
//!
//! Loads the committed fixture built from src/test_v22_fixture.lila
//! (v5 format: the v22 opcodes NOISE1/NOISE2/M_NEXT/M_NEXT_V/M_NEXT_C/
//! QPUSH/QPOP/QLEN/SPUSH/SPOP/SLEN/SPEEK/AFILL/ACOPY/ASHUF/AFIND/ACOUNT +
//! the synthesized touch_Rock_12 contact-edge field) and asserts every
//! observable result BIT-EXACTLY: the lattice noise against an independent
//! reference, dict iteration, FIFO/LIFO ring semantics with overflow drops,
//! array fill/copy/find/count, the LCG-exact Fisher-Yates shuffle, the
//! enter/exit/stay contact-edge timeline, the u32 array cells — and that
//! the wyhash chain stays stable while all of it runs.
//!
//! Regenerate the fixture with:
//!   ../compiler/target/release/lilac build src/test_v22_fixture.lila \
//!       -o src/test_v22_fixture.libyte

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");
const vm21 = @import("vm21.zig");
const vm22 = @import("vm22.zig");
const audio = @import("audio.zig");

// global typed-field ids (fixture declaration order; entities first:
// Rock.x/y = 0,1; Bullet.x/y = 2,3; Bullet.touch_Rock_12 = 4)
const TF_N1: u32 = 5;
const TF_N2: u32 = 6;
const TF_ITERS: u32 = 7;
const TF_MSUM: u32 = 8;
const TF_MK: u32 = 9;
const TF_MV: u32 = 10;
const TF_Q1: u32 = 11;
const TF_Q2: u32 = 12;
const TF_Q3: u32 = 13;
const TF_Q0: u32 = 14;
const TF_QLEN: u32 = 15;
const TF_QEMPTY: u32 = 16;
const TF_QFULL: u32 = 17;
const TF_S1: u32 = 18;
const TF_S2: u32 = 19;
const TF_S3: u32 = 20;
const TF_S0: u32 = 21;
const TF_SLEN: u32 = 22;
const TF_SPEEK: u32 = 23;
const TF_FILL0: u32 = 24;
const TF_FILL5: u32 = 25;
const TF_CPY: u32 = 26;
const TF_FIND: u32 = 27;
const TF_CNT: u32 = 28;
const TF_SHUF: u32 = 29;
const TF_SHSUM: u32 = 30;
const TF_SHSS: u32 = 31;
const TF_RAW: u32 = 32;
const TF_ENTER: u32 = 33;
const TF_EXIT: u32 = 34;
const TF_STAY: u32 = 35;
const TF_INB: u32 = 36;
const TF_PHASE: u32 = 37;

// entity handles (generation-composed, the honest way)
const BULLET_T: u32 = 1;
const ROCK_T: u32 = 0;
const TF_BX: u32 = 2;   // Bullet.x
const TF_BY: u32 = 3;   // Bullet.y
const TF_TOUCH: u32 = 4; // Bullet.touch_Rock_12 (synthesized)

fn loadFixture() ![]const u8 {
    return @embedFile("test_v22_fixture.libyte");
}

fn g(tf: u32) i32 {
    return ent.globalLoad(tf);
}

fn runFrames(n: u32) void {
    var sink: [735]i16 = undefined;
    var i: u32 = 0;
    while (i < n) : (i += 1) {
        engine.frame();
        _ = audio.pull(&sink);
    }
}

fn bulletHandle() u32 {
    return @as(u32, ent.genOf(BULLET_T, 0)) << 20;
}

fn setPhase(p: i32) void {
    ent.globalStore(TF_PHASE, p);
}

// ---------------------------------------------------------------------------
// independent reference implementations (re-derived in the test, not shared
// with vm22.zig — cross-checks, not tautologies)
// ---------------------------------------------------------------------------

fn refMix32(k0: u32) u32 {
    // the engine's avalanche (core.zig mix32): Murmur-style finalizer,
    // no seeding constant — re-derived here independently
    var h: u32 = k0;
    h ^= h >> 16;
    h *%= 0x7FEB352D;
    h ^= h >> 15;
    h *%= 0x846CA68B;
    h ^= h >> 16;
    return h;
}

fn refMulF(a: i32, b: i32) i32 {
    return @intCast((@as(i64, a) * @as(i64, b)) >> 8);
}

fn refHash1(i: i32) i32 {
    return @intCast(refMix32(@bitCast(i)) >> 24);
}

fn refHash2(x: i32, y: i32) i32 {
    const hx = refMix32(@as(u32, @bitCast(x)) +% 0x9E3779B1);
    const hy = refMix32(@as(u32, @bitCast(y)) +% 0x85EBCA77);
    return @intCast(refMix32(hx ^ hy) >> 24);
}

fn refFade(u: i32) i32 {
    const usq = refMulF(u, u);
    const ucub = refMulF(usq, u);
    const gq = 6 * usq - 15 * u + 2560;
    return refMulF(ucub, gq);
}

fn refNoise1(t: i32) i32 {
    const i = t >> 8;
    const u = t & 0xFF;
    const a = refHash1(i);
    const b = refHash1(i + 1);
    return a + refMulF(b - a, refFade(u));
}

fn refNoise2(x: i32, y: i32) i32 {
    const ix = x >> 8;
    const iy = y >> 8;
    const fx = x & 0xFF;
    const fy = y & 0xFF;
    const h00 = refHash2(ix, iy);
    const h10 = refHash2(ix + 1, iy);
    const h01 = refHash2(ix, iy + 1);
    const h11 = refHash2(ix + 1, iy + 1);
    const wx = refFade(fx);
    const wy = refFade(fy);
    const n0 = h00 + refMulF(h10 - h00, wx);
    const n1 = h01 + refMulF(h11 - h01, wx);
    return n0 + refMulF(n1 - n0, wy);
}

// ---------------------------------------------------------------------------
// fixture tests
// ---------------------------------------------------------------------------

test "v22: v5 fixture loads with queues/stacks as plain arrays" {
    const blob = try loadFixture();
    const rc = engine.init(blob);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);
    try std.testing.expectEqual(@as(u32, 1), c.n_dicts); // Tab
    try std.testing.expectEqual(@as(u16, 16), c.dict_cap[0]);
    // queue/stack sugar -> arrays: raw, buf, dst, four, Events(cap 6), Undo(cap 10)
    try std.testing.expectEqual(@as(u32, 6), c.n_arrs);
    try std.testing.expectEqual(@as(u32, 16), c.arr_cap[0]); // raw (u32[16])
    try std.testing.expectEqual(@as(u32, 4), c.arr_cap[3]); // four (u16[4])
    try std.testing.expectEqual(@as(u32, 6), c.arr_cap[4]); // Events = 4+2
    try std.testing.expectEqual(@as(u32, 10), c.arr_cap[5]); // Undo = 8+2
}

test "v22: lattice noise matches the independent reference" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // noise1(2.5): i=2, u=128 — the quintic midpoint
    try std.testing.expectEqual(refNoise1(2 * 256 + 128), g(TF_N1));
    // noise2(3.25, 7.5)
    try std.testing.expectEqual(refNoise2(3 * 256 + 64, 7 * 256 + 128), g(TF_N2));
    // in range [0, 1.0) Q24.8
    try std.testing.expect(g(TF_N1) >= 0 and g(TF_N1) < 256);
    try std.testing.expect(g(TF_N2) >= 0 and g(TF_N2) < 256);
}

test "v22: noise range + continuity over a lattice sweep (direct)" {
    const _rc = engine.init(try loadFixture());
    try std.testing.expectEqual(@as(i32, c.ERR_OK), _rc);
    var t: i32 = -6;
    while (t < 6) : (t += 1) {
        const n = vm22.noise1(t * 25); // ~0.1 steps
        try std.testing.expect(n >= 0 and n < 256);
        // C2-ish continuity: a ~0.1 step moves at most the corner spread
        const n2 = vm22.noise1(t * 25 + 3);
        const d = if (n2 > n) n2 - n else n - n2;
        try std.testing.expect(d <= 8); // max corner delta * fade'(u~0.01)
    }
    var y: i32 = -40;
    while (y < 40) : (y += 3) {
        var x: i32 = -40;
        while (x < 40) : (x += 5) {
            const n = vm22.noise2(x * 256, y * 256);
            try std.testing.expect(n >= 0 and n < 256);
            try std.testing.expectEqual(refNoise2(x * 256, y * 256), n);
        }
    }
    // integer lattice points are pure hashes (no interpolation)
    try std.testing.expectEqual(refHash1(17), vm22.noise1(17 * 256));
    try std.testing.expectEqual(refHash2(5, -9), vm22.noise2(5 * 256, -9 * 256));
}

test "v22: mnext iterates every entry exactly once (foreach dict)" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // 3 entries: keys 3/5/9, values 30/50/90
    try std.testing.expectEqual(@as(i32, 3), g(TF_ITERS));
    // checksum: sum(k + v) = 3+30+5+50+9+90 = 187
    try std.testing.expectEqual(@as(i32, 187), g(TF_MSUM));
    // values are key*10 (the fixture's rule) -> last-entry consistency
    const mk = g(TF_MK);
    try std.testing.expect(mk == 3 or mk == 5 or mk == 9);
    try std.testing.expectEqual(mk * 10, g(TF_MV));
}

test "v22: mnext direct — slot order, exhaustion, -1 sentinel" {
    var sink: [735]i16 = undefined;
    _ = &sink;
    // direct algorithm test on dict 0 (fresh boot, same fixture schema)
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // clear and re-fill with known keys
    var i: u32 = 0;
    while (i < c.dict_cap[0]) : (i += 1) {
        c.wr32(c.dictKey(0, i), c.DICT_EMPTY);
    }
    c.wr32(c.dict_base[0], 0);
    vm21.mapPut(0, 100, 1);
    vm21.mapPut(0, 200, 2);
    vm21.mapPut(0, 300, 3);
    var seen: [3]u32 = [_]u32{0} ** 3;
    var count: u32 = 0;
    var cursor: u32 = 0;
    while (true) {
        const k = vm22.mnext(0, cursor);
        if (k == -1) break;
        try std.testing.expect(count < 3);
        const v = c.rd32(c.ADDR_MN_VAL);
        const nc = c.rd32(c.ADDR_MN_CUR);
        try std.testing.expectEqual(vm21.mapGet(0, @bitCast(k)), v);
        seen[@intCast(v - 1)] = @bitCast(k);
        count += 1;
        cursor = nc;
    }
    try std.testing.expectEqual(@as(u32, 3), count);
    try std.testing.expectEqual(@as(u32, 100), seen[0]);
    try std.testing.expectEqual(@as(u32, 200), seen[1]);
    try std.testing.expectEqual(@as(u32, 300), seen[2]);
    // exhausted: cursor stash reads back as 0xFFFFFFFF
    try std.testing.expectEqual(@as(u32, 0xFFFFFFFF), c.rd32(c.ADDR_MN_CUR));
    // re-iterate from 0: stable (no mutation in between)
    var count2: u32 = 0;
    cursor = 0;
    while (vm22.mnext(0, cursor) != -1) : (count2 += 1) {
        cursor = c.rd32(c.ADDR_MN_CUR);
    }
    try std.testing.expectEqual(@as(u32, 3), count2);
}

test "v22: queue FIFO order, empty-pop, overflow drop" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    try std.testing.expectEqual(@as(i32, 3), g(TF_QLEN));   // before pops
    try std.testing.expectEqual(@as(i32, 11), g(TF_Q1));   // FIFO: first in
    try std.testing.expectEqual(@as(i32, 22), g(TF_Q2));
    try std.testing.expectEqual(@as(i32, 33), g(TF_Q3));
    try std.testing.expectEqual(@as(i32, 0), g(TF_Q0));    // empty: cell convention
    try std.testing.expectEqual(@as(i32, 0), g(TF_QEMPTY));
    // 6 pushes into 4 data slots: 2 dropped (soft-land), 4 live
    try std.testing.expectEqual(@as(i32, 4), g(TF_QFULL));
}

test "v22: stack LIFO order, peek, empty-pop" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    try std.testing.expectEqual(@as(i32, 3), g(TF_SLEN));
    try std.testing.expectEqual(@as(i32, 9), g(TF_SPEEK));  // top, not removed
    try std.testing.expectEqual(@as(i32, 9), g(TF_S1));    // LIFO: last in
    try std.testing.expectEqual(@as(i32, 8), g(TF_S2));
    try std.testing.expectEqual(@as(i32, 7), g(TF_S3));
    try std.testing.expectEqual(@as(i32, 0), g(TF_S0));    // empty
}

test "v22: ring counters live in the array cells (transparent memory)" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // Events = arr 4: cell0=head, cell1=tail. After init: 3+6 pushes, 3
    // pops of the first 3 -> head=3, tail=7 (4 live, wrapped by dcap=4).
    const base = c.arr_base[4];
    try std.testing.expectEqual(@as(u32, 3), c.rd32(base));
    try std.testing.expectEqual(@as(u32, 7), c.rd32(base + 4));
    try std.testing.expectEqual(@as(u32, 4), vm22.ringLen(4));
    // Undo = arr 5: LIFO pops decrement TAIL only -> head=0, tail back to 0
    const ub = c.arr_base[5];
    try std.testing.expectEqual(@as(u32, 0), c.rd32(ub));
    try std.testing.expectEqual(@as(u32, 0), c.rd32(ub + 4));
    try std.testing.expectEqual(@as(u32, 0), vm22.ringLen(5));
}

test "v22: queue survives the ring wrap (direct)" {
    const _rc = engine.init(try loadFixture());
    try std.testing.expectEqual(@as(i32, c.ERR_OK), _rc);
    // raw = arr 0, cap 16 -> dcap 14. Wrap the counters deliberately.
    const gid: u32 = 0;
    c.wr32(c.arr_base[gid], 0);
    c.wr32(c.arr_base[gid] + 4, 0);
    var i: u32 = 0;
    while (i < 14) : (i += 1) vm22.qpush(gid, i * 3 + 1); // full
    try std.testing.expectEqual(@as(u32, 14), vm22.ringLen(gid));
    vm22.qpush(gid, 999); // dropped
    try std.testing.expectEqual(@as(u32, 14), vm22.ringLen(gid));
    // pop 10 -> head=10; push 6 more (tail wraps 14 -> 20)
    i = 0;
    while (i < 10) : (i += 1) {
        try std.testing.expectEqual(i * 3 + 1, vm22.qpop(gid));
    }
    i = 0;
    while (i < 6) : (i += 1) vm22.qpush(gid, 100 + i);
    // counters now head=10, tail=20: len 10, slots index tail%14 = 6..
    try std.testing.expectEqual(@as(u32, 10), vm22.ringLen(gid));
    // FIFO continues across the wrap: 4 old (i=10..13) then 100..105
    try std.testing.expectEqual(@as(u32, 31), vm22.qpop(gid)); // i=10 -> 31
    try std.testing.expectEqual(@as(u32, 34), vm22.qpop(gid)); // i=11
    try std.testing.expectEqual(@as(u32, 37), vm22.qpop(gid)); // i=12
    try std.testing.expectEqual(@as(u32, 40), vm22.qpop(gid)); // i=13
    var w: u32 = 0;
    while (w < 6) : (w += 1) {
        try std.testing.expectEqual(100 + w, vm22.qpop(gid)); // wrapped tail data
    }
    try std.testing.expectEqual(@as(u32, 0), vm22.qpop(gid)); // empty
}

test "v22: afill / acopy / afind / acount" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    try std.testing.expectEqual(@as(i32, 7), g(TF_FILL0));
    try std.testing.expectEqual(@as(i32, 7), g(TF_FILL5));
    try std.testing.expectEqual(@as(i32, 9), g(TF_CPY));   // dst[1] copied
    try std.testing.expectEqual(@as(i32, 1), g(TF_FIND));  // buf[1] = 9 first
    try std.testing.expectEqual(@as(i32, 2), g(TF_CNT));   // buf[1], buf[3]
}

test "v22: ashuffle is the exact LCG Fisher-Yates (seeded 0x12345678)" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // the fixture consumed NO rand before the shuffle: state was the seed
    var perm = [4]i32{ 1, 2, 3, 4 };
    var st: u32 = 0x12345678;
    var i: usize = 3;
    while (i > 0) : (i -= 1) {
        st = st *% 1664525 +% 1013904223;
        const j: usize = @intCast((st >> 8) % @as(u32, @intCast(i + 1)));
        const t = perm[i];
        perm[i] = perm[j];
        perm[j] = t;
    }
    const expect: i32 = perm[0] * 1000 + perm[1] * 100 + perm[2] * 10 + perm[3];
    try std.testing.expectEqual(expect, g(TF_SHUF));
    // permutation proofs: same multiset {1,2,3,4}
    try std.testing.expectEqual(@as(i32, 10), g(TF_SHSUM));
    try std.testing.expectEqual(@as(i32, 30), g(TF_SHSS));
}

test "v22: ashuffle direct — reproducibility + clamping" {
    const _rc = engine.init(try loadFixture());
    try std.testing.expectEqual(@as(i32, c.ERR_OK), _rc);
    // use `dst` (arr 2, cap 8): pin the LCG, shuffle, re-pin, shuffle again
    const gid: u32 = 2;
    var i: u32 = 0;
    while (i < 8) : (i += 1) c.wr32(c.garrElem(gid, i), i);
    c.wr32(c.ADDR_RAND, 0xDEADBEEF);
    vm22.ashuffle(gid, 8);
    var first: [8]u32 = undefined;
    i = 0;
    while (i < 8) : (i += 1) first[i] = c.rd32(c.garrElem(gid, i));
    // a permutation of 0..7
    var seen = [_]bool{false} ** 8;
    i = 0;
    while (i < 8) : (i += 1) {
        try std.testing.expect(first[i] < 8);
        try std.testing.expect(!seen[first[i]]);
        seen[first[i]] = true;
    }
    // same seed -> same permutation; different seed -> (almost surely) different
    i = 0;
    while (i < 8) : (i += 1) c.wr32(c.garrElem(gid, i), i);
    c.wr32(c.ADDR_RAND, 0xDEADBEEF);
    vm22.ashuffle(gid, 8);
    i = 0;
    while (i < 8) : (i += 1) try std.testing.expectEqual(first[i], c.rd32(c.garrElem(gid, i)));
    // clamp: n > cap behaves as n = cap (soft-land, documented)
    i = 0;
    while (i < 8) : (i += 1) c.wr32(c.garrElem(gid, i), i);
    vm22.ashuffle(gid, 999);
    var cnt: u32 = 0;
    i = 0;
    while (i < 8) : (i += 1) {
        if (c.rd32(c.garrElem(gid, i)) != i) cnt += 1;
    }
    try std.testing.expect(cnt > 1); // 999 clamped to 8: it really shuffled
}

test "v22: u32 array cells carry full-width ints" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    try std.testing.expectEqual(@as(i32, 4242), g(TF_RAW));
    // raw slot 3 really holds the raw u32 (direct cell check)
    try std.testing.expectEqual(@as(u32, 4242), c.rd32(c.garrElem(0, 3)));
}

// ---------------------------------------------------------------------------
// contact edges — the enter/exit timeline
// ---------------------------------------------------------------------------

test "v22: enter fires once per contact begin, exit once per end" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // frame 1: scan sees spawn position (8,8) vs rock (16,8): touching
    runFrames(1);
    try std.testing.expectEqual(@as(i32, 1), g(TF_ENTER));
    try std.testing.expectEqual(@as(i32, 1), g(TF_STAY));
    try std.testing.expectEqual(@as(i32, 0), g(TF_EXIT));
    try std.testing.expectEqual(@as(i32, 16), g(TF_INB)); // partner x
    // the synthesized touch counter is live on the bullet
    try std.testing.expectEqual(@as(i32, 1), ent.fieldLoad(TF_TOUCH, bulletHandle()));

    // frames 2-5: still touching — NO new enter, stay accumulates
    runFrames(4);
    try std.testing.expectEqual(@as(i32, 1), g(TF_ENTER));
    try std.testing.expectEqual(@as(i32, 5), g(TF_STAY));
    try std.testing.expectEqual(@as(i32, 0), g(TF_EXIT));

    // phase 1: the bullet leaves. frame 6's scan still sees the OLD x=8
    // (updates run after update0); frame 7 sees x=100 -> exit edge
    setPhase(1);
    runFrames(1);
    try std.testing.expectEqual(@as(i32, 6), g(TF_STAY)); // old position
    runFrames(1);
    try std.testing.expectEqual(@as(i32, 1), g(TF_EXIT));
    try std.testing.expectEqual(@as(i32, 6), g(TF_STAY));
    try std.testing.expectEqual(@as(i32, 0), ent.fieldLoad(TF_TOUCH, bulletHandle()));

    // frames 8-10 away: nothing fires
    runFrames(3);
    try std.testing.expectEqual(@as(i32, 1), g(TF_ENTER));
    try std.testing.expectEqual(@as(i32, 1), g(TF_EXIT));
    try std.testing.expectEqual(@as(i32, 6), g(TF_STAY));

    // phase 0 again: frame 11's scan sees x=100 (nothing), frame 12 re-enters
    setPhase(0);
    runFrames(1);
    try std.testing.expectEqual(@as(i32, 1), g(TF_ENTER));
    runFrames(1);
    try std.testing.expectEqual(@as(i32, 2), g(TF_ENTER));
    try std.testing.expectEqual(@as(i32, 7), g(TF_STAY));
    try std.testing.expectEqual(@as(i32, 1), g(TF_EXIT));
    try std.testing.expectEqual(@as(i32, 1), ent.fieldLoad(TF_TOUCH, bulletHandle()));
}

test "v22: the wyhash chain stays deterministic across the whole stack" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    var sink: [735]i16 = undefined;
    _ = &sink;
    runFrames(120);
    const h1 = tt.stateHash(119);
    // fresh boot, same input -> identical chain
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    runFrames(120);
    try std.testing.expectEqual(h1, tt.stateHash(119));
}

test "v22: snapshot/rewind captures the touch field + ring counters" {
    try std.testing.expectEqual(@as(i32, c.ERR_OK), engine.init(try loadFixture()));
    // 6 frames touching, then leave; snapshot right after the exit edge
    runFrames(6); // frames 1-6 (phase 0)
    setPhase(1);
    runFrames(2); // frame 7 still sees x=8; frame 8 sees x=100 -> exit
    try std.testing.expectEqual(@as(i32, 1), g(TF_EXIT));

    var snap = try tt.Snapshot.capture(std.testing.allocator, 7);
    defer std.testing.allocator.free(snap.mem);

    // run 10 more frames away, then rewind to the exit instant
    runFrames(10);
    try std.testing.expectEqual(@as(i32, 1), g(TF_EXIT)); // no double-exit
    const h_replayed: u64 = tt.stateHash(18);
    snap.restore();
    try std.testing.expectEqual(@as(i32, 1), g(TF_EXIT));
    try std.testing.expectEqual(@as(i32, 0), ent.fieldLoad(TF_TOUCH, bulletHandle()));
    // re-run the SAME 10 frames: identical state (the ring counters + the
    // touch field are plain c.mem — the memcpy contract)
    runFrames(10);
    try std.testing.expectEqual(h_replayed, tt.stateHash(18));
    try std.testing.expect(h_replayed != 0);
}
