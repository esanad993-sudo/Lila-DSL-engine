const std = @import("std");
pub fn main(init: std.process.Init) !void {
    const lc = @import("lila_c.zig");
    const io = init.io;
    const arena_alloc = init.arena.allocator();
    const args = try init.minimal.args.toSlice(arena_alloc);
    var dir = try std.Io.Dir.cwd().openDir(io, ".", .{});
    defer dir.close(io);
    var blob_buf: [256 * 1024]u8 = undefined;
    const blob = dir.readFile(io, args[1], &blob_buf) catch |e| {
        std.debug.print("cannot read {s}: {}\n", .{ args[1], e });
        return;
    };
    const rc = lc.lila_init(blob.ptr, blob.len);
    std.debug.print("init rc={d}\n", .{rc});
    var f: u32 = 0;
    while (f < 5) : (f += 1) {
        lc.lila_input_set(4);
        lc.lila_frame();
    }
    std.debug.print("hash={x}\n", .{lc.lila_state_hash(5)});
}
