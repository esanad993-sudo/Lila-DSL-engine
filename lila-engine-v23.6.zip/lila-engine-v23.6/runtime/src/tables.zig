//! ============================================================================
//! TABLES — execution becomes data (v19 runtime side)
//! ============================================================================
//!
//! The forge proves a fn PURE (params/locals/constants only) and ships its
//! dense argument DOMAIN in the pack (a TBL1 section, ~20 bytes). This
//! module installs those domains and BAKES the values by running the REAL
//! fn once per entry on the REAL VM — there is no second implementation of
//! the game's logic anywhere. After baking, every call in the domain is a
//! load; every call outside it falls through to the real fn. Worst case
//! (all misses) the game runs exactly as it always did.
//!
//! HASH NEUTRALITY (the property that makes this shippable):
//!   * this module's storage lives OUTSIDE the flat 2MB — the hash chain
//!     cannot see it;
//!   * a hit performs the same stack pops and the same ret_val store that
//!     the real call's OP_RET_V would (VM stack/frames/ret_val are
//!     threadlocal, outside the hashed image);
//!   * a pure fn touches nothing else — that is what the forge proved;
//!   * therefore the memory image after a hit is bit-identical to the image
//!     after a real call, and `--replay movie --tables pack` reproduces the
//!     recorded hash chain 300/300. That replay is the end-to-end proof.
//!
//! DEFENSE IN DEPTH (purity is a proof, proofs have bugs):
//!   * bake = execution, so the values are correct AS OF INSTALL;
//!   * spot-verify re-runs the real fn on the first 64 hits of small
//!     tables and drops the table on any mismatch (a stale-value canary);
//!   * out-of-domain args always take the real call — the table is a
//!     cache, not a contract.

const std = @import("std");
const c = @import("core.zig");
const vm = @import("vm.zig");

pub const MAX_TABLES: u32 = 16;
/// total baked entries across all tables (static arena, no allocator)
pub const MAX_ENTRIES_TOTAL: usize = 65536;

pub const Table = struct {
    fn_idx: u16,
    n_args: u8,
    lo: [2]i32,
    hi: [2]i32,
    w0: i32, // hi[0] - lo[0] + 1
    values: []const i32,
    /// v23.6: the fn returns f64 — `values` holds the LOW cells and
    /// `hivalues` the HIGH cells of each entry's (lo, hi) result pair; a
    /// probe hit writes BOTH into the fn's `__ret64[ret_slot]` (the real
    /// call's return lowering writes the same cells — hash-neutral).
    hivalues: []const i32 = &.{},
    wide: bool,
    ret_arr: u32,
    ret_slot: u32,
    spot_verify: bool,
    spot_checked: u32,
    // u32 telemetry counters: wasm32 has no 64-bit atomics, and these are
    // diagnostics (they may wrap after billions of hits — that is fine)
    hits: std.atomic.Value(u32) = std.atomic.Value(u32).init(0),
    misses: std.atomic.Value(u32) = std.atomic.Value(u32).init(0),
    spot_mismatch: std.atomic.Value(u32) = std.atomic.Value(u32).init(0),
    dead: bool, // spot-verify killed it: always fall through
    name: [48]u8,
    name_len: u8,
};

// static storage — no allocator anywhere (the -lc freestanding discipline)
var arena: [MAX_ENTRIES_TOTAL]i32 = undefined;
var arena_used: usize = 0;
/// v23.6: parallel HIGH-cell storage for wide (f64-return) tables.
var hi_arena: [MAX_ENTRIES_TOTAL]i32 = undefined;
var tables: [MAX_TABLES]Table = undefined;
var n_tables: u32 = 0;
var bake_ns: u64 = 0;

pub inline fn count() u32 {
    return @atomicLoad(u32, &n_tables, .monotonic);
}

/// The VM's call hook. Returns the tabled value when the (fn, args) pair is
/// inside a baked domain; null means "take the real call".
/// Called from OP_CALL_FN AFTER the args were popped and pc was advanced.
pub inline fn probe(fi: u32, a0: i32, a1: i32, n: u32) ?i32 {
    const nt = count();
    if (nt == 0) return null; // legacy path: one predictable branch
    var i: u32 = 0;
    while (i < nt) : (i += 1) {
        const t = &tables[i];
        if (t.dead or t.fn_idx != fi) continue;
        if (t.n_args != n) continue;
        if (a0 < t.lo[0] or a0 > t.hi[0]) {
            _ = t.misses.fetchAdd(1, .monotonic);
            return null; // out of domain -> the real call
        }
        if (n == 2 and (a1 < t.lo[1] or a1 > t.hi[1])) {
            _ = t.misses.fetchAdd(1, .monotonic);
            return null;
        }
        const idx0 = a0 - t.lo[0];
        const idx = if (n == 2) idx0 + (a1 - t.lo[1]) * t.w0 else idx0;
        // v23.6 spot-verify for wide tables re-runs the real fn and compares
        // the __ret64 pair; the runValue below returns the fn's dummy ret
        // register (0), so the pair is read from the GARR plane after it.
        const v = t.values[@intCast(idx)];
        if (t.spot_verify and t.spot_checked < 64) {
            t.spot_checked += 1;
            const real = vm.runValue(fi, a0, a1, n);
            var ok: bool = undefined;
            if (t.wide) {
                const rhi = ret64Hi(t.ret_arr, t.ret_slot);
                ok = (real == v) and (rhi == t.hivalues[@intCast(idx)]);
            } else {
                ok = real == v;
            }
            if (!ok) {
                _ = t.spot_mismatch.fetchAdd(1, .monotonic);
                t.dead = true; // the table lied once — retire it forever
                _ = t.misses.fetchAdd(1, .monotonic);
                return null; // and take the real call for THIS one
            }
        }
        // v23.6: a wide hit must reproduce the real call's IMAGE — the fn's
        // return lowering writes (lo, hi) into __ret64[ret_slot], so the hit
        // writes the cached pair to the same cells (bit-identical). The
        // returned ret_val is the real path's dummy 0.
        if (t.wide) {
            writeRet64(t.ret_arr, t.ret_slot, v, t.hivalues[@intCast(idx)]);
            _ = t.hits.fetchAdd(1, .monotonic);
            return 0;
        }
        _ = t.hits.fetchAdd(1, .monotonic);
        return v;
    }
    return null;
}

// ---------------- v23.6: the __ret64 baked-return channel ----------------

/// GARR plane address of __ret64[slot]'s LOW cell (the array is width 2,
/// so slot s lives at cells 2s and 2s+1 — the same addressing LD_GARR uses).
inline fn ret64Cell(ret_arr: u32, slot: u32, off: u32) u32 {
    const i = c.arrIndex(ret_arr, @bitCast(slot)) * 2;
    return c.garrElem(ret_arr, i + off);
}

inline fn ret64Hi(ret_arr: u32, slot: u32) i32 {
    return @bitCast(c.rd32(ret64Cell(ret_arr, slot, 1)));
}

inline fn writeRet64(ret_arr: u32, slot: u32, lo: i32, hi: i32) void {
    c.wr32(ret64Cell(ret_arr, slot, 0), @bitCast(lo));
    c.wr32(ret64Cell(ret_arr, slot, 1), @bitCast(hi));
}

// ---------------- mining (the empirical-domain recorder) ----------------

pub const MAX_MINE_FNS: u32 = 64;

pub const MineStat = struct {
    fn_idx: u16,
    n_args: u8,
    lo: [4]i32,
    hi: [4]i32,
    calls: u64,
};

var mine_list: [MAX_MINE_FNS]u16 = undefined;
var mine_n: u32 = 0;
var mine_lo: [MAX_MINE_FNS][4]i32 = undefined;
var mine_hi: [MAX_MINE_FNS][4]i32 = undefined;
var mine_calls: [MAX_MINE_FNS]u64 = undefined;

/// Arm the mining hooks with a list of cartridge fn indices (the forge's
/// game.minelist). Mining runs on the main thread — callers mining with
/// parallel workers must force --threads 1 (the runner does).
pub fn setMining(list: []const u16) void {
    const n = @min(list.len, MAX_MINE_FNS);
    for (list[0..n], 0..) |fi, i| {
        mine_list[i] = fi;
        mine_lo[i] = .{ std.math.maxInt(i32), std.math.maxInt(i32), std.math.maxInt(i32), std.math.maxInt(i32) };
        mine_hi[i] = .{ std.math.minInt(i32), std.math.minInt(i32), std.math.minInt(i32), std.math.minInt(i32) };
        mine_calls[i] = 0;
    }
    mine_n = @intCast(n);
}

pub fn mineCount() u32 {
    return mine_n;
}

/// The VM's mining hook (called from OP_CALL_FN BEFORE the probe, with the
/// args still in hand). Records dense per-arg ranges across the corpus.
pub inline fn mineCall(fi: u32, args: []const i32, n: u32) void {
    // v23.5: slice (was *const [8]i32) — the arg window widened to 16 cells
    // for f64 params; mining still records at most 4 arg slots (diagnostics
    // only, nothing hashed sees it).
    if (mine_n == 0) return;
    var i: u32 = 0;
    while (i < mine_n) : (i += 1) {
        if (mine_list[i] != fi) continue;
        const k: usize = i;
        const na = @min(n, 4);
        var a: u32 = 0;
        while (a < na and a < args.len) : (a += 1) {
            if (args[a] < mine_lo[k][a]) mine_lo[k][a] = args[a];
            if (args[a] > mine_hi[k][a]) mine_hi[k][a] = args[a];
        }
        mine_calls[k] += 1;
    }
}

/// Write the MINE file ("MINE" + records — the format forge/tables.rs
/// parses; 2 arg slots per fn, calls counted at the call site).
pub fn writeMine(buf: []u8) usize {
    if (buf.len < 6) return 0;
    @memcpy(buf[0..4], "MINE");
    std.mem.writeInt(u16, buf[4..6], @intCast(mine_n), .little);
    var p: usize = 6;
    var i: u32 = 0;
    while (i < mine_n) : (i += 1) {
        const k: usize = i;
        if (p + 3 + 32 > buf.len) break;
        std.mem.writeInt(u16, buf[p..][0..2], mine_list[k], .little);
        buf[p + 2] = 2; // both arg slots recorded
        p += 3;
        var a: u32 = 0;
        while (a < 2) : (a += 1) {
            // a slot never hit stays [maxint, minint] — forge treats that
            // as "no evidence for arg1" (single-arg fn)
            std.mem.writeInt(i32, buf[p..][0..4], mine_lo[k][a], .little);
            std.mem.writeInt(i32, buf[p + 4 ..][0..4], mine_hi[k][a], .little);
            std.mem.writeInt(u64, buf[p + 8 ..][0..8], mine_calls[k], .little);
            p += 16;
        }
    }
    return p;
}

// ---------------- pack install (parse TBL1 -> bake -> activate) ----------------

pub const InstallResult = struct {
    installed: i32,
    entries: usize,
    bake_ns: u64,
};

/// Parse an FGP1 forgepack, take every TBL1 section, bake it on the real VM,
/// activate. Returns installed count (negative = error).
pub fn installPack(pack: []const u8) i32 {
    if (pack.len < 8 or !std.mem.eql(u8, pack[0..4], "FGP1")) return -1;
    const n_sections = std.mem.readInt(u32, pack[4..8], .little);
    // overflow-safe: a hostile count cannot wrap past the real length
    if (n_sections > (pack.len - 8) / 12) return -2;
    var baked: [MAX_TABLES]Table = undefined;
    var nb: u32 = 0;
    var p: usize = 8 + n_sections * 12;
    var s: u32 = 0;
    var used: usize = arena_used;
    var wide_baked: bool = false;
    while (s < n_sections) : (s += 1) {
        const off = 8 + s * 12;
        const tag = pack[off..][0..4];
        const len = std.mem.readInt(u32, pack[off + 8 ..][0..4], .little);
        if (p + len > pack.len) return -3;
        const payload = pack[p..][0..len];
        p += len;
        if (!std.mem.eql(u8, tag, "TBL1")) continue;
        if (nb >= MAX_TABLES) break;
        // TBL1 payload: u8 name_len, name, u16 fn_idx, u8 n_args,
        // per arg: i32 lo, i32 hi, u8 spot_verify
        // v23.6 trailer (always appended): u8 ret_wide, u16 ret_arr, u16 ret_slot
        if (payload.len < 4) return -4;
        const name_len = @as(usize, payload[0]);
        if (payload.len < 1 + name_len + 2 + 1) return -4;
        const fn_idx = std.mem.readInt(u16, payload[1 + name_len ..][0..2], .little);
        const n_args = payload[1 + name_len + 2];
        if (fn_idx >= c.n_fns) return -5; // pack does not match this cartridge
        // cartridge arity must agree with the pack (a stale pack would
        // silently bake the wrong shape — reject loudly instead)
        const nparams = c.rd8(c.ADDR_FNS + @as(u32, fn_idx) * c.FN_SIZE + 2);
        if (nparams != n_args) return -6;
        var q = 1 + name_len + 2 + 1;
        var t = Table{
            .fn_idx = fn_idx,
            .n_args = n_args,
            .lo = .{ 0, 0 },
            .hi = .{ 0, 0 },
            .w0 = 1,
            .values = &.{},
            .wide = false,
            .ret_arr = 0,
            .ret_slot = 0,
            .spot_verify = false,
            .spot_checked = 0,
            .dead = false,
            .name = undefined,
            .name_len = @intCast(@min(name_len, 48)),
        };
        @memcpy(t.name[0..t.name_len], payload[1 .. 1 + t.name_len]);
        var a: u32 = 0;
        while (a < n_args) : (a += 1) {
            if (q + 8 > payload.len) return -4;
            t.lo[a] = std.mem.readInt(i32, payload[q..][0..4], .little);
            t.hi[a] = std.mem.readInt(i32, payload[q + 4 ..][0..4], .little);
            q += 8;
        }
        if (q >= payload.len) return -4;
        t.spot_verify = payload[q] != 0;
        q += 1;
        // v23.6: the ret trailer is always appended by lilac >= v23.6
        if (payload.len >= q + 5) {
            t.wide = payload[q] != 0;
            t.ret_arr = std.mem.readInt(u16, payload[q + 1 ..][0..2], .little);
            t.ret_slot = std.mem.readInt(u16, payload[q + 3 ..][0..2], .little);
        }
        if (t.hi[0] < t.lo[0]) continue; // empty domain: skip section
        if (n_args == 2 and t.hi[1] < t.lo[1]) continue;
        const w0: i64 = @as(i64, t.hi[0]) - t.lo[0] + 1;
        const w1: i64 = if (n_args == 2) @as(i64, t.hi[1]) - t.lo[1] + 1 else 1;
        const entries: i64 = w0 * w1;
        if (entries <= 0 or used + @as(usize, @intCast(entries)) > MAX_ENTRIES_TOTAL) return -7;
        // ---- BAKE: run the REAL fn over the whole domain ----
        // v23.6: a wide (f64-return) fn parks a dummy in the ret register
        // and writes its (lo, hi) result into __ret64[ret_slot] — so the
        // bake captures the pair from the GARR plane after each run.
        const vals = arena[used .. used + @as(usize, @intCast(entries))];
        const hivals = if (t.wide) hi_arena[used .. used + @as(usize, @intCast(entries))] else vals[0..0];
        var k: i64 = 0;
        while (k < entries) : (k += 1) {
            const a0: i32 = t.lo[0] + @as(i32, @intCast(@mod(k, w0)));
            const a1: i32 = if (n_args == 2) t.lo[1] + @as(i32, @intCast(@divTrunc(k, w0))) else 0;
            vals[@intCast(k)] = vm.runValue(fn_idx, a0, a1, n_args);
            if (t.wide) {
                hivals[@intCast(k)] = ret64Hi(t.ret_arr, t.ret_slot);
            }
        }
        used += @intCast(entries);
        t.values = vals;
        t.hivalues = hivals;
        t.w0 = @intCast(w0);
        baked[nb] = t;
        nb += 1;
        wide_baked = wide_baked or t.wide;
    }
    // activate (all baked first: no table serves during another's bake)
    var i: u32 = 0;
    while (i < nb) : (i += 1) {
        tables[i] = baked[i];
    }
    arena_used = used;
    @atomicStore(u32, &n_tables, nb, .monotonic);
    // v23.6 HASH-NEUTRALITY: the bake ran real fns whose return lowering
    // WROTE __ret64 slots (inside the hashed 2MB — unlike this module's own
    // side arena). A no-tables run would show +0.0 there, so zero every
    // wide table's slot back after baking; a probe hit then writes exactly
    // what the real call would have (see probe), and the image after
    // install is byte-identical to the no-tables image.
    if (wide_baked) {
        i = 0;
        while (i < nb) : (i += 1) {
            // each bake run wrote ONLY its own fn's slot — zero it back
            if (tables[i].wide) writeRet64(tables[i].ret_arr, tables[i].ret_slot, 0, 0);
        }
    }
    return @intCast(nb);
}

/// Bake wall-clock (printed by the hosts — the one-time cost of tables).
pub fn bakeNanos() u64 {
    return bake_ns;
}

pub fn setBakeNanos(ns: u64) void {
    bake_ns = ns;
}

/// Aggregate stats for the runner's end-of-run line.
pub const Stats = struct {
    hits: u64,
    misses: u64,
    spot_checks: u64,
    spot_mismatches: u64,
    active: u32,
};


pub fn stats() Stats {
    var s = Stats{ .hits = 0, .misses = 0, .spot_checks = 0, .spot_mismatches = 0, .active = 0 };
    var i: u32 = 0;
    while (i < count()) : (i += 1) {
        const t = &tables[i];
        if (!t.dead) s.active += 1;
        s.hits += t.hits.load(.monotonic);
        s.misses += t.misses.load(.monotonic);
        s.spot_mismatches += t.spot_mismatch.load(.monotonic);
        s.spot_checks += t.spot_checked;
    }
    return s;
}

/// Human-readable per-table line (the runner prints these at exit).
/// Manual formatting — the no-allocator discipline applies to diagnostics
/// too.
pub fn printStats() void {
    var i: u32 = 0;
    while (i < count()) : (i += 1) {
        const t = &tables[i];
        var line: [200]u8 = undefined;
        var w: usize = 0;
        const put = struct {
            fn f(buf: []u8, comptime fmt: []const u8, args: anytype) usize {
                const s = std.fmt.bufPrint(buf, fmt, args) catch return 0;
                return s.len;
            }
        }.f;
        w += put(line[w..], "  table {d} [{s}] domain [{d}..{d}]", .{
            i, t.name[0..t.name_len], t.lo[0], t.hi[0],
        });
        if (t.n_args == 2) {
            w += put(line[w..], "x[{d}..{d}]", .{ t.lo[1], t.hi[1] });
        }
        w += put(line[w..], " entries={d} hits={d} misses={d}", .{
            t.values.len, t.hits.load(.monotonic), t.misses.load(.monotonic),
        });
        if (t.dead) {
            w += put(line[w..], " RETIRED (spot-verify mismatch)", .{});
        }
        w += put(line[w..], "\n", .{});
        std.debug.print("{s}", .{line[0..w]});
    }
}

/// Reset (tests + hot-swap discipline: tables are cartridge-bound).
pub fn reset() void {
    n_tables = 0;
    arena_used = 0;
    mine_n = 0;
    bake_ns = 0;
}

// ---------------- tests ----------------

const testing = std.testing;

test "no tables -> probe misses (legacy path)" {
    reset();
    try testing.expectEqual(@as(?i32, null), probe(0, 1, 0, 1));
}

test "pack rejects garbage" {
    reset();
    try testing.expectEqual(@as(i32, -1), installPack("JUNKJUNK"));
    try testing.expectEqual(@as(i32, -2), installPack("FGP1\xFF\xFF\xFF\xFF"));
}

test "well-formed but empty pack installs nothing" {
    reset();
    // FGP1 + zero sections
    var buf: [8]u8 = undefined;
    @memcpy(buf[0..4], "FGP1");
    std.mem.writeInt(u32, buf[4..8], 0, .little);
    try testing.expectEqual(@as(i32, 0), installPack(&buf));
    try testing.expectEqual(@as(?i32, null), probe(0, 1, 0, 1));
}

test "mine recording" {
    reset();
    setMining(&.{7});
    mineCall(7, &.{ 3, 0, 0, 0, 0, 0, 0, 0 }, 1);
    mineCall(7, &.{ 100, 0, 0, 0, 0, 0, 0, 0 }, 1);
    mineCall(7, &.{ 50, 0, 0, 0, 0, 0, 0, 0 }, 1);
    mineCall(9, &.{ 1, 0, 0, 0, 0, 0, 0, 0 }, 1); // not mined
    var out: [64]u8 = undefined;
    const n = writeMine(&out);
    try testing.expect(n > 6);
    try testing.expectEqualSlices(u8, out[0..4], "MINE");
    const cnt = std.mem.readInt(u16, out[4..6], .little);
    try testing.expectEqual(@as(u16, 1), cnt);
    // record: idx=7, nargs=2, then lo/hi/calls for slots
    try testing.expectEqual(@as(u16, 7), std.mem.readInt(u16, out[6..8], .little));
    try testing.expectEqual(@as(i32, 3), std.mem.readInt(i32, out[9..13], .little));
    try testing.expectEqual(@as(i32, 100), std.mem.readInt(i32, out[13..17], .little));
}
