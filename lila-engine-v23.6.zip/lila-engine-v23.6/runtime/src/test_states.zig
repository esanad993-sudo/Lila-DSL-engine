//! runtime/src/test_states.zig — v20 COROUTINE STATE tests.
//!
//! Loads the fixture built from demo/test_states_fixture.lila and asserts
//! the EXACT frame-by-frame timing of the lowered state machine:
//!
//!   frame 1:  st==0 -> default arm -> st=16 (state 1 phase 0), return
//!   frame 2:  idle phase 0: phase_g=1; wt=10; st=17
//!   frames 3-12: wt counts 10..1 (phase_g stays 1)
//!   frame 13: wt==0 -> phase 1 body: `-> run` -> st=32, return
//!   frames 14-18: run: phase_g=4; hp 5->4->3->2->1
//!   frame 18: hp==0 -> `-> done` -> st=48
//!   frame 19+: done: phase_g=7 every frame, loop_g increments
//!
//! The cartridge is a plain v1 file — the entire coroutine machinery
//! compiled to a switch (zero new opcodes).

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");

// typed-field ids from the fixture's disasm
const TF_PHASE: u32 = 4; // global phase_g
const TF_WT: u32 = 5; // global wt_g
const TF_ST: u32 = 6; // global st_g
const TF_LOOP: u32 = 7; // global loop_g
const TF_HP: u32 = 1; // Bot.hp

fn loadFixture() ![]const u8 {
    return @embedFile("test_states_fixture.libyte");
}

fn frame() void {
    engine.frame();
}

fn frames(n: u32) void {
    var i: u32 = 0;
    while (i < n) : (i += 1) frame();
}

test "states: entry, wait timing, transition and terminal loop" {
    const blob = try loadFixture();
    const rc = engine.init(blob);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);

    // NOTE: the global update() runs BEFORE the per-entity update in a
    // frame, so the mirror globals (st_g/wt_g) carry a ONE-FRAME LAG of the
    // entity's fields; phase_g/loop_g are written BY the entity fn (no lag).
    // frame 1: the default arm enters state 1 (st=16) and returns
    frames(1);
    try std.testing.expectEqual(@as(i32, 0), ent.globalLoad(TF_PHASE));
    try std.testing.expectEqual(@as(i32, 0), ent.globalLoad(TF_ST)); // lag: pre-entity

    // frame 2: idle phase 0 runs, suspends 10 frames
    frames(1);
    try std.testing.expectEqual(@as(i32, 1), ent.globalLoad(TF_PHASE));
    try std.testing.expectEqual(@as(i32, 16), ent.globalLoad(TF_ST));

    // frame 3: the suspension is visible (wt was set at frame 2)
    frames(1);
    try std.testing.expectEqual(@as(i32, 10), ent.globalLoad(TF_WT));
    try std.testing.expectEqual(@as(i32, 17), ent.globalLoad(TF_ST));
    try std.testing.expectEqual(@as(i32, 1), ent.globalLoad(TF_PHASE));

    // frames 4..13: the countdown (wt 10..1, then 0 at f13)
    frames(10);
    try std.testing.expectEqual(@as(i32, 1), ent.globalLoad(TF_PHASE));
    try std.testing.expectEqual(@as(i32, 0), ent.globalLoad(TF_WT));

    // frame 13: wait expired -> `-> run` fired (mirror sees st=32 at f14)
    frames(1);
    frames(1);
    try std.testing.expectEqual(@as(i32, 32), ent.globalLoad(TF_ST));
    try std.testing.expectEqual(@as(i32, 4), ent.globalLoad(TF_PHASE));

    // frames 16..17: run decrements hp (trace: f15 hp=3, f16 hp=2, f17 hp=1)
    frames(2);
    {
        const h = ent.nextLive(0, 0);
        try std.testing.expect(h != 0xFFFFFFFF);
        try std.testing.expectEqual(@as(i32, 1), ent.fieldLoad(TF_HP, @intCast(h)));
    }

    // frame 18: hp hits 0 -> `-> done` (mirror sees st=48 at f19)
    frames(2);
    try std.testing.expectEqual(@as(i32, 48), ent.globalLoad(TF_ST));

    // frames 20+: done loops every frame (loop=3 at f21)
    frames(2);
    try std.testing.expectEqual(@as(i32, 7), ent.globalLoad(TF_PHASE));
    try std.testing.expectEqual(@as(i32, 3), ent.globalLoad(TF_LOOP));
}

test "states: deterministic replay" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    frames(40);
    const h1 = tt.stateHash(40);
    _ = engine.init(blob);
    frames(40);
    try std.testing.expectEqual(h1, tt.stateHash(40));
}
