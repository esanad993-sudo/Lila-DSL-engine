//! hostopt.zig — v17.2 HOST SERVICES: the "make the host fast" layer.
//!
//! Everything here lives OUTSIDE the hashed 2MB flat memory, so it can
//! never fork a timeline: these are read-side accelerators for the engine
//! that embeds LILA (Unity / Unreal / custom C). The simulation core
//! (core.zig / vm.zig / engine.zig) is NOT modified — old games' hash
//! chains are bit-identical by construction.
//!
//!   1. BATCHED RENDER FEED  — the game's vert stream, grouped by token
//!      into first-appearance-ordered batches. One instanced draw per
//!      sprite instead of per-vert work; painter's order preserved both
//!      across batches (first-appearance) and within (stable sort).
//!   2. DELTA SNAPSHOTS      — LSA1 minus the unchanged bytes: regions of
//!      differing words vs a base snapshot. Rollback rings stop costing
//!      9 x 2MB; the wire format for netcode falls out for free.
//!   3. HISTORY RING         — opt-in built-in recorder: every frame is
//!      delta-captured into a 512-slot ring with a keyframe every 64
//!      frames. lila_history_seek() is instant rewind for any host
//!      (the Braid/GGPO primitive, engine-side, three calls to wire).
//!   4. SPRITE MANIFEST      — the sprite table the loader already placed
//!      in flat memory, exposed for Path-B hosts so they can build
//!      procedural placeholder meshes/textures at boot, per game, with
//!      zero game-specific host code.

const std = @import("std");
const c = @import("core.zig");
const tt = @import("timetravel.zig");

// ============================================================
// 1. BATCHED RENDER FEED
// ============================================================

/// One instancing batch: verts [first, first+count) of the sorted stream
/// all carry this token (sprite/text/... domain index). Batches are
/// ordered by FIRST APPEARANCE in the game's draw order — rendering
/// batches in order and verts within a batch in order reproduces the
/// painter's-algorithm result exactly (matters for additive blending).
pub const CBatch = extern struct {
    token: u16,
    pad: u16 = 0,
    first: u32,
    count: u32,
};

pub const MAX_BATCHES: u32 = 4096;

var sorted_verts: [c.MAX_VERTS * 14]u8 = undefined;
var batches: [MAX_BATCHES]CBatch = undefined;
var n_batches: u32 = 0;
var cached_frame: u32 = 0xFFFFFFFF;

/// Token histogram for the counting sort (u16 token space, direct index).
var tok_counts: [65536]u32 = undefined;
/// Per-token write cursor into sorted_verts, valid only during the pass.
var tok_cursor: [65536]u32 = undefined;

/// Rebuild the batch table if the frame advanced. O(n + 65536) counting
/// sort over the stream; the stream itself is never touched (read-only).
fn rebuildBatches() void {
    const n = c.rd32(c.ADDR_STREAM);
    n_batches = 0;
    if (n == 0 or n > c.MAX_VERTS) return;

    @memset(&tok_counts, 0);
    const src_base = c.ADDR_STREAM + 4;

    // pass 1: count tokens in first-appearance order
    var i: u32 = 0;
    while (i < n) : (i += 1) {
        const tok = c.rd16(src_base + i * 14 + 12);
        tok_counts[tok] += 1;
        if (tok_counts[tok] == 1) { // first appearance
            if (n_batches >= MAX_BATCHES) { // pathological token soup
                @memset(&tok_counts, 0);
                return; // host falls back to the raw stream
            }
            batches[n_batches] = .{ .token = tok, .first = 0, .count = 0 };
            n_batches += 1;
        }
    }

    // prefix: batch.first = running total in first-appearance order
    var run: u32 = 0;
    var b: u32 = 0;
    while (b < n_batches) : (b += 1) {
        const t = batches[b].token;
        batches[b].first = run;
        batches[b].count = tok_counts[t];
        tok_cursor[t] = run;
        run += tok_counts[t];
    }

    // pass 2: stable scatter (verts of one token keep draw order)
    i = 0;
    while (i < n) : (i += 1) {
        const s = src_base + i * 14;
        const tok = c.rd16(s + 12);
        const dst = tok_cursor[tok] * 14;
        var k: u32 = 0;
        while (k < 14) : (k += 1) sorted_verts[dst + k] = c.mem[s + k];
        tok_cursor[tok] += 1;
    }
}

/// The batch table for THIS frame (rebuilt lazily, cached per frame).
/// Returns the batch array; *out_count == 0 means "no batches — use the
/// raw stream" (empty frame, or > MAX_BATCHES distinct tokens).
pub fn streamBatches(out_count: *i32) [*]const CBatch {
    const f = c.rd32(c.ADDR_FRAME);
    if (f != cached_frame) {
        rebuildBatches();
        cached_frame = f;
    }
    out_count.* = @intCast(n_batches);
    return &batches;
}

/// The token-grouped verts (14B each, same layout as the raw stream).
/// Valid only when the batch count > 0; only the first
/// sum(batch.count) * 14 bytes are meaningful.
pub fn streamSortedPtr() [*]const u8 {
    return &sorted_verts;
}

// ============================================================
// 2. DELTA SNAPSHOTS  ("LDL1")
// ============================================================

pub const DELTA_MAGIC: u32 = 0x314C444C; // "LDL1"
pub const DELTA_VERSION: u32 = 1;
/// header: magic u32 | version u32 | frame u32 | nregions u32 |
///         spawn_denied u32 | stream_drop u32 | sram_dirty u32 | pad u32
/// regions: (start_word u32, count u32, count x u32) — absolute word
/// indices into the 2MB image, so a delta pairs with ANY full LSA1 base
/// the host saved (the host must keep the pairing, documented).
pub const DELTA_HEADER: u32 = 32;

/// Worst-case delta size (everything changed): header + one region
/// covering all words.
pub fn deltaMax() usize {
    return DELTA_HEADER + 8 + @as(usize, c.MEM_SIZE);
}

inline fn rdU32(p: [*]const u8) u32 {
    return @as(*align(1) const u32, @ptrCast(p)).*;
}
inline fn wrU32(p: [*]u8, v: u32) void {
    @as(*align(1) u32, @ptrCast(p)).* = v;
}

/// Compare the live engine against a full LSA1 base image; encode the
/// differing regions (plus the host scalars, which live outside mem but
/// inside the LSA1 header) as an LDL1 delta. Returns bytes written,
/// or 0 if dst is too small / base is malformed.
pub fn deltaSave(base: [*]const u8, base_len: usize, dst: [*]u8, dst_len: usize) usize {
    if (base_len < 44 + @as(usize, c.MEM_SIZE)) return 0;
    if (rdU32(base[0..4].ptr) != tt.SNAP_MAGIC) return 0;

    const words = c.MEM_SIZE / 4;
    const cur: [*]align(1) const u32 = @ptrCast(&c.mem);
    const ref: [*]align(1) const u32 = @ptrCast(base + 44);

    // two passes over the region list: count first (size check), then
    // write. Regions are greedy maximal runs of differing words.
    var nreg: u32 = 0;
    var need: usize = DELTA_HEADER;
    {
        var i: u32 = 0;
        while (i < words) {
            if (cur[i] != ref[i]) {
                var j = i;
                while (j < words and cur[j] != ref[j]) j += 1;
                nreg += 1;
                need += 8 + @as(usize, j - i) * 4;
                i = j;
            } else i += 1;
        }
    }
    if (dst_len < need) return 0;

    wrU32(dst + 0, DELTA_MAGIC);
    wrU32(dst + 4, DELTA_VERSION);
    wrU32(dst + 8, c.rd32(c.ADDR_FRAME));
    wrU32(dst + 12, nreg);
    wrU32(dst + 16, c.spawn_denied_total);
    wrU32(dst + 20, c.stream_drop_total);
    wrU32(dst + 24, c.sram_dirty);
    wrU32(dst + 28, 0);

    var w: usize = DELTA_HEADER;
    {
        var i: u32 = 0;
        while (i < words) {
            if (cur[i] != ref[i]) {
                var j = i;
                while (j < words and cur[j] != ref[j]) j += 1;
                wrU32(dst + w, i);
                wrU32(dst + w + 4, j - i);
                w += 8;
                var k = i;
                while (k < j) : (k += 1) {
                    wrU32(dst + w, cur[k]);
                    w += 4;
                }
                i = j;
            } else i += 1;
        }
    }
    return w;
}

/// Reconstruct (base + delta) and restore the engine through the same
/// verified LSA1 path. Returns the frame number, or -1 on any mismatch.
var delta_scratch: [44 + c.MEM_SIZE]u8 = undefined;

pub fn deltaLoad(base: [*]const u8, base_len: usize, delta: [*]const u8, delta_len: usize) i32 {
    if (base_len < 44 + @as(usize, c.MEM_SIZE)) return -1;
    if (delta_len < DELTA_HEADER) return -1;
    if (rdU32(base[0..4].ptr) != tt.SNAP_MAGIC) return -1;
    if (rdU32(delta[0..4].ptr) != DELTA_MAGIC) return -1;
    if (rdU32(delta[4..8].ptr) != DELTA_VERSION) return -1;

    const frame = rdU32(delta[8..12].ptr);
    const nreg = rdU32(delta[12..16].ptr);

    // scratch = base, then patch header fields the delta owns
    @memcpy(delta_scratch[0 .. 44 + c.MEM_SIZE], base[0 .. 44 + c.MEM_SIZE]);
    wrU32(delta_scratch[8..12].ptr, frame);
    wrU32(delta_scratch[16..24].ptr, 0); // schema sig: same cartridge, same schema
    wrU32(delta_scratch[24..28].ptr, rdU32(delta[16..20].ptr)); // spawn_denied
    wrU32(delta_scratch[28..32].ptr, rdU32(delta[20..24].ptr)); // stream_drop
    wrU32(delta_scratch[32..36].ptr, rdU32(delta[24..28].ptr)); // sram_dirty

    // apply regions (bounds-checked against the image)
    var w: usize = DELTA_HEADER;
    var r: u32 = 0;
    while (r < nreg) : (r += 1) {
        if (w + 8 > delta_len) return -1;
        const start = rdU32(delta + w);
        const count = rdU32(delta + w + 4);
        w += 8;
        if (@as(usize, start) + count > c.MEM_SIZE / 4) return -1;
        if (w + @as(usize, count) * 4 > delta_len) return -1;
        var k: u32 = 0;
        while (k < count) : (k += 1) {
            wrU32(delta_scratch[44 + (start + k) * 4 ..].ptr, rdU32(delta + w));
            w += 4;
        }
    }

    const f = tt.deserializeInto(delta_scratch[0 .. 44 + c.MEM_SIZE]) catch return -1;
    return @intCast(f);
}

// ============================================================
// 3. HISTORY RING — engine-side rewind recorder
// ============================================================

const HIST_SLOTS: u32 = 512;
const SLOT_BYTES: u32 = 64 * 1024; // worst measured game churn: ~50KB/63f
const KEY_EVERY: u32 = 64;
const N_KEYS: u32 = HIST_SLOTS / KEY_EVERY; // 8

const Slot = struct {
    kind: u8 = 0, // 0 empty, 1 keyframe, 2 delta
    key_group: u16 = 0, // for deltas: which key image it is against
    frame: u32 = 0, // stored post-frame counter
    bytes: u32 = 0, // payload size (deltas)
    data: [SLOT_BYTES]u8 = undefined,
};

var hist_slots: [HIST_SLOTS]Slot = undefined;
var hist_keys: [N_KEYS][44 + c.MEM_SIZE]u8 = undefined;
var hist_on: bool = false;
var hist_abs: u32 = 0; // absolute captures taken (slot = abs % SLOTS)
var hist_start_abs: u32 = 0; // oldest LIVE capture (key images behind it die)
var hist_last: i64 = -1; // frame of the previous capture (continuity check)
var hist_prev_input: u32 = 0; // input word as observed at the LAST capture —
// the canonical value for THIS capture: hash(F-1) was taken while the input
// word still held the PREVIOUS frame's mask (the host writes the next mask
// before calling lila_frame). The ring images must match that, or a
// post-seek hash check diverges by exactly one word at address 0x00.

/// Begin recording. `frames` is clamped to the ring size (512). The ring
/// fills as lila_frame() runs; audio stays on the host contract. Returns
/// the slots actually reserved, or -1 if frames == 0.
pub fn historyStart(frames: u32) i32 {
    if (frames == 0) return -1;
    hist_on = true;
    hist_abs = 0;
    hist_start_abs = 0;
    hist_last = -1;
    hist_prev_input = c.rd32(c.ADDR_INPUT);
    const reserved = @min(frames, HIST_SLOTS);
    var i: u32 = 0;
    while (i < reserved) : (i += 1) hist_slots[i].kind = 0;
    return @intCast(reserved);
}

pub fn historyStop() void {
    hist_on = false;
}

/// Oldest buffered frame (-1 when empty).
pub fn historyBegin() i32 {
    if (hist_abs <= hist_start_abs) return -1;
    return @intCast(hist_slots[hist_start_abs % HIST_SLOTS].frame);
}

/// Number of buffered frames (post-frame images).
pub fn historyFrames() i32 {
    return @intCast(hist_abs - hist_start_abs);
}

/// Called at the START of lila_frame() (and lazily from historySeek):
/// captures the CURRENT state — the previous frame's settled post-audio-pull
/// image, the exact state the hash chain hashes. ~one 2MB diff per frame
/// (opt-in only).
pub fn historyTick() void {
    if (!hist_on) return;
    const f = c.rd32(c.ADDR_FRAME);

    // continuity: the legal advances from hist_last are +1 (a frame ran and
    // settled) or +0 (just restored / just lazily captured — already have it).
    // Anything else is an external snapshot_load (host rollback): the
    // buffered timeline is dead — restart the ring.
    if (hist_last >= 0) {
        const fl: u64 = @intCast(hist_last);
        if (fl == f) return; // nothing new since the last capture
        if (fl + 1 != f) {
            hist_abs = 0;
            hist_start_abs = 0;
            hist_last = -1;
        }
    }
    hist_last = f;

    const pos = hist_abs % HIST_SLOTS;
    const group = hist_abs / KEY_EVERY;
    const key_idx = group % N_KEYS;
    const slot = &hist_slots[pos];

    // Canonical input word: the state being captured (post-frame f-1) was
    // hashed while the input word held the PREVIOUS mask — but the host has
    // already written THIS frame's mask by now. Patch it for the capture,
    // restore immediately (the mutation is transient between frames and
    // invisible to both the host and the hash chain).
    const input_now = c.rd32(c.ADDR_INPUT);
    c.wr32(c.ADDR_INPUT, hist_prev_input);
    defer {
        c.wr32(c.ADDR_INPUT, input_now);
        hist_prev_input = input_now;
    }

    if (hist_abs % KEY_EVERY == 0) {
        // keyframe: full image into the key store; slot just marks it.
        // KEY-LIFETIME FIX: the ring spans up to ceil(SLOTS/KEY_EVERY)+1 = 9
        // groups when the oldest live slot is not group-aligned. Writing key
        // for group g invalidates every live capture in groups <= g-8 (same
        // key slot) — retire them instead of leaving dangling references.
        const g = hist_abs / KEY_EVERY;
        const img: [*]u8 = &hist_keys[key_idx];
        if (lilaSnapshotSaveRaw(img) != 0) return; // cannot happen; keep type honest
        if (g >= N_KEYS) {
            const first_valid = (g - N_KEYS + 1) * KEY_EVERY;
            if (hist_start_abs < first_valid) hist_start_abs = first_valid;
        }
        slot.* = .{ .kind = 1, .key_group = @intCast(key_idx), .frame = f, .bytes = 0 };
    } else {
        const base: [*]const u8 = &hist_keys[key_idx];
        const n = deltaSave(base, 44 + @as(usize, c.MEM_SIZE), &slot.data, SLOT_BYTES);
        if (n == 0) {
            // Slot overflow (>64KB churn in one frame — scene changes,
            // full-screen effects). SAFE degradation: this slot becomes a
            // NEW KEY for its group and the group's EARLIER slots retire
            // (they reference the key we are about to overwrite). Slots in
            // EARLIER groups keep their own (untouched) keys. Future
            // captures in this group diff against the new key. Worst cost:
            // up to 63 frames of rewind depth — never a corrupt restore.
            const img: [*]u8 = &hist_keys[key_idx];
            if (lilaSnapshotSaveRaw(img) != 0) return;
            const gstart = group * KEY_EVERY;
            if (hist_start_abs < gstart) hist_start_abs = gstart;
            slot.* = .{ .kind = 1, .key_group = @intCast(key_idx), .frame = f, .bytes = 0 };
        } else {
            slot.* = .{ .kind = 2, .key_group = @intCast(key_idx), .frame = f, .bytes = @intCast(n) };
        }
    }
    hist_abs += 1;
}

/// Rewind the engine to a buffered post-frame state. Returns the frame
/// (>= 0) or -1 (not buffered / corrupt). Recording resumes from there:
/// the buffered future is truncated (GGPO semantics).
pub fn historySeek(frame: u32) i32 {
    // lazy capture: the CURRENT state (post-pull of the last frame) is
    // exactly what the next lila_frame() would capture — do it now so the
    // newest frame is always rewindable. If the host externally rolled
    // back (counter jump), historyTick's continuity check resets instead.
    historyTick();

    var abs = hist_start_abs;
    while (abs < hist_abs) : (abs += 1) {
        const slot = &hist_slots[abs % HIST_SLOTS];
        if (slot.kind == 0 or slot.frame != frame) continue;

        var rc: i32 = -1;
        if (slot.kind == 1) {
            const img: [*]const u8 = &hist_keys[slot.key_group];
            rc = lilaSnapshotLoadRaw(img);
        } else {
            const base: [*]const u8 = &hist_keys[slot.key_group];
            rc = deltaLoad(base, 44 + @as(usize, c.MEM_SIZE), &slot.data, slot.bytes);
        }
        if (rc < 0) return -1;

        // truncate the future, continue recording from here; the restored
        // image's input word IS the canonical value for the next capture.
        hist_abs = abs + 1;
        hist_last = frame;
        hist_prev_input = c.rd32(c.ADDR_INPUT);
        return @intCast(slot.frame);
    }
    return -1;
}

// internal: LSA1 save/load without going through the export layer's
// pointer types (identical bytes — this is the same 44B header + mem).
fn lilaSnapshotSaveRaw(dst: [*]u8) i32 {
    const out = dst[0 .. 44 + c.MEM_SIZE];
    @memset(out[0..44], 0);
    std.mem.writeInt(u32, out[0..4], tt.SNAP_MAGIC, .little);
    std.mem.writeInt(u32, out[4..8], tt.SNAP_VERSION, .little);
    std.mem.writeInt(u32, out[8..12], c.rd32(c.ADDR_FRAME), .little);
    std.mem.writeInt(u32, out[12..16], c.MEM_SIZE, .little);
    std.mem.writeInt(u64, out[16..24], @import("engine.zig").computeSchemaSig(), .little);
    std.mem.writeInt(u32, out[24..28], c.spawn_denied_total, .little);
    std.mem.writeInt(u32, out[28..32], c.stream_drop_total, .little);
    std.mem.writeInt(u32, out[32..36], c.sram_dirty, .little);
    @memcpy(out[44..], c.mem[0..]);
    return 0;
}

fn lilaSnapshotLoadRaw(src: [*]const u8) i32 {
    const f = tt.deserializeInto(src[0 .. 44 + c.MEM_SIZE]) catch return -1;
    return @intCast(f);
}

// ============================================================
// 4. SPRITE MANIFEST (Path B asset discovery)
// ============================================================

/// Sprites the loader placed in flat memory (same 14B vert layout as the
/// render stream: i16 x, i16 y, u16 uv, u32 rgba, u16 token). A host
/// rasterizes these once at boot into textures, or builds meshes from
/// them — per game, zero game-specific host code.
pub fn spriteCount() i32 {
    return @intCast(c.n_sprites);
}

pub fn spriteVertCount(i: u32) i32 {
    if (i >= c.n_sprites) return -1;
    return @intCast(c.rd16(c.ADDR_SPRITES + i * c.SPRITE_STRIDE));
}

pub fn spriteVerts(i: u32) ?[*]const u8 {
    if (i >= c.n_sprites) return null;
    return c.mem[c.ADDR_SPRITES + i * c.SPRITE_STRIDE + 2 ..].ptr;
}
