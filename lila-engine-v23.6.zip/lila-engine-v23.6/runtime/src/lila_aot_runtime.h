/* ============================================================================
 * LILA AOT RUNTIME — C-side declarations for AOT-compiled functions
 * ============================================================================
 *
 * This header is the C-side contract for `lilac aot` output. It declares:
 *   - LilaState: the C view of the live interpreter state (vm.zig::State
 *     prefix — ABI v2 shared state, no mirror copying)
 *   - The runtime symbols the AOT code reads (lila_globals, lila_pool, etc.)
 *   - The runtime helper functions the AOT code calls (lila_sin, lila_dist,
 *     lila_draw, etc. — the full C ABI surface)
 *
 * The matching Zig-side definitions live in lila_aot_bridge.zig. Linking:
 *   cc -O2 -c lila_aot.c -o lila_aot.o
 *   zig build-lib src/lila_aot_bridge.zig -dynamic -O ReleaseFast
 *   cc lila_aot.o -llila_aot_bridge -o my_game
 *
 * See opt/cbackend.rs for the C source emitter and the full design.
 * ============================================================================ */

#ifndef LILA_AOT_RUNTIME_H
#define LILA_AOT_RUNTIME_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- LilaState: the C VIEW of the live interpreter state (vm.zig::State)
 * v23.5 ABI v2: LilaState is a layout PREFIX of vm.State (extern struct,
 * comptime-asserted on the Zig side). AOT functions take a `LilaState*`
 * that IS the live interpreter state pointer (see lila_state_ptr) — reads
 * and writes land directly on the interpreter with NO mirror copying.
 * The pointer a compiled fn receives is exactly lila_state_ptr().
 */
typedef struct {
    int32_t  stack[512];
    uint32_t sp;
    struct {
        uint32_t ret_pc;
        uint32_t fn_idx;
        int32_t  locals[32];
    } frames[32];
    uint32_t fp;
    uint32_t pc;
    int32_t  ret_val; /* v17 threadlocal return register */
} LilaState;

/* ---- Decoded instruction stream (mirrors core.zig::iOp/iA/iB/iC) ----
 * The AOT C reads `lila_code[pc].op/a/b/c` exactly like the interpreter.
 */
typedef struct {
    uint8_t  op;
    uint8_t  _pad[3];
    int32_t  a;
    int32_t  b;
    int32_t  c;
    uint32_t extra_off;
} LilaInstr;

/* ---- Runtime mirrors (accessed through functions, NOT extern data) -------
 * Exported mutable DATA symbols break under executable copy relocations
 * (the exe gets its own copy; the library writes its internal one — the
 * classic split-brain, verified by the v23.2 probe). Accessor functions
 * are immune; the macros below keep C sources reading naturally.
 */
LilaInstr* lila_code_ptr(void);
int32_t*   lila_pool_ptr(void);
int32_t*   lila_globals_ptr(void);
uint32_t   lila_input_read(void);
uint32_t   lila_frame_read(void);
int32_t    lila_cam_x_read(void);
int32_t    lila_cam_y_read(void);

/* v23.5 ABI v2: the shared live interpreter state (the same pointer the
 * dispatch hands to every compiled fn). Threadlocal on native builds —
 * each parallel worker sees its own. Hosts may read it for tooling; AOT
 * code should simply use the `st` argument it was passed. */
LilaState* lila_state_ptr(void);

/* Typed global access — the OP_LD_GLBL/OP_ST_GLBL handler bodies. `tf` is
 * a typed-field index in the bit-packed global plane (NOT a word index).
 * 32-bit fields only: f64 globals are Tier-1 and never reach AOT code. */
int32_t lila_global_read(int32_t tf);
void    lila_global_write(int32_t tf, int32_t value);

/* Mirror macros carry a trailing underscore so they can NEVER shadow the
 * engine API (lila_frame() steps a frame; lila_frame_ is the counter
 * mirror) — the first probe build caught the collision.
 * v23.2 note: the generated C reads the mirrors through these macros. */
#define lila_code_    (lila_code_ptr())
#define lila_pool_    (lila_pool_ptr())
#define lila_globals_ (lila_globals_ptr())
#define lila_input_   (lila_input_read())
#define lila_frame_   (lila_frame_read())
#define lila_cam_x_   (lila_cam_x_read())
#define lila_cam_y_   (lila_cam_y_read())

/* ---- Init + per-frame mirrors -------------------------------------------
 * v23.5 ABI v2: BOTH ARE NO-OPS kept for source compatibility. The image
 * accessors (lila_code_ptr/lila_pool_ptr/lila_globals_ptr) self-aim on
 * every call, and the input/frame/camera reads go LIVE to the image —
 * there is no init contract and no per-frame refresh contract anymore.
 */
void lila_bridge_init(void);
void lila_bridge_frame_sync(void);

/* ---- Loop machinery (branch decisions, jumps suppressed) ------------------
 * The AOT emitter branches on the returned flag; the interpreter's relative
 * jump inside these handlers is neutralized. Iterator state lives in the
 * live interpreter state across calls, so nested loops work unchanged.
 * (ABI v2: `st` is the shared state pointer — the parameter is kept for
 * source compatibility; the helpers operate on the live state directly.)
 */
int32_t lila_for_bgn(LilaState* st, int32_t type, int32_t slot, uint32_t pc);
int32_t lila_for_adv(LilaState* st, uint32_t pc);
int32_t lila_for_mask_bgn(LilaState* st, int32_t slot, int32_t type_base, uint32_t mask, uint32_t pc);
int32_t lila_for_mask_adv(LilaState* st, uint32_t pc);
int32_t lila_pl_for_bgn(LilaState* st, int32_t pool, int32_t slot, uint32_t pc);
int32_t lila_pl_for_adv(LilaState* st, uint32_t pc);
void    lila_iter_pop(LilaState* st);

/* ---- Direct leaf services (the exact calls the opcode handlers make) ----- */

/* Entity fields + lifecycle — HANDLE convention (gen<<20 | idx), not slots */
int32_t lila_ent_field(int32_t handle, int32_t tf_idx);
void    lila_ent_set_field(int32_t handle, int32_t tf_idx, int32_t value);
int32_t lila_count(int32_t type);
void    lila_kill(int32_t type, int32_t handle);

/* Trig + math (LUT-driven, integer-exact) */
int32_t lila_sin(int32_t ang);
int32_t lila_cos(int32_t ang);
int32_t lila_atan2(int32_t dx, int32_t dy);
int32_t lila_dist(int32_t x1, int32_t y1, int32_t x2, int32_t y2);
int32_t lila_rand_max(int32_t n);
int32_t lila_anim(int32_t anim_id, int32_t t);

/* Input edges */
int32_t lila_key_edge(int32_t bit, int32_t mode);

/* Audio + screen */
void    lila_sfx(int32_t atom);
void    lila_music(int32_t atom);
void    lila_stop_music(void);
void    lila_music_vol(int32_t v);
void    lila_shake(int32_t amp);
void    lila_camera(int32_t x, int32_t y);

/* Save/load (SRAM) */
void    lila_save(int32_t ix, int32_t value);
int32_t lila_saved(int32_t ix);

/* Draw calls (render stream emit) */
void    lila_draw(int32_t sprite, int32_t x, int32_t y, int32_t rot, int32_t scale, int32_t rgba);
void    lila_draw_text(int32_t atom, int32_t x, int32_t y, int32_t rgba);
void    lila_draw_num(int32_t v, int32_t x, int32_t y, int32_t rgba);
void    lila_draw_numz(int32_t v, int32_t digits, int32_t x, int32_t y, int32_t rgba);

/* 3D pipeline: proj3 stashes sx/sy/ok and RETURNS the scale. The full
 * draw3d/draw3di/cam3 pipeline stays behind lila_interpreter_step (it owns
 * cull/sort/raster engine state). */
int32_t lila_proj3(int32_t x, int32_t y, int32_t z);
int32_t lila_proj_x(void);
int32_t lila_proj_y(void);
int32_t lila_proj_ok(void);

/* Quat / mat4 rig math (pure register-plane transforms) */
void    lila_quat_aa(int32_t q_arr, int32_t off, int32_t ax, int32_t ay, int32_t az, int32_t ang);
void    lila_q_mul(int32_t d, int32_t doff, int32_t a, int32_t aoff, int32_t b, int32_t boff);
void    lila_m4_qt(int32_t m, int32_t moff, int32_t q, int32_t qoff, int32_t tx, int32_t ty, int32_t tz);
void    lila_m4_mul(int32_t d, int32_t doff, int32_t a, int32_t aoff, int32_t b, int32_t boff);
void    lila_skin3(int32_t v, int32_t voff, int32_t m, int32_t moff, int32_t x, int32_t y, int32_t z);
void    lila_m4_look(int32_t m, int32_t moff, int32_t ex, int32_t ey, int32_t ez, int32_t tx, int32_t ty, int32_t tz);

/* FSM bit-plane transitions (image-only table read, soft-landed) */
int32_t lila_fsm_next(int32_t fsm_id, int32_t state, int32_t event_mask);

/* swept Minkowski interval test (OP_SWEPT) — pure i64 math, VM handler body
 * verbatim; pops are done by the generated code in VM order. */
int32_t lila_swept(int32_t hw, int32_t hh, int32_t ax, int32_t ay, int32_t avx, int32_t avy, int32_t bx, int32_t by);

/* v11 ARRAYS (raw plane cells; the interpreter's mask/mod indexing lives in
 * these bridge calls — identical soft-land semantics). The 64-bit forms move
 * an f64 array element as one u64 (hi<<32|lo); the emitters pick the form by
 * the array's static element type. */
int32_t lila_ld_garr(int32_t arr, int32_t idx);
void    lila_st_garr(int32_t arr, int32_t idx, int32_t value);
int32_t lila_ld_earr(int32_t slot_handle, int32_t arr, int32_t idx);
void    lila_st_earr(int32_t slot_handle, int32_t arr, int32_t idx, int32_t value);
uint64_t lila_ld_garr64(int32_t arr, int32_t idx);
void    lila_st_garr64(int32_t arr, int32_t idx, uint64_t v);
uint64_t lila_ld_earr64(int32_t slot_handle, int32_t arr, int32_t idx);
void    lila_st_earr64(int32_t slot_handle, int32_t arr, int32_t idx, uint64_t v);

/* v21 sort + dicts + ray + astar (real grid dimensions are part of the ABI) */
void    lila_psort(int32_t pool, int32_t pfield, int32_t dir);
void    lila_m_put(int32_t dict, int32_t key, int32_t value);
int32_t lila_m_get(int32_t dict, int32_t key);
void    lila_m_del(int32_t dict, int32_t key);
int32_t lila_m_len(int32_t dict);
int32_t lila_m_next(int32_t dict, int32_t cursor);
int32_t lila_m_next_v(void);
int32_t lila_m_next_c(void);
int32_t lila_ray(int32_t grid, int32_t gw, int32_t gh, int32_t x, int32_t y, int32_t ang, int32_t maxd);
int32_t lila_ray_x(void);
int32_t lila_ray_y(void);
int32_t lila_astar(int32_t grid, int32_t path, int32_t gw, int32_t gh, int32_t sx, int32_t sy, int32_t tx, int32_t ty);

/* v22 queues + stacks + arrays + noise */
void    lila_qpush(int32_t arr, int32_t value);
int32_t lila_qpop(int32_t arr);
int32_t lila_qlen(int32_t arr);
void    lila_spush(int32_t arr, int32_t value);
int32_t lila_spop(int32_t arr);
int32_t lila_slen(int32_t arr);
int32_t lila_speek(int32_t arr);
void    lila_afill(int32_t arr, int32_t value);
void    lila_acopy(int32_t dst, int32_t src, int32_t n);
void    lila_ashuf(int32_t arr, int32_t n);
int32_t lila_afind(int32_t arr, int32_t value);
int32_t lila_acount(int32_t arr, int32_t value);
int32_t lila_noise1(int32_t t);
int32_t lila_noise2(int32_t x, int32_t y);

/* v20 f32 software-IEEE ops (softfloat.zig; F32 = raw bit pattern) */
uint32_t lila_f32_add(uint32_t a, uint32_t b);
uint32_t lila_f32_sub(uint32_t a, uint32_t b);
uint32_t lila_f32_mul(uint32_t a, uint32_t b);
uint32_t lila_f32_div(uint32_t a, uint32_t b);
uint32_t lila_f32_sqrt(uint32_t a);
int32_t  lila_f32_eq(uint32_t a, uint32_t b);
int32_t  lila_f32_ne(uint32_t a, uint32_t b);
int32_t  lila_f32_lt(uint32_t a, uint32_t b);
int32_t  lila_f32_gt(uint32_t a, uint32_t b);
int32_t  lila_f32_le(uint32_t a, uint32_t b);
int32_t  lila_f32_ge(uint32_t a, uint32_t b);
uint32_t lila_i2f32(int32_t v);
int32_t  lila_f322i(uint32_t f);
uint32_t lila_fix2f32(int32_t q);
int32_t  lila_f322fix(uint32_t f);

/* v23.6: schema-width-aware global access — an f64 global (tf bits > 32)
 * moves a (lo, hi) cell pair, exactly like the interpreter's LD/ST_GLBL */
uint64_t lila_global_read64(uint32_t tf);
void     lila_global_write64(uint32_t tf, uint64_t v);
/* v23.6: same for ENTITY fields (LD/ST_ENT width-aware forms) */
uint64_t lila_ent_field64(int32_t handle, int32_t tf);
void     lila_ent_set_field64(int32_t handle, int32_t tf, uint64_t v);

/* v23.6 f64 software-IEEE ops (softfloat.zig; F64 = raw u64 bit pattern,
 * (hi << 32) | lo — the SAME correctly-rounded binary64 routines the
 * interpreter runs, so native f64 math is bit-identical by construction) */
uint64_t lila_f64_add(uint64_t a, uint64_t b);
uint64_t lila_f64_sub(uint64_t a, uint64_t b);
uint64_t lila_f64_mul(uint64_t a, uint64_t b);
uint64_t lila_f64_div(uint64_t a, uint64_t b);
uint64_t lila_f64_sqrt(uint64_t a);
int32_t  lila_f64_eq(uint64_t a, uint64_t b);
int32_t  lila_f64_ne(uint64_t a, uint64_t b);
int32_t  lila_f64_lt(uint64_t a, uint64_t b);
int32_t  lila_f64_gt(uint64_t a, uint64_t b);
int32_t  lila_f64_le(uint64_t a, uint64_t b);
int32_t  lila_f64_ge(uint64_t a, uint64_t b);
uint64_t lila_i2f64(int32_t v);
int32_t  lila_f642i(uint64_t f);
uint64_t lila_fix2f64(int32_t q);
int32_t  lila_f642fix(uint64_t f);
uint64_t lila_f322f64(uint32_t x);
int32_t  lila_f642f32(uint64_t f);

/* ---- AOT DISPATCH ----------------------------------------------------------
 * Install the generated table (lila_aot.c defines lila_aot_table); from
 * then on every fn call routes through it (NULL entries = interpreter).
 * lila_call_fn is what generated code emits for LILA->LILA calls: pops n
 * arg cells off the shared stack (guarded exactly like the interpreter's
 * OP_CALL_FN handler), runs the callee (compiled body or interpreter) to
 * completion, leaves the return value in st->ret_val. ABI v2: implemented
 * by running the REAL OP_CALL_FN handler through dispatch — zero drift.
 */
typedef void (*LilaFn)(LilaState*);
void lila_aot_install(const LilaFn* table, uint32_t len);
void lila_aot_uninstall(void);
void lila_call_fn(int32_t fi, int32_t n, LilaState* st);

/* ---- THE UNIVERSAL FALLBACK ----------------------------------------------
 * Execute the REAL decoded instruction at pc (spawn, swept, aggregates,
 * arrays, pools, signals, call_tbl/call_fn, dist_near, cam3, draw3d, ...
 * — the full table with per-opcode stack orders is documented in
 * lila_aot_bridge.zig) on the LIVE state. ABI v2: `st` is the shared state
 * pointer (nothing is copied); the AOT code owns its control flow and reads
 * results from st->stack. Tier-1 fns (try/catch, f64-heavy, thread) run
 * ENTIRELY through this: the AOT dispatch-table entry is NULL and the host
 * interprets the body one instruction at a time.
 */
void lila_interpreter_step(LilaState* st, uint32_t pc);

#ifdef __cplusplus
}
#endif

#endif /* LILA_AOT_RUNTIME_H */
