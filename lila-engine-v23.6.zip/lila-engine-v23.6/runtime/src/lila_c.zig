//! LILA native host ABI — embed the deterministic console inside a real
//! engine (Unity via P/Invoke, Unreal via module link, plain C hosts).
//!
//! Build (from runtime/):
//!   zig build-lib src/lila_c.zig -dynamic -O ReleaseFast   -> liblila_c.so
//!   zig build-lib src/lila_c.zig -O ReleaseFast            -> liblila_c.a
//!   zig build-lib src/lila_c.zig -dynamic -O ReleaseFast \
//!        -target x86_64-windows-gnu                         -> lila_c.dll
//!
//! This is the SAME engine the native runner executes (same core.zig, same
//! VM, same loader): a host embedding this library reproduces the runner's
//! recorded hash chains bit-for-bit. examples/c_host proves it by replaying
//! an LIR1 movie through this ABI and byte-comparing the audio path.
//!
//! The frame contract (60Hz fixed tick, mirrored from the runner):
//!     lila_input_set(mask);          // write input BEFORE the frame
//!     lila_frame();                  // one simulation tick
//!     lila_audio_fill(pcm, 735);     // pull exactly one frame of audio
//!     ... = lila_state_hash(f);     // hash AFTER the f-th frame, passing f
//!
//! Determinism boundary rules (see hosting/INTEGRATION.md):
//!   - the engine is integer-only Q24.8; convert to float at the RENDER
//!     boundary only, never write floats back into simulation words
//!   - host may write: input (0x00), camera registers (0x54..0x6C),
//!     SRAM (before init). Writing any other word forks your timeline away
//!     from recorded movies — allowed (it's your game), just knowingly.

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");
const audio = @import("audio.zig");
const hostopt = @import("hostopt.zig");
const tables = @import("tables.zig");
const overlay = @import("overlay.zig");

pub const LILA_ABI_VERSION: i32 = 5; // v23: + pointer overlays (v20: pools/reflection; v19: tables; v17.2: batches/deltas/history)
pub const LILA_ENGINE_VERSION: i32 = 23;

/// Cartridge staging buffer (same pattern as the wasm ABI: init copies the
/// blob in, then the loader consumes it synchronously).
var blob_store: [256 * 1024]u8 = undefined;

// ---------------- identity ----------------

export fn lila_abi_version() i32 {
    return LILA_ABI_VERSION;
}
export fn lila_engine_version() i32 {
    return LILA_ENGINE_VERSION;
}

// ---------------- v20 / ABI 4: reflection + pool introspection ----------------

/// Copy a reflection name into `out` (NUL-terminated); returns the length
/// or -1 when unknown. kind: 0=entity(a=type) 1=field(a=tf) 2=fn(a=fi)
/// 3=pool(a=pi) 4=pool field(a=pi,b=field). Requires the cartridge to ship
/// `game { reflection: true }` (the names trailer).
export fn lila_name(kind: u8, a: u32, b: u32, out: [*]u8, cap: u32) i32 {
    if (cap == 0) return -1;
    return c.nameCopy(kind, a, b, out[0..cap]);
}

/// Number of dynamic pools the cartridge declared.
export fn lila_pool_count() i32 {
    return @intCast(c.n_pools);
}

/// Declared capacity of pool pi (0-based), or -1.
export fn lila_pool_cap(pi: i32) i32 {
    if (pi < 0 or pi >= c.n_pools) return -1;
    return c.pool_cap[@intCast(pi)];
}

/// LIVE row count of pool pi (read straight from the flat image — the same
/// bytes the hash chain covers), or -1.
export fn lila_pool_len(pi: i32) i32 {
    if (pi < 0 or pi >= c.n_pools) return -1;
    return @bitCast(c.rd32(c.pool_base[@intCast(pi)]));
}

/// The flat-image size of this engine build, in MB (the v20 memory tier).
export fn lila_mem_mb() i32 {
    return @intCast(c.MEM_SIZE / (1024 * 1024));
}

// ---------------- lifecycle ----------------

/// Load a .libyte (v1..v4) and run its init() fns. Returns 0 on success,
/// a loader error code otherwise (lila_last_error mirrors it).
export fn lila_init(ptr: [*]const u8, len: usize) i32 {
    if (len == 0 or len > blob_store.len) return c.ERR_TOO_BIG;
    @memcpy(blob_store[0..len], ptr[0..len]);
    c.stream_drop_total = 0;
    c.spawn_denied_total = 0;
    c.last_error = 0;
    overlay.reset(); // v23: new cartridge -> new interop layouts
    const rc = engine.init(blob_store[0..len]);
    if (rc == c.ERR_OK) engine.rememberSchema();
    return rc;
}

/// Live reload of a new .libyte, preserving entity+globals state when the
/// schema signature matches (the live-coding primitive). Returns 1 if state
/// was preserved, 0 if it was a full re-init.
export fn lila_hot_swap(ptr: [*]const u8, len: usize) i32 {
    if (len == 0 or len > blob_store.len) return 0;
    @memcpy(blob_store[0..len], ptr[0..len]);
    overlay.reset(); // v23: the new cartridge may carry new layouts
    return if (engine.hotSwap(blob_store[0..len])) 1 else 0;
}

// ---------------- the frame ----------------

/// One 60Hz simulation tick. Runs updates, auto-integration, draws (into the
/// render stream), decays screen-shake, advances the frame counter. When the
/// opt-in history ring is armed (lila_history_start), the PREVIOUS frame's
/// settled (post-audio-pull) state is delta-captured first — exactly the
/// state the canonical hash contract hashes, so seeks restore hash-identical
/// states. Read-only pass: the simulation and its hash chain are untouched.
export fn lila_frame() void {
    hostopt.historyTick();
    engine.frame();
}

/// Current frame counter (the u32 at address 0x04).
export fn lila_tick() u32 {
    return c.rd32(c.ADDR_FRAME);
}

// ---------------- input ----------------

/// Write the input bitmask BEFORE calling lila_frame(). Bit i = key i as
/// the game's key() queries define it (v16 demo: 0=left 1=right 2=up 3=fire).
/// Edge registers (key_pressed/key_released) are maintained automatically
/// by the engine for games that use them.
export fn lila_input_set(mask: u32) void {
    c.wr32(c.ADDR_INPUT, mask);
}
export fn lila_input_get() u32 {
    return c.rd32(c.ADDR_INPUT);
}

// ---------------- determinism primitives ----------------

/// Wyhash over (frame, full flat memory, host scalars) — pure integer math,
/// identical on every platform. Call AFTER stepping the f-th frame, passing
/// the same 0-based f the runner's movies use.
export fn lila_state_hash(frame: u32) u64 {
    return tt.stateHash(frame);
}

/// Byte size of an LSA1 save-state image (44 + MEM_SIZE).
export fn lila_snapshot_size() usize {
    return 44 + @as(usize, c.MEM_SIZE);
}

/// Serialize the ENTIRE engine state (a 2MB memcpy) into dst as an LSA1
/// image — the "save anywhere, instantly" primitive. Returns 0 on success,
/// -1 if the buffer is too small.
export fn lila_snapshot_save(dst: [*]u8, len: usize) i32 {
    if (len < 44 + @as(usize, c.MEM_SIZE)) return -1;
    const out = dst[0 .. 44 + c.MEM_SIZE];
    @memset(out[0..44], 0);
    std.mem.writeInt(u32, out[0..4], tt.SNAP_MAGIC, .little);
    std.mem.writeInt(u32, out[4..8], tt.SNAP_VERSION, .little);
    std.mem.writeInt(u32, out[8..12], c.rd32(c.ADDR_FRAME), .little);
    std.mem.writeInt(u32, out[12..16], c.MEM_SIZE, .little);
    std.mem.writeInt(u64, out[16..24], engine.computeSchemaSig(), .little);
    std.mem.writeInt(u32, out[24..28], c.spawn_denied_total, .little);
    std.mem.writeInt(u32, out[28..32], c.stream_drop_total, .little);
    std.mem.writeInt(u32, out[32..36], c.sram_dirty, .little);
    @memcpy(out[44..], c.mem[0..]);
    return 0;
}

/// Restore an LSA1 image (another memcpy back + interpreter reset).
/// Returns the stored frame number (>= 0), or -1 if rejected.
export fn lila_snapshot_load(src: [*]const u8, len: usize) i32 {
    const image = src[0..len];
    const f = tt.deserializeInto(image) catch return -1;
    return @intCast(f);
}

// ---------------- memory bridge ----------------

/// Direct pointer to the flat engine memory. READ by convention; the
/// sanctioned host-writable words are input (0x00) and camera (0x54..0x6C).
export fn lila_mem_ptr() [*]u8 {
    return &c.mem;
}
export fn lila_mem_size() usize {
    return c.MEM_SIZE;
}

/// Read a 32-bit word at an engine address (see the address map in lila.h).
export fn lila_read32(addr: u32) i32 {
    return @bitCast(c.rd32(addr));
}

/// Write a 32-bit word at an engine address. For host-fed state ONLY
/// (input, camera, scene). Writing simulation words diverges recorded
/// timelines — deterministic, but no longer the same movie.
export fn lila_write32(addr: u32, v: i32) void {
    c.wr32(addr, @bitCast(v));
}

// ---------------- render stream (path A: render the game's draws) -------

/// Pointer to the vertex stream filled by this frame's draw fns:
/// count x 14-byte verts (i16 x, i16 y, u16 uv, u32 rgba, u16 token),
/// screen-space pixels. Rasterized by the runner/wasm host; a Unity or
/// Unreal host can turn the same records into quads/meshes instead.
export fn lila_stream_ptr() [*]const u8 {
    return c.mem[c.ADDR_STREAM + 4 ..].ptr;
}
export fn lila_stream_count() i32 {
    return @intCast(c.rd32(c.ADDR_STREAM));
}

// ---------------- v17.2 host services (hostopt.zig) ----------------

/// Batched feed for instanced rendering: the same verts, grouped by token,
/// stable within groups, batches in first-appearance (painter) order.
/// *out_count == 0 -> fall back to the raw stream above.
export fn lila_stream_batches(out_count: *i32) [*]const hostopt.CBatch {
    return hostopt.streamBatches(out_count);
}
export fn lila_stream_sorted_ptr() [*]const u8 {
    return hostopt.streamSortedPtr();
}

/// Delta snapshots vs a full LSA1 base: lila_delta_save encodes only the
/// changed words (+ host scalars); lila_delta_load reconstructs through
/// the same verified LSA1 path. Returns bytes written / frame or -1.
export fn lila_delta_max() usize {
    return hostopt.deltaMax();
}
export fn lila_delta_save(base: [*]const u8, base_len: usize, dst: [*]u8, dst_len: usize) usize {
    return hostopt.deltaSave(base, base_len, dst, dst_len);
}
export fn lila_delta_load(base: [*]const u8, base_len: usize, delta: [*]const u8, delta_len: usize) i32 {
    return hostopt.deltaLoad(base, base_len, delta, delta_len);
}

/// Built-in history ring: opt-in recorder + instant rewind. Frames are
/// delta-captured as they run; seek restores and truncates the future
/// (GGPO semantics). An external snapshot_load is detected (counter jump)
/// and the ring restarts cleanly.
// ---------------- v19: execution-as-data (tables) ----------------
// The host owns the forgepack bytes (it already parses them for graphics);
// these two exports let it hand the TBL1 sections to the VM. Install AFTER
// lila_init, BEFORE the first lila_frame. The values are baked by the real
// VM on first use — there is no second implementation of the game's logic
// anywhere. Returns the installed table count (negative = error; -6 means
// the pack was forged for a different cartridge).

export fn lila_tables_install(pack: [*]const u8, len: usize) i32 {
    return tables.installPack(pack[0..len]);
}

/// Aggregate table telemetry (hits/misses/spot-checks/mismatches) for
/// dashboards and tests. OUTSIDE the hashed memory — diagnostics only.
export fn lila_tables_stats(out_hits: *u64, out_misses: *u64, out_spot_checks: *u64, out_mismatches: *u64, out_active: *u32) void {
    const s = tables.stats();
    out_hits.* = s.hits;
    out_misses.* = s.misses;
    out_spot_checks.* = s.spot_checks;
    out_mismatches.* = s.spot_mismatches;
    out_active.* = s.active;
}

export fn lila_history_start(frames: u32) i32 {
    return hostopt.historyStart(frames);
}
export fn lila_history_stop() void {
    hostopt.historyStop();
}
export fn lila_history_begin() i32 {
    return hostopt.historyBegin();
}
export fn lila_history_frames() i32 {
    return hostopt.historyFrames();
}
export fn lila_history_seek(frame: u32) i32 {
    return hostopt.historySeek(frame);
}

/// Sprite manifest (Path B asset discovery): the loader's sprite table,
/// same 14B vert layout as the render stream. Build placeholder
/// meshes/textures from these at boot — per game, no game-specific code.
export fn lila_sprite_count() i32 {
    return hostopt.spriteCount();
}
export fn lila_sprite_vert_count(i: u32) i32 {
    return hostopt.spriteVertCount(i);
}
export fn lila_sprite_verts(i: u32) ?[*]const u8 {
    return hostopt.spriteVerts(i);
}

// ---------------- audio ----------------

/// Pull up to `len` i16 PCM samples (call with 735 = 44100/60 per frame,
/// AFTER lila_frame, to keep audio phase on the hash chain). Returns the
/// number of samples written.
export fn lila_audio_fill(dst: [*]i16, len: usize) usize {
    if (len == 0) return 0;
    const n: usize = @min(len, 16384);
    return audio.pull(dst[0..n]);
}

// ---------------- entity bridge (path B: read tables, drive transforms) ---

export fn lila_entity_types() i32 {
    return @intCast(c.n_entities);
}
export fn lila_entity_count(t: u32) i32 {
    return @intCast(ent.count(t));
}
export fn lila_live_ents() i32 {
    var n: i32 = 0;
    var t: u32 = 0;
    while (t < c.n_entities) : (t += 1) n += @intCast(ent.count(t));
    return n;
}

/// Typed-field registry (see SPEC.md): the schema of every entity field
/// plus globals. ent == 0xFF marks a global.
export fn lila_tf_count() i32 {
    return @intCast(c.n_tfs);
}
export fn lila_tf_ent(tf: u32) i32 {
    return @intCast(c.tfEnt(tf));
}
/// Byte offset of the field inside its entity's 32-byte dense row.
export fn lila_tf_off(tf: u32) i32 {
    return @intCast(c.tfOff(tf));
}
/// Field width in bits.
export fn lila_tf_bits(tf: u32) i32 {
    return @intCast(c.tfBits(tf));
}
/// Value type code (0 = fixed Q24.8, per SPEC.md typed-field registry).
export fn lila_tf_vt(tf: u32) i32 {
    return @intCast(c.tfVt(tf));
}
/// 1 if the field lives in the cold row (8B stride) instead of dense.
export fn lila_tf_cold(tf: u32) i32 {
    return @intCast(c.tfCold(tf));
}

/// Walk live slots of a type: returns the next live index >= from, or -1.
/// Pair with lila_gen to build stable handles.
export fn lila_next_live(t: u32, from: u32) i32 {
    const idx = ent.nextLive(t, from);
    return if (idx == 0xFFFFFFFF) -1 else @intCast(idx);
}
export fn lila_gen(t: u32, idx: u32) i32 {
    return @intCast(ent.genOf(t, idx));
}

/// handle = (gen << 20) | idx — the entity's identity across respawns.
export fn lila_make_handle(gen: u32, idx: u32) u32 {
    return (gen << 20) | idx;
}

/// Read/write a typed field of entity `handle` (the engine's own accessors —
/// no duplicated address math). Writes are game-visible next frame.
export fn lila_field_read(tf: u32, handle: u32) i32 {
    return ent.fieldLoad(tf, handle);
}
export fn lila_field_write(tf: u32, handle: u32, v: i32) void {
    ent.fieldStore(tf, handle, v);
}

/// Read/write a global (tf with ent == 0xFF) — score, lives, wave, ...
export fn lila_global_read(tf: u32) i32 {
    return ent.globalLoad(tf);
}
export fn lila_global_write(tf: u32, v: i32) void {
    ent.globalStore(tf, v);
}

// ---------------- v23 / ABI 5: pointer overlays (zero-copy) --------------
//
// The host allocates the entity arrays itself (TArray / NativeArray /
// malloc — the LilaXRow structs lilac --emit-bridges generates) and hands
// us the raw pointer. Every tick we scatter the live dense rows straight
// into that memory, in place: no marshalling, no per-field FFI calls,
// nothing for the C# GC to track. Row i mirrors entity slot i; bit0 of
// lila_meta = alive (CHECK IT before reading lanes — dead rows keep stale
// lane bytes); bits 4..15 = slot generation.

/// The loaded cartridge's interop layout hash — compare against
/// LILA_INTEROP_LAYOUT_HASH in the generated LilaInterop.h / .cs.
export fn lila_overlay_layout_hash() u32 {
    return overlay.layoutHash();
}

/// Interop row size in bytes for entity type t (lila_meta included).
export fn lila_overlay_row_bytes(t: u32) i32 {
    return overlay.rowBytes(t);
}

/// Register a host buffer as type t's mirror surface. stride may exceed the
/// row size (embed the row in a bigger host struct); cap = rows allocated.
/// 0 ok; -1 bad type; -2 layout hash mismatch (REGENERATE the interop
/// files); -3 stride < row size; -4 cap > MAX_ENT.
export fn lila_overlay_install(t: u32, ptr: [*]u8, stride: u32, cap: u32, layout_hash: u32) i32 {
    return overlay.install(t, ptr, stride, cap, layout_hash);
}

/// Flush every installed overlay NOW. Read-only on engine memory — the
/// hash chain, snapshots and rollback are untouched by construction.
export fn lila_overlay_flush() void {
    overlay.flushAll();
}

/// One tick + flush (lila_input_set BEFORE this, as with lila_frame).
export fn lila_overlay_tick() void {
    hostopt.historyTick();
    engine.frame();
    overlay.flushAll();
}

/// The one-call pointer-overlay pipeline (single-type games): point type 0
/// at host_ptr (entity_count rows, canonical stride) and run one full frame
/// with the flush built in. Multi-type games: install per type, then
/// lila_overlay_tick / lila_overlay_flush.
export fn lila_tick_pipeline(host_ptr: ?[*]u8, entity_count: u32) void {
    if (host_ptr) |p| _ = overlay.retarget0(p, entity_count);
    hostopt.historyTick();
    engine.frame();
    overlay.flushAll();
}

/// Rows written by the last flush (diagnostics). -1 = bad type.
export fn lila_overlay_written(t: u32) i32 {
    return overlay.written(t);
}

/// Spawn entities of type t from host interop rows (the import path —
/// boot/level loads): floats quantize through the lila_f_to_q truncation
/// here, so the result is bit-identical to host-fed lila_field_write
/// spawns. Returns the number spawned; -1 = bad type.
export fn lila_overlay_spawn_from(t: u32, ptr: [*]const u8, count: u32) i32 {
    return overlay.spawnFrom(t, ptr, count);
}

// ---------------- SRAM persistence ----------------

/// 256-byte battery-backed block. Copy saved bytes here BEFORE lila_init
/// (init's zeroing pass skips this range). Poll lila_sram_dirty each frame.
export fn lila_sram_ptr() [*]u8 {
    return c.mem[c.ADDR_SRAM ..].ptr;
}
export fn lila_sram_size() usize {
    return c.SRAM_BYTES;
}
export fn lila_sram_dirty() i32 {
    if (c.sram_dirty != 0) {
        c.sram_dirty = 0;
        return 1;
    }
    return 0;
}

// ---------------- build profile + diagnostics ----------------

export fn lila_cap_types() i32 {
    return @intCast(c.MAX_TYPES);
}
export fn lila_cap_ent() i32 {
    return @intCast(c.MAX_ENT);
}
export fn lila_cap_verts() i32 {
    return @intCast(c.MAX_VERTS);
}
export fn lila_cap_instr() i32 {
    return @intCast(c.MAX_INSTR);
}
/// Screen (viewport) size this game declared.
export fn lila_screen_w() i32 {
    return @intCast(c.game_w);
}
export fn lila_screen_h() i32 {
    return @intCast(c.game_h);
}
/// Simulation bounds (== screen when the game declared no larger world).
export fn lila_world_w() i32 {
    return @intCast(c.game_world_w);
}
export fn lila_world_h() i32 {
    return @intCast(c.game_world_h);
}
export fn lila_last_error() i32 {
    return c.last_error;
}
export fn lila_stream_dropped() i32 {
    return @intCast(c.stream_drop_total);
}
export fn lila_spawn_denied() i32 {
    return @intCast(c.spawn_denied_total);
}

// ============================================================================
// v23 STEP 6: DEBUGGER + PROFILER BRIDGE
// ============================================================================
//
// Exposes the lila_debug.zig module via the C ABI. The host (Unity Editor,
// Unreal Insights, VS Code debugger) consumes these to provide interactive
// debugging + profiling of LILA code alongside the host's own debugger.
//
// Determinism boundary: breakpoints and inspection are READ-ONLY on engine
// memory — they don't touch the hash chain. The lila_write_local/global
// functions DO touch the hash chain (the host is responsible — typically
// only used in debug builds).
//
// See runtime/src/lila_debug.zig for the implementation.

const debug = @import("lila_debug.zig");

// ---- Breakpoints ----

/// Set a breakpoint at (fn_idx, pc_offset). Returns bp_id (>0) or -1.
export fn lila_set_breakpoint(fn_idx: i32, pc: i32) i32 {
    if (fn_idx < 0 or pc < 0) return -1;
    return debug.set_breakpoint(@intCast(fn_idx), @intCast(pc));
}

/// Clear a breakpoint by id. Returns 0 on success, -1 if not found.
export fn lila_clear_breakpoint(bp_id: i32) i32 {
    return debug.clear_breakpoint(bp_id);
}

/// Clear all breakpoints (e.g., on hot-swap).
export fn lila_clear_all_breakpoints() void {
    debug.clear_all_breakpoints();
}

/// Check if the current (fn_idx, pc) hits a breakpoint. The VM calls
/// this from its step loop. Returns 1 if the host should pause, 0 otherwise.
export fn lila_check_breakpoint_hit(fn_idx: i32, pc: i32) i32 {
    if (fn_idx < 0 or pc < 0) return 0;
    return if (debug.check_breakpoint_hit(@intCast(fn_idx), @intCast(pc))) 1 else 0;
}

// ---- Inspection (read engine memory) ----

/// Read a local variable from the current frame. slot is the u8 operand
/// of OP_LD_LOCAL. Returns 0 if out of range.
export fn lila_inspect_local(slot: i32) i32 {
    if (slot < 0 or slot > 255) return 0;
    return debug.inspect_local(@intCast(slot));
}

/// Write a local variable in the current frame. Affects the hash chain.
export fn lila_write_local(slot: i32, value: i32) void {
    if (slot < 0 or slot > 255) return;
    debug.write_local(@intCast(slot), value);
}

/// Read a global variable. offset is the u16 operand of OP_LD_GLBL.
export fn lila_inspect_global(offset: i32) i32 {
    if (offset < 0 or offset > 65535) return 0;
    return debug.inspect_global(@intCast(offset));
}

/// Write a global variable. Affects the hash chain.
export fn lila_write_global(offset: i32, value: i32) void {
    if (offset < 0 or offset > 65535) return;
    debug.write_global(@intCast(offset), value);
}

// ---- Chrome tracing event emission (for host profiler) ----

/// Trace event callback signature: void (*)(i32 kind, const char* name, u64 ts_ns)
/// kind: 0=begin, 1=end, 2=instant
/// The host registers a callback; the VM emits events at fn entry/exit.
pub const TraceCallback = *const fn (kind: i32, name_ptr: [*]const u8, name_len: usize, ts_ns: u64) void;

var trace_cb: ?TraceCallback = null;

/// Set the trace callback (null to disable).
export fn lila_trace_set_callback(cb: ?TraceCallback) void {
    trace_cb = cb;
    debug.set_trace_callback(if (cb != null) struct {
        fn wrap(ev: debug.TraceEvent) void {
            if (trace_cb) |live| live(@intFromEnum(ev.kind), &ev.name, ev.name_len, ev.ts_ns);
        }
    }.wrap else null);
}

/// Emit a trace begin event. The VM calls this at fn entry.
export fn lila_trace_begin(name_ptr: [*]const u8, name_len: usize) void {
    if (name_len == 0 or name_len > 64) return;
    var name_buf: [64]u8 = undefined;
    @memcpy(name_buf[0..name_len], name_ptr[0..name_len]);
    debug.emit_trace(.begin, name_buf[0..name_len]);
}

/// Emit a trace end event. The VM calls this at fn exit.
export fn lila_trace_end(name_ptr: [*]const u8, name_len: usize) void {
    if (name_len == 0 or name_len > 64) return;
    var name_buf: [64]u8 = undefined;
    @memcpy(name_buf[0..name_len], name_ptr[0..name_len]);
    debug.emit_trace(.end, name_buf[0..name_len]);
}

/// Emit an instant event (point-in-time marker, e.g. a scene change).
export fn lila_trace_instant(name_ptr: [*]const u8, name_len: usize) void {
    if (name_len == 0 or name_len > 64) return;
    var name_buf: [64]u8 = undefined;
    @memcpy(name_buf[0..name_len], name_ptr[0..name_len]);
    debug.emit_trace(.instant, name_buf[0..name_len]);
}

/// Drain the trace buffer (host polls this if no callback was set).
/// Returns the number of events written to out (up to out_cap).
export fn lila_trace_drain(out: [*]u8, out_cap: usize) usize {
    _ = out;
    _ = out_cap;
    // The real impl packs TraceEvent structs into the byte buffer.
    // For the v23 bridge, we return 0 — the host uses the callback form.
    return 0;
}

// ---- Step (single-instruction advance) ----

/// Advance the VM by ONE instruction. Returns the new pc, or -1 if a
/// breakpoint fires this step (host should pause). The host calls this
/// in a loop for step-by-step debugging.
export fn lila_step() i32 {
    // v23.1: real single-step — one instruction, new pc (or -1 halted).
    // The host pauses when a breakpoint fires (lila_check_breakpoint_hit /
    // debug.paused).
    const vm = @import("vm.zig");
    return vm.dbgStepOne();
}
