//! v20 DREAM — the cartridge plays itself.
//!
//! The one resource this engine has that no conventional engine does:
//! a game is a PURE, BIT-EXACT function of its input sequence, states
//! are 2MB memcpys, and every state has a wyhash identity. That turns
//! the input space into a searchable graph:
//!
//!   node  = (2MB snapshot, frame index)     — memcpy-cheap to clone
//!   edge  = one u32 input mask              — one engine.frame(), ~86us
//!   goal  = maximize a global (the "score") and maximize branch coverage
//!
//! So the DREAM pass is a graph search over game states — Jaffar-style
//! beam search for breadth, (1+1)-ES macro-mutations for depth — where
//! every explored edge is a REAL simulated frame on the REAL VM. The
//! outputs are ordinary engine artifacts:
//!
//!   <out>.lir1      a movie that replays on the vanilla runner (the
//!                   hash chain proves the search's timeline is legal)
//!   <out>.lir1z     the same movie entropy-coded to its measured
//!                   Shannon floor (movie_codec.zig)
//!   <out>.dreammap  branch-exact evidence for `lilac dreamtrace`
//!
//! Unity cannot do this (no bit-exact snapshot, no determinism). We do
//! it with @memcpy. The attract mode, the QA corpus and the coverage
//! evidence are all FOUND, not scripted.
//!
//! Determinism of the tool itself: seeded host-side PRNG (never touches
//! the hashed image), fixed candidate/evaluation orders, a total-order
//! selection key (novelty, reward, parent slot, mask), and a closed set
//! keyed by the state hash. Same cartridge + same seed => byte-identical
//! artifacts, forever. The runner's --replay is the external proof that
//! whatever the dream found is a legal timeline.
//!
//! Memory model: an arena. The search never frees; peak use is bounded
//! by construction: 2 x beam x 2MB state pools (double-buffered so a
//! level's child captures can never clobber a live parent state) plus
//! per-level movie dupes (O(beam x horizon^2 / 2) u32s, a few MB).

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const audio = @import("audio.zig");
const tt = @import("timetravel.zig");
const vm = @import("vm.zig");
const cover = @import("cover.zig");
const codec = @import("movie_codec.zig");

const SPF: u32 = 44100 / 60; // samples pulled per frame (the movie contract)
const MAX_BEAM: usize = 32;
const MAX_CANDS: usize = 40; // idle + momentum + <=32 singles + randoms

pub const Error = error{
    NoGlobals, // reward needs at least one declared global
    BadSpec, // parse/logic error (message printed by the caller)
    OutOfMemory,
};

pub const Spec = struct {
    reward_global: u32 = 0, // global ordinal (declaration order)
    minimize: bool = false,
    reward_target: ?i32 = null, // stop early when reached
    horizon: u32 = 300,
    beam: u32 = 8,
    budget: u64 = 24_000, // total simulated frames (the real cost unit)
    explore_pct: u32 = 60, // % of budget for the beam phase
    seed: u64 = 7,
    random_masks: u32 = 2, // seeded random combos per cell per level
};

/// Parse a .dream spec. One `key value(s)` per line, `#` comments.
/// Unknown keys are loud errors, not silent ignores.
pub fn parseSpec(text: []const u8) Error!Spec {
    var s = Spec{};
    var it = std.mem.tokenizeScalar(u8, text, '\n');
    while (it.next()) |raw| {
        const line = std.mem.trim(u8, raw, " \r\t");
        if (line.len == 0 or line[0] == '#') continue;
        var tk = std.mem.tokenizeScalar(u8, line, ' ');
        const key = tk.next() orelse continue;
        const nextTk = struct {
            fn f(t: *std.mem.TokenIterator(u8, .scalar)) Error![]const u8 {
                return t.next() orelse Error.BadSpec;
            }
        }.f;
        if (std.mem.eql(u8, key, "reward")) {
            // reward global <ordinal> max|min [target <v>]
            const what = try nextTk(&tk);
            if (!std.mem.eql(u8, what, "global")) return Error.BadSpec;
            s.reward_global = std.fmt.parseInt(u32, try nextTk(&tk), 10) catch return Error.BadSpec;
            const dir = tk.next() orelse "max";
            if (std.mem.eql(u8, dir, "min")) s.minimize = true;
            const maybe_t = tk.next();
            if (maybe_t != null and std.mem.eql(u8, maybe_t.?, "target")) {
                s.reward_target = std.fmt.parseInt(i32, try nextTk(&tk), 10) catch return Error.BadSpec;
            }
        } else if (std.mem.eql(u8, key, "horizon")) {
            s.horizon = std.fmt.parseInt(u32, try nextTk(&tk), 10) catch return Error.BadSpec;
        } else if (std.mem.eql(u8, key, "beam")) {
            s.beam = std.fmt.parseInt(u32, try nextTk(&tk), 10) catch return Error.BadSpec;
        } else if (std.mem.eql(u8, key, "budget")) {
            s.budget = std.fmt.parseInt(u64, try nextTk(&tk), 10) catch return Error.BadSpec;
        } else if (std.mem.eql(u8, key, "explore")) {
            s.explore_pct = std.fmt.parseInt(u32, try nextTk(&tk), 10) catch return Error.BadSpec;
        } else if (std.mem.eql(u8, key, "seed")) {
            s.seed = std.fmt.parseInt(u64, try nextTk(&tk), 10) catch return Error.BadSpec;
        } else return Error.BadSpec;
    }
    if (s.beam == 0 or s.beam > MAX_BEAM) return Error.BadSpec;
    if (s.horizon == 0 or s.horizon > 100_000) return Error.BadSpec;
    if (s.budget == 0) return Error.BadSpec;
    if (s.explore_pct > 100) return Error.BadSpec;
    if (s.random_masks > 4) return Error.BadSpec;
    return s;
}

pub const Stats = struct {
    frames_simulated: u64 = 0,
    wall_ns: u64 = 0,
    distinct_states: u32 = 0,
    levels_reached: u32 = 0,
    explore_children: u64 = 0,
    hill_rollouts: u32 = 0,
    hill_accepts: u32 = 0,
    best_reward: i32 = 0,
    coverage_slots: u32 = 0,
    sites: cover.SiteStats = .{ .sites = 0, .both = 0, .one = 0 },
    entropy_q16: u64 = 0, // winning movie: the model's Shannon floor
    lir1_bytes: usize = 0,
    liz1_bytes: usize = 0,
    used_buttons: u32 = 0,
};

pub const Result = struct {
    /// Winning input sequence (frames 0..n-1).
    movie: []const u32,
    /// Per-frame state hashes — the LIR1 chain (replay-verifiable).
    hashes: []u64,
    /// Complete LIZ1 image (entropy-coded movie).
    liz1: []u8,
    /// Complete DRM1 image (branch evidence) — empty if it did not fit.
    dreammap: []u8,
    stats: Stats,
};

// ---------------- scaffolding ----------------

/// A generation cell: a live candidate timeline.
const Cell = struct {
    movie: []const u32,
    mem: []const u8, // state image (aliases a pool buffer or the boot image)
    scalars: tt.Scalars,
    reward: i32,
};

/// One candidate child during a beam level. Selection key (total order):
/// reward-better, novelty desc, continuation (momentum) first, parent
/// asc, mask asc — unique per surviving child. Reward leads (the beam
/// climbs score gradients); novelty breaks reward ties; and when both
/// tie — the sparse-reward regime — CONTINUATION outranks switching, so
/// a lineage that commits to a direction keeps its beam slot instead of
/// being crowded out by idle siblings (the classic all-zero-reward beam
/// collapse: without this, the beam re-expands the idle parent forever
/// and never travels anywhere). Per-parent caps (see POOL_PER_PARENT)
/// keep one lineage from flooding the beam with its own siblings.
const Child = struct {
    nov: u32,
    reward: i32,
    cont: bool, // is this the parent's momentum (same mask held)?
    parent: u16,
    mask: u32,
    h: u64,
    buf: u8, // pool buffer index (assigned on placement)
};

/// Children kept per parent in the selection pool. 8 (= the demo beam
/// width) means the FIRST level (one parent) keeps every direction in
/// the beam — the direction portfolio that momentum then sustains — and
/// a rewarded lineage can concentrate to fill the whole beam. The flat
/// top-K selection rebalances: after concentration, the winner's
/// children (diverse directions around the collected state) become the
/// next generation's parents and the portfolio re-forms around them.
const POOL_PER_PARENT: usize = 8;

/// Closed set of visited state hashes: open addressing, linear probing,
/// membership only — never iterated, so it cannot leak order into the
/// search. Keys are already wyhash outputs (0 reserved as the marker).
const Seen = struct {
    slots: []u64,
    mask: usize,
    n: u32,

    fn init(alloc: std.mem.Allocator) Error!Seen {
        const cap: usize = 1 << 18; // 262,144 slots = 2MB
        const slots = try alloc.alloc(u64, cap);
        @memset(slots, 0);
        return .{ .slots = slots, .mask = cap - 1, .n = 0 };
    }

    fn has(self: *const Seen, k: u64) bool {
        var i: usize = @intCast(k & self.mask);
        while (true) {
            const v = self.slots[i];
            if (v == 0) return false;
            if (v == k) return true;
            i = (i + 1) & self.mask;
        }
    }

    /// True if newly inserted (false = already seen).
    fn insert(self: *Seen, k: u64) bool {
        if (k == 0) return false;
        var i: usize = @intCast(k & self.mask);
        while (true) {
            const v = self.slots[i];
            if (v == 0) {
                self.slots[i] = k;
                self.n += 1;
                return true;
            }
            if (v == k) return false;
            i = (i + 1) & self.mask;
        }
    }
};

/// The whole search. One instance per run; everything lives on the arena.
const Dream = struct {
    spec: Spec,
    reward_tf: u32,
    used_buttons: u32,
    rng: std.Random.DefaultPrng,
    seen: Seen,
    boot: tt.Snapshot, // full post-init state (mem + scalars)
    budget_left: u64,
    stats: Stats,

    fn better(self: *const Dream, a: i32, b: i32) bool {
        if (self.spec.minimize) return a < b;
        return a > b;
    }

    fn reached(self: *const Dream, a: i32, t: i32) bool {
        return a == t or self.better(a, t);
    }

    /// One contract frame: input -> frame -> audio pull -> state hash.
    /// Byte-for-byte the --replay path; that is the point.
    fn advance(self: *Dream, mask: u32, frame: u32) u64 {
        self.stats.frames_simulated += 1;
        self.budget_left -|= 1;
        c.wr32(c.ADDR_INPUT, mask);
        engine.frame();
        var sink: [SPF]i16 = undefined;
        _ = audio.pull(&sink);
        return tt.stateHash(frame);
    }

    fn reward(self: *const Dream) i32 {
        return ent.globalLoad(self.reward_tf);
    }

    fn randomUsedMask(self: *Dream) u32 {
        return self.rng.random().int(u32) & self.used_buttons;
    }
};

/// Nth global typed field (declaration order), mirroring the runner's
/// firstGlobalTf pattern. Errors when the game declares no globals.
fn nthGlobalTf(ordinal: u32) Error!u32 {
    var tf: u32 = 0;
    var n: u32 = 0;
    while (tf < c.n_tfs) : (tf += 1) {
        if (c.tfEnt(tf) == 0xFF) {
            if (n == ordinal) return tf;
            n += 1;
        }
    }
    return Error.NoGlobals;
}

/// Scan the decoded code for OP_KEY / OP_KEY_EDGE operands: the buttons
/// this cartridge actually reads. The dream does not press buttons that
/// do not exist — it learned them from the bytecode.
fn usedKeyBits() u32 {
    var bits: u32 = 0;
    var pc: u32 = 0;
    while (pc < c.instr_count) : (pc += 1) {
        const op = c.iOp(pc);
        if (op == c.OP_KEY or op == c.OP_KEY_EDGE) {
            const k: u5 = @intCast(@as(u32, @bitCast(c.iA(pc))) & 31);
            bits |= @as(u32, 1) << k;
        }
    }
    return bits;
}

/// Place a child into its parent's bounded bucket (top-POOL_PER_PARENT per
/// parent). Pure record-keeping — states are re-derived at commit time.
fn placeChild(d: *const Dream, level: u32, pool: *[MAX_BEAM][POOL_PER_PARENT]Child, pool_n: *[MAX_BEAM]usize, child: Child) void {
    const p = child.parent;
    const n = pool_n[p];
    if (n < POOL_PER_PARENT) {
        pool[p][n] = child;
        pool_n[p] = n + 1;
        return;
    }
    // full: replace the worst slot if the child outranks it
    const worst: usize = if (ranksAfter(d, pool[p][0], pool[p][1], level)) 0 else 1;
    if (ranksAfter(d, child, pool[p][worst], level)) return; // worse than both
    pool[p][worst] = child;
}

/// Deterministic per-level pseudo-random tie key. When reward AND
/// novelty AND continuation are all flat (the sparse-reward regime), any
/// fixed structural order (parent index, mask bits) is adversarial for
/// SOME game — the beam would explore only the smallest-mask directions
/// forever. A seeded hash of (mask, level) instead gives every direction
/// a fair, reproducible shuffle that changes each level: the beam becomes
/// a portfolio of drifting lineages instead of a corner case.
fn tieKey(mask: u32, level: u32, seed: u64) u32 {
    var h = std.hash.Wyhash.init(seed ^ (@as(u64, level) << 32));
    h.update(std.mem.asBytes(&mask));
    return @truncate(h.final());
}

/// True when `a` ranks strictly after (worse than) `b` under the total
/// order: reward-better, novelty desc, continuation, seeded tie key,
/// parent asc, mask asc.
fn ranksAfter(d: *const Dream, a: Child, b: Child, level: u32) bool {
    if (a.reward != b.reward) return d.better(b.reward, a.reward);
    if (a.nov != b.nov) return a.nov < b.nov;
    if (a.cont != b.cont) return !a.cont;
    const ta = tieKey(a.mask, level, d.spec.seed);
    const tb = tieKey(b.mask, level, d.spec.seed);
    if (ta != tb) return ta > tb; // lower key ranks first
    if (a.parent != b.parent) return a.parent > b.parent;
    return a.mask < b.mask;
}

fn dupeMovie(alloc: std.mem.Allocator, parent: []const u32, mask: u32) Error![]u32 {
    const out = try alloc.alloc(u32, parent.len + 1);
    @memcpy(out[0..parent.len], parent);
    out[parent.len] = mask;
    return out;
}

/// Macro-mutation of the elite. Operators act on SPANS of frames —
/// delayed-commit strategies (hold right 40 frames, then fire) survive
/// because mutations preserve spans, not single buttons.
fn mutate(d: *Dream, alloc: std.mem.Allocator, elite: []const u32, hist: []const []u32) Error![]u32 {
    const rnd = d.rng.random();
    const child = try alloc.dupe(u32, elite);
    const n = elite.len;
    if (n == 0) return child;
    const op = rnd.uintLessThanBiased(u3, 5);
    const nbits: u32 = @intCast(@popCount(d.used_buttons));
    switch (op) {
        0 => { // flip one used button at one random frame
            if (nbits > 0) {
                const f = rnd.uintLessThanBiased(u32, @intCast(n));
                child[f] ^= pickBit(d.used_buttons, rnd.uintLessThanBiased(u5, @intCast(nbits)));
            }
        },
        1 => { // zero a span (release everything — dodge, wait)
            const span = 1 + rnd.uintLessThanBiased(u32, @intCast(@max(40, n / 3)));
            const a = rnd.uintLessThanBiased(u32, @intCast(n));
            const b = @min(n, a + span);
            @memset(child[a..b], 0);
        },
        2 => { // hold a random used mask over a span (commit to a move)
            const span = 1 + rnd.uintLessThanBiased(u32, @intCast(@max(60, n / 3)));
            const a = rnd.uintLessThanBiased(u32, @intCast(n));
            const b = @min(n, a + span);
            const m = d.randomUsedMask();
            @memset(child[a..b], m);
        },
        3 => { // splice a span from a past elite (crossover memory)
            if (hist.len > 0 and n > 8) {
                const src = hist[rnd.uintLessThanBiased(u32, @intCast(hist.len))];
                const a = rnd.uintLessThanBiased(u32, @intCast(n));
                const span = 1 + rnd.uintLessThanBiased(u32, @intCast(@min(n - a, src.len)));
                const b = @min(n, a + span);
                var i = a;
                while (i < b) : (i += 1) child[i] = src[i % src.len];
            }
        },
        4 => { // punch one frame to a random used mask (timing nudge)
            const f = rnd.uintLessThanBiased(u32, @intCast(n));
            child[f] = d.randomUsedMask();
        },
        else => {},
    }
    return child;
}

fn pickBit(bits: u32, ordinal: u5) u32 {
    var b = bits;
    var k: u5 = 0;
    while (true) : (k += 1) {
        const low: u5 = @intCast(@ctz(b));
        if (k == ordinal) return @as(u32, 1) << low;
        b &= b - 1;
    }
}

// ---------------- the search ----------------

/// Run the dream on an ALREADY-INITIALIZED engine (the runner — or a
/// test — loads the cartridge and calls engine.init first).
pub fn run(alloc: std.mem.Allocator, spec: Spec) Error!Result {
    const t0 = engine.nowNs();
    const reward_tf = try nthGlobalTf(spec.reward_global);

    engine.threads_enabled = false; // one writer for cover; sequential = deterministic
    cover.reset();
    cover.on = true;
    defer cover.on = false;

    var d = Dream{
        .spec = spec,
        .reward_tf = reward_tf,
        .used_buttons = usedKeyBits(),
        .rng = std.Random.DefaultPrng.init(spec.seed),
        .seen = try Seen.init(alloc),
        .boot = try tt.Snapshot.capture(alloc, 0),
        .budget_left = spec.budget,
        .stats = .{},
    };
    d.boot.scalars = tt.readScalars(); // the hash covers scalars too
    d.stats.used_buttons = d.used_buttons;

    // candidate masks: idle, momentum, one per used button, random combos
    var fixed: [MAX_CANDS]u32 = undefined;
    var n_fixed: usize = 0;
    fixed[n_fixed] = 0;
    n_fixed += 1;
    {
        var b = d.used_buttons;
        while (b != 0) {
            const low: u5 = @intCast(@ctz(b));
            fixed[n_fixed] = @as(u32, 1) << low;
            n_fixed += 1;
            b &= b - 1;
        }
    }
    if (n_fixed + spec.random_masks > MAX_CANDS) return Error.BadSpec;

    // ---- state pools: double-buffered so level N's child captures can
    // never clobber a level-(N-1) parent state still awaiting evaluation.
    const K: usize = @intCast(spec.beam);
    var bufs: [2][MAX_BEAM][]u8 = undefined;
    for (&bufs) |*half| {
        for (half[0..K]) |*bb| bb.* = try alloc.alloc(u8, c.MEM_SIZE);
    }

    var cells: [MAX_BEAM]Cell = undefined;
    var n_cells: usize = 1;
    cells[0] = .{ .movie = &.{}, .mem = d.boot.mem, .scalars = d.boot.scalars, .reward = d.reward() };

    var explore_frames: u64 = spec.budget * spec.explore_pct / 100;

    // ---- EXPLORE: beam over frames, selected on (reward, novelty) ----
    // Two passes per level: pass 1 evaluates every candidate from its
    // parent's state and keeps per-parent RECORDS (top-2 by rank — no
    // state buffers needed); pass 2 re-derives only the selected
    // children's states. The re-derivation is bit-exact by determinism
    // (and guarded by a hash assert).
    var level: u32 = 0;
    explore: while (level < spec.horizon and d.budget_left > 0 and explore_frames > 0) : (level += 1) {
        const half = level % 2; // state buffers alternate by level parity
        const filled_start = cover.filled;
        var pool: [MAX_BEAM][POOL_PER_PARENT]Child = undefined;
        var pool_n: [MAX_BEAM]usize = [_]usize{0} ** MAX_BEAM;
        var any_new = false;

        var ci: usize = 0;
        while (ci < n_cells) : (ci += 1) {
            const cell = cells[ci];
            const prev: u32 = if (level > 0) cell.movie[level - 1] else 0;

            // candidate list for this cell: fixed + momentum + randoms
            var cands: [MAX_CANDS]u32 = undefined;
            var n_c: usize = 0;
            for (fixed[0..n_fixed]) |m| {
                cands[n_c] = m;
                n_c += 1;
            }
            if (prev != 0) { // momentum: keep holding what you held
                cands[n_c] = prev;
                n_c += 1;
            }
            var r: u32 = 0;
            while (r < spec.random_masks) : (r += 1) {
                const m = d.randomUsedMask();
                var dup = false;
                for (cands[0..n_c]) |x| {
                    if (x == m) {
                        dup = true;
                        break;
                    }
                }
                if (!dup) {
                    cands[n_c] = m;
                    n_c += 1;
                }
            }

            for (cands[0..n_c]) |mask| {
                // every candidate advances FROM THE PARENT STATE — the
                // restore is per-candidate, never per-cell (children that
                // share a prefix must not accumulate).
                @memcpy(c.mem[0..], cell.mem);
                tt.writeScalars(cell.scalars);
                vm.resetVm();
                const h = d.advance(mask, level);
                explore_frames -|= 1;
                const last = d.budget_left == 0 or explore_frames == 0;
                if (!d.seen.has(h)) {
                    _ = d.seen.insert(h);
                    any_new = true;
                    placeChild(&d, level, &pool, &pool_n, .{
                        .nov = cover.filled - filled_start,
                        .reward = d.reward(),
                        .cont = mask == prev,
                        .parent = @intCast(ci),
                        .mask = mask,
                        .h = h,
                        .buf = 0,
                    });
                }
                if (last) break :explore;
            }
        }

        if (!any_new) {
            // saturated: every child repeated a visited state. Escape with
            // random combos; give up when those repeat too.
            sat: for (0..2 * spec.random_masks + 1) |_| {
                ci = 0;
                while (ci < n_cells) : (ci += 1) {
                    const cell = cells[ci];
                    var tries: u32 = 0;
                    while (tries < 4) : (tries += 1) {
                        @memcpy(c.mem[0..], cell.mem);
                        tt.writeScalars(cell.scalars);
                        vm.resetVm();
                        const m = d.randomUsedMask();
                        const h = d.advance(m, level);
                        explore_frames -|= 1;
                        if (!d.seen.has(h)) {
                            _ = d.seen.insert(h);
                            placeChild(&d, level, &pool, &pool_n, .{
                                .nov = cover.filled - filled_start,
                                .reward = d.reward(),
                                .cont = m == cell.movie[level -| 1],
                                .parent = @intCast(ci),
                                .mask = m,
                                .h = h,
                                .buf = 0,
                            });
                            continue :sat;
                        }
                        if (d.budget_left == 0 or explore_frames == 0) break :explore;
                    }
                }
                break; // nowhere to escape — phase saturated
            }
        }

        // flatten + insertion-sort by rank (best first; keys are unique)
        var flat: [MAX_BEAM * POOL_PER_PARENT]Child = undefined;
        var n_flat: usize = 0;
        for (0..n_cells) |p| {
            for (0..pool_n[p]) |j| {
                flat[n_flat] = pool[p][j];
                n_flat += 1;
            }
        }
        if (n_flat == 0) break; // nothing survived dedup at this level
        {
            var a: usize = 1;
            while (a < n_flat) : (a += 1) {
                const key = flat[a];
                var b2: usize = a;
                while (b2 > 0 and ranksAfter(&d, flat[b2 - 1], key, level)) : (b2 -= 1) {
                    flat[b2] = flat[b2 - 1];
                }
                flat[b2] = key;
            }
        }
        const n_sel = @min(K, n_flat);

        // pass 2: re-derive the selected children from their parents
        var new_cells: [MAX_BEAM]Cell = undefined;
        var ni: usize = 0;
        while (ni < n_sel) : (ni += 1) {
            const ch = flat[ni];
            const cell = cells[ch.parent];
            @memcpy(c.mem[0..], cell.mem);
            tt.writeScalars(cell.scalars);
            vm.resetVm();
            const h2 = d.advance(ch.mask, level);
            if (h2 != ch.h) break :explore; // determinism guard (cannot happen)
            @memcpy(bufs[half][ni], c.mem[0..]);
            new_cells[ni] = .{
                .movie = try dupeMovie(alloc, cell.movie, ch.mask),
                .mem = bufs[half][ni],
                .scalars = tt.readScalars(),
                .reward = ch.reward,
            };
        }
        @memcpy(cells[0..n_sel], new_cells[0..n_sel]);
        n_cells = n_sel;
        d.stats.levels_reached = level + 1;
        d.stats.explore_children += n_sel;

        // early exit if a target is already reached by some cell
        if (spec.reward_target) |t| {
            for (cells[0..n_cells]) |cell| {
                if (d.reached(cell.reward, t)) break :explore;
            }
        }
    }

    // elite from the beam: best reward; tie -> smallest movie (fixed order)
    var elite: []const u32 = &.{};
    var elite_reward: i32 = cells[0].reward;
    {
        var bi: usize = 0;
        while (bi < n_cells) : (bi += 1) {
            if (d.better(cells[bi].reward, elite_reward)) {
                elite_reward = cells[bi].reward;
                elite = cells[bi].movie;
            }
        }
        if (elite.len == 0) elite = cells[0].movie;
    }

    // ---- HILL: (1+1)-ES with macro-mutations over the elite ----
    if (elite.len > 0) {
        var elite_buf: []u32 = try alloc.dupe(u32, elite);
        var hist: [8][]u32 = undefined;
        var hist_n: usize = 0;
        while (d.budget_left >= elite_buf.len and elite_buf.len > 0) {
            if (spec.reward_target) |t| {
                if (d.reached(elite_reward, t)) break;
            }
            const hist_slice: []const []u32 = hist[0..hist_n];
            const child = try mutate(&d, alloc, elite_buf, hist_slice);
            // full rollout from boot (a truncated rollout is discarded)
            @memcpy(c.mem[0..], d.boot.mem);
            tt.writeScalars(d.boot.scalars);
            vm.resetVm();
            for (child, 0..) |m, f| _ = d.advance(m, @intCast(f));
            const rw = d.reward();
            d.stats.hill_rollouts += 1;
            if (d.better(rw, elite_reward)) {
                if (hist_n == hist.len) {
                    alloc.free(hist[hist_n - 1]);
                    hist_n -= 1;
                }
                hist[hist_n] = elite_buf;
                hist_n += 1;
                elite_buf = child;
                elite_reward = rw;
                d.stats.hill_accepts += 1;
            } else {
                alloc.free(child);
            }
        }
        elite = elite_buf;
        for (hist[0..hist_n]) |h| alloc.free(h);
    }

    // ---- final verification rollout + artifact build ----
    const movie = elite;
    const hashes = try alloc.alloc(u64, movie.len);
    @memcpy(c.mem[0..], d.boot.mem);
    tt.writeScalars(d.boot.scalars);
    vm.resetVm();
    for (movie, 0..) |m, f| hashes[f] = d.advance(m, @intCast(f));
    if (movie.len > 0 and d.reward() != elite_reward) {
        // determinism canary: the clean rollout MUST reproduce the
        // search's reward — if not, the search state handling is broken.
        std.debug.print("dream canary: final reward {d} != elite {d} (movie {d}f, levels {d}, hill {d}/{d})\n", .{ d.reward(), elite_reward, movie.len, d.stats.levels_reached, d.stats.hill_rollouts, d.stats.hill_accepts });
        return Error.BadSpec;
    }

    const enc = try codec.encode(alloc, movie, if (movie.len > 0) hashes[movie.len - 1] else 0);
    var mapbuf: []u8 = &.{};
    if (c.instr_count <= cover.MAX_SITES) {
        mapbuf = try alloc.alloc(u8, cover.drm1Size(c.instr_count));
        if (cover.serialize(mapbuf, c.instr_count) == 0) mapbuf = &.{};
    }

    d.stats.wall_ns = engine.nowNs() -| t0;
    d.stats.distinct_states = d.seen.n;
    d.stats.best_reward = elite_reward;
    d.stats.coverage_slots = cover.filled;
    d.stats.sites = cover.siteStats(c.instr_count);
    d.stats.entropy_q16 = codec.entropyQ16(movie);
    d.stats.lir1_bytes = 8 + movie.len * 12;
    d.stats.liz1_bytes = enc.data.len;
    return .{
        .movie = movie,
        .hashes = hashes,
        .liz1 = enc.data,
        .dreammap = mapbuf,
        .stats = d.stats,
    };
}
