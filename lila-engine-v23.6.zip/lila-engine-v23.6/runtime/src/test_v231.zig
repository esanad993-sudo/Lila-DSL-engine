//! runtime/src/test_v231.zig — v23.1 feature tests: f64 (two-cell
//! convention), vec4u8 packed lanes, and try/catch/throw exception
//! semantics. The fixture cartridge (test_v231_fixture.lila) exercises
//! every path end to end; these tests assert EXACT results.
//!
//! tf map (see the fixture header): tf0 Cell.acc:f64, tf1 Cell.tag,
//! tf2 acc:f64, tf3 flag, tf4 ic, tf5 sv:vec4u8, tf6 c1, tf7 r, tf8 e,
//! tf9 gcell, tf10 g64:f64.

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");

const FIXTURE = @embedFile("test_v231_fixture.libyte");

fn frame() void {
    engine.frame();
}

test "v231: fixture loads clean" {
    const rc = engine.init(FIXTURE);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);
}

test "v231: f64 arithmetic + conversions are exact" {
    _ = engine.init(FIXTURE);
    // acc = f64(3) * 2.5 + 0.5 = 8.0 -> bits 0x4020000000000000
    try std.testing.expectEqual(@as(u64, 0x4020000000000000), ent.globalLoad64(2));
    // flag = fixed(8.0) = 2048
    try std.testing.expectEqual(@as(i32, 2048), ent.globalLoad(3));
    // ic = int(f64(1000) / 8.0) = 125
    try std.testing.expectEqual(@as(i32, 125), ent.globalLoad(4));
}

test "v231: vec4u8 pack/add/unpack lanes" {
    _ = engine.init(FIXTURE);
    // sv = v4uadd(v4u(10,20,30,40), v4u(1,2,3,4)) + v4u(1,1,1,1)
    //    = (12, 23, 34, 45) packed x | y<<8 | z<<16 | w<<24
    try std.testing.expectEqual(@as(i32, 12 | (23 << 8) | (34 << 16) | (@as(i32, 45) << 24)), ent.globalLoad(5));
    // c1 = x*100 + y*10 + z = 1200 + 230 + 34 = 1234
    try std.testing.expectEqual(@as(i32, 1234), ent.globalLoad(6));
}

test "v231: try/catch unwinds to the handler with the error value" {
    _ = engine.init(FIXTURE);
    // r = risky(5.0) completed (6.0); risky(99.0) threw 42 mid-try; the
    // `r + 1000` statement never ran; the catch bound err = 42.
    try std.testing.expectEqual(@as(i32, 6 * 256), ent.globalLoad(7));
    try std.testing.expectEqual(@as(i32, 42), ent.globalLoad(8));
}

test "v231: f64 entity fields survive spawn + load (hash-chain neutral)" {
    _ = engine.init(FIXTURE);
    _ = frame(); // init + first update
    // gcell = fixed(Cell.acc) = 2.5 -> 640: the spawn's fieldStore64 wrote
    // the full 64-bit pattern and the update loop's LD_ENT pushed two cells.
    try std.testing.expectEqual(@as(i32, 640), ent.globalLoad(9));
    // g64 advanced by one update: 0.25 -> bits 0x3FD0000000000000
    try std.testing.expectEqual(@as(u64, 0x3FD0000000000000), ent.globalLoad64(10));
    // determinism red line: replay the same cart from scratch — the hash
    // chain must be bit-identical (the f64/vec4/try paths never touch the
    // flat image outside declared fields).
    const chain_a = tt.stateHash(1);
    _ = engine.init(FIXTURE);
    _ = frame();
    try std.testing.expectEqual(chain_a, tt.stateHash(1));
}
