const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
test "v4" {
    std.debug.print("rc={d}\n", .{engine.init(@embedFile("v4.libyte"))});
    std.debug.print("a = 0x{X:08} (want 0x281E140A)\n", .{@as(u32, @bitCast(ent.globalLoad(0)))});
    std.debug.print("b = 0x{X:08} (want 0x04030201)\n", .{@as(u32, @bitCast(ent.globalLoad(1)))});
    std.debug.print("c = 0x{X:08} (want 0x2C21140B)\n", .{@as(u32, @bitCast(ent.globalLoad(2)))});
}
