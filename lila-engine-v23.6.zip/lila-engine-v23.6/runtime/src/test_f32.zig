//! runtime/src/test_f32.zig — v20 F32 (software IEEE binary32) tests.
//!
//! Loads the fixture built from demo/test_f32_fixture.lila (a damped spring
//! oscillator at true float precision — THE Math Problem case) and asserts
//! the VM's softfloat arithmetic is BIT-EXACT against the host's native
//! IEEE f32 computing the SAME recurrence. Plus the casts, sqrt, and
//! comparison surface.
//!
//! Regenerate the fixture with:
//!   ../compiler/target/release/lilac build ../demo/test_f32_fixture.lila \
//!       -o src/test_f32_fixture.libyte

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const tt = @import("timetravel.zig");
const sf = @import("softfloat.zig");

// typed-field ids from the fixture's disasm (globals)
const TF_XF: u32 = 0; // f32 spring position
const TF_VF: u32 = 1;
const TF_GOUT: u32 = 2;
const TF_SQRT: u32 = 3;
const TF_CAST: u32 = 4;
const TF_CMP: u32 = 5;

fn loadFixture() ![]const u8 {
    return @embedFile("test_f32_fixture.libyte");
}

/// The oracle: the SAME 60-step damped spring in native IEEE f32.
fn oracleSpring() f32 {
    var x: f32 = 1.0;
    var v: f32 = 0.0;
    var t: u32 = 0;
    while (t < 60) : (t += 1) {
        const acc = (0.0 - x) * 0.05 - v * 0.02;
        v += acc;
        x += v;
    }
    return x;
}

test "f32: damped spring is bit-exact vs native IEEE" {
    const blob = try loadFixture();
    const rc = engine.init(blob);
    try std.testing.expectEqual(@as(i32, c.ERR_OK), rc);
    // init ran the 60-step recurrence through the VM's softfloat
    const got = c.rd32(c.ADDR_GLOBALS); // xf cell = raw IEEE bits
    const want: u32 = @bitCast(oracleSpring());
    try std.testing.expectEqual(want, got);
}

test "f32: fsqrt(2.0) is the correctly rounded root" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    // gsqrt_out = fsqrt(2.0f): must equal the native correctly-rounded value
    // (globals bit layout: xf@0 vf@+4 g_out@+8 gsqrt_out@+12)
    const got = c.rd32(c.ADDR_GLOBALS + 12);
    const want: u32 = @bitCast(@sqrt(@as(f32, 2.0)));
    try std.testing.expectEqual(want, got);
}

test "f32: casts round-trip the value classes" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    // cast_out = int(f32(7) / 2.0f) * 100 + int(fixed(1.5f))
    //          = int(3.5) * 100 + int(1.5 as Q24.8 = 384 raw >> 8) = 300 + 1
    const got = ent.globalLoad(TF_CAST);
    try std.testing.expectEqual(@as(i32, 301), got);
}

test "f32: comparisons follow IEEE semantics" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    // 0.5 < 1.0 && sqrt(9) == 3 && !(2 == 3) -> 1
    try std.testing.expectEqual(@as(i32, 1), ent.globalLoad(TF_CMP));
}

test "f32: the hash chain stays deterministic across replays" {
    const blob = try loadFixture();
    _ = engine.init(blob);
    var f: u32 = 0;
    while (f < 30) : (f += 1) engine.frame();
    const h1 = tt.stateHash(30);
    _ = engine.init(blob);
    f = 0;
    while (f < 30) : (f += 1) engine.frame();
    try std.testing.expectEqual(h1, tt.stateHash(30));
}

test "f32: softfloat module self-check (host oracle, 100k randoms)" {
    // re-run the module's own exhaustive oracle suite indirectly: spot the
    // op set through the public API against native here (the in-module
    // tests cover 100k each; this pins the linkage into the VM build)
    var st: u64 = 0xABCDEF0123456789;
    var i: usize = 0;
    while (i < 10_000) : (i += 1) {
        var s = st;
        s ^= s << 13;
        s ^= s >> 7;
        s ^= s << 17;
        st = s;
        const a: sf.F32 = @truncate(s);
        s ^= s << 13;
        s ^= s >> 7;
        s ^= s << 17;
        const b: sf.F32 = @truncate(s);
        const na: f32 = @bitCast(a);
        const nb: f32 = @bitCast(b);
        // finite-only here: the in-module suite exhaustively covers
        // NaN/Inf/subnormal patterns (native NaN payloads differ from the
        // canonical softfloat NaN by contract)
        if ((a & 0x7F800000) == 0x7F800000 or (b & 0x7F800000) == 0x7F800000) continue;
        const want_add: sf.F32 = @bitCast(na + nb);
        const got_add = sf.add(a, b);
        try std.testing.expectEqual(want_add, got_add);
        if (b == 0) continue;
        const want_div: sf.F32 = @bitCast(na / nb);
        const got_div = sf.div(a, b);
        try std.testing.expectEqual(want_div, got_div);
        const pa: f32 = @abs(na);
        const want_sqrt: sf.F32 = @bitCast(@sqrt(pa));
        const got_sqrt = sf.sqrt(a & 0x7FFFFFFF);
        try std.testing.expectEqual(want_sqrt, got_sqrt);
    }
}
