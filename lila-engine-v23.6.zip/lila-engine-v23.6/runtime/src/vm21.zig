//! ============================================================================
//! LILA v21 — ENGINE FUNDAMENTALS (the C++/C# game-dev parity opcodes)
//! ============================================================================
//!
//! The runtime half of the v21 feature set. Everything here executes INSIDE
//! one VM opcode and touches ONLY:
//!   * c.mem (pool field planes, dict tables, grid/path arrays) — hashed,
//!     snapshot-safe, rewind/rollback capture it with the standard memcpy;
//!   * engine-owned threadlocal scratch (radix buffers, A* open lists) —
//!     write-before-read within a single opcode, never hashed (the same
//!     discipline as the VM's own stack/frames).
//!
//! Determinism contract: every algorithm below is pure integer math with
//! FIXED tie-breaking (LSD radix is stable; the A* heap orders by (f, node)
//! lexicographically) — bit-identical on every runtime, every build.

const std = @import("std");
const c = @import("core.zig");

// ---------------------------------------------------------------------------
// PSORT — stable LSD radix sort of a pool's live rows by a key field
// (C++ std::stable_sort / C# List.Sort, the LILA way: one opcode; rows
// permute in place, gens move WITH rows so stale handles soft-land to 0).
// ---------------------------------------------------------------------------

threadlocal var ps_keys: [c.MAX_PSORT]u64 = undefined;
threadlocal var ps_perm: [c.MAX_PSORT]u16 = undefined;
threadlocal var ps_tmp: [c.MAX_PSORT]u16 = undefined;

/// Sort pool `t`'s live rows by pfield `pf` (global id, pool*16+f).
/// dir 0 = ascending, 1 = descending. Keys compare as SIGNED i32 (Q24.8 and
/// int both order correctly): the sign bit flips into the low domain first.
/// v23.6: an f64 key field (schema width 2) compares in IEEE-754 total
/// order — the u64 bit pattern maps to an order-preserving u64 (flip all
/// bits for negatives, flip the sign bit for positives; canonical NaN sorts
/// above +inf, deterministically). Row moves are width-aware (f64 rows
/// carry both cells). Pools larger than MAX_PSORT ignore the call (the
/// soft-land capacity contract). Iteration order after the sort IS key
/// order; equal keys keep their relative push order (stability).
pub fn psort(t: u32, pf: u32, dir: u32) void {
    if (t >= c.n_pools) return;
    const count = c.poolCount(t);
    if (count < 2 or count > c.MAX_PSORT) return;
    const f = pf & 15;
    const fb = c.poolFieldBase(t, f);
    const wide = c.pool_fw[t][f] == 2;
    const passes: u32 = if (wide) 8 else 4;
    // 1. biased keys: order-preserving transform; invert for descending.
    //    (Both transforms preserve stability: equal keys stay equal.)
    var i: u32 = 0;
    while (i < count) : (i += 1) {
        var k: u64 = undefined;
        if (wide) {
            const lo: u64 = c.rd32(fb + i * 4); // u32 -> u64 zero-extend
            const hi: u64 = c.rd32(fb + i * 4 + 4);
            const bits: u64 = (hi << 32) | lo;
            // IEEE-754 total order: negatives flip all bits, the rest flip
            // the sign bit (the classic float-to-rank transform)
            k = if ((bits >> 63) != 0) ~bits else bits ^ 0x8000000000000000;
        } else {
            k = @as(u64, c.rd32(fb + i * 4) ^ 0x80000000);
        }
        if (dir != 0) k = ~k;
        ps_keys[i] = k;
        ps_perm[i] = @intCast(i);
    }
    // 2. stable 8-bit counting passes (LSD) over the index array — 4 for
    //    32-bit keys, 8 for f64 keys.
    var pass: u32 = 0;
    while (pass < passes) : (pass += 1) {
        const shift: u6 = @intCast(pass * 8);
        var counts: [256]u32 = [_]u32{0} ** 256;
        i = 0;
        while (i < count) : (i += 1) {
            counts[@intCast((ps_keys[ps_perm[i]] >> shift) & 0xFF)] += 1;
        }
        var starts: [256]u32 = undefined;
        var acc: u32 = 0;
        var b: u32 = 0;
        while (b < 256) : (b += 1) {
            starts[b] = acc;
            acc += counts[b];
        }
        i = 0;
        while (i < count) : (i += 1) {
            const d: u32 = @intCast((ps_keys[ps_perm[i]] >> shift) & 0xFF);
            ps_tmp[starts[d]] = ps_perm[i];
            starts[d] += 1;
        }
        i = 0;
        while (i < count) : (i += 1) ps_perm[i] = ps_tmp[i];
    }
    // ps_perm[k] = the source row that belongs at position k.
    // 3. apply the permutation, one cycle at a time, moving whole ROWS
    //    (every field plane + the gen word) with a single row temp.
    //    v23.6: width-aware — an f64 field moves BOTH cells.
    const nf: u32 = c.pool_nfields[t];
    if (nf > 16) return; // schema-guaranteed <= MAX_PFIELDS; defensive
    const gens = c.poolGens(t);
    var row_tmp: [32]u32 = undefined; // 16 fields x 2 cells
    i = 0;
    while (i < count) : (i += 1) {
        var src: u32 = ps_perm[i];
        if (src == i) continue; // fixed point
        // save the displaced row i (it belongs somewhere later in the cycle)
        var fld: u32 = 0;
        while (fld < nf) : (fld += 1) {
            const plane = c.poolFieldBase(t, fld);
            row_tmp[fld * 2] = c.rd32(plane + i * 4);
            if (c.pool_fw[t][fld] == 2) row_tmp[fld * 2 + 1] = c.rd32(plane + i * 4 + 4);
        }
        const gen_tmp = c.rd16(gens + i * 2);
        var j: u32 = i;
        while (true) {
            src = ps_perm[j];
            if (src == i) break; // the cycle wants the saved row here
            // move row `src` into position `j` (all fields + gens)
            fld = 0;
            while (fld < nf) : (fld += 1) {
                const plane = c.poolFieldBase(t, fld);
                c.wr32(plane + j * 4, c.rd32(plane + src * 4));
                if (c.pool_fw[t][fld] == 2) c.wr32(plane + j * 4 + 4, c.rd32(plane + src * 4 + 4));
            }
            c.wr16(gens + j * 2, c.rd16(gens + src * 2));
            ps_perm[j] = @intCast(j); // mark done
            j = src;
        }
        // place the saved row (from position i) at position j
        fld = 0;
        while (fld < nf) : (fld += 1) {
            const plane = c.poolFieldBase(t, fld);
            c.wr32(plane + j * 4, row_tmp[fld * 2]);
            if (c.pool_fw[t][fld] == 2) c.wr32(plane + j * 4 + 4, row_tmp[fld * 2 + 1]);
        }
        c.wr16(gens + j * 2, gen_tmp);
        ps_perm[j] = @intCast(j);
    }
}

// ---------------------------------------------------------------------------
// DICTS — u32 -> u32 open-addressing (C# Dictionary / C++ unordered_map)
// ---------------------------------------------------------------------------

/// Insert or overwrite. key 0xFFFFFFFF is reserved (the EMPTY marker) —
/// storing it is a no-op (the soft-land convention). A full table drops the
/// insert (documented: size the power-of-two capacity for the load).
pub fn mapPut(d: u32, key: u32, val: u32) void {
    if (d >= c.n_dicts or key == c.DICT_EMPTY) return;
    const cap: u32 = c.dict_cap[d];
    const mask: u32 = cap - 1;
    var idx: u32 = c.mix32(key) & mask;
    var i: u32 = 0;
    while (i < cap) : (i += 1) {
        const k = c.rd32(c.dictKey(d, idx));
        if (k == key) {
            c.wr32(c.dictVal(d, idx), val); // overwrite in place
            return;
        }
        if (k == c.DICT_EMPTY) {
            c.wr32(c.dictKey(d, idx), key);
            c.wr32(c.dictVal(d, idx), val);
            const count = c.rd32(c.dict_base[d]);
            c.wr32(c.dict_base[d], count + 1);
            return;
        }
        idx = (idx + 1) & mask;
    }
    // table full: drop (soft-land)
}

/// Lookup: 0 if absent (the cell convention — like SRAM and stale handles).
pub fn mapGet(d: u32, key: u32) u32 {
    if (d >= c.n_dicts or key == c.DICT_EMPTY) return 0;
    const cap: u32 = c.dict_cap[d];
    const mask: u32 = cap - 1;
    var idx: u32 = c.mix32(key) & mask;
    var i: u32 = 0;
    while (i < cap) : (i += 1) {
        const k = c.rd32(c.dictKey(d, idx));
        if (k == key) return c.rd32(c.dictVal(d, idx));
        if (k == c.DICT_EMPTY) return 0; // probe chain ends: absent
        idx = (idx + 1) & mask;
    }
    return 0;
}

/// Backward-shift deletion: after removing a slot, pull chain successors
/// forward so probe sequences stay dense (no tombstones, deterministic).
pub fn mapDel(d: u32, key: u32) void {
    if (d >= c.n_dicts or key == c.DICT_EMPTY) return;
    const cap: u32 = c.dict_cap[d];
    const mask: u32 = cap - 1;
    var idx: u32 = c.mix32(key) & mask;
    var i: u32 = 0;
    while (i < cap) : (i += 1) {
        const k = c.rd32(c.dictKey(d, idx));
        if (k == key) {
            var hole = idx;
            var j: u32 = (hole + 1) & mask;
            while (j != idx) : (j = (j + 1) & mask) {
                const jk = c.rd32(c.dictKey(d, j));
                if (jk == c.DICT_EMPTY) break; // chain ended
                const home = c.mix32(jk) & mask;
                // movable iff `hole` is NOT strictly inside j's probe span
                // [home+1 .. j] (circular) — i.e. its distance from home is
                // <= the distance j already traveled.
                const d_home_hole = (hole -% home) & mask;
                const d_home_j = (j -% home) & mask;
                if (d_home_hole < d_home_j or (d_home_hole == 0)) {
                    c.wr32(c.dictKey(d, hole), jk);
                    c.wr32(c.dictVal(d, hole), c.rd32(c.dictVal(d, j)));
                    hole = j;
                }
            }
            c.wr32(c.dictKey(d, hole), c.DICT_EMPTY);
            const count = c.rd32(c.dict_base[d]);
            if (count > 0) c.wr32(c.dict_base[d], count - 1);
            return;
        }
        if (k == c.DICT_EMPTY) return; // absent: no-op
        idx = (idx + 1) & mask;
    }
}

// ---------------------------------------------------------------------------
// RAY — fixed-point Amanatides-Woo DDA over a global array grid
// (Unity Physics2D.Raycast / Linecast, the LILA way)
// ---------------------------------------------------------------------------

pub const RAY_MISS: i32 = 0x7FFFFFFF;

/// Cast from (x, y) Q24.8 pixels along screen-convention `ang` (0 = up), up
/// to `maxd` Q24.8 pixels, through global array `gid` as a gw x gh row-major
/// tile grid (any nonzero cell = solid). Returns the Q24.8 distance to the
/// first solid cell, or RAY_MISS. Leaving the grid or exhausting maxd = miss
/// (the world past the grid edges is open space). The hit CELL coords are
/// stashed packed at ADDR_RAY_CELL ((x << 16) | y) for rayx()/rayy().
pub fn ray(gid: u32, gw: i32, gh: i32, x: i32, y: i32, ang: i32, maxd: i32) i32 {
    if (gid >= c.n_arrs or gw <= 0 or gh <= 0) return RAY_MISS;
    const dirx = c.sinA(ang);
    const diry = -c.cosA(ang);
    if (dirx == 0 and diry == 0) return RAY_MISS;
    const cx: i32 = x >> 8; // arithmetic: floor toward -inf, bounds-checked after
    const cy: i32 = y >> 8;
    if (cx >= 0 and cy >= 0 and cx < gw and cy < gh) {
        const cell: u32 = @intCast(cy * gw + cx);
        if (c.rd32(c.arr_base[gid] + cell * 4) != 0) {
            c.wr32(c.ADDR_RAY_CELL,
                ((@as(u32, @bitCast(cx)) & 0xFFFF) << 16) | (@as(u32, @bitCast(cy)) & 0xFFFF));
            return 0;
        }
    }
    const stepx: i32 = if (dirx > 0) 1 else (if (dirx < 0) @as(i32, -1) else 0);
    const stepy: i32 = if (diry > 0) 1 else (if (diry < 0) @as(i32, -1) else 0);
    const INF: i32 = 0x7FFFFFF0;
    const adx: i32 = if (dirx < 0) -dirx else dirx;
    const ady: i32 = if (diry < 0) -diry else diry;
    const tdx: i32 = if (adx == 0) INF else c.divF(256, adx); // Q24.8 per cell
    const tdy: i32 = if (ady == 0) INF else c.divF(256, ady);
    var tmaxx: i32 = INF;
    var tmaxy: i32 = INF;
    if (stepx > 0) {
        tmaxx = c.divF(((cx + 1) << 8) -% x, dirx);
    } else if (stepx < 0) {
        tmaxx = c.divF(x -% (cx << 8), -dirx);
    }
    if (stepy > 0) {
        tmaxy = c.divF(((cy + 1) << 8) -% y, diry);
    } else if (stepy < 0) {
        tmaxy = c.divF(y -% (cy << 8), -diry);
    }
    if (tmaxx < 0) tmaxx = 0; // exactly on a boundary: take the next crossing
    if (tmaxy < 0) tmaxy = 0;
    var gx = cx;
    var gy = cy;
    // a straight ray crosses at most gw + gh cell boundaries; +4 slack.
    var steps: u32 = @intCast(gw + gh + 4);
    while (steps > 0) : (steps -= 1) {
        // d = the boundary crossing distance for THIS step, captured BEFORE
        // the tmax advance (tmax - tdelta is wrong when the other axis is
        // INF: INF - INF wraps to 0 and steals the min).
        var d: i32 = 0;
        if (tmaxx < tmaxy) {
            d = tmaxx;
            if (d > maxd) return RAY_MISS;
            gx += stepx;
            tmaxx += tdx;
        } else {
            d = tmaxy;
            if (d > maxd) return RAY_MISS;
            gy += stepy;
            tmaxy += tdy;
        }
        if (gx < 0 or gy < 0 or gx >= gw or gy >= gh) return RAY_MISS;
        const cell: u32 = @intCast(gy * gw + gx);
        if (c.rd32(c.arr_base[gid] + cell * 4) != 0) {
            c.wr32(c.ADDR_RAY_CELL,
                ((@as(u32, @bitCast(gx)) & 0xFFFF) << 16) | (@as(u32, @bitCast(gy)) & 0xFFFF));
            return if (d < 0) 0 else d;
        }
    }
    return RAY_MISS;
}

// ---------------------------------------------------------------------------
// ASTAR — deterministic 8-way grid planner (the NavMesh analog)
// ---------------------------------------------------------------------------

// Engine-owned scratch (write-before-read within one OP_ASTAR execution).
const N: u32 = c.MAX_ASTAR_NODES;
threadlocal var as_g: [N]i32 = undefined; // cost from start (10 = straight, 14 = diagonal)
threadlocal var as_from: [N]u16 = undefined; // came-from node (0xFFFF = none)
threadlocal var as_closed: [N]u8 = undefined;
threadlocal var as_heapf: [N]i32 = undefined; // binary min-heap keys
threadlocal var as_heapn: [N]u16 = undefined; // ... and payloads
threadlocal var as_path: [N]u16 = undefined; // reconstruction stack

const ASTAR_INF: i32 = 0x7FFFFFFF;

fn heur(dx: u32, dy: u32) i32 {
    // octile distance in cost units: 14*min + 10*(max-min)
    const mx: u32 = @max(dx, dy);
    const mn: u32 = @min(dx, dy);
    return @intCast(10 * mx + 4 * mn);
}

/// Plan from (sx, sy) to (tx, ty) through global array `gid` (gw x gh tiles,
/// nonzero = solid), writing (x, y) int cell pairs START-ADJACENT FIRST into
/// global array `pid`. Returns the waypoint count; -1 unreachable, -2 grid
/// too large (gw*gh > 16384), -3 bad args. Path longer than the array's
/// capacity (in pairs) truncates to fit (documented soft-land).
pub fn astar(gid: u32, pid: u32, gw: i32, gh: i32, sx: i32, sy: i32, tx: i32, ty: i32) i32 {
    if (gid >= c.n_arrs or pid >= c.n_arrs or gw <= 0 or gh <= 0) return -3;
    if (@as(u64, @intCast(gw)) * @as(u64, @intCast(gh)) > N) return -2;
    if (sx < 0 or sy < 0 or sx >= gw or sy >= gh) return -3;
    // v23.1: the target check was garbled (`tx >= gh and tx >= gw` — AND
    // instead of OR, gh compared against tx); it only worked by accident for
    // square grids and was immediately re-checked correctly below. One
    // correct check now.
    if (tx < 0 or ty < 0 or tx >= gw or ty >= gh) return -3;
    const start: u32 = @intCast(sy * gw + sx);
    const target: u32 = @intCast(ty * gw + tx);
    const grid = c.arr_base[gid];
    if (c.rd32(grid + target * 4) != 0) return -1; // target is solid
    if (start == target) return 0;
    const ncells: u32 = @intCast(gw * gh);
    // init scratch
    @memset(as_g[0..ncells], ASTAR_INF);
    @memset(as_closed[0..ncells], 0);
    @memset(as_from[0..ncells], 0xFFFF);
    var heap_len: u32 = 0;
    // push start
    as_g[start] = 0;
    as_heapf[0] = heur(@abs(sx - tx), @abs(sy - ty));
    as_heapn[0] = @intCast(start);
    heap_len = 1;
    while (heap_len > 0) {
        // pop min by (f, node) lexicographic — the deterministic tie-break
        // sift the root down
        const n0 = as_heapn[0];
        heap_len -= 1;
        if (heap_len > 0) {
            as_heapf[0] = as_heapf[heap_len];
            as_heapn[0] = as_heapn[heap_len];
            var k: u32 = 0;
            while (true) {
                const l = 2 * k + 1;
                const r = l + 1;
                var m = k;
                if (l < heap_len and (as_heapf[l] < as_heapf[m] or
                    (as_heapf[l] == as_heapf[m] and as_heapn[l] < as_heapn[m]))) m = l;
                if (r < heap_len and (as_heapf[r] < as_heapf[m] or
                    (as_heapf[r] == as_heapf[m] and as_heapn[r] < as_heapn[m]))) m = r;
                if (m == k) break;
                const tf = as_heapf[k]; const tn = as_heapn[k];
                as_heapf[k] = as_heapf[m]; as_heapn[k] = as_heapn[m];
                as_heapf[m] = tf; as_heapn[m] = tn;
                k = m;
            }
        }
        if (as_closed[n0] != 0) continue;
        as_closed[n0] = 1;
        if (n0 == target) break;
        const nx: i32 = @rem(@as(i32, @intCast(n0)), gw);
        const ny: i32 = @divTrunc(@as(i32, @intCast(n0)), gw);
        var dy: i32 = -1;
        while (dy <= 1) : (dy += 1) {
            var dx: i32 = -1;
            while (dx <= 1) : (dx += 1) {
                if (dx == 0 and dy == 0) continue;
                const ax = nx + dx;
                const ay = ny + dy;
                if (ax < 0 or ay < 0 or ax >= gw or ay >= gh) continue;
                const nb: u32 = @intCast(ay * gw + ax);
                if (c.rd32(grid + nb * 4) != 0) continue; // solid
                const step_cost: i32 = if (dx != 0 and dy != 0) 14 else 10;
                const ng = as_g[n0] + step_cost;
                if (ng < as_g[nb]) {
                    as_g[nb] = ng;
                    as_from[nb] = n0;
                    // push (ng + h(nb), nb)
                    if (heap_len < N) {
                        var k: u32 = heap_len;
                        as_heapf[k] = ng + heur(@abs(ax - tx), @abs(ay - ty));
                        as_heapn[k] = @intCast(nb);
                        heap_len += 1;
                        while (k > 0) {
                            const p = (k - 1) / 2;
                            if (as_heapf[p] < as_heapf[k] or
                                (as_heapf[p] == as_heapf[k] and as_heapn[p] < as_heapn[k])) break;
                            const tf = as_heapf[k]; const tn = as_heapn[k];
                            as_heapf[k] = as_heapf[p]; as_heapn[k] = as_heapn[p];
                            as_heapf[p] = tf; as_heapn[p] = tn;
                            k = p;
                        }
                    }
                }
            }
        }
    }
    if (as_from[target] == 0xFFFF or as_closed[target] == 0) return -1;
    // reconstruct: walk came-from backwards, then emit start-adjacent first
    var len: u32 = 0;
    var cur: u32 = target;
    while (cur != start and len < N) : (len += 1) {
        as_path[len] = @intCast(cur);
        cur = as_from[cur];
    }
    // the path array holds (x, y) int pairs; cap by its declared capacity
    const cap_pairs: u32 = @as(u32, c.arr_cap[pid]) / 2;
    const out: u32 = if (len < cap_pairs) len else cap_pairs;
    var k: u32 = 0;
    while (k < out) : (k += 1) {
        const node: u32 = as_path[len - 1 - k]; // reverse: start-adjacent first
        const x: i32 = @rem(@as(i32, @intCast(node)), gw);
        const y: i32 = @divTrunc(@as(i32, @intCast(node)), gw);
        c.wr32(c.garrElem(pid, k * 2), @bitCast(x));
        c.wr32(c.garrElem(pid, k * 2 + 1), @bitCast(y));
    }
    return @intCast(out);
}
