//! v20 DREAM tests: the search must be deterministic, its movies must be
//! engine-legal, its artifacts must parse — and the search must actually
//! PLAY (find optima on carts with known answers).
//!
//! Fixtures are compiled once by lilac and embedded:
//!   dream_micro.libyte  — +1/frame while RIGHT held (optimum == horizon)
//!   dream_delay.libyte — +100 only on a rising FIRE edge after a >=45
//!                        frame RIGHT streak (delayed-commit reward)

const std = @import("std");
const c = @import("core.zig");
const engine = @import("engine.zig");
const ent = @import("entity.zig");
const audio = @import("audio.zig");
const tt = @import("timetravel.zig");
const vm = @import("vm.zig");
const cover = @import("cover.zig");
const codec = @import("movie_codec.zig");
const dream = @import("dream.zig");

comptime {
    _ = cover;
    _ = codec;
}

const SPF: u32 = 44100 / 60;

fn arenaAlloc() std.mem.Allocator {
    // dream.run is arena-based BY DESIGN (never frees; bounded usage
    // documented in the module header) — the leak-checking testing
    // allocator would flag that on purpose, so tests give it the page
    // allocator, exactly like the runner gives it its process arena.
    return std.heap.page_allocator;
}

// ---------------- spec parsing ----------------

test "dream: spec parses (defaults, full, rejects junk)" {
    const good =
        \\# comment line
        \\reward global 2 min target 50
        \\horizon 90
        \\beam 4
        \\budget 5000
        \\explore 30
        \\seed 99
        \\
    ;
    const s = try dream.parseSpec(good);
    try std.testing.expectEqual(@as(u32, 2), s.reward_global);
    try std.testing.expect(s.minimize);
    try std.testing.expectEqual(@as(i32, 50), s.reward_target.?);
    try std.testing.expectEqual(@as(u32, 90), s.horizon);
    try std.testing.expectEqual(@as(u32, 4), s.beam);
    try std.testing.expectEqual(@as(u64, 5000), s.budget);
    try std.testing.expectEqual(@as(u32, 30), s.explore_pct);
    try std.testing.expectEqual(@as(u64, 99), s.seed);

    // defaults
    const d = try dream.parseSpec("reward global 0 max\n");
    try std.testing.expectEqual(@as(u32, 300), d.horizon);
    try std.testing.expectEqual(@as(u32, 8), d.beam);
    try std.testing.expect(d.reward_target == null);

    // loud rejections
    try std.testing.expectError(dream.Error.BadSpec, dream.parseSpec("wat 7\n"));
    try std.testing.expectError(dream.Error.BadSpec, dream.parseSpec("reward global\n"));
    try std.testing.expectError(dream.Error.BadSpec, dream.parseSpec("beam 0\n"));
    try std.testing.expectError(dream.Error.BadSpec, dream.parseSpec("horizon 999999\n"));
}

// ---------------- the micro optimum ----------------

test "dream: micro cart — search finds perfect play" {
    const rc = engine.init(@embedFile("dream_micro.libyte"));
    try std.testing.expectEqual(@as(i32, 0), rc);

    const s = dream.Spec{
        .reward_global = 0,
        .horizon = 60,
        .beam = 4,
        .budget = 1200,
        .explore_pct = 80,
        .seed = 3,
    };
    const res = try dream.run(arenaAlloc(), s);

    // perfect play: every frame held right => reward == frames simulated
    // by the winning timeline (the movie may be shorter than the horizon
    // only if the budget ran out; with this budget it does not).
    try std.testing.expect(res.movie.len > 0);
    try std.testing.expectEqual(@as(i32, @intCast(res.movie.len)), res.stats.best_reward);
    // the movie is the pure right-hold
    for (res.movie) |m| try std.testing.expect(m & 1 == 1); // bit 0 = #right

    // the used-button scan learned the cartridge's only read button
    try std.testing.expectEqual(@as(u32, 1), res.stats.used_buttons);

    // artifacts exist and parse
    const hdr = try codec.parseHeader(res.liz1);
    try std.testing.expectEqual(@as(u32, @intCast(res.movie.len)), hdr.n_frames);
    try std.testing.expectEqual(res.hashes[res.movie.len - 1], hdr.final_hash);
    try std.testing.expect(res.dreammap.len == cover.drm1Size(c.instr_count));
    try std.testing.expect(std.mem.eql(u8, res.dreammap[0..4], cover.DRM_MAGIC));

    // compression sanity: 80 frames of one button must be tiny vs LIR1
    try std.testing.expect(res.liz1.len < res.stats.lir1_bytes / 8);
}

test "dream: determinism — same seed, identical artifacts" {
    const a = arenaAlloc();
    const s = dream.Spec{ .horizon = 40, .beam = 4, .budget = 900, .seed = 11 };
    try std.testing.expectEqual(@as(i32, 0), engine.init(@embedFile("dream_micro.libyte")));
    const r1 = try dream.run(a, s);
    // a completely fresh boot (engine.init resets everything)
    try std.testing.expectEqual(@as(i32, 0), engine.init(@embedFile("dream_micro.libyte")));
    cover.reset();
    const r2 = try dream.run(a, s);
    try std.testing.expectEqualSlices(u32, r1.movie, r2.movie);
    try std.testing.expectEqualSlices(u64, r1.hashes, r2.hashes);
    try std.testing.expectEqualSlices(u8, r1.liz1, r2.liz1);
    try std.testing.expectEqualSlices(u8, r1.dreammap, r2.dreammap);
}

test "dream: found movie replays bit-identically (the external proof)" {
    const a = arenaAlloc();
    try std.testing.expectEqual(@as(i32, 0), engine.init(@embedFile("dream_micro.libyte")));
    const res = try dream.run(a, .{ .horizon = 40, .beam = 4, .budget = 900, .seed = 5 });

    // fresh boot + the exact --replay loop
    try std.testing.expectEqual(@as(i32, 0), engine.init(@embedFile("dream_micro.libyte")));
    var sink: [SPF]i16 = undefined;
    for (res.movie, 0..) |m, f| {
        c.wr32(c.ADDR_INPUT, m);
        engine.frame();
        _ = audio.pull(&sink);
        try std.testing.expectEqual(res.hashes[f], tt.stateHash(@intCast(f)));
    }
}

// ---------------- delayed-commit reward ----------------

test "dream: delay cart — span search finds the 45-frame commitment" {
    try std.testing.expectEqual(@as(i32, 0), engine.init(@embedFile("dream_delay.libyte")));
    // generous budget: the beam must hold right >=45 frames then press
    // fire on top of it (a rising edge while the streak is live).
    const res = try dream.run(arenaAlloc(), .{
        .horizon = 90,
        .beam = 6,
        .budget = 5000,
        .explore_pct = 85,
        .seed = 2,
    });
    // at least one +100 (delayed rewards are the whole point of this cart)
    try std.testing.expect(res.stats.best_reward >= 100);
    // coverage of both branch sides of the reward condition
    try std.testing.expect(res.stats.sites.both >= 1);
}

// ---------------- coverage + dreammap evidence ----------------

test "dream: cover is monotone and evidence is real" {
    try std.testing.expectEqual(@as(i32, 0), engine.init(@embedFile("dream_micro.libyte")));
    cover.reset();
    cover.on = true;
    defer cover.on = false;
    engine.threads_enabled = false;

    var prev_filled: u32 = 0;
    var sink: [SPF]i16 = undefined;
    var f: u32 = 0;
    while (f < 40) : (f += 1) {
        c.wr32(c.ADDR_INPUT, if (f % 2 == 0) 1 else 0); // alternating right/idle
        engine.frame();
        _ = audio.pull(&sink);
        try std.testing.expect(cover.filled >= prev_filled); // monotone
        prev_filled = cover.filled;
    }
    // a branchy little game: some site must be one-sided, some both
    const s = cover.siteStats(c.instr_count);
    try std.testing.expect(s.sites >= 2);
    try std.testing.expect(s.one >= 1); // the key branch flip-flops directions
}
