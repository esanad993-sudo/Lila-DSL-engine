//! LILA bytecode VM: decoded-instruction interpreter with i32 value stack,
//! frame stack, entity-iterator stack. Runs game logic at 60Hz.

const std = @import("std");
const c = @import("core.zig");
const sf = @import("softfloat.zig");
const ent = @import("entity.zig");
const render = @import("render.zig");
const render3d = @import("render3d.zig");
const audio = @import("audio.zig");
const tables = @import("tables.zig");
const vm21 = @import("vm21.zig");
const vm22 = @import("vm22.zig");
const cover = @import("cover.zig");


// v23.2: pub — the AOT bridge comptime-asserts its C-side LilaState mirror
// against these (a profile change that resizes the interpreter state must
// fail the bridge build, not silently corrupt AOT frames).
pub const STACK_SIZE: u32 = 512;
pub const MAX_FRAMES: u32 = 32;
// v12: 32 slots (was 16 — real articulated rigs need more scratch locals).
// The compiler enforces the same limit at build time with a loud error, so
// a game that outgrows the frame is rejected, never silently miscompiled
// (slots >= the limit would drop writes and hang loops).
pub const MAX_LOCALS: u32 = 32;
pub const MAX_ITERS: u32 = 8;
const NO_IDX: u32 = 0xFFFFFFFF;

// v23.5 ABI v2: Frame is part of the C-visible state prefix (LilaFrame in
// lila_aot_runtime.h) — extern layout, field order is the ABI.
pub const Frame = extern struct {
    ret_pc: u32,
    fn_idx: u32,
    locals: [MAX_LOCALS]i32,
};

pub const Iter = extern struct {
    typ: u32,
    next_bit: u32,
    slot: u32,
    mask: u32 = 0,
    base: u32 = 0,
    /// v20 POOLS: this iterator walks a pool (count-ordered) instead of an
    /// entity type's live bitmap (slot-ordered). The is_pool flag keeps
    /// OP_FOR_ADV/OP_PL_FOR_ADV from cross-decoding an iterator.
    is_pool: bool = false,
};

/// The entire interpreter state. On native builds this is THREADLOCAL so the
/// v10 parallel systems can run proven-disjoint update groups on concurrent
/// workers — each worker gets its own stack/frames/iterators automatically.
/// On wasm32-freestanding (single-threaded host) it is a plain static.
/// v23.5 ABI v2: State is an extern struct whose C-VISIBLE PREFIX (stack /
/// sp / frames / fp / pc / ret_val) is field-for-field identical to
/// lila_aot_runtime.h's LilaState (comptime-asserted in lila_aot_bridge.zig).
/// AOT-compiled functions operate DIRECTLY on this live state — the v23.2
/// per-call mirror sync (a ~6 KB stack+frames memcpy on every Tier-0 call
/// and every machinery opcode) is gone. The vm-internal tail (iterators,
/// try/catch, ret_hi) sits BELOW the prefix and is never touched by C code.
pub const State = extern struct {
    // ---- C ABI prefix (lila_aot_runtime.h LilaState) — DO NOT REORDER ----
    stack: [STACK_SIZE]i32 = undefined,
    sp: u32 = 0,
    frames: [MAX_FRAMES]Frame = undefined,
    fp: u32 = 0, // number of live frames
    pc: u32 = 0,
    /// v17 RETURN VALUES: the last OP_RET_V's value. THREADLOCAL (part of
    /// the interpreter state, NOT the flat memory image) so it never touches
    /// the snapshot hash chain, and every v10 parallel worker owns one.
    /// Codegen always pairs CALL_FN with an immediate RET_GET in expression
    /// contexts, so the register is consumed before any nested call writes it.
    ret_val: i32 = 0,
    // ---- vm-internal tail (invisible to the C ABI) ----
    iters: [MAX_ITERS]Iter = undefined,
    itr: u32 = 0, // number of live iterators
    halted: bool = false,
    /// v23.1: high cell of a two-cell (f64) return. THREADLOCAL like
    /// ret_val — never touches the snapshot hash chain.
    ret_hi: i32 = 0,
    /// v23.1 TRY/CATCH: handler stack (catch pc, saved sp, saved fp, catch
    /// local slot). THREADLOCAL interpreter state — control-flow metadata
    /// re-derivable from the pc; never part of the flat image, so the
    /// snapshot hash chain is untouched.
    try_sp: u32 = 0,
    try_catch_pc: [8]u32 = .{0} ** 8,
    try_stack_sp: [8]u32 = .{0} ** 8,
    try_frame_fp: [8]u32 = .{0} ** 8,
    try_slot: [8]u32 = .{0} ** 8,
};

const IS_WASM = @import("builtin").cpu.arch.isWasm();
threadlocal var st_thread: State = .{};
var st_single: State = .{};

inline fn st() *State {
    if (IS_WASM) return &st_single;
    return &st_thread;
}

/// v23.5 ABI v2 — the shared-state accessor. AOT-compiled code receives THIS
/// pointer (viewed as the C LilaState struct) and works on the live
/// interpreter state directly; there is no mirror copy anywhere. Threadlocal
/// on native builds, so an AOT fn invoked from a v10 parallel worker touches
/// that worker's state (the v23.2 static mirror was shared across workers —
/// a latent race this design removes by construction).
pub fn statePtr() *State {
    return st();
}

comptime {
    // The C ABI prefix must be exactly LilaState's shape: ret_val directly
    // after pc (the bridge asserts every prefix offset against its own
    // extern LilaState — this catches a prefix reorder inside vm.zig alone).
    const pc_end = @offsetOf(State, "pc") + 4;
    if (@offsetOf(State, "ret_val") != pc_end)
        @compileError("vm.State: ret_val must sit directly after pc (C ABI prefix order)");
    if (@offsetOf(State, "iters") != pc_end + 4)
        @compileError("vm.State: the vm-internal tail must start right after ret_val");
}

// ---------------- v23.1 f64/vec4 helpers ----------------
inline fn mk64(lo: u32, hi: u32) sf.F64 {
    return (@as(u64, hi) << 32) | lo;
}
inline fn push64(v: sf.F64) void {
    push(@bitCast(@as(u32, @truncate(v))));
    push(@bitCast(@as(u32, @truncate(v >> 32))));
}
inline fn f64cmp(comptime f: fn (sf.F64, sf.F64) bool) bool {
    const h2: u32 = @bitCast(pop()); const l2: u32 = @bitCast(pop());
    const h1: u32 = @bitCast(pop()); const l1: u32 = @bitCast(pop());
    return f(mk64(l1, h1), mk64(l2, h2));
}
inline fn fmulLane(a: i32, b: i32) i32 {
    return @truncate((@as(i64, a) * @as(i64, b)) >> 8);
}

/// Relative jump with wrap-safe semantics: a 16-bit sign-extended offset
/// can push the target below 0 (crafted bytecode). The old @intCast
/// panicked in ReleaseSafe (and was UB in ReleaseFast); the hardened
/// contract wraps to a huge pc, which the step() prologue treats as
/// off-the-end -> implicit RET. Deterministic, never a trap — the same
/// soft-landing contract as every other operand mask.
inline fn jumpRel(next: u32, rel: i32) u32 {
    return next +% @as(u32, @bitCast(rel));
}

pub fn resetVm() void {
    st().sp = 0;
    st().fp = 0;
    st().itr = 0;
    st().halted = false;
}

// ---------------- v10: VM state snapshots ----------------
// The interpreter state is threadlocal on native builds, so parallel-system
// workers own their state by construction — no save/restore needed. This
// API remains for hosts/tools that want a full interpreter copy.

pub const VmSnapshot = State;

pub fn snapshot() State {
    return st().*;
}

pub fn restore(s: State) void {
    st().* = s;
}

inline fn push(v: i32) void {
    if (st().sp < STACK_SIZE) {
        st().stack[st().sp] = v;
        st().sp += 1;
    }
}
inline fn pop() i32 {
    if (st().sp > 0) {
        st().sp -= 1;
        return st().stack[st().sp];
    }
    return 0;
}

/// Call a function: args land in locals[0..n]. NOTE: this only PUSHES the
/// frame — running the body goes through `aot_invoke` (installed by the AOT
/// bridge) at the five dispatch sites, or the plain step() loop.
fn callFn(fi: u32, args: []const i32) bool {
    if (st().fp >= MAX_FRAMES) return false;
    if (st().sp + 4 > STACK_SIZE) return false;
    const f = &st().frames[st().fp];
    f.ret_pc = st().pc;
    f.fn_idx = fi;
    f.locals = [_]i32{0} ** MAX_LOCALS;
    for (args, 0..) |a, i| {
        if (i < MAX_LOCALS) f.locals[i] = a;
    }
    st().fp += 1;
    st().pc = c.fnStart(fi);
    return true;
}

/// v23.2 AOT dispatch hook — installed by lila_aot_bridge.zig (see
/// lila_aot_install). Contract: fn `fi`'s frame is ALREADY pushed; run it
/// TO COMPLETION (callees included) and pop it. Tier-1 fns route back to
/// the interpreter loop inside the hook. Null = pure interpreter.
pub var aot_invoke: ?*const fn (fi: u32) callconv(.c) void = null;

/// AOT host hook support: pop the frame the hook's fn just completed.
pub fn pop_frame() void {
    popFrame();
}

/// AOT host hook support: push a call frame from the bridge
/// (lila_call_fn's C-side entry for AOT -> any-fn calls).
pub fn call_fn(fi: u32, args: []const i32) bool {
    return callFn(fi, args);
}

/// Run a function to completion (used by engine for scheduled fns).
pub fn run(fi: u32) void {
    if (st().halted) return;
    const saved_pc = st().pc;
    if (!callFn(fi, &.{})) { st().pc = saved_pc; return; }
    // sentinel: mark this base frame by ret_pc = 0xFFFFFFFE
    st().frames[st().fp - 1].ret_pc = 0xFFFFFFFE;
    // v23.2 AOT: the installed hook runs the fn to completion (C body or
    // bridged interpreter) and pops the frame.
    if (aot_invoke) |inv| {
        inv(fi);
        st().pc = saved_pc;
        return;
    }
    // execute until that frame is popped
    while (st().fp > 0 and !st().halted) {
        step();
    }
    st().pc = saved_pc;
}

/// v19: run a (pure) fn to completion with explicit args and return its
/// value — the TABLE BAKER's engine. The same frame discipline as run():
/// pc saved/restored, sentinel base frame, loop until popped. Reentrancy is
/// the point: the baker calls this at install time AND the spot-verifier
/// calls it from inside probe() mid-frame; both are safe because a pure fn
/// balances the threadlocal stack exactly like every scheduled call does.
pub fn runValue(fi: u32, a0: i32, a1: i32, n: u32) i32 {
    if (st().halted) return st().ret_val;
    var args: [4]i32 = .{ a0, a1, 0, 0 };
    const saved_pc = st().pc;
    // REENTRANT: this is called mid-frame from the spot-verifier (inside
    // OP_CALL_FN, with the caller's frames live). The loop must stop at the
    // ENTRY frame pointer — `fp > 0` (run()'s condition) would run straight
    // through the caller's remaining instructions with a foreign stack. The
    // spot-verify canary caught exactly this on its first run.
    const entry_fp = st().fp;
    if (!callFn(fi, args[0..@min(n, 4)])) {
        st().pc = saved_pc;
        return st().ret_val;
    }
    st().frames[st().fp - 1].ret_pc = 0xFFFFFFFE;
    // v23.2 AOT hook (see run())
    if (aot_invoke) |inv| {
        inv(fi);
        st().pc = saved_pc;
        return st().ret_val;
    }
    while (st().fp > entry_fp and !st().halted) {
        step();
    }
    st().pc = saved_pc;
    return st().ret_val;
}

/// Run an entity fn for one entity handle.
pub fn runEntity(fi: u32, handle: i32) void {
    if (st().halted) return;
    const saved_pc = st().pc;
    if (!callFn(fi, &[1]i32{handle})) { st().pc = saved_pc; return; }
    st().frames[st().fp - 1].ret_pc = 0xFFFFFFFE;
    // v23.2 AOT hook (see run())
    if (aot_invoke) |inv| {
        inv(fi);
        st().pc = saved_pc;
        return;
    }
    while (st().fp > 0 and !st().halted) {
        step();
    }
    st().pc = saved_pc;
}

/// One decoded instruction.
// ---------------- v23.1: debugger accessors (read-only unless written) ----
pub fn dbgReadLocal(slot: u8) i32 {
    if (st().fp == 0) return 0;
    if (slot >= MAX_LOCALS) return 0;
    return st().frames[st().fp - 1].locals[slot];
}

pub fn dbgWriteLocal(slot: u8, value: i32) void {
    if (st().fp == 0) return;
    if (slot >= MAX_LOCALS) return;
    st().frames[st().fp - 1].locals[slot] = value;
}

/// Single-step for host debuggers: run ONE instruction, return the new pc
/// (or -1 when the VM halted).
pub fn dbgStepOne() i32 {
    step();
    if (st().halted or st().fp == 0) return -1;
    return @intCast(st().pc);
}

fn step() void {
    comptime @setEvalBranchQuota(10000); // v11: the opcode switch grew past the 1000 default
    if (st().pc >= c.instr_count) {
        // ran off the end: implicit RET
        popFrame();
        return;
    }
    // v23.1: debugger hot path — ONE well-predicted branch when idle. When
    // a breakpoint is armed it fires on the (fn_idx, pc) pair; trace events
    // are emitted at fn entry. Neither touches the flat image (the hash
    // chain is untouched — breakpoints are read-only; pausing is the
    // host's job via dbgStepOne).
    const dbg = @import("lila_debug.zig");
    if (dbg.hook_enabled) {
        const cur_fn: u32 = if (st().fp > 0) st().frames[st().fp - 1].fn_idx else 0;
        if (dbg.check_breakpoint_hit(cur_fn, st().pc)) {
            dbg.paused = true;
        }
        if (dbg.trace_callback != null and !dbg.was_in_fn(cur_fn)) {
            var name_buf: [16]u8 = undefined;
            const name = std.fmt.bufPrint(&name_buf, "fn{d}", .{cur_fn}) catch "fn";
            dbg.emit_trace(.begin, name);
            dbg.note_fn_entry(cur_fn);
        }
    }
    const op = c.iOp(st().pc);
    const a = c.iA(st().pc);
    const b = c.iB(st().pc);
    const cc = c.iC(st().pc);
    const next = st().pc + 1;
    dispatch(op, a, b, cc, next);
}

/// Execute ONE instruction with explicit operands. This is the interpreter's
/// opcode handler table, callable from outside the fetch/decode loop:
///
///   * The AOT bridge (lila_aot_bridge.zig) routes every machinery opcode
///     (spawn / for-loops / pools / signals / dist-near / ...) through here
///     after syncing the C-side LilaState mirror, so the AOT path can never
///     drift from the interpreter's semantics — it IS the interpreter.
///   * Differential tests drive both paths with the same operands and
///     compare the full State.
///
/// CONTRACT: st().pc must point at the instruction being executed BEFORE the
/// call — handlers read iExtra(st().pc) (spawn tf lists, dist-near fields),
/// cover.branch() sites, and jump-relative targets off it. Handlers that
/// jump set st().pc themselves and return early; all others fall through to
/// `st().pc = next` at the end.
pub fn dispatch(op: u8, a: i32, b: i32, cc: i32, next: u32) void {
    comptime @setEvalBranchQuota(10000); // the opcode switch grew past the 1000 default
    switch (op) {
        c.OP_NOP => {},
        c.OP_PUSH_S8 => push(a),
        c.OP_PUSH_POOL => {
            const pi = @as(u32, @bitCast(a)) & 0xFFFF;
            push(@bitCast(c.rd32(c.ADDR_POOL + pi * 4)));
        },
        c.OP_LD_LOCAL => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @intCast(@as(u32, @bitCast(a)) & 0xFF);
            push(if (slot < MAX_LOCALS) fr.locals[slot] else 0);
        },
        c.OP_ST_LOCAL => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const v = pop();
            if (slot < MAX_LOCALS) fr.locals[slot] = v;
        },
        c.OP_LD_GLBL => {
            // v23.1: schema-width-aware — a 64-bit field (f64) pushes TWO
            // cells (low first, matching the F64Lit two-cell convention).
            const tf: u32 = @intCast(@as(u32, @bitCast(a)));
            if (tf < c.n_tfs and (c.tfBits(tf) & 0x7F) > 32) {
                const raw = ent.globalLoad64(tf);
                push(@bitCast(@as(u32, @truncate(raw))));
                push(@bitCast(@as(u32, @truncate(raw >> 32))));
            } else {
                push(ent.globalLoad(tf));
            }
        },
        c.OP_ST_GLBL => {
            // v23.1: 64-bit counterpart — pops TWO cells (top = high).
            const tf: u32 = @intCast(@as(u32, @bitCast(a)));
            if (tf < c.n_tfs and (c.tfBits(tf) & 0x7F) > 32) {
                const hi: u32 = @bitCast(pop());
                const lo: u32 = @bitCast(pop());
                ent.globalStore64(tf, (@as(u64, hi) << 32) | lo);
            } else {
                const v = pop();
                ent.globalStore(tf, v);
            }
        },
        c.OP_LD_ENT => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const tf: u32 = @as(u32, @bitCast(b)) & 0xFFFF;
            const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
            // v23.1: 64-bit fields (f64) push TWO cells (low first).
            if (tf < c.n_tfs and (c.tfBits(tf) & 0x7F) > 32) {
                const raw = ent.fieldLoad64(tf, @bitCast(handle));
                push(@bitCast(@as(u32, @truncate(raw))));
                push(@bitCast(@as(u32, @truncate(raw >> 32))));
            } else {
                push(ent.fieldLoad(tf, @bitCast(handle)));
            }
        },
        c.OP_ST_ENT => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const tf: u32 = @as(u32, @bitCast(b)) & 0xFFFF;
            // v23.1: 64-bit counterpart — pops TWO cells (top = high).
            if (tf < c.n_tfs and (c.tfBits(tf) & 0x7F) > 32) {
                const hi: u32 = @bitCast(pop());
                const lo: u32 = @bitCast(pop());
                const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
                ent.fieldStore64(tf, @bitCast(handle), (@as(u64, hi) << 32) | lo);
            } else {
                const v = pop();
                const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
                ent.fieldStore(tf, @bitCast(handle), v);
            }
        },
        c.OP_ADD_F, c.OP_ADD_I => {
            const y = pop(); const x = pop();
            push(x +% y);
        },
        c.OP_SUB_F, c.OP_SUB_I => {
            const y = pop(); const x = pop();
            push(x -% y);
        },
        c.OP_MUL_F => {
            const y = pop(); const x = pop();
            push(c.mulF(x, y));
        },
        c.OP_MUL_I => {
            const y = pop(); const x = pop();
            push(x *% y);
        },
        c.OP_DIV_F => {
            const y = pop(); const x = pop();
            push(c.divF(x, y));
        },
        c.OP_DIV_I => {
            const y = pop(); const x = pop();
            // v23.2: INT_MIN / -1 overflowed @divTrunc's safety check
            // (ReleaseSafe panic — the soft-land contract says crafted OR
            // GAME-DRIVEN values never trap). Wrap convention: the quotient
            // stays INT_MIN, matching x86 idiv's two's-complement result.
            if (y == 0) {
                push(0);
            } else if (y == -1 and x == std.math.minInt(i32)) {
                push(x);
            } else {
                push(@divTrunc(x, y));
            }
        },
        c.OP_MOD_I => {
            const y = pop(); const x = pop();
            if (y == 0) { push(0); } else { push(@rem(x, y)); }
        },
        c.OP_AND_I => { const y = pop(); const x = pop(); push(x & y); },
        c.OP_OR_I => { const y = pop(); const x = pop(); push(x | y); },
        c.OP_XOR_I => { const y = pop(); const x = pop(); push(x ^ y); },
        c.OP_SHL => {
            const y = pop(); const x = pop();
            const sh: u5 = @intCast(@as(u32, @bitCast(y)) & 31);
            push(x << sh);
        },
        c.OP_SHR => {
            const y = pop(); const x = pop();
            const sh: u5 = @intCast(@as(u32, @bitCast(y)) & 31);
            push(x >> sh);
        },
        c.OP_AND_B => { const y = pop(); const x = pop(); push(@intFromBool((x != 0) and (y != 0))); },
        c.OP_OR_B => { const y = pop(); const x = pop(); push(@intFromBool((x != 0) or (y != 0))); },
        c.OP_NOT_B => { const x = pop(); push(@intFromBool(x == 0)); },
        c.OP_NEG => { const x = pop(); push(-%x); },
        c.OP_EQ_F, c.OP_EQ_I => { const y = pop(); const x = pop(); push(@intFromBool(x == y)); },
        c.OP_NE_F, c.OP_NE_I => { const y = pop(); const x = pop(); push(@intFromBool(x != y)); },
        c.OP_LT_F, c.OP_LT_I => { const y = pop(); const x = pop(); push(@intFromBool(x < y)); },
        c.OP_GT_F, c.OP_GT_I => { const y = pop(); const x = pop(); push(@intFromBool(x > y)); },
        c.OP_LE_F, c.OP_LE_I => { const y = pop(); const x = pop(); push(@intFromBool(x <= y)); },
        c.OP_GE_F, c.OP_GE_I => { const y = pop(); const x = pop(); push(@intFromBool(x >= y)); },
        c.OP_SIN => { const x = pop(); push(c.sinA(x)); },
        c.OP_COS => { const x = pop(); push(c.cosA(x)); },
        c.OP_RAND_MAX => { const m = pop(); push(c.randMax(m)); },
        c.OP_ANIM => {
            const t = pop();
            push(evalAnim(@as(u32, @bitCast(a)) & 0xFFFF, t));
        },
        c.OP_KEY => {
            const input = c.rd32(c.ADDR_INPUT);
            const k: u5 = @intCast(@as(u32, @bitCast(a)) & 31);
            push(@intFromBool((input >> k) & 1 != 0));
        },
        c.OP_JMP => { st().pc = jumpRel(next, a); return; },
        c.OP_JZ => {
            const v = pop();
            cover.branch(st().pc, v == 0);
            if (v == 0) { st().pc = jumpRel(next, a); return; }
        },
        c.OP_JNZ => {
            const v = pop();
            cover.branch(st().pc, v != 0);
            if (v != 0) { st().pc = jumpRel(next, a); return; }
        },
        c.OP_FOR_BGN => {
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const slot: u32 = @as(u32, @bitCast(b)) & 0xFF;
            if (st().itr >= MAX_ITERS) {
                cover.branch(st().pc, false);
                st().pc = jumpRel(next, cc);
                return;
            }
            const idx = ent.nextLive(t, 0);
            if (idx == NO_IDX) {
                cover.branch(st().pc, false);
                st().pc = jumpRel(next, cc);
                return;
            }
            cover.branch(st().pc, true);
            st().iters[st().itr] = .{ .typ = t, .next_bit = idx + 1, .slot = slot };
            st().itr += 1;
            const fr = &st().frames[st().fp - 1];
            if (slot < MAX_LOCALS) fr.locals[slot] = @bitCast((@as(u32, ent.genOf(t, idx)) << 20) | idx);
        },
        c.OP_FOR_ADV => {
            if (st().itr == 0) { cover.branch(st().pc, false); st().pc = jumpRel(next, a); return; }
            const it = &st().iters[st().itr - 1];
            const idx = ent.nextLive(it.typ, it.next_bit);
            if (idx == NO_IDX) {
                st().itr -= 1; // loop done: fall through (exit)
            } else {
                cover.branch(st().pc, true);
                it.next_bit = idx + 1;
                // find the FOR_BGN's slot operand: stored in the b of the loop head.
                // We re-derive: the local slot was set by FOR_BGN; keep a parallel
                // slot record in the iterator.
                const fr = &st().frames[st().fp - 1];
                if (it.slot < MAX_LOCALS) {
                    fr.locals[it.slot] = @bitCast((@as(u32, ent.genOf(it.typ, idx)) << 20) | idx);
                }
                st().pc = jumpRel(next, a);
                return;
            }
        },
        c.OP_SPAWN => {
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const n: u32 = @as(u32, @bitCast(b)) & 0xFF;
            const handle = ent.spawn(t);
            if (handle != NO_IDX) {
                ent.applyDefaults(t, handle);
                // extra tf list at ADDR_EXTRA + extra_off*2
                const ex = c.ADDR_EXTRA + c.iExtra(st().pc) * 2;
                // v23.1: the stack payload is per-CELL (b = total cells —
                // a 64-bit field consumes TWO, lo then hi) while the tf
                // list is per-FIELD. The walk consumes 1 or 2 cells per
                // field by schema width; legacy carts (one cell per field)
                // encode and behave identically.
                var cells: u32 = 0;
                var k: u32 = 0;
                // v14: a crafted arg count could read below the stack base
                // (u32 wrap -> OOB panic) — reads index from a SATURATING
                // base instead (in-bounds garbage for crafted counts, the
                // same soft-land philosophy).
                const base: u32 = st().sp -| n;
                while (cells < n) : (k += 1) {
                    const tf = c.rd16(ex + k * 2);
                    if (tf < c.n_tfs and (c.tfBits(tf) & 0x7F) > 32) {
                        // v23.1 FIX: the hi guard demanded `sp >= n + 1` —
                        // one cell MORE than the compiler ever pushes — so
                        // every f64 spawn field silently wrote 0.0. hi is
                        // cell `cells+1` of n, valid while cells+1 < n.
                        const lo: i32 = st().stack[base + cells];
                        const hi: i32 = if (cells + 1 < n) st().stack[base + cells + 1] else 0;
                        ent.fieldStore64(tf, handle, (@as(u64, @as(u32, @bitCast(hi))) << 32) | @as(u64, @as(u32, @bitCast(lo))));
                        cells += 2;
                    } else {
                        const v: i32 = st().stack[base + cells];
                        ent.fieldStore(tf, handle, v);
                        cells += 1;
                    }
                }
                st().sp -|= n;
            } else {
                st().sp -|= n;
            }
        },
        c.OP_KILL => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const t: u32 = @as(u32, @bitCast(b)) & 0xFF;
            const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
            const h: u32 = @bitCast(handle);
            ent.kill(t, h & 0xFFFFF);
        },
        // ---------------- v20: f32 (software IEEE binary32) ----------------
        // Values are raw bit patterns on the stack; softfloat.zig does the
        // correctly-rounded integer math. NaN is canonical (0x7FC00000),
        // comparisons follow IEEE unordered semantics.
        c.OP_F32_ADD => { const yv = pop(); const xv = pop(); push(@bitCast(sf.add(@bitCast(xv), @bitCast(yv)))); },
        c.OP_F32_SUB => { const yv = pop(); const xv = pop(); push(@bitCast(sf.sub(@bitCast(xv), @bitCast(yv)))); },
        c.OP_F32_MUL => { const yv = pop(); const xv = pop(); push(@bitCast(sf.mul(@bitCast(xv), @bitCast(yv)))); },
        c.OP_F32_DIV => { const yv = pop(); const xv = pop(); push(@bitCast(sf.div(@bitCast(xv), @bitCast(yv)))); },
        c.OP_F32_SQRT => { const xv = pop(); push(@bitCast(sf.sqrt(@bitCast(xv)))); },
        c.OP_F32_EQ => { const yv = pop(); const xv = pop(); push(if (sf.eq(@bitCast(xv), @bitCast(yv))) 1 else 0); },
        c.OP_F32_NE => { const yv = pop(); const xv = pop(); push(if (sf.eq(@bitCast(xv), @bitCast(yv))) 0 else 1); },
        c.OP_F32_LT => { const yv = pop(); const xv = pop(); push(if (sf.lt(@bitCast(xv), @bitCast(yv))) 1 else 0); },
        c.OP_F32_GT => { const yv = pop(); const xv = pop(); push(if (sf.lt(@bitCast(yv), @bitCast(xv))) 1 else 0); },
        c.OP_F32_LE => { const yv = pop(); const xv = pop(); push(if (sf.le(@bitCast(xv), @bitCast(yv))) 1 else 0); },
        c.OP_F32_GE => { const yv = pop(); const xv = pop(); push(if (sf.le(@bitCast(yv), @bitCast(xv))) 1 else 0); },
        c.OP_I2F32 => { const xv = pop(); push(@bitCast(sf.fromI32(xv))); },
        c.OP_F322I => { const xv = pop(); push(sf.toI32(@bitCast(xv))); },
        c.OP_FIX2F32 => { const xv = pop(); push(@bitCast(sf.fromFix(xv))); },
        c.OP_F322FIX => { const xv = pop(); push(sf.toFix(@bitCast(xv))); },

        // ---------------- v23.1: f64 (two-cell convention, low first) --------
        // Every operand pops (hi, lo); every result pushes (lo, hi). The
        // binary64 softfloat core is correctly rounded (RNE, subnormals
        // exact, canonical NaN), so these ops are bit-identical to hardware
        // IEEE on every conformant target.
        c.OP_F64_ADD => {
            const h2: u32 = @bitCast(pop()); const l2: u32 = @bitCast(pop());
            const h1: u32 = @bitCast(pop()); const l1: u32 = @bitCast(pop());
            push64(sf.f64_add(mk64(l1, h1), mk64(l2, h2)));
        },
        c.OP_F64_SUB => {
            const h2: u32 = @bitCast(pop()); const l2: u32 = @bitCast(pop());
            const h1: u32 = @bitCast(pop()); const l1: u32 = @bitCast(pop());
            push64(sf.f64_sub(mk64(l1, h1), mk64(l2, h2)));
        },
        c.OP_F64_MUL => {
            const h2: u32 = @bitCast(pop()); const l2: u32 = @bitCast(pop());
            const h1: u32 = @bitCast(pop()); const l1: u32 = @bitCast(pop());
            push64(sf.f64_mul(mk64(l1, h1), mk64(l2, h2)));
        },
        c.OP_F64_DIV => {
            const h2: u32 = @bitCast(pop()); const l2: u32 = @bitCast(pop());
            const h1: u32 = @bitCast(pop()); const l1: u32 = @bitCast(pop());
            push64(sf.f64_div(mk64(l1, h1), mk64(l2, h2)));
        },
        c.OP_F64_SQRT => {
            const h: u32 = @bitCast(pop()); const l: u32 = @bitCast(pop());
            push64(sf.f64_sqrt(mk64(l, h)));
        },
        c.OP_F64_EQ => push(if (f64cmp(sf.f64_eq)) 1 else 0),
        c.OP_F64_NE => push(if (f64cmp(sf.f64_ne)) 1 else 0),
        c.OP_F64_LT => push(if (f64cmp(sf.f64_lt)) 1 else 0),
        c.OP_F64_GT => push(if (f64cmp(sf.f64_gt)) 1 else 0),
        c.OP_F64_LE => push(if (f64cmp(sf.f64_le)) 1 else 0),
        c.OP_F64_GE => push(if (f64cmp(sf.f64_ge)) 1 else 0),
        c.OP_I2F64 => { const xv = pop(); push64(sf.i2f64(xv)); },
        c.OP_F642I => { const h: u32 = @bitCast(pop()); const l: u32 = @bitCast(pop()); push(sf.f642i(mk64(l, h))); },
        c.OP_FIX2F64 => { const xv = pop(); push64(sf.fix2f64(xv)); },
        c.OP_F642FIX => { const h: u32 = @bitCast(pop()); const l: u32 = @bitCast(pop()); push(sf.f642fix(mk64(l, h))); },
        c.OP_F322F64 => { const xv: u32 = @bitCast(pop()); push64(sf.f322f64(xv)); },
        c.OP_F642F32 => { const h: u32 = @bitCast(pop()); const l: u32 = @bitCast(pop()); push(@bitCast(sf.f642f32(mk64(l, h)))); },

        // ---------------- v23.1: vec4 (v23 STEP 5 opcodes, now wired) --------
        // vec4u8 lanes pack into ONE cell: x | y<<8 | z<<16 | w<<24.
        // vec4fixed lanes are FOUR stacked Q24.8 cells pushed x,y,z,w (x
        // deepest). Lane math wraps exactly like the scalar ops.
        c.OP_VEC4F_ADD => {
            const w2 = pop(); const z2 = pop(); const y2 = pop(); const x2 = pop();
            const w1 = pop(); const z1 = pop(); const y1 = pop(); const x1 = pop();
            push(x1 +% x2); push(y1 +% y2); push(z1 +% z2); push(w1 +% w2);
        },
        c.OP_VEC4F_SUB => {
            const w2 = pop(); const z2 = pop(); const y2 = pop(); const x2 = pop();
            const w1 = pop(); const z1 = pop(); const y1 = pop(); const x1 = pop();
            push(x1 -% x2); push(y1 -% y2); push(z1 -% z2); push(w1 -% w2);
        },
        c.OP_VEC4F_MUL => {
            // per-lane Q24.8 multiply: (a * b) >> 8 on i64, wrapping cast
            const w2 = pop(); const z2 = pop(); const y2 = pop(); const x2 = pop();
            const w1 = pop(); const z1 = pop(); const y1 = pop(); const x1 = pop();
            push(fmulLane(x1, x2)); push(fmulLane(y1, y2));
            push(fmulLane(z1, z2)); push(fmulLane(w1, w2));
        },
        c.OP_VEC4F_DOT => {
            // sum of per-lane Q24.8 products -> one fixed cell
            const w2 = pop(); const z2 = pop(); const y2 = pop(); const x2 = pop();
            const w1 = pop(); const z1 = pop(); const y1 = pop(); const x1 = pop();
            const acc: i64 =
                (@as(i64, x1) * @as(i64, x2)) +
                (@as(i64, y1) * @as(i64, y2)) +
                (@as(i64, z1) * @as(i64, z2)) +
                (@as(i64, w1) * @as(i64, w2));
            push(@truncate(acc >> 8));
        },
        c.OP_VEC4U_ADD => {
            // per-lane u8 wrapping add on the packed cell
            const vb = pop(); const va = pop();
            const ax: u32 = @bitCast(va); const bx: u32 = @bitCast(vb);
            const r: u32 =
                (((ax & 0xFF) +% (bx & 0xFF)) & 0xFF) |
                ((((ax >> 8) & 0xFF) +% ((bx >> 8) & 0xFF)) & 0xFF) << 8 |
                ((((ax >> 16) & 0xFF) +% ((bx >> 16) & 0xFF)) & 0xFF) << 16 |
                ((((ax >> 24) & 0xFF) +% ((bx >> 24) & 0xFF)) & 0xFF) << 24;
            push(@bitCast(r));
        },
        c.OP_VEC4U_PACK => {
            // stack pushes x,y,z,w -> top is w
            const w = pop(); const z = pop(); const y = pop(); const x = pop();
            const r: u32 = (@as(u32, @bitCast(x)) & 0xFF) |
                (@as(u32, @bitCast(y)) & 0xFF) << 8 |
                (@as(u32, @bitCast(z)) & 0xFF) << 16 |
                (@as(u32, @bitCast(w)) & 0xFF) << 24;
            push(@bitCast(r));
        },
        c.OP_VEC4U_UNPACK => {
            // pops the packed cell, pushes x,y,z,w (x deepest)
            const v: u32 = @bitCast(pop());
            push(@bitCast(v & 0xFF));
            push(@bitCast((v >> 8) & 0xFF));
            push(@bitCast((v >> 16) & 0xFF));
            push(@bitCast((v >> 24) & 0xFF));
        },
        c.OP_DROP => { _ = pop(); },

        // ---------------- v23.1: try/catch/throw ----------------
        c.OP_TRY => {
            // a = relative offset to the catch handler; b = catch-var local
            // slot. Registers a handler (bounded stack of 8; overflow
            // soft-lands by ignoring the registration — the catch simply
            // never fires for that try, matching the denial philosophy).
            if (st().try_sp < 8) {
                st().try_catch_pc[st().try_sp] = jumpRel(next, a);
                st().try_stack_sp[st().try_sp] = st().sp;
                st().try_frame_fp[st().try_sp] = st().fp;
                st().try_slot[st().try_sp] = @as(u32, @bitCast(b)) & 0xFF;
                st().try_sp += 1;
            }
        },
        c.OP_TRY_END => {
            // normal completion of a try body: drop the handler
            if (st().try_sp > 0) st().try_sp -= 1;
        },
        c.OP_THROW => {
            // pop the error value; unwind to the nearest handler (restoring
            // sp/fp discards any partial state the try body left behind),
            // land on the catch pc with the error pushed for ST_LOCAL.
            // No handler anywhere: soft-land as an early fn return.
            const err = pop();
            if (st().try_sp > 0) {
                st().try_sp -= 1;
                st().sp = st().try_stack_sp[st().try_sp];
                st().fp = st().try_frame_fp[st().try_sp];
                st().pc = st().try_catch_pc[st().try_sp];
                push(err);
                return; // pc set above — skip the default pc = next
            }
            cover.edge(st().pc, 0);
            popFrame();
            return; // st().pc set by popFrame
        },

        // ---------------- v20: aggregates + signals ----------------
        c.OP_AGG => {
            // LINQ Sum/Min/Max as one engine-side scan: no per-entity VM
            // dispatch, i64 accumulate, deterministic slot order. Empty set:
            // sum 0, min 0x7FFFFFFF, max -2147483648 (sentinel convention).
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const mode: u32 = @as(u32, @bitCast(b)) & 0xFF;
            const ex = c.ADDR_EXTRA + c.iExtra(st().pc) * 2;
            const tf = c.rd16(ex);
            var acc: i64 = switch (mode) {
                1 => 0x7FFFFFFF, // min sentinel
                2 => -2147483648, // max sentinel
                else => 0, // sum
            };
            var idx = ent.nextLive(t, 0);
            while (idx != NO_IDX) {
                const h: u32 = (@as(u32, ent.genOf(t, idx)) << 20) | idx;
                const v: i32 = ent.fieldLoad(tf, h);
                switch (mode) {
                    0 => acc += v,
                    1 => { if (v < acc) acc = v; },
                    else => { if (v > acc) acc = v; },
                }
                idx = ent.nextLive(t, idx + 1);
            }
            push(@intCast(acc));
        },
        // ---------------- v21: engine fundamentals ----------------
        c.OP_PSORT => {
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const pf: u32 = @as(u32, @bitCast(b)) & 0xFFFF;
            const dir: u32 = @as(u32, @bitCast(cc)) & 0xFF;
            vm21.psort(t, pf, dir);
        },
        c.OP_M_PUT => {
            // stack: key, val (pushed in source order)
            const d: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const val: u32 = @bitCast(pop());
            const key: u32 = @bitCast(pop());
            vm21.mapPut(d, key, val);
        },
        c.OP_M_GET => {
            const d: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const key: u32 = @bitCast(pop());
            push(@bitCast(vm21.mapGet(d, key)));
        },
        c.OP_M_DEL => {
            const d: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const key: u32 = @bitCast(pop());
            vm21.mapDel(d, key);
        },
        c.OP_M_LEN => {
            const d: u32 = @as(u32, @bitCast(a)) & 0xFF;
            push(if (d < c.n_dicts) @bitCast(c.rd32(c.dict_base[d])) else 0);
        },
        c.OP_RAY => {
            // a = grid array id; stack: gw, gh, x, y, ang, maxd (pops reversed)
            const gid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const maxd = pop();
            const ang = pop();
            const y = pop();
            const x = pop();
            const gh = pop();
            const gw = pop();
            push(vm21.ray(gid, gw, gh, x, y, ang, maxd));
        },
        c.OP_RAY_X => {
            const packed_cell = c.rd32(c.ADDR_RAY_CELL);
            push(@bitCast(packed_cell >> 16));
        },
        c.OP_RAY_Y => {
            const packed_cell = c.rd32(c.ADDR_RAY_CELL);
            push(@bitCast(packed_cell & 0xFFFF));
        },
        c.OP_ASTAR => {
            // a = grid array, b = path array; stack: gw, gh, sx, sy, tx, ty
            const gid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const pid: u32 = @as(u32, @bitCast(b)) & 0xFF;
            const ty = pop();
            const tx = pop();
            const sy = pop();
            const sx = pop();
            const gh = pop();
            const gw = pop();
            push(vm21.astar(gid, pid, gw, gh, sx, sy, tx, ty));
        },
        c.OP_FRAME => {
            push(@bitCast(c.rd32(c.ADDR_FRAME)));
        },
        c.OP_DRAW_NUMZ => {
            const rgba = pop();
            const y = pop();
            const x = pop();
            const val = pop();
            render.drawNumZ(val, @as(u32, @bitCast(a)) & 0xF, x, y, @bitCast(rgba));
        },

        // ---------------- v22: deterministic collections ----------------
        c.OP_NOISE1 => {
            const t = pop();
            push(vm22.noise1(t));
        },
        c.OP_NOISE2 => {
            // stack: x, y (pops reversed)
            const y = pop();
            const x = pop();
            push(vm22.noise2(x, y));
        },
        c.OP_M_NEXT => {
            const d: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const cursor: u32 = @bitCast(pop());
            push(vm22.mnext(d, cursor));
        },
        c.OP_M_NEXT_V => {
            push(@bitCast(c.rd32(c.ADDR_MN_VAL)));
        },
        c.OP_M_NEXT_C => {
            push(@bitCast(c.rd32(c.ADDR_MN_CUR)));
        },
        c.OP_QPUSH => {
            const gid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const val: u32 = @bitCast(pop());
            vm22.qpush(gid, val);
        },
        c.OP_QPOP => {
            push(@bitCast(vm22.qpop(@as(u32, @bitCast(a)) & 0xFF)));
        },
        c.OP_QLEN => {
            push(@bitCast(vm22.ringLen(@as(u32, @bitCast(a)) & 0xFF)));
        },
        c.OP_SPUSH => {
            const gid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const val: u32 = @bitCast(pop());
            vm22.spush(gid, val);
        },
        c.OP_SPOP => {
            push(@bitCast(vm22.spop(@as(u32, @bitCast(a)) & 0xFF)));
        },
        c.OP_SLEN => {
            push(@bitCast(vm22.ringLen(@as(u32, @bitCast(a)) & 0xFF)));
        },
        c.OP_SPEEK => {
            push(@bitCast(vm22.speek(@as(u32, @bitCast(a)) & 0xFF)));
        },
        c.OP_AFILL => {
            const gid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const val: u32 = @bitCast(pop());
            vm22.afill(gid, val);
        },
        c.OP_ACOPY => {
            const dst: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const src: u32 = @as(u32, @bitCast(b)) & 0xFF;
            const n = pop();
            vm22.acopy(dst, src, n);
        },
        c.OP_ASHUF => {
            const gid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const n = pop();
            vm22.ashuffle(gid, n);
        },
        c.OP_AFIND => {
            const gid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const val: u32 = @bitCast(pop());
            push(vm22.afind(gid, val));
        },
        c.OP_ACOUNT => {
            const gid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const val: u32 = @bitCast(pop());
            push(@bitCast(vm22.acount(gid, val)));
        },

        // ---------------- v20: pools (dynamic side tables) ----------------
        c.OP_PL_PUSH => {
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            // v23.6: b counts CELLS (f64 fields carry two) — the drain and
            // the defensive sp math use it; c is the LISTED-FIELD count
            // (the extra word list length). For legacy 1-cell fields
            // cells == values, so the encoding is byte-identical.
            const n: u32 = @as(u32, @bitCast(b)) & 0xFF;
            // v23.6: c = the LISTED-FIELD count. Legacy carts (<= v23.5)
            // encoded the count in b and left c = 0 — fall back for them.
            const nf_listed: u32 = blk: {
                const cc_v: u32 = @as(u32, @bitCast(cc)) & 0xFF;
                break :blk if (cc_v == 0) n else cc_v;
            };
            if (t >= c.n_pools) {
                st().sp -|= n; // defensive: schema guarantees the pool exists
            } else {
                const base = c.pool_base[t];
                const cap: u32 = c.pool_cap[t];
                const count = c.rd32(base);
                if (count >= cap) {
                    // deny like an entity spawn budget: drop the row, count it
                    c.pool_denied_total += 1;
                    st().sp -|= n;
                } else {
                    const ex = c.ADDR_EXTRA + c.iExtra(st().pc) * 2;
                    const nf = @as(u32, c.pool_nfields[t]);
                    // defaults for every field NOT in the init list
                    // (width-aware: an f64 default zeroes both cells)
                    var listed: u32 = 0;
                    var j: u32 = 0;
                    while (j < nf_listed) : (j += 1) {
                        const pf = c.rd16(ex + j * 2);
                        if (pf < 16) listed |= @as(u32, 1) << @intCast(pf & 15);
                    }
                    var f: u32 = 0;
                    while (f < nf) : (f += 1) {
                        if (listed & (@as(u32, 1) << @intCast(f)) == 0) {
                            const fb = c.poolFieldBase(t, f) + count * 4;
                            c.wr32(fb, @bitCast(c.pool_defaults[t][f]));
                            if (c.pool_fw[t][f] == 2) c.wr32(fb + 4, 0); // f64 hi cell (+0.0)
                        }
                    }
                    // init values (source order, guarded pops mirror SPAWN).
                    // v23.6: walk the listed fields with a running CELL offset
                    // — an f64 field consumes (lo, hi) from the block. The
                    // block's bottom sits at sp - n (push order = field order),
                    // so field j's lo cell is at sp - n + off; for legacy
                    // 1-cell fields off == j and the address matches v20.
                    var off: u32 = 0;
                    j = 0;
                    while (j < nf_listed) : (j += 1) {
                        const pf = c.rd16(ex + j * 2);
                        const w: u32 = if (pf < c.MAX_PFIELDS) c.pool_fw[t][pf] else 1;
                        const fb = c.poolFieldBase(t, pf) + count * 4;
                        const lo: i32 = if (st().sp >= n) st().stack[st().sp - n + off] else 0;
                        c.wr32(fb, @bitCast(lo));
                        if (w == 2) {
                            const hi: i32 = if (st().sp >= n) st().stack[st().sp - n + off + 1] else 0;
                            c.wr32(fb + 4, @bitCast(hi));
                            off += 2;
                        } else {
                            off += 1;
                        }
                    }
                    st().sp -|= n;
                    c.wr32(base, count + 1);
                }
            }
        },
        c.OP_PL_REM => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const t: u32 = @as(u32, @bitCast(b)) & 0xFF;
            const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
            const h: u32 = @bitCast(handle);
            if (t < c.n_pools) {
                const base = c.pool_base[t];
                const count = c.rd32(base);
                const idx = h & 0xFFFFF;
                const gen = (h >> 20) & 0xFFF;
                const gens = c.poolGens(t);
                if (idx < count and (c.rd16(gens + idx * 2) & 0xFFF) == gen) {
                    const last = count - 1;
                    const nf = @as(u32, c.pool_nfields[t]);
                    if (idx != last) {
                        // swap-remove: the last row moves into the hole; both
                        // gens bump so stale handles to either index die.
                        // v23.6: width-aware — an f64 field copies both cells.
                        var f: u32 = 0;
                        while (f < nf) : (f += 1) {
                            const fb = c.poolFieldBase(t, f);
                            c.wr32(fb + idx * 4, c.rd32(fb + last * 4));
                            if (c.pool_fw[t][f] == 2) {
                                c.wr32(fb + idx * 4 + 4, c.rd32(fb + last * 4 + 4));
                                c.wr32(fb + last * 4, 0);
                                c.wr32(fb + last * 4 + 4, 0);
                            }
                        }
                        c.wr16(gens + last * 2, (c.rd16(gens + last * 2) + 1) & 0xFFF);
                    }
                    c.wr16(gens + idx * 2, (c.rd16(gens + idx * 2) + 1) & 0xFFF);
                    c.wr32(base, last);
                }
                // stale handle or bad pool: no-op (soft-land, like kill)
            }
        },
        c.OP_PL_LEN => {
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const v: i32 = if (t < c.n_pools) @bitCast(c.rd32(c.pool_base[t])) else 0;
            push(v);
        },
        c.OP_PL_LD => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const pf: u32 = @as(u32, @bitCast(b)) & 0xFFFF;
            const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
            const h: u32 = @bitCast(handle);
            const t = pf >> 4;
            const f = pf & 15;
            var v: i32 = 0;
            if (t < c.n_pools) {
                const base = c.pool_base[t];
                const count = c.rd32(base);
                const idx = h & 0xFFFFF;
                const gen = (h >> 20) & 0xFFF;
                if (idx < count and (c.rd16(c.poolGens(t) + idx * 2) & 0xFFF) == gen)
                    v = @bitCast(c.rd32(c.poolFieldBase(t, f) + idx * 4));
            }
            push(v); // stale handle reads 0 — the entity-field contract
        },
        c.OP_PL_ST => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const pf: u32 = @as(u32, @bitCast(b)) & 0xFFFF;
            const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
            const h: u32 = @bitCast(handle);
            const t = pf >> 4;
            const f = pf & 15;
            if (t < c.n_pools) {
                const base = c.pool_base[t];
                const count = c.rd32(base);
                const idx = h & 0xFFFFF;
                const gen = (h >> 20) & 0xFFF;
                if (idx < count and (c.rd16(c.poolGens(t) + idx * 2) & 0xFFF) == gen) {
                    const v = pop();
                    c.wr32(c.poolFieldBase(t, f) + idx * 4, @bitCast(v));
                } else {
                    _ = pop(); // stale: value still popped (stack discipline)
                }
            } else {
                _ = pop();
            }
        },
        // ---------------- v23.6: f64 pool fields (wire v7) ----------------
        // Same operand encoding as PL_LD/PL_ST (a=handle slot, b=pfield);
        // the field's width comes from the pool schema (tag 5 = f64, two
        // cell planes). The WIDTH TEST comes first so every path drains
        // exactly what was pushed — the same discipline as ST_GARR wide.
        c.OP_PL_LD64 => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const pf: u32 = @as(u32, @bitCast(b)) & 0xFFFF;
            const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
            const h: u32 = @bitCast(handle);
            const t = pf >> 4;
            const f = pf & 15;
            if (t < c.n_pools and c.pool_fw[t][f] == 2) {
                const base = c.pool_base[t];
                const count = c.rd32(base);
                const idx = h & 0xFFFFF;
                const gen = (h >> 20) & 0xFFF;
                if (idx < count and (c.rd16(c.poolGens(t) + idx * 2) & 0xFFF) == gen) {
                    const fb = c.poolFieldBase(t, f) + idx * 4;
                    const lo: u32 = @bitCast(c.rd32(fb));
                    const hi: u32 = @bitCast(c.rd32(fb + 4));
                    push(@bitCast(lo)); push(@bitCast(hi));
                } else {
                    push(0); push(0); // stale handle reads +0.0
                }
            } else {
                push(0); push(0); // wrong-width/absent pool: soft-land +0.0
            }
        },
        c.OP_PL_ST64 => {
            const fr = &st().frames[st().fp - 1];
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const pf: u32 = @as(u32, @bitCast(b)) & 0xFFFF;
            const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
            const h: u32 = @bitCast(handle);
            const t = pf >> 4;
            const f = pf & 15;
            // stack: (lo, hi) pushed — top is hi. Width test first: every
            // path (live, stale, wrong width) drains exactly two cells.
            const hi = pop();
            const lo = pop();
            if (t < c.n_pools and c.pool_fw[t][f] == 2) {
                const base = c.pool_base[t];
                const count = c.rd32(base);
                const idx = h & 0xFFFFF;
                const gen = (h >> 20) & 0xFFF;
                if (idx < count and (c.rd16(c.poolGens(t) + idx * 2) & 0xFFF) == gen) {
                    const fb = c.poolFieldBase(t, f) + idx * 4;
                    c.wr32(fb, @bitCast(lo));
                    c.wr32(fb + 4, @bitCast(hi));
                }
            }
        },
        c.OP_PL_FOR_BGN => {
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const slot: u32 = @as(u32, @bitCast(b)) & 0xFF;
            if (st().itr >= MAX_ITERS or t >= c.n_pools or c.rd32(c.pool_base[t]) == 0) {
                st().pc = jumpRel(next, cc);
                return;
            }
            st().iters[st().itr] = .{ .typ = t, .next_bit = 1, .slot = slot, .is_pool = true };
            st().itr += 1;
            const fr = &st().frames[st().fp - 1];
            const g = c.rd16(c.poolGens(t)) & 0xFFF;
            if (slot < MAX_LOCALS) fr.locals[slot] = @bitCast((@as(u32, g) << 20) | 0);
        },
        c.OP_PL_FOR_ADV => {
            if (st().itr == 0) { st().pc = jumpRel(next, a); return; }
            const it = &st().iters[st().itr - 1];
            if (!it.is_pool or it.typ >= c.n_pools) {
                st().itr -= 1; // defensive: not a pool iterator — treat as done
            } else {
                const count = c.rd32(c.pool_base[it.typ]);
                if (it.next_bit >= count) {
                    st().itr -= 1; // loop done: fall through (exit)
                } else {
                    const idx = it.next_bit;
                    it.next_bit = idx + 1;
                    const fr = &st().frames[st().fp - 1];
                    if (it.slot < MAX_LOCALS) {
                        const g = c.rd16(c.poolGens(it.typ) + idx * 2) & 0xFFF;
                        fr.locals[it.slot] = @bitCast((@as(u32, g) << 20) | idx);
                    }
                    st().pc = jumpRel(next, a);
                    return;
                }
            }
        },
        c.OP_SFX => audio.triggerSfx(@as(u32, @bitCast(a)) & 0xFFFF),
        c.OP_MUSIC => audio.startMusic(@as(u32, @bitCast(a)) & 0xFFFF),
        c.OP_STOP_MUSIC => audio.stopMusic(),
        c.OP_SHAKE => {
            // bump amplitude (overlapping shakes take the max, never cancel)
            const amp: u32 = @as(u32, @bitCast(a)) & 0xFF;
            if (amp > c.rd32(c.ADDR_SHAKE)) c.wr32(c.ADDR_SHAKE, amp);
        },
        // ---------------- v7: camera / persistence / aim math / music vol ----------------
        c.OP_CAMERA => {
            // pop y, x (fixed) — clamp so the viewport stays inside the world
            const y = pop();
            const x = pop();
            const cl = c.clampCam(x, y);
            c.wr32(c.ADDR_CAM_X, @bitCast(cl.x));
            c.wr32(c.ADDR_CAM_Y, @bitCast(cl.y));
        },
        c.OP_MUSIC_VOL => audio.setMusicVol(@as(u32, @bitCast(a)) & 0xFF),
        c.OP_SAVE => {
            // pop value, then slot index — raw 32-bit store, host persists
            const v = pop();
            const ix = pop();
            const slot: u32 = @as(u32, @bitCast(ix)) % c.SRAM_SLOTS;
            c.wr32(c.ADDR_SRAM + slot * 4, @bitCast(v));
            c.sram_dirty = 1;
        },
        c.OP_SAVED => {
            const ix = pop();
            const slot: u32 = @as(u32, @bitCast(ix)) % c.SRAM_SLOTS;
            push(@bitCast(c.rd32(c.ADDR_SRAM + slot * 4)));
        },
        c.OP_DIST => {
            // st().stack: x1 y1 x2 y2 (fixed) -> pop y2 x2 y1 x1
            const y2 = pop();
            const x2 = pop();
            const y1 = pop();
            const x1 = pop();
            push(c.distF(x1, y1, x2, y2));
        },
        c.OP_ATAN2 => {
            // st().stack: dy dx (fixed) -> pop dx then dy
            const dx = pop();
            const dy = pop();
            push(c.atan2ang(dy, dx));
        },
        c.OP_CAM_X => push(@bitCast(c.rd32(c.ADDR_CAM_X))),
        c.OP_CAM_Y => push(@bitCast(c.rd32(c.ADDR_CAM_Y))),
        // ---------------- v8: optimizer-baked physics / AI ----------------
        c.OP_SWEPT => {
            // swept Minkowski interval test (subsystem 3): A moves by
            // (avx, avy) over the frame step, B static. Relative position
            // per axis is linear in t in [0,1]; the axis is hit iff the
            // segment CROSSES zero (r0·r1 < 0) or an endpoint already sits
            // inside (min(|r0|,|r1|) < h) — exact continuous 1D solve,
            // unit-tested against sub-step sampling in opt::physics.
            const hh = pop();
            const hw = pop();
            const by = pop();
            const bx = pop();
            const avy = pop();
            const avx = pop();
            const ay = pop();
            const ax = pop();
            const dx: i64 = @as(i64, bx) - @as(i64, ax);
            const dy: i64 = @as(i64, by) - @as(i64, ay);
            const r1x: i64 = dx - @as(i64, avx);
            const r1y: i64 = dy - @as(i64, avy);
            const hitx = (dx * r1x < 0) or (@min(@abs(dx), @abs(r1x)) < @as(i64, hw));
            const hity = (dy * r1y < 0) or (@min(@abs(dy), @abs(r1y)) < @as(i64, hh));
            push(@intFromBool(hitx and hity));
        },
        c.OP_COLLIDE_MASK => {
            // Galois 32-lane collision mask (subsystem 3): ONE pass over a
            // 32-slot WINDOW of the type, per-lane Chebyshev box test in pure
            // ALU — the resulting immediate bitmask feeds a ctz candidate
            // scan (OP_FOR_MASK_BGN). The exact dist() test still runs on
            // candidates; the mask is a provable SUPERSET of the disk.
            // v9 multi-window: a = type | (window_base/32 << 8); windows
            // tile capacities up to 128 slots (4 windows).
            const cy = pop();
            const cx = pop();
            const au = @as(u32, @bitCast(a));
            const t: u32 = au & 0xFF;
            const base: u32 = ((au >> 8) & 0xFF) * 32;
            const hw: i32 = @bitCast(c.rd32(c.ADDR_POOL + (@as(u32, @bitCast(b)) & 0xFFFF) * 4));
            const hh: i32 = @bitCast(c.rd32(c.ADDR_POOL + (@as(u32, @bitCast(cc)) & 0xFFFF) * 4));
            const ex = c.ADDR_EXTRA + c.iExtra(st().pc) * 2;
            const x_tf: u32 = c.rd16(ex);
            const y_tf: u32 = c.rd16(ex + 2);
            var mask: u32 = 0;
            const top = @min(base + 32, c.maxLive(t));
            var idx: u32 = base;
            while (idx < top) : (idx += 1) {
                if (!ent.isAlive(t, idx)) continue;
                const h: u32 = (@as(u32, ent.genOf(t, idx)) << 20) | idx;
                const x = ent.fieldLoad(x_tf, h);
                const y = ent.fieldLoad(y_tf, h);
                const dx = x -% cx;
                const dy = y -% cy;
                // strict |dx| < hw && |dy| < hh — the SAME L-inf guard the
                // compiler proves sound against the retained exact test
                if (dx < hw and dx > -%hw and dy < hh and dy > -%hh) {
                    mask |= @as(u32, 1) << @intCast(idx - base);
                }
            }
            push(@bitCast(mask));
        },
        c.OP_FOR_MASK_BGN => {
            // ctz-scan entry over an immediate lane mask: pop mask; first set
            // bit = the first candidate slot. mask == 0 -> exit (c is rel).
            // v9: b = type | (window_base/32 << 8) — handles offset by base.
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const bu = @as(u32, @bitCast(b));
            const t: u32 = bu & 0xFF;
            const base: u32 = ((bu >> 8) & 0xFF) * 32;
            const mask: u32 = @bitCast(pop());
            if (st().itr >= MAX_ITERS or mask == 0) {
                cover.branch(st().pc, false);
                st().pc = jumpRel(next, cc);
                return;
            }
            const idx: u32 = base + @ctz(mask);
            cover.branch(st().pc, true);
            st().iters[st().itr] = .{ .typ = t, .next_bit = 0, .slot = slot, .mask = mask & (mask - 1), .base = base };
            st().itr += 1;
            const fr = &st().frames[st().fp - 1];
            if (slot < MAX_LOCALS) fr.locals[slot] = @bitCast((@as(u32, ent.genOf(t, idx)) << 20) | idx);
        },
        c.OP_FOR_MASK_ADV => {
            // next candidate: lowest remaining set bit; jump back to the body
            // while any remain, otherwise pop the iterator and fall through.
            if (st().itr == 0) { cover.branch(st().pc, false); st().pc = jumpRel(next, a); return; }
            const it = &st().iters[st().itr - 1];
            if (it.mask == 0) {
                st().itr -= 1; // scan complete: exit the loop
            } else {
                cover.branch(st().pc, true);
                const idx: u32 = it.base + @ctz(it.mask);
                it.mask &= it.mask - 1;
                const fr = &st().frames[st().fp - 1];
                if (it.slot < MAX_LOCALS) {
                    fr.locals[it.slot] = @bitCast((@as(u32, ent.genOf(it.typ, idx)) << 20) | idx);
                }
                st().pc = jumpRel(next, a);
                return;
            }
        },
        c.OP_FSM_NEXT => {
            // bit-plane transition (subsystem 5): next = T[s * span + em].
            // Guard priority was PRECOMPUTED into the table by the compiler;
            // the runtime is one shift + mask + load. Stack: em pushed first,
            // s second -> pop s then em.
            // v23.1: `ti` was masked to 0xFFFF but never bounded by the
            // loaded-table count — a crafted operand reached
            // ADDR_FSM + 65535*260 (~17MB) against the 2MB image (ReleaseSafe
            // panic / ReleaseFast OOB read), violating the soft-land contract.
            const s = pop();
            const em = pop();
            const ti: u32 = @as(u32, @bitCast(a)) & 0xFFFF;
            if (ti >= c.n_fsms) {
                push(0); // unloaded/crafted table: stay in the current state
            } else {
                const base = c.ADDR_FSM + ti * c.FSM_STRIDE;
                const nstates: u32 = c.mem[base + 2];
                const span: u32 = c.mem[base + 3];
                if (nstates == 0 or span == 0) { push(0); } // no table loaded: stay
                else {
                    const su: u32 = @as(u32, @bitCast(s)) % nstates;
                    const eu: u32 = @as(u32, @bitCast(em)) & (span - 1);
                    push(c.mem[base + 4 + su * span + eu]);
                }
            }
        },
        c.OP_SEL => {
            // branchless conditional move (subsystem 6): a DATA edge, not a
            // control edge — the PC never jumps, execution time is constant
            // whatever the condition. Stack: cond, then, else pushed in that
            // order -> pop else, then, cond. Values are raw i32 payloads, so
            // bool/int/fixed all select bit-exactly.
            const elsev = pop();
            const thenv = pop();
            const cond = pop();
            push(if (cond != 0) thenv else elsev);
        },
        // ---------------- v11: arrays ----------------
        c.OP_LD_GARR => {
            // a = array id; pop idx (wrapped by mask|mod), push the raw cell.
            // v23.5: f64 arrays (arr_wide == 2) push TWO cells (lo, hi) —
            // the same pair order as every f64 value on the stack.
            const id: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const idx = pop();
            if (id >= c.n_arrs or c.arr_ent[id] != 0xFF) { push(0); }
            else {
                const w: u32 = c.arr_wide[id];
                const i = c.arrIndex(id, idx) * w;
                if (w == 2) {
                    const lo: u32 = @bitCast(c.rd32(c.garrElem(id, i)));
                    const hi: u32 = @bitCast(c.rd32(c.garrElem(id, i + 1)));
                    push(@bitCast(lo)); push(@bitCast(hi));
                } else {
                    push(@bitCast(c.rd32(c.garrElem(id, i))));
                }
            }
        },
        c.OP_ST_GARR => {
            const id: u32 = @as(u32, @bitCast(a)) & 0xFF;
            // stack: idx pushed, then val -> top is val. v23.5: f64 arrays
            // carry a (lo, hi) pair (top = hi) — the WIDTH TEST comes first
            // so every path drains exactly what was pushed.
            const wide = id < c.n_arrs and c.arr_ent[id] == 0xFF and c.arr_wide[id] == 2;
            if (wide) {
                const hi = pop(); const lo = pop(); const idx = pop();
                const i = c.arrIndex(id, idx) * 2;
                c.wr32(c.garrElem(id, i), @bitCast(lo));
                c.wr32(c.garrElem(id, i + 1), @bitCast(hi));
            } else {
                const v = pop();
                const idx = pop();
                if (id < c.n_arrs and c.arr_ent[id] == 0xFF) {
                    const i = c.arrIndex(id, idx);
                    c.wr32(c.garrElem(id, i), @bitCast(v));
                }
            }
        },
        c.OP_LD_EARR => {
            // a = local slot holding the entity handle, b = array id; pop idx.
            // Stale handles read 0 (same contract as fieldLoad).
            // v23.5: f64 arrays (arr_wide == 2) push TWO cells (lo, hi).
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const id: u32 = @as(u32, @bitCast(b)) & 0xFF;
            const idx = pop();
            const fr = &st().frames[st().fp - 1];
            const handle: u32 = @bitCast(if (slot < MAX_LOCALS) fr.locals[slot] else 0);
            if (id >= c.n_arrs or c.arr_ent[id] == 0xFF) { push(0); }
            else {
                const t: u32 = c.arr_ent[id];
                const sidx = handle & 0xFFFFF;
                const gen = (handle >> 20) & 0xFFF;
                if (sidx >= c.maxLive(t) or ent.genOf(t, sidx) != gen or !ent.isAlive(t, sidx)) {
                    push(0);
                } else {
                    const w: u32 = c.arr_wide[id];
                    const i = c.arrIndex(id, idx) * w;
                    if (w == 2) {
                        const lo: u32 = @bitCast(c.rd32(c.earrRow(id, sidx) + i * 4));
                        const hi: u32 = @bitCast(c.rd32(c.earrRow(id, sidx) + (i + 1) * 4));
                        push(@bitCast(lo)); push(@bitCast(hi));
                    } else {
                        push(@bitCast(c.rd32(c.earrRow(id, sidx) + i * 4)));
                    }
                }
            }
        },
        c.OP_ST_EARR => {
            const slot: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const id: u32 = @as(u32, @bitCast(b)) & 0xFF;
            // stack: idx pushed, then val -> top is val. v23.5: the WIDTH
            // TEST comes first so every path (live, stale handle, wrong
            // kind) drains exactly what was pushed.
            const wide = id < c.n_arrs and c.arr_ent[id] != 0xFF and c.arr_wide[id] == 2;
            if (wide) {
                const hi = pop(); const lo = pop(); const idx = pop();
                if (id < c.n_arrs and c.arr_ent[id] != 0xFF) {
                    const t: u32 = c.arr_ent[id];
                    const fr = &st().frames[st().fp - 1];
                    const handle: u32 = @bitCast(if (slot < MAX_LOCALS) fr.locals[slot] else 0);
                    const sidx = handle & 0xFFFFF;
                    const gen = (handle >> 20) & 0xFFF;
                    if (sidx < c.maxLive(t) and ent.genOf(t, sidx) == gen and ent.isAlive(t, sidx)) {
                        const i = c.arrIndex(id, idx) * 2;
                        c.wr32(c.earrRow(id, sidx) + i * 4, @bitCast(lo));
                        c.wr32(c.earrRow(id, sidx) + (i + 1) * 4, @bitCast(hi));
                    }
                }
            } else {
                const v = pop();
                const idx = pop();
                if (id < c.n_arrs and c.arr_ent[id] != 0xFF) {
                    const t: u32 = c.arr_ent[id];
                    const fr = &st().frames[st().fp - 1];
                    const handle: u32 = @bitCast(if (slot < MAX_LOCALS) fr.locals[slot] else 0);
                    const sidx = handle & 0xFFFFF;
                    const gen = (handle >> 20) & 0xFFF;
                    if (sidx < c.maxLive(t) and ent.genOf(t, sidx) == gen and ent.isAlive(t, sidx)) {
                        const i = c.arrIndex(id, idx);
                        c.wr32(c.earrRow(id, sidx) + i * 4, @bitCast(v));
                    }
                }
            }
        },
        c.OP_DUP => {
            // duplicate top of stack (compound array assigns keep the index
            // under the element without re-evaluating it)
            if (st().sp > 0 and st().sp < STACK_SIZE) {
                st().stack[st().sp] = st().stack[st().sp - 1];
                st().sp += 1;
            }
        },
        // ---------------- v11: 3D camera + projection ----------------
        c.OP_CAM3 => {
            // pop pitch, yaw, z, y, x -> page-0 registers (snapshot-safe)
            const pitch = pop();
            const yaw = pop();
            const z = pop();
            const y = pop();
            const x = pop();
            c.wr32(c.ADDR_CAM3_X, @bitCast(x));
            c.wr32(c.ADDR_CAM3_Y, @bitCast(y));
            c.wr32(c.ADDR_CAM3_Z, @bitCast(z));
            c.wr32(c.ADDR_CAM3_YAW, @bitCast(yaw));
            c.wr32(c.ADDR_CAM3_PITCH, @bitCast(pitch));
        },
        c.OP_PROJ3 => {
            const z = pop();
            const y = pop();
            const x = pop();
            const p = c.proj3(x, y, z);
            c.wr32(c.ADDR_PROJ_X, @bitCast(p.sx));
            c.wr32(c.ADDR_PROJ_Y, @bitCast(p.sy));
            c.wr32(c.ADDR_PROJ_OK, @intFromBool(p.ok));
            push(p.scale);
        },
        c.OP_PROJ_X => push(@bitCast(c.rd32(c.ADDR_PROJ_X))),
        c.OP_PROJ_Y => push(@bitCast(c.rd32(c.ADDR_PROJ_Y))),
        c.OP_PROJ_OK => push(@intFromBool(c.rd32(c.ADDR_PROJ_OK) != 0)),
        c.OP_DRAW3D => {
            // a = global array id (mesh); stack: n, x, y, z, yaw, rgba pushed
            // in that order -> pop rgba, yaw, z, y, x, n. render3d owns the
            // whole transform/view/project/cull/sort/raster pipeline.
            const rgba = pop();
            const yaw = pop();
            const z = pop();
            const y = pop();
            const x = pop();
            const n = pop();
            const id: u32 = @as(u32, @bitCast(a)) & 0xFF;
            render3d.draw3d(id, n, x, y, z, yaw, @bitCast(rgba));
        },
        // ---------------- v12: articulated 3D (mat4/quat over arrays) ----
        c.OP_QUAT_AA => {
            // stack: q_aid, off, ax, ay, az, ang pushed in source order
            const ang = pop();
            const az = pop();
            const ay = pop();
            const ax = pop();
            const off = pop();
            const qid: u32 = @bitCast(pop());
            render3d.quatAA(qid, off, ax, ay, az, ang);
        },
        c.OP_Q_MUL => {
            // stack: d_aid, doff, a_aid, aoff, b_aid, boff
            const boff = pop();
            const bid: u32 = @bitCast(pop());
            const aoff = pop();
            const aid: u32 = @bitCast(pop());
            const doff = pop();
            const did: u32 = @bitCast(pop());
            render3d.qMul(did, doff, aid, aoff, bid, boff);
        },
        c.OP_M4_QT => {
            // stack: m_aid, moff, q_aid, qoff, tx, ty, tz
            const tz = pop();
            const ty = pop();
            const tx = pop();
            const qoff = pop();
            const qid: u32 = @bitCast(pop());
            const moff = pop();
            const mid: u32 = @bitCast(pop());
            render3d.m4QT(mid, moff, qid, qoff, tx, ty, tz);
        },
        c.OP_M4_MUL => {
            // stack: d_aid, doff, a_aid, aoff, b_aid, boff (D = A*B)
            const boff = pop();
            const bid: u32 = @bitCast(pop());
            const aoff = pop();
            const aid: u32 = @bitCast(pop());
            const doff = pop();
            const did: u32 = @bitCast(pop());
            render3d.m4Mul(did, doff, aid, aoff, bid, boff);
        },
        c.OP_SKIN3 => {
            // stack: v_aid, voff, m_aid, moff, x, y, z -> verts[voff..+2]
            const z = pop();
            const y = pop();
            const x = pop();
            const moff = pop();
            const mid: u32 = @bitCast(pop());
            const voff = pop();
            const vid: u32 = @bitCast(pop());
            render3d.skin3(vid, voff, mid, moff, x, y, z);
        },
        c.OP_DRAW3DI => {
            // a = vertex buffer id, b = index buffer id; stack: nv, ni, x,
            // y, z, yaw, rgba -> pop rgba, yaw, z, y, x, ni, nv.
            const rgba = pop();
            const yaw = pop();
            const z = pop();
            const y = pop();
            const x = pop();
            const ni = pop();
            const nv = pop();
            const vid: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const iid: u32 = @as(u32, @bitCast(b)) & 0xFF;
            render3d.draw3di(vid, iid, nv, ni, x, y, z, yaw, @bitCast(rgba));
        },
        c.OP_GOTO => {
            const scene: u32 = @as(u32, @bitCast(a)) & 0xFFFF;
            c.wr32(c.ADDR_SCENE, scene + 1);
            cover.branch(st().pc, scene < c.n_scenes);
            if (scene < c.n_scenes) {
                const fi = c.rd16(c.ADDR_SCENES + scene * 2);
                st().pc = next;
                _ = callFn(fi, &.{});
                // v23.2 AOT hook (see OP_CALL_FN)
                if (aot_invoke) |inv| { inv(fi); }
                return;
            }
        },
        c.OP_DRAW => {
            const rgba = pop();
            const scale = pop();
            const rot = pop();
            const y = pop();
            const x = pop();
            render.drawSprite(@as(u32, @bitCast(a)) & 0xFFFF, x, y, rot, scale, @bitCast(rgba));
        },
        c.OP_DRAW_TEXT => {
            const rgba = pop();
            const y = pop();
            const x = pop();
            render.drawText(@as(u32, @bitCast(a)) & 0xFFFF, x, y, @bitCast(rgba));
        },
        c.OP_DRAW_NUM => {
            const rgba = pop();
            const y = pop();
            const x = pop();
            const val = pop();
            render.drawNum(val, x, y, @bitCast(rgba));
        },
        c.OP_CALL_TBL => {
            const fr = &st().frames[st().fp - 1];
            const table: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const slot: u32 = @as(u32, @bitCast(b)) & 0xFF;
            const key = pop();
            const ku: u32 = @as(u32, @bitCast(key)) & 0xFF;
            const base = c.ADDR_TABLES + table * c.TABLE_STRIDE;
            const fi = c.rd16(base + ku * 2);
            const handle: i32 = if (slot < MAX_LOCALS) fr.locals[slot] else 0;
            cover.edge(st().pc, @as(u32, fi) + 1);
            st().pc = next;
            _ = callFn(fi, &[1]i32{handle});
            // v23.2 AOT hook (see OP_CALL_FN)
            if (aot_invoke) |inv| { inv(fi); }
            return;
        },
        c.OP_COUNT => {
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            push(@intCast(ent.count(t)));
        },
        c.OP_RET => {
            cover.edge(st().pc, 0);
            popFrame();
            return; // st().pc set by popFrame — must NOT fall through to st().pc = next
        },
        c.OP_CALL_FN => {
            const fi: u32 = @as(u32, @bitCast(a)) & 0xFFFF;
            const n: u32 = @as(u32, @bitCast(b)) & 0xFF;
            // args: last n st().stack values in source order
            // v14: guard the underflow a crafted count could cause (the
            // old u32 wrap indexed ~4 billion -> OOB panic)
            // v23.5: the arg window widened from 8 to 16 cells so f64
            // params (2 cells each) fit; the checker caps total arg cells
            // at 16. Legacy carts (<=8 cells) encode identical bytes.
            var args: [16]i32 = .{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            var j: u32 = 0;
            while (j < n and j < 16) : (j += 1) {
                args[j] = if (st().sp >= n) st().stack[st().sp - n + j] else 0;
            }
            // v19 mining: record empirical argument domains (host-side
            // diagnostics only — nothing hashed sees this)
            if (n >= 1) tables.mineCall(fi, args[0..@min(n, 8)], @min(n, 8));
            st().sp -|= n;
            st().pc = next;
            // v19 TABLES: if a baked table covers this (fn, args) pair, the
            // call becomes a load. The probe performs the same stack pops
            // (done above) and the same ret_val store the real call's OP_RET_V
            // would; a pure fn touches nothing else, so the hashed image is
            // bit-identical to the real-call path (proved by corpus replay).
            if (n >= 1) {
                if (tables.probe(fi, args[0], args[1], @min(n, 8))) |v| {
                    st().ret_val = v;
                    return;
                }
            }
            cover.edge(st().pc, fi + 1);
            _ = callFn(fi, args[0..@min(n, 16)]);
            // v23.2 AOT: the hook (if installed) runs the callee to
            // completion and pops the frame; otherwise the step() loop
            // enters it at fnStart.
            if (aot_invoke) |inv| { inv(fi); }
            return;
        },
        // ---------------- v17: expression language + engine services ----------------
        c.OP_RET_V => {
            // valued return: park the top of stack in the threadlocal ret
            // register, then pop the frame exactly like OP_RET. Statement-
            // form callers never read the register, so both call shapes share
            // one convention.
            cover.edge(st().pc, 0);
            st().ret_val = pop();
            popFrame();
            return; // st().pc set by popFrame
        },
        c.OP_RET_GET => {
            // fetch the ret register onto the stack (always emitted right
            // after an OP_CALL_FN in expression context)
            push(st().ret_val);
        },
        c.OP_ITER_POP => {
            // break out of an entity for-loop: drop the innermost iterator.
            // FOR_ADV would otherwise pop it at loop end; breaking past it
            // would leak the slot and desync nested loops (MAX_ITERS = 8).
            if (st().itr > 0) st().itr -= 1;
        },
        c.OP_KEY_EDGE => {
            // v17 input edge test: a = key bit 0..31, b = 0 (pressed, rising
            // edge) | 1 (released, falling edge). The edge registers are
            // maintained by engine.frame() when c.uses_edges — which is
            // exactly when this opcode can exist in the stream.
            const k: u5 = @intCast(@as(u32, @bitCast(a)) & 31);
            const rel = (@as(u32, @bitCast(b)) & 0xFF) != 0;
            const reg = if (rel) c.rd32(c.ADDR_INPUT_REL) else c.rd32(c.ADDR_INPUT_PRESS);
            push(@intFromBool((reg >> k) & 1 != 0));
        },
        c.OP_DIST_NEAR => {
            // v17 nearest-entity query: scan the type's live slots, i64
            // distance math (the OP_DIST internals), minimum on the stack.
            // No live entities -> 0x7FFFFFFF ("infinitely far"). Square-
            // distance comparison (one sqrt for the WINNER only, never
            // per slot; the sentinel avoids best*best overflow entirely).
            const y = pop();
            const x = pop();
            const t: u32 = @as(u32, @bitCast(a)) & 0xFF;
            const ex = c.ADDR_EXTRA + c.iExtra(st().pc) * 2;
            const x_tf: u32 = c.rd16(ex);
            const y_tf: u32 = c.rd16(ex + 2);
            var best_d2: i64 = -1; // no live entity seen yet
            var idx = ent.nextLive(t, 0);
            while (idx != 0xFFFFFFFF) {
                const h: u32 = (@as(u32, ent.genOf(t, idx)) << 20) | idx;
                const px = ent.fieldLoad(x_tf, h);
                const py = ent.fieldLoad(y_tf, h);
                const dx: i64 = @as(i64, px) - @as(i64, x);
                const dy: i64 = @as(i64, py) - @as(i64, y);
                const d2 = dx * dx + dy * dy;
                if (best_d2 < 0 or d2 < best_d2) best_d2 = d2;
                idx = ent.nextLive(t, idx + 1);
            }
            if (best_d2 < 0) {
                push(0x7FFFFFFF);
            } else {
                push(@intCast(c.isqrt64(@intCast(best_d2))));
            }
        },
        c.OP_M4_LOOK => {
            // v17 look-at matrix: stack m_aid, moff, ex, ey, ez, tx, ty, tz
            // (source order) -> pops reversed.
            const tz = pop();
            const ty = pop();
            const tx = pop();
            const ez = pop();
            const ey = pop();
            const ex = pop();
            const moff = pop();
            const mid: u32 = @bitCast(pop());
            render3d.m4Look(mid, moff, ex, ey, ez, tx, ty, tz);
        },
        c.OP_I2F => { const x = pop(); push(x *% 256); },
        c.OP_F2I => { const x = pop(); push(x >> 8); },
        else => {},
    }
    st().pc = next;
}

/// Decode + execute ONE instruction at an explicit pc (the bridge's
/// interpreter-fallback entry). Includes the debugger hook — an AOT fallback
/// frame is still a LILA frame, so breakpoints/tracing fire identically.
/// Off-the-end pcs keep the implicit-RET soft-landing.
pub fn dispatchAt(pc: u32) void {
    st().pc = pc;
    step();
}

fn popFrame() void {
    if (st().fp == 0) {
        st().halted = true;
        return;
    }
    st().fp -= 1;
    // v23.1: prune exception handlers registered by the frames being
    // popped — a `return` from inside a try body must not leave a stale
    // handler pointing into an abandoned frame (the compiler unwinds
    // handlers lexically for break/continue; returns unwind HERE).
    while (st().try_sp > 0 and st().try_frame_fp[st().try_sp - 1] > st().fp) {
        st().try_sp -= 1;
    }
    const ret = st().frames[st().fp].ret_pc;
    if (ret == 0xFFFFFFFE) {
        st().halted = false; // base frame — caller loop stops on st().fp==0
        return;
    }
    st().pc = ret;
}

/// Cubic Hermite evaluation of an anim curve at integer frame t (wraps at
/// duration). All math in Q24.8 with i64 intermediates. O(#segs) segment scan.
pub fn evalAnim(curve: u32, t: i32) i32 {
    if (curve >= c.n_anims) return 0;
    const base = c.ADDR_ANIM + curve * c.ANIM_STRIDE;
    const dur: u32 = c.rd16(base);
    const nseg: u32 = c.mem[base + 2];
    if (nseg == 0 or dur == 0) return @bitCast(c.rd32(base + 4 + 2));
    const tt: u32 = @as(u32, @bitCast(t)) % dur;
    // find segment
    var s: u32 = 0;
    while (s < nseg) : (s += 1) {
        const off = base + 4 + s * 20;
        const t0: u32 = c.rd16(off);
        const t1: u32 = if (s + 1 < nseg) c.rd16(base + 4 + (s + 1) * 20) else dur;
        if (tt >= t0 and tt < t1) {
            const p0: i32 = @bitCast(c.rd32(off + 2));
            const m0: i32 = @bitCast(c.rd32(off + 6));
            const p1: i32 = @bitCast(c.rd32(off + 10));
            const m1: i32 = @bitCast(c.rd32(off + 14));
            const dt: i32 = @intCast(t1 - t0);
            // s in Q8: 0..256
            const sq8: i32 = @intCast(@divTrunc(@as(i64, @as(i32, @intCast(tt - t0))) << 8, @as(i64, dt)));
            const s2: i32 = @intCast(@divTrunc(@as(i64, sq8) * sq8, 256));
            const s3: i32 = @intCast(@divTrunc(@as(i64, s2) * sq8, 256));
            const h00: i32 = 256 + 2 * s3 - 3 * s2;
            const h01: i32 = 256 - h00;
            const h10: i32 = s3 - 2 * s2 + sq8;
            const h11: i32 = s3 - s2;
            const v: i64 = @as(i64, h00) * p0 + @as(i64, h10) * dt * m0 +
                @as(i64, h01) * p1 + @as(i64, h11) * dt * m1;
            return @intCast(@divTrunc(v, 256));
        }
    }
    // t == dur edge: clamp to last segment end
    const off = base + 4 + (nseg - 1) * 20;
    return @bitCast(c.rd32(off + 10));
}
