//! Combined export root: the engine C API (lila_c.zig) + the AOT bridge
//! (lila_aot_bridge.zig) in one shared library, so a C host can drive
//! frames AND install compiled Tier-0 fns from a single link.
//!   zig build-lib aot_all.zig -dynamic -O ReleaseFast -femit-bin liblila_all.so
comptime {
    _ = @import("lila_c.zig");
    _ = @import("lila_aot_bridge.zig");
}
