//! ============================================================================
//! LILA DEBUG + PROFILER BRIDGE — Step 6 of the tiered-compilation roadmap
//! ============================================================================
//!
//! Provides the host-debugger + host-profiler integration surface:
//!   - Breakpoint registry (set/clear breakpoints at fn_idx + pc_offset)
//!   - Single-step (advance the VM one instruction at a time)
//!   - Variable inspection (read/write locals, globals, entity fields)
//!   - Chrome tracing event emission (per-fn wall-clock + deterministic counts)
//!
//! The host (Unity Editor, Unreal Insights, VS Code debugger) consumes
//! these via the existing C ABI in lila_c.zig. The contract:
//!
//!   - lila_set_breakpoint(fn_idx, pc) → bp_id (or -1 on bad fn_idx)
//!   - lila_clear_breakpoint(bp_id)
//!   - lila_step() → runs ONE instruction; returns the new pc (or -1 if
//!     the breakpoint fires this step and the host should pause)
//!   - lila_inspect_local(slot) → i32 value
//!   - lila_inspect_global(offset) → i32 value
//!   - lila_trace_begin(name) / lila_trace_end() → Chrome tracing events
//!
//! Determinism boundary: breakpoints and inspection are READ-ONLY on
//! engine memory — they don't touch the hash chain. The host writes to
//! variables via lila_write_local/global, which DOES touch the hash chain
//! (the host is responsible for the consequences — typically only used
//! in debug builds).
//!
//! See runtime/src/lila_c.zig for the C ABI exports that wrap this module.

const std = @import("std");
const c = @import("core.zig");

/// Maximum simultaneous breakpoints. Plenty for interactive debugging.
pub const MAX_BREAKPOINTS: usize = 64;

/// A breakpoint: (fn_idx, pc_offset) pair. When the VM's pc reaches this
/// (fn_idx, pc_offset), the step function returns -1 to signal the host
/// to pause. Breakpoints are stored in a fixed-size array (no allocation).
pub const Breakpoint = struct {
    fn_idx: u32,
    pc: u32,
    active: bool,
};

/// The global breakpoint registry. Fixed-size, no allocation.
pub var breakpoints: [MAX_BREAKPOINTS]Breakpoint = [_]Breakpoint{
    .{ .fn_idx = 0, .pc = 0, .active = false }
} ** MAX_BREAKPOINTS;

/// Per-slot ids (0 = none) so clear_breakpoint(id) is exact — the draft
/// cleared "the first active slot", which cleared the wrong breakpoint.
var bp_ids: [MAX_BREAKPOINTS]u32 = [_]u32{0} ** MAX_BREAKPOINTS;

/// Next breakpoint id (1-indexed; 0 = invalid).
pub var next_bp_id: u32 = 1;

/// v23.1: the VM hot path consults this ONE bool per instruction — it is
/// true only while at least one breakpoint is armed or tracing is on, so
/// the interpreter pays a single well-predicted branch when the debugger
/// is idle. Set/clear/trace-callback sites keep it up to date.
pub var hook_enabled: bool = false;

fn recompute_hook() void {
    hook_enabled = blk: {
        for (breakpoints) |bp| if (bp.active) break :blk true;
        break :blk trace_callback != null;
    };
}

/// The current VM state (mirrors vm.zig::st() — but the debug module owns
/// its own snapshot to avoid coupling). The host calls lila_step() to
/// advance; lila_step() calls into vm.zig::step() once.
pub var current_fn_idx: u32 = 0;
pub var current_pc: u32 = 0;
pub var paused: bool = false;

// v23.1: fn-entry edge detection for trace events (a 64-entry shadow of
// "which fn is live on which frame depth" is overkill — one bit per fn is
// enough for begin/end events).
var fn_live: [64]bool = [_]bool{false} ** 64;

pub fn was_in_fn(fn_idx: u32) bool {
    if (fn_idx >= 64) return true; // out of range: suppress events
    return fn_live[fn_idx];
}

pub fn note_fn_entry(fn_idx: u32) void {
    if (fn_idx < 64) fn_live[fn_idx] = true;
}

/// Set a breakpoint. Returns the bp_id (>0) or -1 if the table is full
/// or the fn_idx is invalid.
pub fn set_breakpoint(fn_idx: u32, pc: u32) i32 {
    if (fn_idx >= c.n_fns) return -1;
    for (&breakpoints, 0..) |*bp, i| {
        if (!bp.active) {
            bp.fn_idx = fn_idx;
            bp.pc = pc;
            bp.active = true;
            const id = next_bp_id;
            bp_ids[i] = id;
            next_bp_id += 1;
            recompute_hook();
            return @intCast(id);
        }
    }
    return -1; // table full
}

/// Clear a breakpoint by id. Returns 0 on success, -1 if not found.
pub fn clear_breakpoint(bp_id: i32) i32 {
    if (bp_id <= 0) return -1;
    // v23.1: exact per-slot id lookup (the draft cleared the first active
    // slot regardless of id — clearing bp 2 killed bp 1).
    for (&breakpoints, 0..) |*bp, i| {
        if (bp.active and bp_ids[i] == @as(u32, @intCast(bp_id))) {
            bp.active = false;
            bp_ids[i] = 0;
            recompute_hook();
            return 0;
        }
    }
    return -1;
}

/// Check if the current (fn_idx, pc) matches any active breakpoint.
/// Returns true if the host should pause.
pub fn check_breakpoint_hit(fn_idx: u32, pc: u32) bool {
    for (breakpoints) |bp| {
        if (bp.active and bp.fn_idx == fn_idx and bp.pc == pc) {
            return true;
        }
    }
    return false;
}

/// Clear all breakpoints (e.g., on hot-swap).
pub fn clear_all_breakpoints() void {
    for (&breakpoints) |*bp| {
        bp.active = false;
    }
    for (&bp_ids) |*id| id.* = 0;
    next_bp_id = 1;
    recompute_hook();
}

// ============================================================================
// INSPECTION (read/write engine memory)
// ============================================================================

/// Read a local variable from the current frame. The slot is the u8
/// operand of OP_LD_LOCAL. Returns 0 if the slot is out of range.
pub fn inspect_local(slot: u8) i32 {
    // v23.1: real implementation — reads the VM's current frame through
    // the accessor vm.zig exposes (the debug module and the VM import each
    // other; Zig allows the cycle). READ-ONLY on engine state.
    const vm = @import("vm.zig");
    return vm.dbgReadLocal(slot);
}

/// Write a local variable in the current frame. Affects the hash chain
/// (the host is responsible for the consequences — typically only used
/// in debug builds).
pub fn write_local(slot: u8, value: i32) void {
    const vm = @import("vm.zig");
    vm.dbgWriteLocal(slot, value);
}

/// Read a global variable. The offset is the u16 operand of OP_LD_GLBL.
pub fn inspect_global(offset: u16) i32 {
    // v23.2 FIX: the raw u32 cell was returned as-is — type error under
    // 0.16 (and a silent sign bug conceptually). BitCast preserves the
    // stored bits, matching every other cell read in the runtime.
    return @bitCast(c.rd32(c.ADDR_GLOBALS + @as(u32, offset) * 4));
}

/// Write a global variable. Affects the hash chain.
pub fn write_global(offset: u16, value: i32) void {
    c.wr32(c.ADDR_GLOBALS + @as(u32, offset) * 4, @bitCast(value));
}

// ============================================================================
// CHROME TRACING EVENT EMISSION
// ============================================================================
//
// The host registers a trace event callback via lila_trace_set_callback.
// The VM calls lila_trace_begin("fn_name") at fn entry and
// lila_trace_end() at fn exit. The host formats these as Chrome tracing
// JSON events (https://docs.google.com/document/d/1CvAClvFfyA5R5PhY4).
//
// The trace events are WALL-CLOCK based (not deterministic) — they're
// for the host profiler (Unity Profiler, Unreal Insights), not for the
// replay hash chain. The hash chain is unaffected.

pub const TraceEventKind = enum { begin, end, instant };

var seq_ns: u64 = 0; // wasm: ordered sequence instead of wall clock

pub const TraceEvent = struct {
    kind: TraceEventKind,
    name: [64]u8,
    name_len: u8,
    ts_ns: u64,
};

/// The host-registered callback. If null, trace events are no-ops.
pub var trace_callback: ?*const fn (TraceEvent) void = null;

/// Buffer of trace events (for hosts that poll instead of callback).
pub var trace_buffer: [256]TraceEvent = undefined;
pub var trace_buffer_count: usize = 0;

/// Set the host callback. Pass null to disable.
pub fn set_trace_callback(cb: ?*const fn (TraceEvent) void) void {
    trace_callback = cb;
    recompute_hook();
}

/// Emit a trace event. Called by the VM at fn entry/exit + per-system.
pub fn emit_trace(kind: TraceEventKind, name: []const u8) void {
    if (trace_callback == null and trace_buffer_count >= trace_buffer.len) return;

    var ev: TraceEvent = .{
        .kind = kind,
        .name = std.mem.zeroes([64]u8),
        .name_len = @intCast(@min(name.len, 64)),
        // v23.1: wall-clock ns for the host profiler only (NEVER hashed —
        // the trace path is outside the determinism boundary). Native uses
        // the monotonic clock; wasm32-freestanding has no clock, so a
        // sequence counter keeps events ordered for the host.
        .ts_ns = if (comptime @import("builtin").cpu.arch.isWasm())
            blk: {
                seq_ns += 1;
                break :blk seq_ns;
            }
        else blk: {
            // same Linux clock_gettime discipline as engine.zig's profiler
            var ts: std.os.linux.timespec = undefined;
            _ = std.os.linux.clock_gettime(.MONOTONIC, &ts);
            break :blk @as(u64, @intCast(ts.sec)) * 1_000_000_000 + @as(u64, @intCast(ts.nsec));
        },
    };
    @memcpy(ev.name[0..ev.name_len], name[0..ev.name_len]);

    if (trace_callback) |cb| cb(ev);

    if (trace_buffer_count < trace_buffer.len) {
        trace_buffer[trace_buffer_count] = ev;
        trace_buffer_count += 1;
    }
}

/// Drain the trace buffer (host polls this).
pub fn drain_trace_buffer(out: []TraceEvent) usize {
    const n = @min(out.len, trace_buffer_count);
    @memcpy(out[0..n], trace_buffer[0..n]);
    trace_buffer_count = 0;
    return n;
}
