/* lila_aot_diff.c — Phase-4 capstone: AOT vs INTERPRETER differential test.
 *
 * One process, one cart, one input script, two engines:
 *   pass 1: pure interpreter  (no AOT table)  -> per-frame lila_state_hash
 *   pass 2: AOT-installed     (lila_aot_install + lila_aot_table)
 * The pass hashes must match FRAME FOR FRAME — the AOT path is then proven
 * bit-identical to the interpreter on real game code (the property the
 * whole deterministic-rollback stack rests on).
 *
 * Build (from runtime/src):
 *   cc -O2 -Wall -I. lila_aot_diff.c <outdir>/lila_aot.c \
 *      -L/tmp -llila_aot_bridge -Wl,-rpath,/tmp -o /tmp/lila_aot_diff
 * Run:
 *   /tmp/lila_aot_diff <game.libyte> <frames>
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* C backend: lila_aot.h declares lila_aot_table[N] with the real N.
 * LLVM backend (-DLILA_AOT_LLVM -DLILA_AOT_TABLE_N=n): only the .ll is
 * emitted, so declare the table here with the count passed by the runner. */
#ifdef LILA_AOT_LLVM
#include "lila_aot_runtime.h"
extern LilaFn lila_aot_table[LILA_AOT_TABLE_N];
void lila_aot_init(void);   /* the IR module's table populator */
#else
#include "lila_aot.h"   /* declares lila_aot_table[N] with the real N */
#endif

/* engine C API (lila_c.zig exports; declared here to keep the driver
 * self-contained — lila.h declares the same shapes) */
int32_t lila_init(const uint8_t *blob, size_t len);
void    lila_frame(void);
void    lila_input_set(uint32_t mask);
uint64_t lila_state_hash(uint32_t fr);
uint8_t *lila_sram_ptr(void);   /* 256B battery block — SURVIVES lila_init */
uintptr_t lila_sram_size(void);

static void reset_sram(void) {
    /* SRAM is the battery-backed region: engine.init deliberately does NOT
     * zero it (hi-scores persist across re-init). The two-pass protocol
     * needs BOTH passes to start from the same battery state, or pass2's
     * `saved(0)` reads pass1's final hi-score and the timelines diverge the
     * moment game code branches on it (demo17's `best = saved(0)` did
     * exactly that — the "AOT bug" was a harness artifact). */
    uint8_t *p = lila_sram_ptr();
    size_t n = (size_t)lila_sram_size();
    if (p && n) memset(p, 0, n);
}

static int failures = 0;

static void run_pass(int install_aot, uint32_t frames, unsigned long long *hashes) {
    if (install_aot) {
#ifdef LILA_AOT_LLVM
        lila_aot_init();  /* populate the IR module's dispatch table */
#endif
        lila_aot_install(lila_aot_table, (uint32_t)(sizeof(lila_aot_table) / sizeof(lila_aot_table[0])));
    } else {
        lila_aot_uninstall();
    }
    for (uint32_t f = 0; f < frames; f++) {
        /* deterministic input pattern: a triangle wave on bit0+bit1 */
        uint32_t mask = ((f / 7) % 2 ? 1u : 0u) | ((f / 13) % 2 ? 2u : 0u) | 4u;
        lila_input_set(mask);
        lila_frame();
        hashes[f] = lila_state_hash(f);
    }
}

int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s <game.libyte> <frames>\n", argv[0]);
        return 2;
    }
    const char *cart_path = argv[1];
    uint32_t frames = (uint32_t)atoi(argv[2]);

    FILE *fp = fopen(cart_path, "rb");
    if (!fp) { fprintf(stderr, "cannot open %s\n", cart_path); return 2; }
    static unsigned char cart[1 << 20];
    size_t len = fread(cart, 1, sizeof(cart), fp);
    fclose(fp);
    printf("cart: %s (%zu bytes), %u frames per pass\n", cart_path, len, frames);

    static unsigned long long h1[4096], h2[4096];
    if (frames > 4096) { fprintf(stderr, "cap frames at 4096\n"); return 2; }

    /* ---- pass 1: pure interpreter ---- */
    fprintf(stderr, "[pass1 init...]\n");
    reset_sram();
    if (lila_init(cart, len) != 0) { fprintf(stderr, "lila_init failed\n"); return 2; }
    fprintf(stderr, "[pass1 run...]\n");
    run_pass(0, frames, h1);
    fprintf(stderr, "[pass1 done]\n");
    printf("interp: frame hashes 0..%u recorded (first %016llx)\n", frames - 1, h1[0]);

    /* ---- pass 2: AOT installed ---- */
    fprintf(stderr, "[pass2 init...]\n");
    reset_sram();
    if (lila_init(cart, len) != 0) { fprintf(stderr, "lila_init (2) failed\n"); return 2; }
    fprintf(stderr, "[pass2 run...]\n");
    run_pass(1, frames, h2);
    fprintf(stderr, "[pass2 done]\n");
    printf("aot:    frame hashes 0..%u recorded (first %016llx)\n", frames - 1, h2[0]);

    /* ---- compare ---- */
    for (uint32_t f = 0; f < frames; f++) {
        if (h1[f] != h2[f]) {
            printf("FAIL: frame %u hash mismatch interp=%016llx aot=%016llx\n",
                   f, h1[f], h2[f]);
            failures++;
            if (failures > 8) break;
        }
    }
    if (failures == 0) {
        printf("ALL %u FRAMES BIT-IDENTICAL — AOT path proven equivalent to the interpreter\n", frames);
        return 0;
    }
    printf("%d MISMATCHED FRAMES\n", failures);
    return 1;
}
