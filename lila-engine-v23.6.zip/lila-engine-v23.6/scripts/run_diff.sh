#!/usr/bin/env bash
# run_diff.sh — v23.5 ABI v2 differential proof runner (the regression gate).
#
# For each corpus cart:
#   C backend:    lilac aot -> gcc -O2 -> link with lila_aot_diff.c + bridge .so
#                 -> run interp-vs-AOT, expect frame-for-frame bit-identity.
#   LLVM backend: lilac aot-llvm -> llvmlite parse+verify+emit .ll
#                 -> zig cc (clang) object -> link the same harness -> same proof.
#
# A cart passes only when pass 1 (pure interpreter) and pass 2 (AOT installed)
# produce the SAME lila_state_hash on EVERY frame. Run after ANY compiler,
# bridge, or runtime change:
#   bash scripts/run_diff.sh --all
#
# Requirements: cargo build --release (compiler/target/release/lilac),
# zig 0.16 on PATH (or $ZIG), gcc. Runtime fixtures are rebuilt from source.
#
# Usage: scripts/run_diff.sh <cart.lila> [frames]   (or --all for the corpus)
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export LILA_NO_THREADS=1  # C-host .so: zig 0.16 std.Thread.spawn is broken outside a Zig exe
LILAC=$ROOT/compiler/target/release/lilac
SO=/tmp/liblila_all.so
BRIDGE=$SO
WORK=/tmp/aotdiff
SCRIPTS="$ROOT/scripts"
ZIG=${ZIG:-$(command -v zig \
  || [ -x "$HOME/.local/zig/zig" ] && echo "$HOME/.local/zig/zig" \
  || echo /home/z/tools/zig-x86_64-linux-0.16.0/zig)}

frames=${2:-180}
pass=0; fail=0; failed_carts=()

cd "$ROOT" || exit 2
mkdir -p $WORK

# Build the combined engine+bridge .so FROM SOURCE every run — its SONAME
# (liblila_all.so) is what the dynamic loader resolves at runtime; a stale
# copy elsewhere in /tmp silently wins otherwise (this exact trap cost an
# hour of "two images" ghosting).
(cd runtime/src && "$ZIG" build-lib aot_all.zig -dynamic -O ReleaseFast -lc \
   --name lila_all -femit-bin=$SO) > /dev/null || { echo "BRIDGE BUILD FAILED"; exit 1; }
cp $SO /tmp/liblila_c.so
cp $SO /tmp/liblila_aot_bridge.so
# snapshot the bridge's export list ONCE per run — the phantom check used to
# re-invoke nm -D per symbol per cart, and a transient short read on the
# freshly-written .so flagged REAL exports as missing (demo19/lila_call_fn
# "phantom" that linked fine 30 seconds later).
nm -D "$SO" 2>/dev/null | awk '$2 == "T" || $2 == "W" {print $3}' | sort -u > /tmp/bridge_exports.txt
[ -s /tmp/bridge_exports.txt ] || { echo "EXPORT SNAPSHOT FAILED"; exit 1; }

build_and_run_c() {
  local cart=$1
  local name=$(basename "$cart" .lila)
  local out=$WORK/$name.c
  rm -rf "$out"; mkdir -p "$out"
  # v23.5: `lilac aot` writes lila_aot.c AND game.libyte from ONE pipeline —
  # diff against THAT cart so AOT-vs-interpreter share one compilation.
  $LILAC aot "$cart" -o "$out" > /dev/null 2>&1 || { echo "  [C] aot FAILED"; return 1; }
  cart="$out/game.libyte"
  gcc -O2 -I"$out" -I$ROOT/runtime/src -c "$out/lila_aot.c" -o "$out/lila_aot.o" 2>"$out/cc.log" \
    || { echo "  [C] cc FAILED:"; head -5 "$out/cc.log"; return 1; }
  # phantom-symbol check: every undefined lila_* must exist in the bridge
  local missing=$(nm -u "$out/lila_aot.o" | grep "lila_" | awk '{print $2}' | while read s; do
      grep -qx "$s" /tmp/bridge_exports.txt || echo "$s"; done)
  if [ -n "$missing" ]; then echo "  [C] PHANTOM SYMBOLS: $missing"; return 1; fi
  gcc -O2 -I"$out" -I$ROOT/runtime/src "$SCRIPTS/lila_aot_diff.c" "$out/lila_aot.o" -L/tmp -llila_c -llila_aot_bridge -Wl,-rpath,/tmp \
    -o "$out/diffbin" 2>"$out/link.log" || { echo "  [C] link FAILED:"; head -5 "$out/link.log"; return 1; }
  local cart_file=$2
  "$out/diffbin" "$cart_file" "$frames" > "$out/run.log" 2>&1 || { echo "  [C] RUN FAILED:"; tail -4 "$out/run.log"; return 1; }
  grep -q "ALL .* BIT-IDENTICAL" "$out/run.log" || { echo "  [C] HASH MISMATCH:"; tail -4 "$out/run.log"; return 1; }
  return 0
}

build_and_run_llvm() {
  local cart=$1
  local name=$(basename "$cart" .lila)
  local out=$WORK/$name.ll
  rm -rf "$out"; mkdir -p "$out"
  $LILAC aot-llvm "$cart" -o "$out" > /dev/null 2>&1 || { echo "  [LLVM] aot-llvm FAILED"; return 1; }
  cart="$out/game.libyte"
  # zig cc = modern clang (LLVM 20+, opaque pointers REQUIRED — our IR is
  # opaque-only; llvmlite 0.44 is LLVM 15 typed-mode and cannot parse it)
  $ZIG cc -c -O2 "$out/lila_aot.ll" -o "$out/lila_aot.o" 2>"$out/ll.log" \
    || { echo "  [LLVM] ir FAILED:"; tail -5 "$out/ll.log"; return 1; }
  local tn=$(grep -o '@lila_aot_table = global \[[0-9]* x ptr\]' "$out/lila_aot.ll" | grep -o '[0-9]*')
  gcc -O2 -I"$out" -I$ROOT/runtime/src -DLILA_AOT_LLVM -DLILA_AOT_TABLE_N=${tn:-0} \
    "$SCRIPTS/lila_aot_diff.c" "$out/lila_aot.o" -L/tmp -llila_c -llila_aot_bridge -Wl,-rpath,/tmp \
    -o "$out/diffbin" 2>"$out/link.log" || { echo "  [LLVM] link FAILED:"; head -5 "$out/link.log"; return 1; }
  local cart_file=$2
  "$out/diffbin" "$cart_file" "$frames" > "$out/run.log" 2>&1 || { echo "  [LLVM] RUN FAILED:"; tail -4 "$out/run.log"; return 1; }
  grep -q "ALL .* BIT-IDENTICAL" "$out/run.log" || { echo "  [LLVM] HASH MISMATCH:"; tail -4 "$out/run.log"; return 1; }
  return 0
}

run_cart() {
  local cart=$1
  local cart_file=$2
  local name=$(basename "$cart" .lila)
  printf '%-22s' "$name"
  local ok=1
  if build_and_run_c "$cart" "$cart_file"; then printf ' C:OK'; else printf ' C:FAIL'; ok=0; fi
  if build_and_run_llvm "$cart" "$cart_file"; then printf ' LLVM:OK\n'; else printf ' LLVM:FAIL\n'; ok=0; fi
  if [ $ok -eq 1 ]; then pass=$((pass+1)); else fail=$((fail+1)); failed_carts+=("$name"); fi
}

if [ "${1:-}" = "--all" ]; then
  declare -a CARTS=(
    demo/diff_core.lila demo/diff_garr.lila demo/micro.lila demo/demo19.lila
    demo/demo17.lila demo/delay.lila demo/mesh_demo.lila demo/diff_f64.lila
  )
  for c in "${CARTS[@]}"; do
    [ -f "$c" ] || continue
    n=$(basename "$c" .lila)
    $LILAC build "$c" -o "$WORK/$n.libyte" > /dev/null 2>&1 || { echo "$c BUILD FAILED"; fail=$((fail+1)); continue; }
    run_cart "$c" "$WORK/$n.libyte"
  done
  # bench_cpu is a sed-template (LOOPN literal) — instantiate 100k iters
  sed 's/LOOPN/100000/' demo/bench_cpu.lila > "$WORK/bench_cpu.lila" 2>/dev/null \
    && $LILAC build "$WORK/bench_cpu.lila" -o "$WORK/bench_cpu.libyte" > /dev/null 2>&1 \
    && run_cart "$WORK/bench_cpu.lila" "$WORK/bench_cpu.libyte"
  # the runtime fixtures — REBUILT from source so the cart always matches
  # the current compiler's optimizer output (the committed .libyte can be
  # older than the tree; the AOT view must equal the PACKED view)
  declare -a FIX=(test_v23_fixture test_f32_fixture test_states_fixture test_v20_fixture)
  for f in "${FIX[@]}"; do
    src=$ROOT/runtime/src/$f.lila
    cart=$WORK/$f.libyte
    [ -f "$src" ] || continue
    $LILAC build "$src" -o "$cart" --emit-bridges "$WORK" > /dev/null 2>&1 || { echo "$f BUILD FAILED"; fail=$((fail+1)); continue; }
    run_cart "$src" "$cart"
  done
else
  cart=$1
  n=$(basename "$cart" .lila)
  $LILAC build "$cart" -o "$WORK/$n.libyte" > /dev/null 2>&1
  run_cart "$cart" "$WORK/$n.libyte"
fi

echo "----"
echo "PASS $pass  FAIL $fail"
[ $fail -gt 0 ] && printf 'failed: %s\n' "${failed_carts[*]}"
exit $fail
