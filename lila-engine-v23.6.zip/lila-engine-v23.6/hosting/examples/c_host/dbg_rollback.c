/* dbg_rollback.c — isolate the storm divergence: pure restore + resim,
 * no ring, no saves, no timing. If this matches, the culprit is a side
 * effect of save-during-resim; if it forks, it's restore itself. */
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include "lila.h"

#define SPF 735

static uint32_t input_for(uint32_t f) {
    uint32_t m = 0;
    switch ((f / 30) % 4) {
        case 0: m |= 0x1; break;
        case 1: m |= 0x2; break;
        case 2: m |= 0x4; break;
        default: m |= 0x8; break;
    }
    if (f % 18 == 0) m |= 0x10;
    return m;
}

static uint8_t *read_file(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *b = malloc(n); if (fread(b, 1, n, f) != (size_t)n) exit(2); fclose(f);
    *len = n; return b;
}

int main(int argc, char **argv) {
    size_t bl; uint8_t *blob = read_file(argv[1], &bl);
    if (lila_init(blob, bl) != 0) { printf("init fail\n"); return 1; }
    const uintptr_t ssz = lila_snapshot_size();
    uint8_t *snap = malloc(ssz);
    int16_t pcm[SPF];
    uint64_t *hashes = malloc(sizeof(uint64_t) * 2000);

    /* pass A: 600 frames, record hashes, snapshot at 300 */
    for (uint32_t f = 0; f < 600; f++) {
        lila_input_set(input_for(f));
        lila_frame();
        lila_audio_fill(pcm, SPF);
        if (f == 300) { if (lila_snapshot_save(snap, ssz)) { printf("save fail\n"); return 1; } }
        hashes[f] = lila_state_hash(f);
    }
    printf("pass A done, snapshot at 300 (engine frame %u)\n", lila_tick());

    /* pass B: restore, resim 300..599 with SAME calls, compare */
    const int do_save = argc > 2 && atoi(argv[2]) == 1;
    const int rf = lila_snapshot_load(snap, ssz);
    printf("restore -> frame %d, do_save=%d\n", rf, do_save);
    uint32_t bad = 0, first_bad = 0xFFFFFFFF;
    for (uint32_t f = (uint32_t)rf; f < 600; f++) {
        lila_input_set(input_for(f));
        lila_frame();
        lila_audio_fill(pcm, SPF);
        if (do_save) { uint8_t tmp[8]; (void)tmp; /* keep same call count shape */ }
        const uint64_t h = lila_state_hash(f);
        if (h != hashes[f]) { bad++; if (first_bad == 0xFFFFFFFF) first_bad = f; }
    }
    printf("pass B: %u/%u mismatched, first bad at frame %u (offset from restore: %d)\n",
           bad, 600 - (uint32_t)rf, first_bad, first_bad == 0xFFFFFFFF ? -1 : (int)first_bad - rf);
    return 0;
}
