/* ============================================================================
 * c_host — a plain C program embedding the LILA console via liblila_c.
 * ============================================================================
 *
 * This is the reference host for Unity (P/Invoke), Unreal (module link), or
 * any C/C++ engine. It PROVES the embedding claim:
 *
 *   1. REPLAY   — re-simulates a runner-recorded LIR1 movie through this
 *                 ABI and verifies the per-frame hash chain 300/300.
 *   2. ROLLBACK — saves a 2MB snapshot mid-run, runs to the end, restores,
 *                 re-runs the tail: hashes match again (save-anywhere /
 *                 GGPO-style rollback through the same ABI).
 *   3. AUDIO    — dumps the PCM path to a WAV that must be byte-identical
 *                 to the runner's game.wav.
 *   4. ENTITIES — walks the typed-field registry + live entity tables +
 *                 globals (the data source for driving transforms).
 *
 * Build: see verify.sh (zig build-lib + cc).
 * Usage: c_host <game.libyte> <movie.lir> <out.wav>
 * ==========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lila.h"

#define SR 44100
#define FPS 60
#define SPF (SR / FPS) /* 735 samples per frame, exactly like the runner */

static uint8_t *read_file(const char *path, size_t *len_out) {
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "cannot open %s\n", path); exit(1); }
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t *buf = (uint8_t *)malloc((size_t)n);
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) {
        fprintf(stderr, "short read on %s\n", path); exit(1);
    }
    fclose(f);
    *len_out = (size_t)n;
    return buf;
}

static void w32(FILE *f, uint32_t v) {
    uint8_t b[4] = { (uint8_t)v, (uint8_t)(v >> 8), (uint8_t)(v >> 16), (uint8_t)(v >> 24) };
    fwrite(b, 1, 4, f);
}
static void w16(FILE *f, uint16_t v) {
    uint8_t b[2] = { (uint8_t)v, (uint8_t)(v >> 8) };
    fwrite(b, 1, 2, f);
}

/* the runner's wavHeader(), byte for byte */
static void wav_header(FILE *f, uint32_t n_samples) {
    fwrite("RIFF", 1, 4, f);        w32(f, 36 + n_samples * 2);
    fwrite("WAVEfmt ", 1, 8, f);    w32(f, 16);
    w16(f, 1);                      w16(f, 1);          /* PCM, mono  */
    w32(f, SR);                     w32(f, SR * 2);
    w16(f, 2);                      w16(f, 16);
    fwrite("data", 1, 4, f);        w32(f, n_samples * 2);
}

int main(int argc, char **argv) {
    if (argc != 4) {
        fprintf(stderr, "usage: c_host <game.libyte> <movie.lir> <out.wav>\n");
        return 2;
    }

    /* ---- load cartridge ---- */
    size_t blob_len;
    uint8_t *blob = read_file(argv[1], &blob_len);
    const int32_t rc = lila_init(blob, blob_len);
    if (rc != 0) {
        fprintf(stderr, "lila_init failed: rc=%d (last_error=%d)\n", rc, lila_last_error());
        return 1;
    }
    printf("c_host: LILA console booted (abi=%d engine=%d) — %dx%d screen, %dx%d world\n",
           lila_abi_version(), lila_engine_version(),
           lila_screen_w(), lila_screen_h(), lila_world_w(), lila_world_h());

    /* ---- read movie ---- */
    size_t mov_len;
    uint8_t *mov = read_file(argv[2], &mov_len);
    if (mov_len < 8 || memcmp(mov, "LIR1", 4) != 0) {
        fprintf(stderr, "%s is not an LIR1 movie\n", argv[2]); return 1;
    }
    const uint32_t n = mov[4] | (mov[5] << 8) | ((uint32_t)mov[6] << 16) | ((uint32_t)mov[7] << 24);
    printf("movie:  %u frames (%zuB: u32 input + u64 state-hash per frame)\n", n, mov_len);

    /* ---- pass 1: replay the movie, verify the hash chain, dump audio ---- */
    FILE *wav = fopen(argv[3], "wb");
    if (!wav) { fprintf(stderr, "cannot write %s\n", argv[3]); return 1; }
    wav_header(wav, n * SPF);

    const uint32_t snap_at = n / 3;             /* rollback point */
    uint8_t *snap = (uint8_t *)malloc(lila_snapshot_size());
    uint32_t mism = 0, first_bad = 0xFFFFFFFF;
    uint32_t stream_max = 0;

    for (uint32_t f = 0; f < n; f++) {
        const size_t off = 8 + (size_t)f * 12;
        const uint32_t inp = (uint32_t)mov[off] | ((uint32_t)mov[off + 1] << 8) |
                             ((uint32_t)mov[off + 2] << 16) | ((uint32_t)mov[off + 3] << 24);
        uint64_t hexp = 0;
        for (int b = 0; b < 8; b++) hexp |= (uint64_t)mov[off + 4 + b] << (8 * b);

        lila_input_set(inp);                    /* BEFORE the frame        */
        lila_frame();                           /* one 60Hz tick            */
        int16_t pcm[SPF];
        const size_t got = lila_audio_fill(pcm, SPF); /* one frame of audio */
        if (got != SPF) { fprintf(stderr, "audio: got %zu, want %d\n", got, SPF); return 1; }
        fwrite(pcm, sizeof(int16_t), SPF, wav);
        const uint64_t hgot = lila_state_hash(f); /* AFTER, passing f        */

        const uint32_t sc = (uint32_t)lila_stream_count();
        if (sc > stream_max) stream_max = sc;

        if (hgot != hexp) {
            mism++;
            if (first_bad == 0xFFFFFFFF) {
                printf("  first divergence @ %u: expected %016llx got %016llx\n",
                       f, (unsigned long long)hexp, (unsigned long long)hgot);
            }
        }
        if (f == snap_at && lila_snapshot_save(snap, lila_snapshot_size()) != 0) {
            fprintf(stderr, "snapshot save failed\n"); return 1;
        }
    }
    fclose(wav);

    printf("replay:  hash chain %u/%u frames %s\n", n - mism, n,
           mism == 0 ? "MATCH — bit-identical timeline" : "DIVERGED");
    printf("audio:   %s (%u samples)\n", argv[3], n * SPF);
    printf("stream:  max %u verts/frame this run (path A feed)\n", stream_max);
    if (mism != 0) return 1;

    /* ---- entity bridge telemetry (path B feed) ---- */
    printf("schema:  %d typed fields, %d entity types, %d live entities\n",
           lila_tf_count(), lila_entity_types(), lila_live_ents());
    for (int32_t t = 0; t < lila_entity_types(); t++) {
        const int32_t cnt = lila_entity_count((uint32_t)t);
        printf("  type %d: %d live", t, cnt);
        if (cnt > 0) {
            /* first declared field of this type, first live entity */
            for (int32_t tf = 0; tf < lila_tf_count(); tf++) {
                if (lila_tf_ent((uint32_t)tf) == t) {
                    const int32_t idx = lila_next_live((uint32_t)t, 0);
                    if (idx >= 0) {
                        const uint32_t h = lila_make_handle((uint32_t)lila_gen((uint32_t)t, (uint32_t)idx), (uint32_t)idx);
                        printf(" — field0(via handle) = %d (Q24.8: %.2f)",
                               lila_field_read((uint32_t)tf, h),
                               lila_q_to_f(lila_field_read((uint32_t)tf, h)));
                    }
                    break;
                }
            }
        }
        printf("\n");
    }
    for (int32_t tf = 0; tf < lila_tf_count(); tf++) {
        if (lila_tf_ent((uint32_t)tf) == 0xFF) {
            printf("  global[tf %d] = %d (Q24.8: %.2f)\n", tf,
                   lila_global_read((uint32_t)tf), lila_q_to_f(lila_global_read((uint32_t)tf)));
            break; /* first global, e.g. score */
        }
    }

    /* ---- pass 2: rollback — restore the snapshot, re-run the tail ---- */
    const int32_t rf = lila_snapshot_load(snap, lila_snapshot_size());
    if (rf < 0) { fprintf(stderr, "snapshot load rejected\n"); return 1; }
    uint32_t mism2 = 0;
    for (uint32_t f = (uint32_t)rf; f < n; f++) {
        const size_t off = 8 + (size_t)f * 12;
        const uint32_t inp = (uint32_t)mov[off] | ((uint32_t)mov[off + 1] << 8) |
                             ((uint32_t)mov[off + 2] << 16) | ((uint32_t)mov[off + 3] << 24);
        uint64_t hexp = 0;
        for (int b = 0; b < 8; b++) hexp |= (uint64_t)mov[off + 4 + b] << (8 * b);
        lila_input_set(inp);
        lila_frame();
        int16_t scratch[SPF];
        (void)lila_audio_fill(scratch, SPF);    /* keep the chain, discard */
        if (lila_state_hash(f) != hexp) mism2++;
    }
    printf("rollback: restored @ frame %d, re-ran %u frames — %s\n",
           rf, n - (uint32_t)rf,
           mism2 == 0 ? "hashes MATCH (save-anywhere + GGPO primitive)" : "DIVERGED");

    free(snap);
    free(mov);
    free(blob);
    return mism2 == 0 ? 0 : 1;
}
