/* ============================================================================
 * bench_host — measures EXACTLY what a Unity/Unreal host pays, through the
 * same C ABI (lila.h), on a real game or a stress cartridge.
 *
 *   boot       — lila_init cost, memory footprint, capacities
 *   tick       — steady-state full frame contract (input+frame+audio+hash):
 *                mean/median/p95/p99/max ns, 60Hz budget %, ceiling fps
 *   breakdown  — per-API costs: frame alone, 2MB hash, audio, getters
 *   snap       — save/restore latency (LSA1), memcpy throughput
 *   rollback   — GGPO storm: save-every-frame steady cost + 8-frame rollback
 *                spike cost, with hash verification of the resimulated tail
 *   bridge     — entity-bridge walk (path B) + per-call FFI floor
 *
 * Build: cc -O2 -I hosting/include bench_host.c -o bench/bench_host \
 *          runtime/bench_lila_c.so -Wl,-rpath,$(pwd)/runtime
 * Usage: bench_host <game.libyte> [frames]
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <inttypes.h>
#include "lila.h"

#define SPF 735 /* 44100/60 */
#define NS_PER_FRAME_60HZ 16666667LL

static uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static uint8_t *read_file(const char *path, size_t *len_out) {
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "cannot open %s\n", path); exit(1); }
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t *buf = (uint8_t *)malloc((size_t)n);
    if (fread(buf, 1, (size_t)n, f) != (size_t)n) exit(2);
    fclose(f);
    *len_out = (size_t)n;
    return buf;
}

/* deterministic gameplay-active input script (demo bits: 0L 1R 2U 3D 4fire) */
static uint32_t input_for(uint32_t f) {
    uint32_t m = 0;
    switch ((f / 30) % 4) {
        case 0: m |= 0x1; break;
        case 1: m |= 0x2; break;
        case 2: m |= 0x4; break;
        case 3: m |= 0x8; break;
    }
    if (f % 18 == 0) m |= 0x10;
    return m;
}

static int cmp64(const void *a, const void *b) {
    uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b;
    return x < y ? -1 : (x > y ? 1 : 0);
}
static uint64_t pct(uint64_t *v, size_t n, double p) {
    size_t i = (size_t)((double)n * p);
    if (i >= n) i = n - 1;
    return v[i];
}

static void stats_line(const char *label, uint64_t *v, size_t n) {
    qsort(v, n, sizeof(uint64_t), cmp64);
    uint64_t sum = 0;
    for (size_t i = 0; i < n; i++) sum += v[i];
    printf("  %-22s mean %8.2f us | med %8.2f | p95 %8.2f | p99 %8.2f | max %8.2f\n",
           label,
           (double)sum / n / 1000.0,
           (double)v[n / 2] / 1000.0,
           (double)pct(v, n, 0.95) / 1000.0,
           (double)pct(v, n, 0.99) / 1000.0,
           (double)v[n - 1] / 1000.0);
}

static long rss_kb(void) {
    FILE *f = fopen("/proc/self/status", "r");
    char line[256];
    long kb = -1;
    while (f && fgets(line, sizeof line, f))
        if (sscanf(line, "VmRSS: %ld kB", &kb) == 1) break;
    if (f) fclose(f);
    return kb;
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: bench_host <game.libyte> [frames]\n"); return 2; }
    const uint32_t WARM = 1500;                 /* reach steady state (demo: 12-enemy cap ~1100 frames) */
    const uint32_t N = argc > 2 ? (uint32_t)atoi(argv[2]) : 10000;
    int16_t pcm[SPF];
    uint64_t *ns = (uint64_t *)malloc(sizeof(uint64_t) * N);
    uint64_t *ns2 = (uint64_t *)malloc(sizeof(uint64_t) * N);

    /* ---------------- boot ---------------- */
    size_t blob_len;
    uint8_t *blob = read_file(argv[1], &blob_len);
    uint64_t t0 = now_ns();
    if (lila_init(blob, (uintptr_t)blob_len) != 0) {
        fprintf(stderr, "lila_init failed rc=%d err=%d\n", 0, lila_last_error());
        return 1;
    }
    uint64_t t1 = now_ns();
    printf("[boot]\n  lila_init:            %8.1f us   (cart %zu B)\n",
           (double)(t1 - t0) / 1000.0, blob_len);
    printf("  engine: abi %d, v%d, screen %dx%d, world %dx%d, mem %u B, tf %d, types %d\n",
           lila_abi_version(), lila_engine_version(),
           lila_screen_w(), lila_screen_h(), lila_world_w(), lila_world_h(),
           (unsigned)lila_mem_size(), lila_tf_count(), lila_entity_types());
    printf("  caps: ents %d, verts %d, instr %d\n",
           lila_cap_ent(), lila_cap_verts(), lila_cap_instr());

    /* warm-up to gameplay steady state */
    for (uint32_t f = 0; f < WARM; f++) {
        lila_input_set(input_for(f));
        lila_frame();
        lila_audio_fill(pcm, SPF);
    }
    printf("  steady state:         %d live entities, %d verts this frame\n",
           lila_live_ents(), lila_stream_count());

    /* ---------------- tick: the full host frame contract ---------------- */
    for (uint32_t f = 0; f < N; f++) {
        uint64_t s = now_ns();
        lila_input_set(input_for(f));
        lila_frame();
        lila_audio_fill(pcm, SPF);
        (void)lila_state_hash(f);
        ns[f] = now_ns() - s;
    }
    printf("[tick]  full frame contract (input+frame+audio+hash) x %u\n", N);
    stats_line("per frame", ns, N);
    {
        qsort(ns, N, sizeof(uint64_t), cmp64);
        double med = (double)ns[N / 2] / 1000.0;
        printf("  60Hz budget use:      %8.3f %%   ceiling %8.0f fps\n",
               med * 1000.0 / (double)NS_PER_FRAME_60HZ * 100.0,
               1e6 / med);
    }

    /* ---------------- breakdown ---------------- */
    printf("[breakdown]\n");
    for (uint32_t f = 0; f < N; f++) {
        uint64_t s = now_ns();
        lila_input_set(input_for(f));
        lila_frame();
        ns[f] = now_ns() - s;
    }
    stats_line("lila_frame (sim only)", ns, N);
    {
        const uint32_t cur = lila_tick();
        for (uint32_t i = 0; i < N; i++) ns[i] = now_ns(), (void)lila_state_hash(cur);
        /* time just the call */
        uint64_t s = now_ns();
        for (uint32_t i = 0; i < N; i++) (void)lila_state_hash(cur);
        uint64_t e = now_ns();
        printf("  %-22s mean %8.2f us   (2MB wyhash, ~%.1f GB/s)\n",
               "lila_state_hash", (double)(e - s) / N / 1000.0,
               (double)lila_mem_size() / ((double)(e - s) / N));
    }
    {
        uint64_t s = now_ns();
        for (uint32_t i = 0; i < N; i++) (void)lila_audio_fill(pcm, SPF);
        uint64_t e = now_ns();
        printf("  %-22s mean %8.2f us   (735-sample mix)\n", "lila_audio_fill",
               (double)(e - s) / N / 1000.0);
    }
    {
        uint64_t s = now_ns();
        for (uint32_t i = 0; i < N; i++) (void)lila_stream_count();
        uint64_t e = now_ns();
        printf("  %-22s mean %8.1f ns\n", "lila_stream_count", (double)(e - s) / N);
    }
    {   /* FFI floor: trivial getter through the same boundary */
        enum { M = 1000000 };
        uint64_t s = now_ns();
        for (int i = 0; i < M; i++) (void)lila_tick();
        uint64_t e = now_ns();
        printf("  %-22s mean %8.1f ns   (FFI floor per call)\n", "lila_tick [getter]",
               (double)(e - s) / M);
    }

    /* ---------------- snapshots ---------------- */
    printf("[snap]\n");
    {
        const uintptr_t ssz = lila_snapshot_size();
        uint8_t *snap = (uint8_t *)malloc(ssz);
        for (uint32_t i = 0; i < 1000; i++) ns[i] = now_ns(), (void)lila_snapshot_save(snap, ssz);
        uint64_t s = now_ns();
        for (uint32_t i = 0; i < 1000; i++) (void)lila_snapshot_save(snap, ssz);
        uint64_t e = now_ns();
        const double save_us = (double)(e - s) / 1000.0 / 1000.0;
        printf("  save   %zu B:         %8.1f us   (%.2f GB/s)  [%s]\n",
               (size_t)ssz, save_us, (double)ssz / (save_us * 1000.0),
               lila_snapshot_save(snap, ssz) == 0 ? "ok" : "FAIL");
        for (uint32_t i = 0; i < 1000; i++) ns[i] = now_ns(), (void)lila_snapshot_load(snap, ssz);
        s = now_ns();
        for (uint32_t i = 0; i < 1000; i++) (void)lila_snapshot_load(snap, ssz);
        e = now_ns();
        const double load_us = (double)(e - s) / 1000.0 / 1000.0;
        printf("  restore:              %8.1f us   (%.2f GB/s)\n",
               load_us, (double)ssz / (load_us * 1000.0));
        /* roundtrip correctness: save, run 50, restore, tick must rewind */
        (void)lila_snapshot_save(snap, ssz);
        const uint32_t f_before = lila_tick();
        for (int i = 0; i < 50; i++) { lila_input_set(input_for(f_before + i)); lila_frame(); lila_audio_fill(pcm, SPF); }
        const int32_t rf = lila_snapshot_load(snap, ssz);
        printf("  roundtrip:            restore says frame %d, tick()==%u  [%s]\n",
               rf, lila_tick(), (uint32_t)rf == lila_tick() && rf == (int32_t)f_before ? "ok" : "FAIL");
        free(snap);
    }

    /* ---------------- GGPO rollback storm ---------------- */
    printf("[rollback]  8-frame ring, save every frame, roll every 30\n");
    {
        enum { RING = 9, EVERY = 30 };
        const uintptr_t ssz = lila_snapshot_size();
        uint8_t *ring = (uint8_t *)malloc(ssz * RING);
        uint64_t *hashes = (uint64_t *)malloc(sizeof(uint64_t) * (N + 64));
        double normal_sum = 0; uint32_t normal_n = 0;
        uint64_t *spikes = (uint64_t *)malloc(sizeof(uint64_t) * (N / EVERY + 8));
        uint32_t nspike = 0, diverged = 0;
        for (uint32_t f = 0; f < N; f++) {
            /* --- normal frame: input, sim, audio, save into ring --- */
            uint64_t s = now_ns();
            lila_input_set(input_for(f));
            lila_frame();
            lila_audio_fill(pcm, SPF);
            (void)lila_snapshot_save(ring + ssz * (f % RING), ssz);
            hashes[f] = lila_state_hash(f);
            uint64_t e = now_ns();
            normal_sum += (double)(e - s); normal_n++;
            /* --- storm event: rewind 8 frames, resim the tail with the
             * same inputs (spike frame must still fit the 16.67ms budget) --- */
            if (f >= RING && f % EVERY == 0) {
                uint64_t s2 = now_ns();
                const uint32_t back = f - (RING - 1);      /* ring slot saved 8 frames ago */
                const int32_t rf = lila_snapshot_load(ring + ssz * (back % RING), ssz);
                if (rf < 0) { fprintf(stderr, "restore rejected\n"); return 1; }
                /* ring slot for `back` was saved AFTER frame back ran, so the
                 * restored engine is "post-back": resim runs back+1..f (8 frames) */
                for (uint32_t g = back + 1; g <= f; g++) {
                    lila_input_set(input_for(g));
                    lila_frame();
                    lila_audio_fill(pcm, SPF);
                    (void)lila_snapshot_save(ring + ssz * (g % RING), ssz);
                    if (lila_state_hash(g) != hashes[g]) diverged++;
                }
                uint64_t e2 = now_ns();
                if (nspike < N / EVERY + 8) spikes[nspike++] = e2 - s2;
            }
        }
        printf("  steady (frame+save):  %8.2f us mean   (netcode recording cost)\n",
               normal_sum / normal_n / 1000.0);
        stats_line("rollback spike", spikes, nspike);
        printf("  determinism:          %u resim hashes diverged %s\n",
               diverged, diverged == 0 ? "(chain intact under storm)" : "!! TIMELINE FORK !!");
        free(ring); free(hashes); free(spikes);
    }

    /* ---------------- entity bridge (path B) ---------------- */
    printf("[bridge]\n");
    {
        int32_t best_type = -1, best_cnt = 0;
        for (int32_t t = 0; t < lila_entity_types(); t++) {
            int32_t c = lila_entity_count((uint32_t)t);
            if (c > best_cnt) { best_cnt = c; best_type = t; }
        }
        if (best_type >= 0 && best_cnt > 0) {
            /* first two fields of that type = "x, y" for transform driving */
            int32_t tf0 = -1, tf1 = -1;
            for (int32_t tf = 0; tf < lila_tf_count(); tf++)
                if (lila_tf_ent((uint32_t)tf) == best_type) {
                    if (tf0 < 0) tf0 = tf;
                    else if (tf1 < 0) { tf1 = tf; break; }
                }
            uint64_t s = now_ns();
            volatile int32_t sink = 0;
            int32_t idx = lila_next_live((uint32_t)best_type, 0);
            uint32_t nents = 0, nreads = 0;
            while (idx >= 0) {
                const uint32_t h = lila_make_handle((uint32_t)lila_gen((uint32_t)best_type, (uint32_t)idx), (uint32_t)idx);
                if (tf0 >= 0) { sink += lila_field_read((uint32_t)tf0, h); nreads++; }
                if (tf1 >= 0) { sink += lila_field_read((uint32_t)tf1, h); nreads++; }
                nents++;
                idx = lila_next_live((uint32_t)best_type, (uint32_t)idx + 1);
            }
            uint64_t e = now_ns();
            printf("  walk type %d:          %d entities, %u field reads in %.1f us  (%.0f ns/read)\n",
                   best_type, best_cnt, nreads, (double)(e - s) / 1000.0,
                   (double)(e - s) / (nreads ? nreads : 1));
            printf("  (that is the per-frame Unity transform-drive cost)\n");
        } else {
            printf("  (no live entities — stress cart?)\n");
        }
    }

    /* ---------------- v17.2 host services ---------------- */
    printf("[hostopt] delta snapshots, history ring, batched feed\n");
    {
        /* delta: 60 frames of churn, measured */
        uint8_t *base2 = (uint8_t *)malloc(lila_snapshot_size());
        uint8_t *db = (uint8_t *)malloc(lila_delta_max());
        if (lila_snapshot_save(base2, lila_snapshot_size()) != 0) return 1;
        for (int i = 0; i < 60; i++) { lila_input_set(input_for(lila_tick())); lila_frame(); lila_audio_fill(pcm, SPF); }
        size_t dn = lila_delta_save(base2, lila_snapshot_size(), db, lila_delta_max());
        uint64_t s = now_ns();
        for (int i = 0; i < 100; i++) (void)lila_delta_save(base2, lila_snapshot_size(), db, lila_delta_max());
        uint64_t e = now_ns();
        printf("  delta save (%zu B for 60f):  %8.1f us  (%.2f%% of full)\n",
               dn, (double)(e - s) / 100 / 1000.0, 100.0 * (double)dn / (double)lila_snapshot_size());
        s = now_ns();
        for (int i = 0; i < 100; i++) (void)lila_delta_load(base2, lila_snapshot_size(), db, dn);
        e = now_ns();
        printf("  delta load:                 %8.1f us  (vs 140us full memcpy restore)\n",
               (double)(e - s) / 100 / 1000.0);
        free(base2); free(db);
    }
    {
        /* history: steady capture cost + seek cost, 512-ring */
        if (lila_history_start(512) < 0) return 1;
        for (uint32_t f = 0; f < 3000; f++) {
            lila_input_set(input_for(f)); lila_frame(); lila_audio_fill(pcm, SPF);
        }
        const int32_t hb2 = lila_history_begin();
        const int32_t depth = lila_history_frames();
        const uint32_t last = lila_tick();
        printf("  ring state: begin=%d depth=%d\n", hb2, depth);
        uint64_t total = 0; int nseeks = 0;
        for (int i = 0; i < 50 && depth > 1; i++) {
            const uint32_t target = (uint32_t)(hb2 + (i * 7) % (uint32_t)(depth - 1));
            uint64_t s = now_ns();
            if (lila_history_seek(target) < 0) { printf("  seek failed @%u\n", target); return 1; }
            total += now_ns() - s; nseeks++;
            /* GGPO truncation: replay to the present so later targets exist */
            while (lila_tick() < last) {
                lila_input_set(input_for(lila_tick())); lila_frame(); lila_audio_fill(pcm, SPF);
            }
        }
        printf("  history seek (%dx):         %8.1f us mean, ring %d deep (oldest %d)\n",
               nseeks, (double)total / (nseeks ? nseeks : 1) / 1000.0, lila_history_frames(), hb2);
        /* steady frame cost WITH recording on */
        {
            uint64_t s = now_ns();
            for (uint32_t f = 0; f < 1000; f++) {
                lila_input_set(input_for(f)); lila_frame(); lila_audio_fill(pcm, SPF);
            }
            uint64_t e = now_ns();
            printf("  frame + record:             %8.1f us  (recording overhead)\n",
                   (double)(e - s) / 1000 / 1000.0);
        }
        lila_history_stop();
    }
    {
        /* batched feed: build cost + reduction in host draw calls */
        int32_t nb = 0;
        uint64_t s = now_ns();
        for (int i = 0; i < 100; i++) (void)lila_stream_batches(&nb);
        uint64_t e = now_ns();
        const int32_t nv = lila_stream_count();
        printf("  batch scan (%d verts):       %8.1f us -> %d instanced draws (was %d verts)\n",
               nv, (double)(e - s) / 100 / 1000.0, nb, nv);
    }

    /* ---------------- memory ---------------- */
    printf("mem:     host RSS after all benches: %ld kB (engine image %u B)\n",
           rss_kb(), (unsigned)lila_mem_size());

    free(ns); free(ns2); free(blob);
    return 0;
}
