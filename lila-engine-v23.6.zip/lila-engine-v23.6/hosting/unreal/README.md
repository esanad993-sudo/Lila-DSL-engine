# LILA in Unreal

**The deal:** LILA is the simulation (deterministic, integer-only, replayable,
rollback-able). Unreal is the presentation (Nanite/Lumen, asset pipeline,
MetaSounds, platform ports, editor tooling). They talk through a C ABI that
is verified bit-identical to the native runner — see
`hosting/examples/c_host/verify.sh` (300/300 hash chain, byte-identical WAV).

Unreal's link is *stronger* than Unity's P/Invoke: the engine core links
directly into your monolithic game binary as a static library.

## Files

| File | Status | What it is |
|------|--------|------------|
| `Lila.Build.cs` | skeleton (idiomatic UBT, not compiled here) | module rules linking `lila_c.lib` / `liblila_c.a` |
| `LilaVM.h/.cpp` | skeleton | `ALilaVM` actor: fixed-tick accumulator, `SaveState`/`LoadState` (2MB memcpy), stream/entity presentation hooks |

## Setup

1. **Build the library** (from `runtime/` in the engine repo):
   ```
   zig build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc -target x86_64-windows-gnu
   ```
   → `lila_c.lib` + `lila_c.dll` (import lib + DLL). For Linux:
   drop `-target` (or `-target x86_64-linux`) → `liblila_c.so`/`.a`.
   The `-lc` is REQUIRED — see INTEGRATION.md "The -lc lesson".
2. **ThirdParty layout** (as referenced by `Lila.Build.cs`):
   ```
   Source/ThirdParty/LILA/include/lila.h
   Source/ThirdParty/LILA/lib/x64/Release/lila_c.lib
   Source/ThirdParty/LILA/lib/x64/Release/lila_c.dll
   ```
3. Copy `Lila.Build.cs`, `LilaVM.h/.cpp` into `Source/<YourGame>/` (or a
   runtime module of yours) and regenerate project files.
4. Compile your game (`lilac build MyGame.lila`) into `Content/Games/`.

## Determinism notes for UE specifically

- **GC / streaming hitches**: they delay WHEN a frame computes, never WHAT.
  The `ALilaVM` accumulator caps catch-up at 5 steps — a stall becomes
  slow-motion, not divergence. `lila_state_hash` stays on the movie chain.
- **Chaos physics**: do not run LILA entities through UE physics. LILA's
  integration IS the physics; UE colliders, if wanted, mirror the tables.
- **Presentation**: paths A (decode the 14B vertex stream into a dynamic
  mesh) and B (walk entity tables, drive your components) are documented
  in `LilaVM.cpp` and `hosting/INTEGRATION.md`.
- **Rollback netcode recipe**: keep an input ring + a snapshot ring
  (`lila_snapshot_save` is one memcpy), re-simulate on late input — the
  exact recipe is in INTEGRATION.md §Rollback.

## The party trick

Record a movie with the native runner
(`runner game.libyte --frames 300 --record movie.lir`), then in PIE replay
the same inputs and compare `StateHash(F)` per frame — they match
bit-for-bit. `hosting/examples/c_host` does exactly this against the same
ABI every CI run.
