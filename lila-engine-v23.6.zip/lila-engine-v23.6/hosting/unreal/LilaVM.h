// ============================================================================
// LilaVM.h — UE-style face over the verified C ABI (see hosting/include/lila.h)
// ============================================================================
// Skeleton status: the ABI is verified (hosting/examples/c_host — 300/300
// hash chain, byte-identical audio, snapshot rollback). The UE glue below
// is idiomatic UE5 but was not compiled in the engine repo.
// ============================================================================

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

extern "C" {
#include "lila.h"
}

#include "LilaVM.generated.h"

/** One LILA console embedded in the Unreal world: fixed-tick simulation
 *  driven from Tick, presentation via the stream/entity bridges. */
UCLASS(ClassGroup = (LILA))
class LILA_API ALilaVM : public AActor
{
    GENERATED_BODY()

public:
    ALilaVM();

    /** Path to the compiled .libyte, relative to your Content dir
     *  ("Games/patrol.libyte"). Load scheme is yours — you just need
     *  bytes before BeginPlay ends. */
    UPROPERTY(EditAnywhere, Category = "LILA")
    FString CartridgeContentPath = TEXT("Games/game.libyte");

    /** Input bits: 0=left 1=right 2=up 3=fire (mirror the game's key()
     *  queries). Map your Enhanced Input actions onto this in Blueprint
     *  or C++ before each tick. */
    UPROPERTY(BlueprintReadWrite, Category = "LILA")
    int32 InputMask = 0;

    /** Fired after each simulation tick — present the frame here: decode
     *  the 14B stream (path A) or walk entity tables (path B). */
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnLilaFrame);
    UPROPERTY(BlueprintAssignable, Category = "LILA")
    FOnLilaFrame OnLilaFrame;

    /** Instant save state — a 2MB memcpy, no scene serialization. */
    UFUNCTION(BlueprintCallable, Category = "LILA")
    bool SaveState();

    /** Instant load state — same frame, same RNG, same everything. */
    UFUNCTION(BlueprintCallable, Category = "LILA")
    bool LoadState();

    /** State hash AFTER the given 0-based frame. Compare against a
     *  runner-recorded movie for bit-exact verification (the guarantee
     *  hosting/examples/c_host proves for this ABI). */
    UFUNCTION(BlueprintPure, Category = "LILA")
    int64 StateHash(int32 Frame) const { return (int64)lila_state_hash((uint32)Frame); }

    /** Draw-order vertex count this frame (path A feed). */
    UFUNCTION(BlueprintPure, Category = "LILA")
    int32 StreamVerts() const { return lila_stream_count(); }

    UFUNCTION(BlueprintPure, Category = "LILA")
    int32 LiveEntities() const { return lila_live_ents(); }

    /** Screen size the game declared (pixels). */
    UPROPERTY(BlueprintReadOnly, Category = "LILA")
    int32 ScreenW = 0;
    UPROPERTY(BlueprintReadOnly, Category = "LILA")
    int32 ScreenH = 0;

    // Q24.8 -> float, at the presentation boundary ONLY
    static float QToF(int32 Q) { return (float)Q / 256.0f; }

protected:
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;

    void StepOneFrame();

    bool bBooted = false;
    float Accumulator = 0.0f;
    uint32 FrameNo = 0;

    TArray<uint8> Snapshot;   // LSA1 image (44 + 2MB)
    TArray<int16> Pcm;       // exactly 735 samples per tick (hash chain)
};
