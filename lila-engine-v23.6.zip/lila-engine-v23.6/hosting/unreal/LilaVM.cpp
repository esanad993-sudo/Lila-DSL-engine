// ============================================================================
// LilaVM.cpp — fixed-tick LILA console actor (skeleton, see LilaVM.h)
// ============================================================================

#include "LilaVM.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformFileManager.h"
#include "Kismet/GameplayStatics.h"

ALilaVM::ALilaVM()
{
    PrimaryActorTick.bCanEverTick = true;
    // The simulation runs on OUR accumulator, not on UE's fixed tick —
    // render fps and GC hitches then only affect WHEN frames compute,
    // never WHAT they compute.
}

void ALilaVM::BeginPlay()
{
    Super::BeginPlay();

    // ---- load cartridge bytes ----
    TArray<uint8> Blob;
    const FString Path = FPaths::Combine(FPaths::ProjectContentDir(), CartridgeContentPath);
    if (!FFileHelper::LoadFileToArray(Blob, *Path))
    {
        UE_LOG(LogTemp, Error, TEXT("LILA: cannot read cartridge %s"), *Path);
        return;
    }
    const int32 Rc = lila_init(Blob.GetData(), (uintptr_t)Blob.Num());
    if (Rc != 0)
    {
        UE_LOG(LogTemp, Error, TEXT("LILA: init failed rc=%d last_error=%d"), Rc, lila_last_error());
        return;
    }

    ScreenW = lila_screen_w();
    ScreenH = lila_screen_h();
    Snapshot.SetNum((int32)lila_snapshot_size());
    Pcm.SetNum(44100 / 60); // 735 — exact, audio phase is hash-relevant
    bBooted = true;

    UE_LOG(LogTemp, Log, TEXT("LILA: booted %dx%d, %d fields, %d entity types"),
        ScreenW, ScreenH, lila_tf_count(), lila_entity_types());
}

void ALilaVM::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    if (!bBooted) return;

    Accumulator += DeltaSeconds;
    int32 Steps = 0;
    while (Accumulator >= 1.0f / 60.0f && Steps < 5)
    {
        StepOneFrame();
        Accumulator -= 1.0f / 60.0f;
        Steps++;
    }
    if (Steps == 5) Accumulator = 0.0f; // stall -> slow-mo, never fast-forward
}

void ALilaVM::StepOneFrame()
{
    lila_input_set((uint32)InputMask);              // BEFORE
    lila_frame();                                    // one 60Hz tick
    (void)lila_audio_fill(Pcm.GetData(), (uintptr_t)Pcm.Num()); // one frame
    // (feed Pcm into a USoundWaveProcedural for the audio path — the pull
    //  itself is what keeps the audio phase on the hash chain)
    FrameNo++;
    OnLilaFrame.Broadcast();                         // present the frame
}

bool ALilaVM::SaveState()
{
    return lila_snapshot_save(Snapshot.GetData(), (uintptr_t)Snapshot.Num()) == 0;
}

bool ALilaVM::LoadState()
{
    const int32 F = lila_snapshot_load(Snapshot.GetData(), (uintptr_t)Snapshot.Num());
    if (F < 0) return false;
    FrameNo = (uint32)F;
    return true;
}

// ============================================================================
// Presenting a frame — two patterns, both pure reads of verified state:
//
// PATH A (render the game's own draws): lila_stream_ptr() points at
//   StreamVerts() records of 14 bytes (int16 x, int16 y, uint16 uv,
//   uint32 rgba, uint16 token), screen-space. Build a dynamic mesh /
//   instanced quads from them each OnLilaFrame.
//
// PATH B (your assets): walk the typed-field registry once (lila_tf_ent /
//   lila_tf_off / ...), then per frame: lila_next_live + lila_make_handle
//   + lila_field_read. Q24.8 positions convert with QToF() ONLY here —
//   never write floats back into simulation words.
// ============================================================================
