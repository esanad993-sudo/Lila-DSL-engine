// ============================================================================
// LilaOverlayComponent.cpp — v23 the hijack component (Unreal skeleton)
// ============================================================================
//
// The frame contract, zero-copy edition:
//     lila_input_set(mask);                 // BEFORE the frame
//     lila_tick_pipeline(Rows);              // one tick + in-place flush
//     lila_audio_fill(pcm, 735);             // exact, hash-relevant
//
// The engine footprint is ~770KB of Zig; the gameplay iteration loop is
// `lilac build` + HotSwapCartridge() — no UBT in the loop, ever.
// ============================================================================

#include "LilaOverlayComponent.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformFileManager.h"

ULilaOverlayComponent::ULilaOverlayComponent()
{
        PrimaryComponentTick.bCanEverTick = true;
        PrimaryComponentTick.TickGroup = TG_PrePhysics; // sim before presentation
}

void ULilaOverlayComponent::BeginPlay()
{
        Super::BeginPlay();

        // ---- load cartridge bytes ----
        TArray<uint8> Blob;
        const FString Path = FPaths::Combine(FPaths::ProjectContentDir(), CartridgeContentPath);
        if (!FFileHelper::LoadFileToArray(Blob, *Path))
        {
                UE_LOG(LogTemp, Error, TEXT("LILA overlay: cannot read cartridge %s"), *Path);
                return;
        }
        const int32 Rc = lila_init(Blob.GetData(), (uintptr_t)Blob.Num());
        if (Rc != 0)
        {
                UE_LOG(LogTemp, Error, TEXT("LILA overlay: init failed rc=%d last_error=%d"), Rc, lila_last_error());
                return;
        }

        // ---- the mirror surface: UE-allocated rows ----
        RowStride = LilaOverlay::RowBytes(EntityType);
        if (RowStride <= 0 || MaxRows <= 0)
        {
                UE_LOG(LogTemp, Error, TEXT("LILA overlay: bad entity type %d"), EntityType);
                return;
        }
        Rows.SetNumUninitialized(RowStride * MaxRows);
        FMemory::Memzero(Rows.GetData(), Rows.Num());
        // lila_overlay_install returns 0 = ok; negative = refused (see lila.h):
        // -1 bad type, -2 layout hash mismatch, -3 stride < row size, -4 cap.
        const int32 InstallRc = lila_overlay_install((uint32)EntityType, Rows.GetData(),
                                                     (uint32)RowStride, (uint32)MaxRows,
                                                     LILA_INTEROP_LAYOUT_HASH);
        if (InstallRc != 0)
        {
                // -2 = layout hash mismatch: LilaInterop.h is stale — regenerate it
                // (--emit-bridges) and recompile this module.
                UE_LOG(LogTemp, Error, TEXT("LILA overlay: install REFUSED rc=%d (stale LilaInterop.h?)"), InstallRc);
                return;
        }

        Pcm.SetNumUninitialized(44100 / 60);
        bBooted = true;
        UE_LOG(LogTemp, Log,
               TEXT("LILA overlay: booted, type %d rows %dx%dB, layout 0x%08X"),
               EntityType, MaxRows, RowStride, (uint32)LilaOverlay::LayoutHash());
}

void ULilaOverlayComponent::TickComponent(float DeltaTime, ELevelTick, FActorComponentTickFunction*)
{
        if (!bBooted) return;

        // Fixed 60Hz accumulator: the simulation never sees render fps, GC
        // hitches or UBT stalls — only WHEN frames compute, never WHAT.
        Accumulator += DeltaTime;
        int32 Steps = 0;
        while (Accumulator >= 1.0f / 60.0f && Steps < 5)
        {
                StepOneFrame();
                Accumulator -= 1.0f / 60.0f;
                Steps++;
        }
        if (Steps == 5) Accumulator = 0.0f; // stall -> slow-mo, never fast-forward
}

void ULilaOverlayComponent::StepOneFrame()
{
        lila_input_set((uint32)InputMask);

        // ---- THE ZERO-COPY PIPELINE -----------------------------------------
        // The raw memory of our row array goes straight into the Zig runtime;
        // the live dense SoA rows are scattered into it in place. No UObject,
        // no property system, no marshalling — register-speed lane writes.
        lila_tick_pipeline(Rows.GetData(), (uint32)(RowStride > 0 ? Rows.Num() / RowStride : 0));

        (void)lila_audio_fill(Pcm.GetData(), (uintptr_t)Pcm.Num());
        // (feed Pcm into a USoundWaveProcedural — the pull keeps the hash chain)
        FrameNo++;

        // ---- count live rows for the broadcast (bit0 of lila_meta) ----
        const uint8* Data = Rows.GetData();
        const int32 Cap = RowStride > 0 ? Rows.Num() / RowStride : 0;
        int32 Live = 0;
        for (int32 I = 0; I < Cap; ++I)
        {
                uint32 Meta;
                FMemory::Memcpy(&Meta, Data + (size_t)I * RowStride, 4);
                Live += (Meta & 1u) ? 1 : 0;
        }
        LiveRows = Live;

        OnLilaOverlayFrame.Broadcast(LiveRows);
}

bool ULilaOverlayComponent::HotSwapCartridge(const FString& InPath)
{
        TArray<uint8> Blob;
        if (!FFileHelper::LoadFileToArray(Blob, *InPath))
        {
                UE_LOG(LogTemp, Error, TEXT("LILA overlay: hot-swap: cannot read %s"), *InPath);
                return false;
        }
        const int32 Preserved = lila_hot_swap(Blob.GetData(), (uintptr_t)Blob.Num());

        // A new cartridge means new layouts — reinstall the mirror surface.
        RowStride = LilaOverlay::RowBytes(EntityType);
        Rows.SetNumUninitialized(RowStride * MaxRows);
        FMemory::Memzero(Rows.GetData(), Rows.Num());
        const int32 Rc = lila_overlay_install((uint32)EntityType, Rows.GetData(),
                                             (uint32)RowStride, (uint32)MaxRows,
                                             LILA_INTEROP_LAYOUT_HASH);
        UE_LOG(LogTemp, Log,
               TEXT("LILA overlay: hot-swap: state %s, reinstall rc=%d (layout 0x%08X)"),
               Preserved == 1 ? TEXT("PRESERVED") : TEXT("re-initialized"),
               Rc, (uint32)LilaOverlay::LayoutHash());
        return Rc == 0;
}

void ULilaOverlayComponent::EndPlay(const EEndPlayReason::Type Reason)
{
        // Nothing to free on LILA's side — the engine state is one flat image
        // and the rows are OUR TArray. Dropping the install is enough.
        Rows.Reset();
        bBooted = false;
        Super::EndPlay(Reason);
}
