// ============================================================================
// LilaOverlay.h — v23 pointer-overlay API for the Unreal module.
// ============================================================================
//
// The zero-copy surface: plain C wrappers with strong types on top of the
// ABI (see lila.h "v23 / ABI 5"). The generated LilaInterop.h (from
// `lilac build game.lila --emit-bridges Source/Lila`) defines FLilaXRow —
// pack(1) structs with static asserts pinning sizes and lane offsets, in
// EXACTLY the layout the Zig runtime scatters into.
//
//   TArray<FLilaDroneRow> Rows;              // UE-allocated, UE-owned
//   LilaOverlay::Install(Rows, LILA_DRONE_TYPE);
//   ... per tick: LilaOverlay::TickPipeline(Rows);   // frame + flush
//
// No marshalling, no UObject per entity, no FStruct property system in the
// loop: LILA writes the live SoA rows straight into Rows' memory.
// ============================================================================

#pragma once

#include "CoreMinimal.h"
#include "lila.h"
#include "LilaInterop.h" // generated: FLilaXRow structs + LILA_*_* constants

namespace LilaOverlay
{
	// ---- strong-typed row view (the generated structs are plain C) ----

	FORCEINLINE int32 RowBytes(int32 Type) { return lila_overlay_row_bytes((uint32)Type); }
	FORCEINLINE uint32 LayoutHash() { return lila_overlay_layout_hash(); }

	/** Install a UE-allocated TArray of generated rows as type's mirror.
	 *  Stride is sizeof(RowType) — embed the row in a bigger struct and
	 *  pass a raw pointer + stride instead if you carry per-object data. */
	template <typename RowType>
	FORCEINLINE bool Install(TArray<RowType>& Rows, int32 Type)
	{
		return lila_overlay_install((uint32)Type, (uint8_t*)Rows.GetData(),
		                            sizeof(RowType), Rows.Num(),
		                            LILA_INTEROP_LAYOUT_HASH) == 0;
	}

	/** The one-call pipeline (single-type games): frame + in-place flush.
	 *  lila_input_set BEFORE this, exactly like lila_frame. */
	template <typename RowType>
	FORCEINLINE void TickPipeline(TArray<RowType>& Rows)
	{
		lila_tick_pipeline((uint8_t*)Rows.GetData(), (uint32)Rows.Num());
	}

	/** Multi-type form: install each type once, then tick + flush all. */
	FORCEINLINE void OverlayTick() { lila_overlay_tick(); }
	FORCEINLINE void FlushNow() { lila_overlay_flush(); }

	/** The import path (boot/level loads): host rows -> spawns. Floats
	 *  quantize at this boundary — identical to host-fed field writes. */
	template <typename RowType>
	FORCEINLINE int32 SpawnFrom(const TArray<RowType>& Rows, int32 Type)
	{
		return lila_overlay_spawn_from((uint32)Type,
		                               (const uint8_t*)Rows.GetData(),
		                               (uint32)Rows.Num());
	}

	/** Rows written by the last flush (diagnostics). */
	FORCEINLINE int32 Written(int32 Type) { return lila_overlay_written((uint32)Type); }
}
