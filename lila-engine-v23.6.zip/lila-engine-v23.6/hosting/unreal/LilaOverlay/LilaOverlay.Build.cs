// LilaOverlay.Build.cs — v23 pointer-overlay module (Unreal skeleton).
//
// Links the SAME static liblila_c.a the c_host verify gate proves (300/300
// movie hash chain, byte-identical audio, overlay ABI) — plus the generated
// LilaInterop.h from `lilac build game.lila --emit-bridges Source/Lila`.

using UnrealBuildTool;

public class LilaOverlay : ModuleRules
{
	public LilaOverlay(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			// "Lila" — the v17.1 base module (lila.h + the .a link) if you
			// also use ALilaVM / the graphics components; the overlay
			// component only needs lila.h + liblila_c, which this module
			// links itself when you drop the .a next to it:
		});

		PrivateDependencyModuleNames.AddRange(new string[] { "CoreUObject", "Engine" });

		// The static engine library (built once, ~770KB):
		//   zig build-lib src/lila_c.zig -O ReleaseFast -lc -fPIC -femit-bin=liblila_c.a
		// and the generated interop header:
		//   lilac build game.lila --emit-bridges Source/LilaOverlay
		// PublicIncludePaths + the link line go here once the .a is placed
		// in this module's folder (mirror Lila.Build.cs's pattern).
	}
}
