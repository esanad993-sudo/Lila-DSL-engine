// ============================================================================
// Lila.Build.cs — Unreal runtime module wrapping liblila_c.
// ============================================================================
// Skeleton status: the ABI it links is fully verified (hosting/examples/
// c_host); the module glue is idiomatic UE5 but was not compiled here.
//
// Layout in your project:
//   Source/ThirdParty/LILA/
//     include/lila.h                 (from hosting/include)
//     lib/x64/Release/lila_c.lib      (zig build-lib ... -dynamic -lc
//                                     -target x86_64-windows-gnu)
//     lib/x64/Release/lila_c.dll     (ship beside your .exe / in
//                                     Binaries/Win64)
//   Source/Runtime/LILA/             (this module)
//
// The engine core is the same one the native runner uses: bit-identical
// hash chains (verify.sh proves it through the C ABI this module links).
// ============================================================================

using UnrealBuildTool;

public class Lila : ModuleRules
{
    public Lila(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[] { "Core" });
        PrivateDependencyModuleNames.AddRange(new string[] { "CoreUObject", "Engine", "InputCore" });

        // ---- link the LILA console ----
        string ThirdParty = ModuleDirectory + "/../../ThirdParty/LILA";
        PublicIncludePaths.Add(ThirdParty + "/include");

        if (Target.Platform == UnrealTargetPlatform.Win64)
        {
            PublicAdditionalLibraries.Add(ThirdParty + "/lib/x64/Release/lila_c.lib");
            RuntimeDependencies.Add(ThirdParty + "/lib/x64/Release/lila_c.dll");
        }
        else if (Target.Platform == UnrealTargetPlatform.Linux)
        {
            PublicAdditionalLibraries.Add(ThirdParty + "/lib/Linux/x64/Release/liblila_c.a");
        }
        // Android (aarch64-linux) and iOS (aarch64-macos) follow the same
        // shape once you build the lib for those targets.
    }
}
