# LILA in Unity

**The deal:** LILA is the simulation (deterministic, integer-only, replayable,
rollback-able). Unity is the presentation (URP/HDRP renderer, asset pipeline,
audio mixer, platform ports, editor tooling). They talk through a C ABI that
is verified bit-identical to the native runner — see
`hosting/examples/c_host/verify.sh` (300/300 hash chain, byte-identical WAV).

## Files

| File | Status | What it is |
|------|--------|------------|
| `LilaBridge.cs`   | 1:1 mirror of the verified `lila.h` | P/Invoke bindings |
| `LilaClient.cs`   | skeleton (not compiled here — no Unity in the engine repo) | fixed-tick loop, input, F5/F9 snapshots, audio ring, SRAM |
| `LilaEntityView.cs` | skeleton | path B: entity tables -> prefabs |

## Setup

1. **Build the library** (from `runtime/` in the engine repo):
   ```
   zig build-lib src/lila_c.zig -dynamic -O ReleaseFast -lc -target x86_64-windows-gnu
   ```
   produces `lila_c.dll`. For Android: `-target aarch64-linux`... for
   Linux editor/players: `-target x86_64-linux` or native default. The
   `-lc` is REQUIRED (freestanding TLS segfaults in a CLR host — see
   INTEGRATION.md "The -lc lesson").
2. **Import**: `Assets/Plugins/x86_64/lila_c.dll` — in the plugin inspector
   enable for Editor + Standalone (Windows), CPU x86_64.
3. **Cartridge**: compile your game (`lilac build game.lila`) and include
   the `.libyte` as a binary `TextAsset` (set its importer to "binary").
4. Add `LilaClient` to a scene object, assign the cartridge, assign a
   silent looping `AudioClip` to the required `AudioSource` (so
   `OnAudioFilterRead` keeps firing).

## Determinism notes for Unity specifically

- **GC**: Unity's GC pauses delay WHEN a frame computes, never WHAT it
  computes. The accumulator in `LilaClient` (max 5 catch-up steps)
  converts hitches into slow-motion, not divergence. The state hash
  (`lila_state_hash`) stays on the movie's chain regardless.
- **Floats**: LILA is Q24.8 integers. Convert to `float` only when placing
  transforms/sprites (`LilaBridge.QToF`). Never `FToQ` back into simulation
  state except for sanctioned words (input, camera).
- **Physics**: do NOT run LILA entities through Unity physics — LILA's
  integration IS the physics. Unity colliders/triggers, if you want them,
  should be read-only mirrors driven from the entity tables.
- **Fixed timestep**: `Time.fixedDeltaTime` is NOT used — keep the
  accumulator pattern so render fps can vary freely.

## Try the party trick

Run your game in the native runner, record a movie
(`runner game.libyte --frames 300 --record movie.lir`), then in Unity
replay the same inputs and compare `lila_state_hash` per frame — the
hashes match the native timeline bit-for-bit. That's the whole claim,
proven daily by CI in the engine repo (`verify.sh`).
