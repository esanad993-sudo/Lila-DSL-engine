// ============================================================================
// LilaEntityView.cs — path B rendering: LILA tables -> your prefabs.
// ============================================================================
//
// SKELETON STATUS: calls the verified ABI; Unity-side shape is idiomatic
// but was not compiled in the engine repo.
//
// The pattern (mirrors what the runner prints as telemetry):
//   1. once: map the typed-field registry -> your component's field ids
//   2. per frame: for each entity type, walk live slots, read fields,
//      place instances
// The handles are stable across respawns (gen<<20|idx) — use them as
// dictionary keys so your instances persist while the slot stays live.
// ============================================================================

using System.Collections.Generic;
using UnityEngine;
using Lila;

public class LilaEntityView : MonoBehaviour
{
    public GameObject[] prefabByType;   // index = LILA entity type
    public float pixelsPerUnit = 100f;  // LILA is screen-space pixels

    // type -> (prefab field tf -> per-slot instance)
    readonly Dictionary<uint, Dictionary<uint, GameObject>> _live = new();
    // Reused every SyncFromEngine — a fresh HashSet per type per frame was
    // pure GC churn (Unity: 0-alloc in the steady-state frame is the point).
    readonly HashSet<uint> _seen = new();
    readonly List<uint> _dead = new();      // keys collected, removed after
    int _xTf = -1, _yTf = -1;           // position typed fields (found once)

    void Start()
    {
        // find the first fixed 'x'/'y'-shaped fields of type 0 as a demo —
        // in production, bake the mapping from the schema (SPEC.md) or add
        // name metadata to the registry in a v17.2 (see INTEGRATION.md
        // "Known gaps").
        //
        // KNOWN LIMITATION (kept as-is): this is a HEURISTIC, not schema
        // knowledge. It assumes the first two fixed fields of TYPE 0 are x
        // and y by declaration order — a schema whose hot window leads with
        // something else (hp, ttl, ...) maps the wrong fields, and types > 0
        // reuse type 0's guess. The v23 answer is the reflection registry
        // (LilaBridge.ReadFieldQ) or the generated LilaInterop.cs overlay
        // rows; this walk stays for the bare, reflection-less case.
        int n = LilaBridge.lila_tf_count();
        for (int tf = 0; tf < n && (_xTf < 0 || _yTf < 0); tf++)
        {
            if (LilaBridge.lila_tf_ent((uint)tf) != 0) continue;
            // first two fixed fields of type 0 = x, y by declaration order
            if (_xTf < 0) _xTf = tf; else _yTf = tf;
        }
    }

    public void SyncFromEngine()
    {
        for (int t = 0; t < prefabByType.Length; t++)
        {
            if (prefabByType[t] == null) continue;
            var type = (uint)t;
            if (!_live.TryGetValue(type, out var slots))
                _live[type] = slots = new Dictionary<uint, GameObject>();

            // walk live slots (same walk the C host telemetry does)
            int idx = LilaBridge.lila_next_live(type, 0);
            _seen.Clear();
            while (idx >= 0)
            {
                uint handle = LilaBridge.lila_make_handle((uint)LilaBridge.lila_gen(type, (uint)idx), (uint)idx);
                _seen.Add(handle);
                if (!slots.TryGetValue(handle, out var go))
                    slots[handle] = go = Instantiate(prefabByType[t], transform);

                if (_xTf >= 0 && _yTf >= 0)
                {
                    // Q24.8 -> float ONLY here, at the render boundary
                    float x = LilaBridge.QToF(LilaBridge.lila_field_read((uint)_xTf, handle));
                    float y = LilaBridge.QToF(LilaBridge.lila_field_read((uint)_yTf, handle));
                    int w = LilaBridge.lila_screen_w(), h = LilaBridge.lila_screen_h();
                    go.transform.localPosition = new Vector3(
                        (x - w * 0.5f) / pixelsPerUnit,
                        (y - h * 0.5f) / pixelsPerUnit, 0f);
                }
                idx = LilaBridge.lila_next_live(type, (uint)idx + 1);
            }

            // despawn ALL dead slots this frame (generations bump on kill,
            // so stale handles are unambiguous). Collect first, then remove:
            // a Dictionary cannot be mutated inside its own foreach, and the
            // old `break` only ever despawned ONE dead entity per frame.
            _dead.Clear();
            foreach (var kv in slots)
                if (!_seen.Contains(kv.Key)) _dead.Add(kv.Key);
            for (int d = 0; d < _dead.Count; d++)
            {
                Destroy(slots[_dead[d]]);
                slots.Remove(_dead[d]);
            }
        }
    }
}

// Usage: call SyncFromEngine() from LilaClient right after lila_frame()
// (it is driven by the same fixed tick). Extend with sprite/anim fields
// from the registry as needed — the reads are the same lila_field_read.
